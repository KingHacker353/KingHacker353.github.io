# 🔍 Phase 1: Advanced Reconnaissance & Asset Discovery

## 🎯 Multi-Source Subdomain Enumeration (8+ Elite Techniques)

### 🚀 Advanced Subdomain Discovery Arsenal

#### 1. Passive Reconnaissance Tools
```bash
# Install all subdomain enumeration tools
sudo apt update && sudo apt install -y amass subfinder assetfinder findomain

# Go-based tools installation
go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest
go install -v github.com/owasp-amass/amass/v3/...@master
go install -v github.com/tomnomnom/assetfinder@latest
go install -v github.com/projectdiscovery/chaos-client/cmd/chaos@latest
go install -v github.com/haccer/subjack@latest
go install -v github.com/lc/subjs@latest
```

#### 2. Elite Subdomain Enumeration Script
```bash
cat > elite_subdomain_enum.sh << 'EOF'
#!/bin/bash
"""
Elite Multi-Source Subdomain Enumeration
8+ Advanced Techniques for Maximum Coverage
"""

TARGET=$1
if [ -z "$TARGET" ]; then
    echo "Usage: ./elite_subdomain_enum.sh <target.com>"
    exit 1
fi

echo "🔥 Elite Subdomain Enumeration for $TARGET"
echo "=========================================="

# Create target directory
mkdir -p $TARGET/subdomains
cd $TARGET/subdomains

# Technique 1: Subfinder (Multiple Sources)
echo "[1/8] Subfinder - Passive DNS enumeration..."
subfinder -d $TARGET -all -silent -o subfinder.txt
echo "    Found: $(wc -l < subfinder.txt) subdomains"

# Technique 2: Amass (OSINT + Active)
echo "[2/8] Amass - Comprehensive OSINT..."
amass enum -passive -d $TARGET -config ~/.config/amass/config.ini -o amass_passive.txt
amass enum -active -d $TARGET -brute -w ~/wordlists/subdomains.txt -o amass_active.txt
cat amass_passive.txt amass_active.txt | sort -u > amass.txt
echo "    Found: $(wc -l < amass.txt) subdomains"

# Technique 3: Assetfinder
echo "[3/8] Assetfinder - Facebook/Spyse sources..."
assetfinder --subs-only $TARGET > assetfinder.txt
echo "    Found: $(wc -l < assetfinder.txt) subdomains"

# Technique 4: Certificate Transparency Logs
echo "[4/8] Certificate Transparency - Multiple CT logs..."
# crt.sh
curl -s "https://crt.sh/?q=%25.$TARGET&output=json" | jq -r '.[].name_value' | sed 's/\*\.//g' | sort -u > crt_sh.txt

# Censys
curl -s "https://search.censys.io/api/v2/certificates/search?q=names:$TARGET" \
     -H "Authorization: Basic $(echo -n 'API_ID:API_SECRET' | base64)" | \
     jq -r '.result.hits[].names[]' | grep "$TARGET" | sort -u > censys.txt

# Combine CT sources
cat crt_sh.txt censys.txt | sort -u > certificate_transparency.txt
echo "    Found: $(wc -l < certificate_transparency.txt) subdomains"

# Technique 5: DNS Bruteforcing with Custom Wordlists
echo "[5/8] DNS Bruteforcing - Custom wordlists..."
# Create comprehensive subdomain wordlist
cat > custom_subdomains.txt << 'SUBEOF'
www
mail
ftp
admin
test
dev
staging
api
app
blog
shop
store
portal
dashboard
panel
cpanel
webmail
secure
vpn
remote
support
help
docs
wiki
forum
community
mobile
m
wap
cdn
static
assets
media
images
img
css
js
files
download
upload
backup
old
new
beta
alpha
demo
sandbox
lab
research
internal
intranet
extranet
partner
vendor
client
customer
user
member
guest
public
private
secret
hidden
temp
tmp
cache
proxy
gateway
firewall
router
switch
server
host
node
cluster
cloud
aws
azure
gcp
docker
k8s
kubernetes
jenkins
gitlab
github
bitbucket
jira
confluence
slack
teams
zoom
meet
calendar
drive
docs
sheets
slides
forms
survey
poll
vote
news
press
media
marketing
sales
crm
erp
hr
finance
accounting
legal
compliance
security
audit
monitor
log
analytics
stats
metrics
reports
dashboard
kpi
bi
data
db
database
sql
nosql
redis
mongo
elastic
search
solr
lucene
kafka
rabbit
queue
worker
job
task
cron
scheduler
timer
webhook
api
rest
soap
graphql
grpc
websocket
sse
push
notification
email
sms
voice
chat
message
comment
review
rating
feedback
contact
about
privacy
terms
policy
legal
disclaimer
sitemap
robots
humans
security
pgp
gpg
ssh
ssl
tls
cert
certificate
key
token
oauth
saml
ldap
ad
radius
kerberos
ntlm
cas
sso
mfa
2fa
totp
hotp
yubikey
SUBEOF

# Use multiple DNS bruteforcing tools
puredns bruteforce custom_subdomains.txt $TARGET --resolvers ~/resolvers.txt > dns_bruteforce.txt
echo "    Found: $(wc -l < dns_bruteforce.txt) subdomains"

# Technique 6: Google Dorking & Search Engine Enumeration
echo "[6/8] Search Engine Enumeration - Google/Bing/DuckDuckGo..."
# Google dorking for subdomains
python3 << 'PYEOF'
import requests
import re
import time
import random

def google_dork_subdomains(domain):
    subdomains = set()
    queries = [
        f'site:*.{domain}',
        f'site:{domain} -www',
        f'inurl:{domain}',
        f'intitle:"{domain}"'
    ]
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    }
    
    for query in queries:
        try:
            url = f'https://www.google.com/search?q={query}&num=100'
            response = requests.get(url, headers=headers)
            
            # Extract subdomains from results
            pattern = r'https?://([a-zA-Z0-9.-]+\.' + domain.replace('.', r'\.') + r')'
            matches = re.findall(pattern, response.text)
            subdomains.update(matches)
            
            time.sleep(random.uniform(2, 5))  # Rate limiting
        except:
            continue
    
    return list(subdomains)

domain = "$TARGET"
results = google_dork_subdomains(domain)
with open('search_engines.txt', 'w') as f:
    for subdomain in results:
        f.write(subdomain + '\n')
PYEOF

echo "    Found: $(wc -l < search_engines.txt) subdomains"

# Technique 7: GitHub & Code Repository Mining
echo "[7/8] GitHub Code Mining - API keys & mentions..."
# GitHub API search for subdomains
python3 << 'GHEOF'
import requests
import re
import base64

def github_subdomain_search(domain):
    subdomains = set()
    
    # GitHub API token (replace with your token)
    headers = {
        'Authorization': 'token YOUR_GITHUB_TOKEN',
        'Accept': 'application/vnd.github.v3+json'
    }
    
    # Search queries
    queries = [
        f'"{domain}" extension:txt',
        f'"{domain}" extension:json',
        f'"{domain}" extension:xml',
        f'"{domain}" extension:yml',
        f'"{domain}" extension:yaml',
        f'"{domain}" extension:conf',
        f'"{domain}" extension:config'
    ]
    
    for query in queries:
        try:
            url = f'https://api.github.com/search/code?q={query}'
            response = requests.get(url, headers=headers)
            
            if response.status_code == 200:
                data = response.json()
                for item in data.get('items', []):
                    # Get file content
                    content_url = item['url']
                    content_response = requests.get(content_url, headers=headers)
                    
                    if content_response.status_code == 200:
                        content_data = content_response.json()
                        content = base64.b64decode(content_data['content']).decode('utf-8', errors='ignore')
                        
                        # Extract subdomains
                        pattern = r'([a-zA-Z0-9.-]+\.' + domain.replace('.', r'\.') + r')'
                        matches = re.findall(pattern, content)
                        subdomains.update(matches)
        except:
            continue
    
    return list(subdomains)

domain = "$TARGET"
results = github_subdomain_search(domain)
with open('github_mining.txt', 'w') as f:
    for subdomain in results:
        f.write(subdomain + '\n')
GHEOF

echo "    Found: $(wc -l < github_mining.txt) subdomains"

# Technique 8: Wayback Machine & Archive Mining
echo "[8/8] Archive Mining - Wayback Machine & Common Crawl..."
# Wayback Machine URLs
curl -s "http://web.archive.org/cdx/search/cdx?url=*.$TARGET/*&output=json&fl=original&collapse=urlkey" | \
    jq -r '.[]' | grep -oE "https?://[^/]*\.$TARGET" | sed 's|https\?://||' | sort -u > wayback.txt

# Common Crawl
curl -s "http://index.commoncrawl.org/CC-MAIN-2023-40-index?url=*.$TARGET&output=json" | \
    jq -r '.url' | grep -oE "https?://[^/]*\.$TARGET" | sed 's|https\?://||' | sort -u > commoncrawl.txt

cat wayback.txt commoncrawl.txt | sort -u > archive_mining.txt
echo "    Found: $(wc -l < archive_mining.txt) subdomains"

# Combine all results
echo ""
echo "🔥 Combining all results..."
cat subfinder.txt amass.txt assetfinder.txt certificate_transparency.txt \
    dns_bruteforce.txt search_engines.txt github_mining.txt archive_mining.txt | \
    sort -u > all_subdomains_raw.txt

# Clean and validate subdomains
grep -E "^[a-zA-Z0-9.-]+\.$TARGET$" all_subdomains_raw.txt | \
    grep -v '\*' | sort -u > all_subdomains_clean.txt

echo "✅ Total unique subdomains found: $(wc -l < all_subdomains_clean.txt)"
echo "📁 Results saved in: $TARGET/subdomains/"
echo ""

# Generate summary report
cat > subdomain_summary.txt << 'SUMEOF'
=== Elite Subdomain Enumeration Summary ===
Target: $TARGET
Date: $(date)

Technique Results:
- Subfinder: $(wc -l < subfinder.txt) subdomains
- Amass: $(wc -l < amass.txt) subdomains  
- Assetfinder: $(wc -l < assetfinder.txt) subdomains
- Certificate Transparency: $(wc -l < certificate_transparency.txt) subdomains
- DNS Bruteforcing: $(wc -l < dns_bruteforce.txt) subdomains
- Search Engines: $(wc -l < search_engines.txt) subdomains
- GitHub Mining: $(wc -l < github_mining.txt) subdomains
- Archive Mining: $(wc -l < archive_mining.txt) subdomains

Total Unique: $(wc -l < all_subdomains_clean.txt) subdomains
SUMEOF

echo "📊 Summary report generated: subdomain_summary.txt"
EOF

chmod +x elite_subdomain_enum.sh
```

#### 3. Advanced Subdomain Wordlists
```bash
# Create comprehensive subdomain wordlists directory
mkdir -p ~/wordlists/subdomains

# Download and combine best subdomain wordlists
cd ~/wordlists/subdomains

# SecLists subdomains
wget https://raw.githubusercontent.com/danielmiessler/SecLists/master/Discovery/DNS/subdomains-top1million-110000.txt
wget https://raw.githubusercontent.com/danielmiessler/SecLists/master/Discovery/DNS/fierce-hostlist.txt
wget https://raw.githubusercontent.com/danielmiessler/SecLists/master/Discovery/DNS/namelist.txt

# Assetnote wordlists
wget https://wordlists-cdn.assetnote.io/data/manual/best-dns-wordlist.txt

# Custom elite wordlist
cat > elite_subdomains.txt << 'EOF'
# Elite Bug Bounty Subdomain Wordlist
# API & Development
api
api-v1
api-v2
api-v3
api-dev
api-test
api-staging
api-prod
api-internal
api-external
api-public
api-private
graphql
graphiql
rest
restapi
soap
grpc
webhook
websocket

# Development & Testing
dev
development
test
testing
stage
staging
prod
production
demo
sandbox
lab
playground
experimental
beta
alpha
rc
preview
canary

# Infrastructure & DevOps
jenkins
gitlab
github
bitbucket
ci
cd
pipeline
build
deploy
docker
k8s
kubernetes
rancher
portainer
traefik
nginx
apache
haproxy
loadbalancer
proxy
gateway
firewall

# Monitoring & Analytics
monitor
monitoring
metrics
analytics
stats
grafana
prometheus
kibana
elastic
elasticsearch
logstash
splunk
datadog
newrelic
sentry

# Databases
db
database
mysql
postgres
postgresql
mongo
mongodb
redis
memcached
cassandra
influxdb
clickhouse
neo4j
couchdb

# Cloud & CDN
aws
azure
gcp
cloud
cdn
cloudflare
fastly
akamai
cloudfront
s3
blob
storage

# Security
security
sec
auth
authentication
authorization
oauth
saml
sso
ldap
ad
radius
vpn
ssl
tls
cert
certificate

# Business Functions
admin
administrator
management
manager
dashboard
panel
control
console
portal
intranet
extranet
partner
vendor
client
customer
crm
erp
hr
finance
accounting
legal
compliance

# Communication
mail
email
smtp
imap
pop3
webmail
exchange
outlook
calendar
meet
zoom
teams
slack
chat
message
notification

# Content & Media
www
blog
news
press
media
cdn
static
assets
images
img
css
js
files
upload
download
backup
archive

# Mobile & Apps
mobile
m
app
apps
ios
android
api-mobile
mobile-api

# E-commerce
shop
store
cart
checkout
payment
pay
billing
invoice
order
product
catalog

# Support & Help
support
help
helpdesk
ticket
faq
docs
documentation
wiki
kb
knowledgebase
guide
tutorial

# Regional & Language
us
eu
asia
uk
ca
au
de
fr
es
it
jp
cn
in
br
mx

# Network & Infrastructure
ns1
ns2
ns3
ns4
dns
mx
mx1
mx2
smtp1
smtp2
pop
imap
ftp
sftp
ssh
telnet
snmp
ntp
dhcp
tftp

# Backup & Recovery
backup
bak
old
archive
dump
snapshot
mirror
replica
sync
rsync

# Temporary & Testing
temp
tmp
temporary
scratch
test1
test2
test3
dev1
dev2
dev3
staging1
staging2
staging3
EOF

# Combine all wordlists
cat subdomains-top1million-110000.txt fierce-hostlist.txt namelist.txt \
    best-dns-wordlist.txt elite_subdomains.txt | sort -u > combined_subdomains.txt

echo "✅ Comprehensive subdomain wordlist created: ~/wordlists/subdomains/combined_subdomains.txt"
```

#### 4. DNS Resolver Setup for Fast Enumeration
```bash
# Create fast DNS resolvers list
cat > ~/resolvers.txt << 'EOF'
# Fast Public DNS Resolvers
8.8.8.8
8.8.4.4
1.1.1.1
1.0.0.1
9.9.9.9
149.112.112.112
208.67.222.222
208.67.220.220
64.6.64.6
64.6.65.6
77.88.8.8
77.88.8.1
156.154.70.1
156.154.71.1
199.85.126.10
199.85.127.10
81.218.119.11
209.244.0.3
209.244.0.4
195.46.39.39
195.46.39.40
96.113.151.149
96.113.151.150
EOF

# Install puredns for fast DNS resolution
go install -v github.com/d3mondev/puredns/v2@latest

# Test resolver speed
echo "Testing DNS resolver speeds..."
puredns resolve ~/resolvers.txt --rate-limit 1000 --write-massdns ~/fast_resolvers.txt
```

#### 5. Subdomain Validation & Live Host Detection
```bash
cat > validate_subdomains.sh << 'EOF'
#!/bin/bash
"""
Subdomain Validation & Live Host Detection
Advanced filtering and verification
"""

SUBDOMAIN_FILE=$1
if [ -z "$SUBDOMAIN_FILE" ]; then
    echo "Usage: ./validate_subdomains.sh <subdomain_file>"
    exit 1
fi

echo "🔍 Validating subdomains from $SUBDOMAIN_FILE"

# DNS resolution validation
echo "[1/4] DNS Resolution Validation..."
puredns resolve $SUBDOMAIN_FILE --resolvers ~/fast_resolvers.txt --write resolved_subdomains.txt
echo "    Resolved: $(wc -l < resolved_subdomains.txt) subdomains"

# HTTP/HTTPS probe
echo "[2/4] HTTP/HTTPS Probing..."
cat resolved_subdomains.txt | httpx -silent -ports 80,443,8080,8443,8000,9000,3000,5000 \
    -status-code -title -tech-detect -follow-redirects -o live_hosts.txt
echo "    Live hosts: $(wc -l < live_hosts.txt) found"

# Extract just URLs for further processing
cat live_hosts.txt | awk '{print $1}' > live_urls.txt

# Screenshot capture for visual verification
echo "[3/4] Screenshot Capture..."
mkdir -p screenshots
cat live_urls.txt | head -20 | while read url; do
    filename=$(echo $url | sed 's/https\?:\/\///g' | tr '/' '_' | tr ':' '_')
    echo "Capturing: $url"
    wkhtmltoimage --width 1920 --height 1080 --javascript-delay 3000 \
        "$url" "screenshots/${filename}.png" 2>/dev/null
done

# Technology detection and fingerprinting
echo "[4/4] Technology Fingerprinting..."
cat live_urls.txt | httpx -silent -tech-detect -json -o tech_detection.json

# Generate validation report
cat > validation_report.txt << 'VALEOF'
=== Subdomain Validation Report ===
Date: $(date)
Input file: $SUBDOMAIN_FILE

Results:
- Total subdomains: $(wc -l < $SUBDOMAIN_FILE)
- DNS resolved: $(wc -l < resolved_subdomains.txt)
- Live hosts: $(wc -l < live_hosts.txt)
- Screenshots: $(ls screenshots/ | wc -l)

Files generated:
- resolved_subdomains.txt: DNS validated subdomains
- live_hosts.txt: HTTP/HTTPS accessible hosts
- live_urls.txt: Clean URLs for further testing
- tech_detection.json: Technology fingerprinting results
- screenshots/: Visual verification screenshots
VALEOF

echo "✅ Validation complete! Check validation_report.txt for summary"
EOF

chmod +x validate_subdomains.sh
```

#### 6. Subdomain Monitoring & Continuous Discovery
```bash
cat > subdomain_monitor.sh << 'EOF'
#!/bin/bash
"""
Continuous Subdomain Monitoring
Automated discovery of new subdomains
"""

TARGET=$1
INTERVAL=${2:-3600}  # Default 1 hour

if [ -z "$TARGET" ]; then
    echo "Usage: ./subdomain_monitor.sh <target.com> [interval_seconds]"
    exit 1
fi

echo "🔄 Starting continuous subdomain monitoring for $TARGET"
echo "Interval: $INTERVAL seconds"

# Create monitoring directory
mkdir -p monitoring/$TARGET
cd monitoring/$TARGET

# Initial baseline
if [ ! -f baseline_subdomains.txt ]; then
    echo "Creating baseline..."
    ../elite_subdomain_enum.sh $TARGET
    cp subdomains/all_subdomains_clean.txt baseline_subdomains.txt
    echo "Baseline created with $(wc -l < baseline_subdomains.txt) subdomains"
fi

# Monitoring loop
while true; do
    echo "[$(date)] Running subdomain discovery..."
    
    # Run discovery
    ../elite_subdomain_enum.sh $TARGET
    
    # Compare with baseline
    comm -13 baseline_subdomains.txt subdomains/all_subdomains_clean.txt > new_subdomains.txt
    
    if [ -s new_subdomains.txt ]; then
        echo "🚨 NEW SUBDOMAINS FOUND:"
        cat new_subdomains.txt
        
        # Send notification (customize as needed)
        echo "New subdomains found for $TARGET:" | mail -s "Subdomain Alert" your-email@domain.com
        
        # Update baseline
        cat baseline_subdomains.txt new_subdomains.txt | sort -u > updated_baseline.txt
        mv updated_baseline.txt baseline_subdomains.txt
        
        # Log discovery
        echo "[$(date)] Found $(wc -l < new_subdomains.txt) new subdomains" >> discovery.log
    else
        echo "No new subdomains found"
    fi
    
    echo "Sleeping for $INTERVAL seconds..."
    sleep $INTERVAL
done
EOF

chmod +x subdomain_monitor.sh
```

#### 7. Integration with Bug Bounty Platforms
```bash
cat > bounty_integration.py << 'EOF'
#!/usr/bin/env python3
"""
Bug Bounty Platform Integration
Automatic scope checking and subdomain validation
"""

import requests
import json
import sys
import re

class BountyIntegration:
    def __init__(self):
        self.hackerone_programs = {}
        self.bugcrowd_programs = {}
        
    def get_hackerone_scope(self, program):
        """Get HackerOne program scope"""
        try:
            url = f"https://hackerone.com/{program}.json"
            response = requests.get(url)
            if response.status_code == 200:
                data = response.json()
                scope = []
                for target in data.get('targets', []):
                    if target.get('eligible_for_bounty'):
                        scope.append(target.get('asset_identifier'))
                return scope
        except:
            pass
        return []
    
    def get_bugcrowd_scope(self, program):
        """Get Bugcrowd program scope"""
        try:
            url = f"https://bugcrowd.com/{program}"
            headers = {'Accept': 'application/json'}
            response = requests.get(url, headers=headers)
            # Parse scope from response (implementation depends on Bugcrowd API)
            return []
        except:
            pass
        return []
    
    def check_subdomain_in_scope(self, subdomain, scopes):
        """Check if subdomain is in scope"""
        for scope in scopes:
            if scope.startswith('*.'):
                # Wildcard scope
                domain = scope[2:]
                if subdomain.endswith('.' + domain) or subdomain == domain:
                    return True
            elif subdomain == scope:
                return True
        return False
    
    def filter_subdomains_by_scope(self, subdomains_file, program, platform='hackerone'):
        """Filter subdomains by bug bounty program scope"""
        if platform == 'hackerone':
            scope = self.get_hackerone_scope(program)
        elif platform == 'bugcrowd':
            scope = self.get_bugcrowd_scope(program)
        else:
            return []
        
        if not scope:
            print(f"Could not retrieve scope for {program}")
            return []
        
        print(f"Program scope: {scope}")
        
        in_scope_subdomains = []
        with open(subdomains_file, 'r') as f:
            for line in f:
                subdomain = line.strip()
                if self.check_subdomain_in_scope(subdomain, scope):
                    in_scope_subdomains.append(subdomain)
        
        return in_scope_subdomains

def main():
    if len(sys.argv) != 4:
        print("Usage: python3 bounty_integration.py <subdomains_file> <program> <platform>")
        print("Example: python3 bounty_integration.py subdomains.txt uber hackerone")
        sys.exit(1)
    
    subdomains_file = sys.argv[1]
    program = sys.argv[2]
    platform = sys.argv[3]
    
    integration = BountyIntegration()
    in_scope = integration.filter_subdomains_by_scope(subdomains_file, program, platform)
    
    if in_scope:
        print(f"\n✅ Found {len(in_scope)} in-scope subdomains:")
        for subdomain in in_scope:
            print(f"  - {subdomain}")
        
        # Save in-scope subdomains
        with open(f'{program}_in_scope_subdomains.txt', 'w') as f:
            for subdomain in in_scope:
                f.write(subdomain + '\n')
        
        print(f"\n📁 In-scope subdomains saved to: {program}_in_scope_subdomains.txt")
    else:
        print("No in-scope subdomains found")

if __name__ == "__main__":
    main()
EOF

chmod +x bounty_integration.py
```

### 🎯 Usage Examples

#### Basic Usage
```bash
# Run complete subdomain enumeration
./elite_subdomain_enum.sh target.com

# Validate discovered subdomains
./validate_subdomains.sh target.com/subdomains/all_subdomains_clean.txt

# Start continuous monitoring
./subdomain_monitor.sh target.com 3600

# Filter by bug bounty scope
python3 bounty_integration.py subdomains.txt uber hackerone
```

#### Advanced Techniques
```bash
# Custom wordlist generation for specific target
echo "target-specific-terms" >> ~/wordlists/subdomains/custom_target.txt

# Parallel enumeration for multiple targets
echo -e "target1.com\ntarget2.com\ntarget3.com" | xargs -I {} -P 3 ./elite_subdomain_enum.sh {}

# Integration with other tools
cat subdomains.txt | httpx -silent | nuclei -t ~/nuclei-templates/
```

### 🔥 Pro Tips for Elite Subdomain Discovery

1. **API Keys Configuration**: Set up API keys for maximum results
   ```bash
   # ~/.config/subfinder/config.yaml
   virustotal: ["your-api-key"]
   passivetotal: ["your-api-key"]
   securitytrails: ["your-api-key"]
   shodan: ["your-api-key"]
   ```

2. **Rate Limiting**: Respect rate limits to avoid getting blocked
3. **Continuous Monitoring**: Set up automated monitoring for new subdomains
4. **Scope Validation**: Always validate against bug bounty program scope
5. **Historical Data**: Use Wayback Machine and archive data for comprehensive coverage

### 📊 Expected Results

- **Passive Sources**: 500-2000 subdomains for medium targets
- **DNS Bruteforcing**: 100-500 additional subdomains
- **Certificate Transparency**: 200-800 subdomains
- **Archive Mining**: 50-200 historical subdomains
- **Total Coverage**: 1000-5000+ unique subdomains for large targets

This elite subdomain enumeration approach combines multiple techniques for maximum coverage and ensures no subdomain is missed in your reconnaissance phase!

## 🔐 Certificate Transparency & Advanced DNS Enumeration

### 🎯 Elite Certificate Transparency Mining

#### 1. Advanced CT Log Analysis Tool
```bash
cat > ct_analyzer.py << 'EOF'
#!/usr/bin/env python3
"""
Elite Certificate Transparency Analyzer
Advanced CT log mining with multiple sources and deep analysis
"""

import requests
import json
import sys
import re
import time
import base64
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed

class CTAnalyzer:
    def __init__(self):
        self.ct_logs = [
            'https://crt.sh/?q=%25.{}&output=json',
            'https://api.certspotter.com/v1/issuances?domain={}&include_subdomains=true&expand=dns_names',
            'https://censys.io/api/v1/search/certificates',
            'https://transparencyreport.google.com/https/certificates'
        ]
        
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
    
    def query_crt_sh(self, domain):
        """Query crt.sh certificate transparency logs"""
        subdomains = set()
        try:
            url = f'https://crt.sh/?q=%25.{domain}&output=json'
            response = requests.get(url, headers=self.headers, timeout=30)
            
            if response.status_code == 200:
                certificates = response.json()
                for cert in certificates:
                    name_value = cert.get('name_value', '')
                    # Split multiple domains and clean
                    for name in name_value.split('\n'):
                        name = name.strip()
                        if name and domain in name:
                            # Remove wildcards and clean
                            clean_name = name.replace('*.', '').strip()
                            if clean_name and not clean_name.startswith('.'):
                                subdomains.add(clean_name)
        except Exception as e:
            print(f"Error querying crt.sh: {e}")
        
        return list(subdomains)
    
    def query_certspotter(self, domain):
        """Query CertSpotter API"""
        subdomains = set()
        try:
            url = f'https://api.certspotter.com/v1/issuances?domain={domain}&include_subdomains=true&expand=dns_names'
            response = requests.get(url, headers=self.headers, timeout=30)
            
            if response.status_code == 200:
                certificates = response.json()
                for cert in certificates:
                    dns_names = cert.get('dns_names', [])
                    for name in dns_names:
                        if domain in name:
                            clean_name = name.replace('*.', '').strip()
                            if clean_name and not clean_name.startswith('.'):
                                subdomains.add(clean_name)
        except Exception as e:
            print(f"Error querying CertSpotter: {e}")
        
        return list(subdomains)
    
    def query_censys(self, domain, api_id=None, api_secret=None):
        """Query Censys certificates API"""
        subdomains = set()
        if not api_id or not api_secret:
            return list(subdomains)
        
        try:
            url = 'https://search.censys.io/api/v2/certificates/search'
            auth = (api_id, api_secret)
            params = {
                'q': f'names:{domain}',
                'per_page': 100
            }
            
            response = requests.get(url, auth=auth, params=params, timeout=30)
            
            if response.status_code == 200:
                data = response.json()
                for cert in data.get('result', {}).get('hits', []):
                    names = cert.get('names', [])
                    for name in names:
                        if domain in name:
                            clean_name = name.replace('*.', '').strip()
                            if clean_name and not clean_name.startswith('.'):
                                subdomains.add(clean_name)
        except Exception as e:
            print(f"Error querying Censys: {e}")
        
        return list(subdomains)
    
    def analyze_certificate_details(self, domain):
        """Analyze certificate details for additional intelligence"""
        cert_details = {}
        try:
            url = f'https://crt.sh/?q={domain}&output=json'
            response = requests.get(url, headers=self.headers, timeout=30)
            
            if response.status_code == 200:
                certificates = response.json()
                for cert in certificates[:10]:  # Analyze first 10 certs
                    cert_id = cert.get('id')
                    issuer = cert.get('issuer_name', '')
                    not_before = cert.get('not_before', '')
                    not_after = cert.get('not_after', '')
                    
                    cert_details[cert_id] = {
                        'issuer': issuer,
                        'not_before': not_before,
                        'not_after': not_after,
                        'domains': cert.get('name_value', '').split('\n')
                    }
        except Exception as e:
            print(f"Error analyzing certificate details: {e}")
        
        return cert_details
    
    def comprehensive_ct_search(self, domain, censys_api_id=None, censys_api_secret=None):
        """Comprehensive certificate transparency search"""
        print(f"🔍 Starting comprehensive CT analysis for {domain}")
        
        all_subdomains = set()
        
        # Query multiple CT sources
        print("[1/4] Querying crt.sh...")
        crt_sh_results = self.query_crt_sh(domain)
        all_subdomains.update(crt_sh_results)
        print(f"    Found: {len(crt_sh_results)} subdomains")
        
        print("[2/4] Querying CertSpotter...")
        certspotter_results = self.query_certspotter(domain)
        all_subdomains.update(certspotter_results)
        print(f"    Found: {len(certspotter_results)} subdomains")
        
        print("[3/4] Querying Censys...")
        censys_results = self.query_censys(domain, censys_api_id, censys_api_secret)
        all_subdomains.update(censys_results)
        print(f"    Found: {len(censys_results)} subdomains")
        
        print("[4/4] Analyzing certificate details...")
        cert_details = self.analyze_certificate_details(domain)
        print(f"    Analyzed: {len(cert_details)} certificates")
        
        return {
            'subdomains': list(all_subdomains),
            'certificate_details': cert_details,
            'sources': {
                'crt_sh': len(crt_sh_results),
                'certspotter': len(certspotter_results),
                'censys': len(censys_results)
            }
        }

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 ct_analyzer.py <domain> [censys_api_id] [censys_api_secret]")
        sys.exit(1)
    
    domain = sys.argv[1]
    censys_api_id = sys.argv[2] if len(sys.argv) > 2 else None
    censys_api_secret = sys.argv[3] if len(sys.argv) > 3 else None
    
    analyzer = CTAnalyzer()
    results = analyzer.comprehensive_ct_search(domain, censys_api_id, censys_api_secret)
    
    # Save results
    with open(f'{domain}_ct_subdomains.txt', 'w') as f:
        for subdomain in results['subdomains']:
            f.write(subdomain + '\n')
    
    with open(f'{domain}_ct_analysis.json', 'w') as f:
        json.dump(results, f, indent=2, default=str)
    
    print(f"\n✅ CT Analysis Complete!")
    print(f"Total subdomains found: {len(results['subdomains'])}")
    print(f"Results saved to: {domain}_ct_subdomains.txt")
    print(f"Detailed analysis: {domain}_ct_analysis.json")

if __name__ == "__main__":
    main()
EOF

chmod +x ct_analyzer.py
```

#### 2. Advanced DNS Enumeration Techniques
```bash
cat > dns_enum_advanced.sh << 'EOF'
#!/bin/bash
"""
Advanced DNS Enumeration Suite
Multiple DNS techniques for comprehensive discovery
"""

TARGET=$1
if [ -z "$TARGET" ]; then
    echo "Usage: ./dns_enum_advanced.sh <target.com>"
    exit 1
fi

echo "🔍 Advanced DNS Enumeration for $TARGET"
echo "======================================="

# Create DNS enumeration directory
mkdir -p dns_enum/$TARGET
cd dns_enum/$TARGET

# Technique 1: DNS Zone Transfer Attempts
echo "[1/8] DNS Zone Transfer Attempts..."
dig axfr $TARGET @$(dig ns $TARGET +short | head -1) > zone_transfer.txt 2>/dev/null
if [ -s zone_transfer.txt ]; then
    echo "    ✅ Zone transfer successful!"
    grep -E "^[a-zA-Z0-9.-]+\.$TARGET" zone_transfer.txt | awk '{print $1}' > zone_transfer_domains.txt
else
    echo "    ❌ Zone transfer failed (expected)"
fi

# Technique 2: DNS Record Enumeration
echo "[2/8] DNS Record Type Enumeration..."
record_types=("A" "AAAA" "CNAME" "MX" "NS" "TXT" "SOA" "PTR" "SRV")
for record in "${record_types[@]}"; do
    echo "  Checking $record records..."
    dig $record $TARGET +short >> dns_records_${record}.txt
    dig $record *.$TARGET +short >> dns_records_${record}_wildcard.txt 2>/dev/null
done

# Technique 3: Reverse DNS Enumeration
echo "[3/8] Reverse DNS Enumeration..."
# Get IP ranges for target
target_ips=$(dig A $TARGET +short)
for ip in $target_ips; do
    echo "  Reverse lookup for $ip"
    # Get network range
    network=$(echo $ip | cut -d. -f1-3)
    for i in {1..254}; do
        reverse_ip="$network.$i"
        result=$(dig -x $reverse_ip +short 2>/dev/null)
        if [[ $result == *"$TARGET"* ]]; then
            echo "$reverse_ip -> $result" >> reverse_dns.txt
        fi
    done &
done
wait

# Technique 4: DNS Cache Snooping
echo "[4/8] DNS Cache Snooping..."
common_subdomains=("www" "mail" "ftp" "admin" "test" "dev" "api" "app")
for subdomain in "${common_subdomains[@]}"; do
    # Try cache snooping on common DNS servers
    dig @8.8.8.8 $subdomain.$TARGET +norecurse >> cache_snoop.txt 2>/dev/null
    dig @1.1.1.1 $subdomain.$TARGET +norecurse >> cache_snoop.txt 2>/dev/null
done

# Technique 5: DNS Wildcard Detection
echo "[5/8] DNS Wildcard Detection..."
random_subdomain=$(openssl rand -hex 10)
wildcard_ip=$(dig A $random_subdomain.$TARGET +short)
if [ ! -z "$wildcard_ip" ]; then
    echo "    ⚠️  Wildcard DNS detected: $wildcard_ip"
    echo "$wildcard_ip" > wildcard_ip.txt
else
    echo "    ✅ No wildcard DNS detected"
fi

# Technique 6: DNS Bruteforcing with Custom Wordlists
echo "[6/8] DNS Bruteforcing..."
# Create comprehensive DNS wordlist
cat > dns_wordlist.txt << 'DNSEOF'
# Common subdomains
www
mail
ftp
admin
test
dev
staging
api
app
blog
shop
store
portal
dashboard
panel
cpanel
webmail
secure
vpn
remote
support
help
docs
wiki
forum
community
mobile
m
wap
cdn
static
assets
media
images
img
css
js
files
download
upload
backup
old
new
beta
alpha
demo
sandbox
lab
research
internal
intranet
extranet
partner
vendor
client
customer
user
member
guest
public
private
secret
hidden
temp
tmp
cache
proxy
gateway
firewall
router
switch
server
host
node
cluster
cloud
aws
azure
gcp
docker
k8s
kubernetes
jenkins
gitlab
github
bitbucket
jira
confluence
slack
teams
zoom
meet
calendar
drive
docs
sheets
slides
forms
survey
poll
vote
news
press
media
marketing
sales
crm
erp
hr
finance
accounting
legal
compliance
security
audit
monitor
log
analytics
stats
metrics
reports
dashboard
kpi
bi
data
db
database
sql
nosql
redis
mongo
elastic
search
solr
lucene
kafka
rabbit
queue
worker
job
task
cron
scheduler
timer
webhook
api
rest
soap
graphql
grpc
websocket
sse
push
notification
email
sms
voice
chat
message
comment
review
rating
feedback
contact
about
privacy
terms
policy
legal
disclaimer
sitemap
robots
humans
security
pgp
gpg
ssh
ssl
tls
cert
certificate
key
token
oauth
saml
ldap
ad
radius
kerberos
ntlm
cas
sso
mfa
2fa
totp
hotp
yubikey
DNSEOF

# Use multiple DNS bruteforcing tools
echo "  Using dnsrecon..."
dnsrecon -d $TARGET -D dns_wordlist.txt -t brt --xml dnsrecon_results.xml

echo "  Using fierce..."
fierce --domain $TARGET --wordlist dns_wordlist.txt > fierce_results.txt

echo "  Using dnsmap..."
dnsmap $TARGET -w dns_wordlist.txt -r dnsmap_results.txt

# Technique 7: DNS over HTTPS (DoH) Enumeration
echo "[7/8] DNS over HTTPS Enumeration..."
python3 << 'DOHEOF'
import requests
import json

def doh_query(domain, record_type="A"):
    """Query DNS over HTTPS"""
    doh_servers = [
        "https://cloudflare-dns.com/dns-query",
        "https://dns.google/dns-query",
        "https://dns.quad9.net/dns-query"
    ]
    
    results = []
    for server in doh_servers:
        try:
            params = {
                'name': domain,
                'type': record_type
            }
            headers = {
                'Accept': 'application/dns-json'
            }
            
            response = requests.get(server, params=params, headers=headers, timeout=10)
            if response.status_code == 200:
                data = response.json()
                if 'Answer' in data:
                    for answer in data['Answer']:
                        results.append(answer.get('data', ''))
        except:
            continue
    
    return results

domain = "$TARGET"
record_types = ['A', 'AAAA', 'CNAME', 'MX', 'TXT', 'NS']

with open('doh_results.txt', 'w') as f:
    for record_type in record_types:
        results = doh_query(domain, record_type)
        f.write(f"{record_type} records for {domain}:\n")
        for result in results:
            f.write(f"  {result}\n")
        f.write("\n")
DOHEOF

# Technique 8: DNS Tunneling Detection
echo "[8/8] DNS Tunneling Detection..."
# Look for suspicious DNS patterns
python3 << 'TUNNELEOF'
import subprocess
import re

def detect_dns_tunneling(domain):
    """Detect potential DNS tunneling"""
    suspicious_patterns = []
    
    # Check for long subdomain names (potential data exfiltration)
    try:
        result = subprocess.run(['dig', f'*.{domain}', '+short'], 
                              capture_output=True, text=True, timeout=10)
        
        for line in result.stdout.split('\n'):
            if line and len(line) > 50:  # Suspiciously long
                suspicious_patterns.append(f"Long subdomain: {line}")
    except:
        pass
    
    # Check for base64-like patterns in subdomains
    base64_pattern = re.compile(r'^[A-Za-z0-9+/=]{20,}')
    # This would require actual subdomain data to analyze
    
    return suspicious_patterns

domain = "$TARGET"
tunneling_indicators = detect_dns_tunneling(domain)

with open('dns_tunneling_check.txt', 'w') as f:
    f.write(f"DNS Tunneling Analysis for {domain}\n")
    f.write("=" * 40 + "\n")
    if tunneling_indicators:
        f.write("Suspicious patterns found:\n")
        for indicator in tunneling_indicators:
            f.write(f"  - {indicator}\n")
    else:
        f.write("No obvious DNS tunneling indicators found.\n")
TUNNELEOF

# Combine all DNS enumeration results
echo ""
echo "🔥 Combining DNS enumeration results..."
cat zone_transfer_domains.txt dns_records_*.txt fierce_results.txt dnsmap_results.txt | \
    grep -E "^[a-zA-Z0-9.-]+\.$TARGET$" | sort -u > all_dns_subdomains.txt

echo "✅ DNS enumeration complete!"
echo "📁 Results saved in: dns_enum/$TARGET/"
echo "📊 Total DNS subdomains found: $(wc -l < all_dns_subdomains.txt)"

# Generate DNS enumeration report
cat > dns_enum_report.txt << 'REPORTEOF'
=== Advanced DNS Enumeration Report ===
Target: $TARGET
Date: $(date)

Techniques Used:
1. DNS Zone Transfer Attempts
2. DNS Record Type Enumeration  
3. Reverse DNS Enumeration
4. DNS Cache Snooping
5. DNS Wildcard Detection
6. DNS Bruteforcing
7. DNS over HTTPS (DoH) Enumeration
8. DNS Tunneling Detection

Results:
- Zone Transfer: $([ -f zone_transfer_domains.txt ] && wc -l < zone_transfer_domains.txt || echo "0") domains
- DNS Records: $(find . -name "dns_records_*.txt" -exec cat {} \; | wc -l) records
- Reverse DNS: $([ -f reverse_dns.txt ] && wc -l < reverse_dns.txt || echo "0") entries
- DNS Bruteforce: $([ -f fierce_results.txt ] && grep -c "Found" fierce_results.txt || echo "0") subdomains
- Total Unique: $(wc -l < all_dns_subdomains.txt) subdomains

Files Generated:
- all_dns_subdomains.txt: All discovered subdomains
- dns_records_*.txt: DNS record type results
- fierce_results.txt: Fierce bruteforce results
- dnsmap_results.txt: Dnsmap results
- doh_results.txt: DNS over HTTPS results
- dns_tunneling_check.txt: Tunneling analysis
REPORTEOF

echo "📋 Report generated: dns_enum_report.txt"
EOF

chmod +x dns_enum_advanced.sh
```

#### 3. DNS Security Analysis Tool
```bash
cat > dns_security_analyzer.py << 'EOF'
#!/usr/bin/env python3
"""
DNS Security Analyzer
Advanced DNS security assessment and vulnerability detection
"""

import dns.resolver
import dns.zone
import dns.query
import dns.rdatatype
import socket
import sys
import json
from datetime import datetime

class DNSSecurityAnalyzer:
    def __init__(self):
        self.vulnerabilities = []
        self.security_issues = []
        
    def check_zone_transfer(self, domain):
        """Check for DNS zone transfer vulnerability"""
        print(f"[*] Checking zone transfer for {domain}")
        
        try:
            # Get name servers
            ns_records = dns.resolver.resolve(domain, 'NS')
            
            for ns in ns_records:
                ns_ip = str(ns).rstrip('.')
                try:
                    # Attempt zone transfer
                    zone = dns.zone.from_xfr(dns.query.xfr(ns_ip, domain))
                    if zone:
                        self.vulnerabilities.append({
                            'type': 'Zone Transfer',
                            'severity': 'High',
                            'nameserver': ns_ip,
                            'description': f'Zone transfer allowed on {ns_ip}',
                            'records_count': len(zone.nodes)
                        })
                        print(f"    ⚠️  Zone transfer successful on {ns_ip}")
                        return True
                except Exception as e:
                    print(f"    ✅ Zone transfer failed on {ns_ip} (expected)")
                    
        except Exception as e:
            print(f"    Error checking zone transfer: {e}")
        
        return False
    
    def check_dns_cache_poisoning(self, domain):
        """Check for DNS cache poisoning vulnerabilities"""
        print(f"[*] Checking DNS cache poisoning vectors for {domain}")
        
        try:
            # Check for predictable query IDs
            resolver = dns.resolver.Resolver()
            
            # Multiple queries to detect patterns
            query_ids = []
            for i in range(10):
                try:
                    answer = resolver.resolve(f"test{i}.{domain}", 'A')
                    # This would require lower-level DNS packet analysis
                    # Simplified check here
                except:
                    pass
            
            # Check for weak randomization (simplified)
            if len(set(query_ids)) < len(query_ids) * 0.8:
                self.vulnerabilities.append({
                    'type': 'DNS Cache Poisoning',
                    'severity': 'Medium',
                    'description': 'Potentially weak query ID randomization detected'
                })
                
        except Exception as e:
            print(f"    Error checking cache poisoning: {e}")
    
    def check_dnssec(self, domain):
        """Check DNSSEC implementation"""
        print(f"[*] Checking DNSSEC for {domain}")
        
        try:
            # Check for DNSKEY records
            dnskey_records = dns.resolver.resolve(domain, 'DNSKEY')
            if dnskey_records:
                print(f"    ✅ DNSSEC enabled - found {len(dnskey_records)} DNSKEY records")
                
                # Check DS records
                try:
                    ds_records = dns.resolver.resolve(domain, 'DS')
                    print(f"    ✅ DS records found: {len(ds_records)}")
                except:
                    self.security_issues.append({
                        'type': 'DNSSEC Configuration',
                        'severity': 'Low',
                        'description': 'DNSKEY present but no DS records found'
                    })
            else:
                self.security_issues.append({
                    'type': 'DNSSEC',
                    'severity': 'Medium',
                    'description': 'DNSSEC not implemented'
                })
                print(f"    ⚠️  DNSSEC not enabled")
                
        except dns.resolver.NXDOMAIN:
            self.security_issues.append({
                'type': 'DNSSEC',
                'severity': 'Medium',
                'description': 'DNSSEC not implemented'
            })
            print(f"    ⚠️  DNSSEC not enabled")
        except Exception as e:
            print(f"    Error checking DNSSEC: {e}")
    
    def check_dns_amplification(self, domain):
        """Check for DNS amplification attack potential"""
        print(f"[*] Checking DNS amplification potential for {domain}")
        
        try:
            # Get name servers
            ns_records = dns.resolver.resolve(domain, 'NS')
            
            for ns in ns_records:
                ns_ip = str(ns).rstrip('.')
                try:
                    # Check if server responds to ANY queries (amplification vector)
                    resolver = dns.resolver.Resolver()
                    resolver.nameservers = [socket.gethostbyname(ns_ip)]
                    
                    any_response = resolver.resolve(domain, 'ANY')
                    if any_response:
                        response_size = len(str(any_response))
                        if response_size > 512:  # Large response
                            self.vulnerabilities.append({
                                'type': 'DNS Amplification',
                                'severity': 'Medium',
                                'nameserver': ns_ip,
                                'description': f'Large ANY query response ({response_size} bytes) on {ns_ip}'
                            })
                            print(f"    ⚠️  Potential amplification vector on {ns_ip}")
                            
                except Exception as e:
                    print(f"    Error checking amplification on {ns_ip}: {e}")
                    
        except Exception as e:
            print(f"    Error checking DNS amplification: {e}")
    
    def check_subdomain_takeover_dns(self, domain):
        """Check for subdomain takeover via DNS"""
        print(f"[*] Checking subdomain takeover potential for {domain}")
        
        takeover_signatures = {
            'github.io': ['There isn\'t a GitHub Pages site here'],
            'herokuapp.com': ['No such app'],
            'amazonaws.com': ['NoSuchBucket'],
            'azurewebsites.net': ['404 Web Site not found'],
            'cloudfront.net': ['Bad Request: ERROR']
        }
        
        try:
            # Get CNAME records
            cname_records = dns.resolver.resolve(domain, 'CNAME')
            
            for cname in cname_records:
                cname_target = str(cname).rstrip('.')
                
                for service, signatures in takeover_signatures.items():
                    if service in cname_target:
                        # Check if target is accessible
                        try:
                            import requests
                            response = requests.get(f'http://{domain}', timeout=10)
                            
                            for signature in signatures:
                                if signature in response.text:
                                    self.vulnerabilities.append({
                                        'type': 'Subdomain Takeover',
                                        'severity': 'High',
                                        'service': service,
                                        'cname': cname_target,
                                        'description': f'Potential subdomain takeover via {service}'
                                    })
                                    print(f"    🚨 Potential takeover: {domain} -> {cname_target}")
                                    break
                        except:
                            pass
                            
        except dns.resolver.NXDOMAIN:
            pass
        except Exception as e:
            print(f"    Error checking subdomain takeover: {e}")
    
    def analyze_dns_security(self, domain):
        """Comprehensive DNS security analysis"""
        print(f"🔒 DNS Security Analysis for {domain}")
        print("=" * 50)
        
        # Run all security checks
        self.check_zone_transfer(domain)
        self.check_dns_cache_poisoning(domain)
        self.check_dnssec(domain)
        self.check_dns_amplification(domain)
        self.check_subdomain_takeover_dns(domain)
        
        # Generate security report
        report = {
            'domain': domain,
            'analysis_date': datetime.now().isoformat(),
            'vulnerabilities': self.vulnerabilities,
            'security_issues': self.security_issues,
            'summary': {
                'total_vulnerabilities': len(self.vulnerabilities),
                'high_severity': len([v for v in self.vulnerabilities if v['severity'] == 'High']),
                'medium_severity': len([v for v in self.vulnerabilities if v['severity'] == 'Medium']),
                'low_severity': len([v for v in self.vulnerabilities if v['severity'] == 'Low'])
            }
        }
        
        return report

def main():
    if len(sys.argv) != 2:
        print("Usage: python3 dns_security_analyzer.py <domain>")
        sys.exit(1)
    
    domain = sys.argv[1]
    analyzer = DNSSecurityAnalyzer()
    
    report = analyzer.analyze_dns_security(domain)
    
    # Save report
    with open(f'{domain}_dns_security_report.json', 'w') as f:
        json.dump(report, f, indent=2)
    
    # Print summary
    print(f"\n📊 DNS Security Analysis Summary")
    print(f"Total vulnerabilities: {report['summary']['total_vulnerabilities']}")
    print(f"High severity: {report['summary']['high_severity']}")
    print(f"Medium severity: {report['summary']['medium_severity']}")
    print(f"Low severity: {report['summary']['low_severity']}")
    
    if report['vulnerabilities']:
        print(f"\n🚨 Vulnerabilities Found:")
        for vuln in report['vulnerabilities']:
            print(f"  - {vuln['type']} ({vuln['severity']}): {vuln['description']}")
    
    print(f"\n📁 Detailed report saved: {domain}_dns_security_report.json")

if __name__ == "__main__":
    main()
EOF

chmod +x dns_security_analyzer.py
```

### 🎯 Usage Examples

#### Certificate Transparency Analysis
```bash
# Basic CT analysis
python3 ct_analyzer.py target.com

# With Censys API credentials
python3 ct_analyzer.py target.com YOUR_API_ID YOUR_API_SECRET

# Combine with other tools
python3 ct_analyzer.py target.com && cat target.com_ct_subdomains.txt >> all_subdomains.txt
```

#### Advanced DNS Enumeration
```bash
# Complete DNS enumeration
./dns_enum_advanced.sh target.com

# Combine DNS results with subdomain enumeration
./dns_enum_advanced.sh target.com
cat dns_enum/target.com/all_dns_subdomains.txt >> subdomains/all_subdomains_clean.txt
sort -u subdomains/all_subdomains_clean.txt -o subdomains/all_subdomains_final.txt
```

#### DNS Security Analysis
```bash
# Security assessment
python3 dns_security_analyzer.py target.com

# Batch analysis for multiple domains
cat domains.txt | xargs -I {} python3 dns_security_analyzer.py {}
```

### 🔥 Pro Tips for CT & DNS Enumeration

1. **API Rate Limits**: Respect API rate limits to avoid getting blocke
2. **Historical Data**: CT logs contain historical certificate data - great for finding old subdomains
3. **Wildcard Certificates**: Look for wildcard certificates that might reveal subdomain patterns
4. **DNS Security**: Always check for DNS security misconfigurations
5. **Continuous Monitoring**: Set up monitoring for new certificates issued for your targets

### 📊 Expected Results

- **Certificate Transparency**: 200-1000+ subdomains from CT logs
- **DNS Enumeration**: 100-500 additional subdomains via DNS techniques  
- **Security Issues**: 2-5 DNS security findings per target
- **Historical Coverage**: 6-12 months of certificate history
- **Combined Coverage**: 50-80% more subdomains than basic enumeration

This advanced CT and DNS enumeration provides comprehensive coverage of both current and historical subdomain data!

## 🔍 Advanced Port Scanning & Service Detection

### 🎯 Elite Port Scanning Arsenal

#### 1. Advanced Nmap Scanning Techniques
```bash
cat > elite_port_scanner.sh << 'EOF'
#!/bin/bash
"""
Elite Port Scanner
Advanced port scanning with service detection and evasion
"""

TARGET=$1
if [ -z "$TARGET" ]; then
    echo "Usage: ./elite_port_scanner.sh <target_or_file>"
    exit 1
fi

echo "🔍 Elite Port Scanning for $TARGET"
echo "=================================="

# Create scanning directory
mkdir -p port_scan/$(basename $TARGET)
cd port_scan/$(basename $TARGET)

# Technique 1: Fast Initial Discovery
echo "[1/8] Fast Port Discovery - Top 1000 ports..."
nmap -T4 -F --open -oN fast_scan.txt -oX fast_scan.xml $TARGET
echo "    Fast scan completed"

# Technique 2: Comprehensive TCP Scan
echo "[2/8] Comprehensive TCP Scan - All 65535 ports..."
nmap -p- -T4 -A --open -oN full_tcp_scan.txt -oX full_tcp_scan.xml $TARGET &
TCP_PID=$!

# Technique 3: UDP Scan (Top 1000)
echo "[3/8] UDP Port Scan - Top 1000 ports..."
sudo nmap -sU --top-ports 1000 -T4 --open -oN udp_scan.txt -oX udp_scan.xml $TARGET &
UDP_PID=$!

# Technique 4: Stealth SYN Scan with Service Detection
echo "[4/8] Stealth SYN Scan with Service Detection..."
sudo nmap -sS -sV -sC --version-intensity 9 --open -oN stealth_scan.txt -oX stealth_scan.xml $TARGET

# Technique 5: OS Detection and Fingerprinting
echo "[5/8] OS Detection and Fingerprinting..."
sudo nmap -O --osscan-guess --fuzzy -oN os_detection.txt -oX os_detection.xml $TARGET

# Technique 6: Script Scanning for Vulnerabilities
echo "[6/8] NSE Vulnerability Scripts..."
nmap --script vuln,safe,discovery --script-timeout 30s -oN vuln_scan.txt -oX vuln_scan.xml $TARGET

# Technique 7: Aggressive Service Enumeration
echo "[7/8] Aggressive Service Enumeration..."
nmap -sV --version-all -A --script=banner,http-title,http-headers,ssl-cert,ssh-hostkey \
     --open -oN aggressive_scan.txt -oX aggressive_scan.xml $TARGET

# Wait for background scans
echo "[8/8] Waiting for comprehensive scans to complete..."
wait $TCP_PID
wait $UDP_PID

# Combine and analyze results
echo ""
echo "🔥 Analyzing scan results..."

# Extract open ports
grep -E "^[0-9]+/(tcp|udp)" *.txt | grep open | sort -u > open_ports.txt
echo "Open ports found: $(wc -l < open_ports.txt)"

# Extract services
grep -E "^[0-9]+/(tcp|udp)" *.txt | grep -E "(http|https|ssh|ftp|smtp|dns|mysql|postgres)" > interesting_services.txt
echo "Interesting services: $(wc -l < interesting_services.txt)"

# Generate summary report
cat > port_scan_summary.txt << 'SUMMARY'
=== Elite Port Scan Summary ===
Target: $TARGET
Date: $(date)

Scan Types Performed:
1. Fast Discovery (Top 1000 ports)
2. Comprehensive TCP (All 65535 ports)
3. UDP Scan (Top 1000 ports)
4. Stealth SYN with Service Detection
5. OS Detection and Fingerprinting
6. NSE Vulnerability Scripts
7. Aggressive Service Enumeration

Results:
- Open Ports: $(wc -l < open_ports.txt)
- Interesting Services: $(wc -l < interesting_services.txt)
- Scan Files Generated: $(ls -1 *.txt *.xml | wc -l)

Key Findings:
$(head -10 interesting_services.txt)
SUMMARY

echo "✅ Port scanning complete!"
echo "📁 Results saved in: port_scan/$(basename $TARGET)/"
echo "📊 Summary: port_scan_summary.txt"
EOF

chmod +x elite_port_scanner.sh
```

#### 2. Masscan High-Speed Scanner
```bash
cat > masscan_elite.sh << 'EOF'
#!/bin/bash
"""
Elite Masscan Configuration
Ultra-fast port scanning for large networks
"""

TARGET=$1
RATE=${2:-10000}

if [ -z "$TARGET" ]; then
    echo "Usage: ./masscan_elite.sh <target_range> [rate]"
    echo "Example: ./masscan_elite.sh 192.168.1.0/24 50000"
    exit 1
fi

echo "⚡ Elite Masscan for $TARGET at $RATE pps"
echo "========================================"

# Create masscan directory
mkdir -p masscan_results
cd masscan_results

# Technique 1: Fast TCP Port Discovery
echo "[1/4] Fast TCP Port Discovery..."
sudo masscan $TARGET -p1-65535 --rate=$RATE --open --banners \
    --output-format json --output-filename tcp_masscan.json

# Technique 2: Common Ports with Banners
echo "[2/4] Common Ports with Banner Grabbing..."
sudo masscan $TARGET -p21,22,23,25,53,80,110,111,135,139,143,443,993,995,1723,3306,3389,5432,5900,6379 \
    --rate=$RATE --banners --output-format json --output-filename common_ports.json

# Technique 3: Web Ports Comprehensive
echo "[3/4] Web Ports Comprehensive Scan..."
sudo masscan $TARGET -p80,443,8000,8080,8443,8888,9000,9090,9443,3000,5000,7000,7001,7002 \
    --rate=$RATE --banners --output-format json --output-filename web_ports.json

# Technique 4: Database and Service Ports
echo "[4/4] Database and Service Ports..."
sudo masscan $TARGET -p1433,1521,3306,5432,6379,11211,27017,27018,27019,28017 \
    --rate=$RATE --banners --output-format json --output-filename db_ports.json

# Process results
echo ""
echo "🔥 Processing Masscan results..."

# Convert JSON to readable format
python3 << 'PYEOF'
import json
import sys

def process_masscan_json(filename):
    try:
        with open(filename, 'r') as f:
            results = []
            for line in f:
                if line.strip():
                    data = json.loads(line)
                    if 'ports' in data:
                        for port_info in data['ports']:
                            result = {
                                'ip': data['ip'],
                                'port': port_info['port'],
                                'protocol': port_info['proto'],
                                'status': port_info['status'],
                                'service': port_info.get('service', {}).get('name', 'unknown'),
                                'banner': port_info.get('service', {}).get('banner', '')
                            }
                            results.append(result)
            return results
    except Exception as e:
        print(f"Error processing {filename}: {e}")
        return []

# Process all JSON files
json_files = ['tcp_masscan.json', 'common_ports.json', 'web_ports.json', 'db_ports.json']
all_results = []

for json_file in json_files:
    results = process_masscan_json(json_file)
    all_results.extend(results)

# Save processed results
with open('masscan_processed.txt', 'w') as f:
    f.write("IP\t\tPort\tProto\tStatus\tService\tBanner\n")
    f.write("="*80 + "\n")
    for result in all_results:
        f.write(f"{result['ip']}\t{result['port']}\t{result['protocol']}\t{result['status']}\t{result['service']}\t{result['banner'][:50]}\n")

# Generate statistics
with open('masscan_stats.txt', 'w') as f:
    f.write(f"=== Masscan Statistics ===\n")
    f.write(f"Total open ports found: {len(all_results)}\n")
    f.write(f"Unique IPs: {len(set([r['ip'] for r in all_results]))}\n")
    f.write(f"Unique ports: {len(set([r['port'] for r in all_results]))}\n")
    f.write(f"Services detected: {len(set([r['service'] for r in all_results if r['service'] != 'unknown']))}\n")

print(f"Processed {len(all_results)} results")
PYEOF

echo "✅ Masscan complete!"
echo "📁 Results: masscan_processed.txt"
echo "📊 Statistics: masscan_stats.txt"
EOF

chmod +x masscan_elite.sh
```

#### 3. RustScan Ultra-Fast Scanner
```bash
# Install RustScan
wget https://github.com/RustScan/RustScan/releases/download/2.0.1/rustscan_2.0.1_amd64.deb
sudo dpkg -i rustscan_2.0.1_amd64.deb

cat > rustscan_elite.sh << 'EOF'
#!/bin/bash
"""
Elite RustScan Configuration
Ultra-fast port discovery with Nmap integration
"""

TARGET=$1
if [ -z "$TARGET" ]; then
    echo "Usage: ./rustscan_elite.sh <target>"
    exit 1
fi

echo "🦀 Elite RustScan for $TARGET"
echo "============================="

# Create rustscan directory
mkdir -p rustscan_results
cd rustscan_results

# Technique 1: Ultra-fast discovery
echo "[1/3] Ultra-fast Port Discovery..."
rustscan -a $TARGET --ulimit 5000 --timeout 1000 -g > rustscan_fast.txt

# Technique 2: RustScan with Nmap integration
echo "[2/3] RustScan + Nmap Service Detection..."
rustscan -a $TARGET --ulimit 5000 -- -sV -sC -A -oN rustscan_nmap.txt

# Technique 3: Custom port ranges
echo "[3/3] Custom Port Ranges..."
# Web ports
rustscan -a $TARGET -p 80,443,8000,8080,8443,8888,9000,3000,5000 --ulimit 5000 -- -sV -sC > web_ports.txt

# Database ports  
rustscan -a $TARGET -p 1433,1521,3306,5432,6379,11211,27017 --ulimit 5000 -- -sV -sC > db_ports.txt

# Service ports
rustscan -a $TARGET -p 21,22,23,25,53,110,143,993,995,1723,3389,5900 --ulimit 5000 -- -sV -sC > service_ports.txt

echo "✅ RustScan complete!"
echo "📁 Results saved in: rustscan_results/"
EOF

chmod +x rustscan_elite.sh
```

#### 4. Custom Service Detection Scripts
```bash
cat > service_detector.py << 'EOF'
#!/usr/bin/env python3
"""
Elite Service Detection Tool
Advanced service fingerprinting and banner grabbing
"""

import socket
import ssl
import threading
import sys
import json
import time
from concurrent.futures import ThreadPoolExecutor

class ServiceDetector:
    def __init__(self):
        self.common_ports = {
            21: 'ftp', 22: 'ssh', 23: 'telnet', 25: 'smtp', 53: 'dns',
            80: 'http', 110: 'pop3', 111: 'rpcbind', 135: 'msrpc', 139: 'netbios',
            143: 'imap', 443: 'https', 993: 'imaps', 995: 'pop3s', 1723: 'pptp',
            3306: 'mysql', 3389: 'rdp', 5432: 'postgresql', 5900: 'vnc', 6379: 'redis',
            8000: 'http-alt', 8080: 'http-proxy', 8443: 'https-alt', 9000: 'http-alt2'
        }
        
        self.service_probes = {
            'http': b'GET / HTTP/1.1\r\nHost: {}\r\nUser-Agent: Mozilla/5.0\r\n\r\n',
            'https': b'GET / HTTP/1.1\r\nHost: {}\r\nUser-Agent: Mozilla/5.0\r\n\r\n',
            'ftp': b'USER anonymous\r\n',
            'smtp': b'EHLO test.com\r\n',
            'ssh': b'SSH-2.0-Test\r\n',
            'mysql': b'\x00\x00\x00\x01',
            'redis': b'INFO\r\n'
        }
    
    def grab_banner(self, host, port, timeout=5):
        """Grab service banner"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(timeout)
            sock.connect((host, port))
            
            # Send appropriate probe
            service = self.common_ports.get(port, 'unknown')
            if service in self.service_probes:
                probe = self.service_probes[service]
                if b'{}' in probe:
                    probe = probe.replace(b'{}', host.encode())
                sock.send(probe)
            
            # Receive banner
            banner = sock.recv(1024).decode('utf-8', errors='ignore').strip()
            sock.close()
            
            return banner
            
        except Exception as e:
            return f"Error: {str(e)}"
    
    def detect_ssl_service(self, host, port, timeout=5):
        """Detect SSL/TLS services and get certificate info"""
        try:
            context = ssl.create_default_context()
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE
            
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(timeout)
            
            ssl_sock = context.wrap_socket(sock, server_hostname=host)
            ssl_sock.connect((host, port))
            
            # Get certificate info
            cert = ssl_sock.getpeercert()
            ssl_sock.close()
            
            return {
                'ssl': True,
                'subject': dict(x[0] for x in cert.get('subject', [])),
                'issuer': dict(x[0] for x in cert.get('issuer', [])),
                'version': cert.get('version'),
                'serial_number': cert.get('serialNumber'),
                'not_before': cert.get('notBefore'),
                'not_after': cert.get('notAfter')
            }
            
        except Exception as e:
            return {'ssl': False, 'error': str(e)}
    
    def detect_http_service(self, host, port, ssl=False):
        """Advanced HTTP service detection"""
        try:
            protocol = 'https' if ssl else 'http'
            
            import requests
            url = f"{protocol}://{host}:{port}"
            
            response = requests.get(url, timeout=10, verify=False, 
                                  headers={'User-Agent': 'Mozilla/5.0'})
            
            return {
                'status_code': response.status_code,
                'headers': dict(response.headers),
                'server': response.headers.get('Server', 'Unknown'),
                'title': self.extract_title(response.text),
                'technologies': self.detect_technologies(response)
            }
            
        except Exception as e:
            return {'error': str(e)}
    
    def extract_title(self, html):
        """Extract HTML title"""
        import re
        match = re.search(r'<title[^>]*>([^<]+)</title>', html, re.IGNORECASE)
        return match.group(1).strip() if match else 'No title'
    
    def detect_technologies(self, response):
        """Detect web technologies"""
        technologies = []
        
        # Check headers
        headers = response.headers
        if 'X-Powered-By' in headers:
            technologies.append(headers['X-Powered-By'])
        if 'Server' in headers:
            technologies.append(headers['Server'])
        
        # Check response content
        content = response.text.lower()
        tech_patterns = {
            'WordPress': ['wp-content', 'wp-includes'],
            'Drupal': ['drupal', '/sites/default/files'],
            'Joomla': ['joomla', '/media/system/js'],
            'Django': ['csrfmiddlewaretoken'],
            'Laravel': ['laravel_session'],
            'React': ['react', '__react'],
            'Angular': ['ng-', 'angular'],
            'Vue.js': ['vue.js', '__vue__']
        }
        
        for tech, patterns in tech_patterns.items():
            if any(pattern in content for pattern in patterns):
                technologies.append(tech)
        
        return technologies
    
    def comprehensive_scan(self, host, ports, threads=50):
        """Comprehensive service detection"""
        results = []
        
        def scan_port(port):
            result = {
                'host': host,
                'port': port,
                'service': self.common_ports.get(port, 'unknown'),
                'banner': '',
                'ssl_info': {},
                'http_info': {}
            }
            
            # Banner grabbing
            result['banner'] = self.grab_banner(host, port)
            
            # SSL detection for common SSL ports
            if port in [443, 993, 995, 8443] or 'ssl' in result['banner'].lower():
                result['ssl_info'] = self.detect_ssl_service(host, port)
            
            # HTTP detection
            if port in [80, 443, 8000, 8080, 8443, 9000] or 'http' in result['banner'].lower():
                ssl_enabled = port in [443, 8443] or result['ssl_info'].get('ssl', False)
                result['http_info'] = self.detect_http_service(host, port, ssl_enabled)
            
            return result
        
        # Multi-threaded scanning
        with ThreadPoolExecutor(max_workers=threads) as executor:
            futures = [executor.submit(scan_port, port) for port in ports]
            for future in futures:
                try:
                    result = future.result(timeout=30)
                    results.append(result)
                except Exception as e:
                    print(f"Error scanning port: {e}")
        
        return results

def main():
    if len(sys.argv) < 3:
        print("Usage: python3 service_detector.py <host> <ports>")
        print("Example: python3 service_detector.py 192.168.1.1 80,443,22,21")
        sys.exit(1)
    
    host = sys.argv[1]
    ports = [int(p.strip()) for p in sys.argv[2].split(',')]
    
    detector = ServiceDetector()
    print(f"🔍 Comprehensive Service Detection for {host}")
    print("=" * 50)
    
    results = detector.comprehensive_scan(host, ports)
    
    # Save results
    with open(f'{host}_service_detection.json', 'w') as f:
        json.dump(results, f, indent=2, default=str)
    
    # Print summary
    print(f"\n📊 Service Detection Summary")
    print(f"Host: {host}")
    print(f"Ports scanned: {len(ports)}")
    print(f"Services detected: {len([r for r in results if r['banner'] and 'Error' not in r['banner']])}")
    
    print(f"\n🔍 Detected Services:")
    for result in results:
        if result['banner'] and 'Error' not in result['banner']:
            print(f"  Port {result['port']}: {result['service']}")
            if result['http_info'] and 'server' in result['http_info']:
                print(f"    HTTP Server: {result['http_info']['server']}")
            if result['ssl_info'].get('ssl'):
                subject = result['ssl_info'].get('subject', {})
                print(f"    SSL Subject: {subject.get('commonName', 'Unknown')}")
    
    print(f"\n📁 Detailed results saved: {host}_service_detection.json")

if __name__ == "__main__":
    main()
EOF

chmod +x service_detector.py
```

#### 5. Network Service Enumeration
```bash
cat > network_enum.sh << 'EOF'
#!/bin/bash
"""
Network Service Enumeration
Comprehensive service-specific enumeration
"""

TARGET=$1
if [ -z "$TARGET" ]; then
    echo "Usage: ./network_enum.sh <target>"
    exit 1
fi

echo "🌐 Network Service Enumeration for $TARGET"
echo "=========================================="

# Create enumeration directory
mkdir -p network_enum/$TARGET
cd network_enum/$TARGET

# Get open ports first
echo "[*] Discovering open ports..."
nmap -T4 --top-ports 1000 --open $TARGET | grep "^[0-9]" | grep "open" > open_ports.txt

# Service-specific enumeration
echo ""
echo "🔍 Service-specific enumeration..."

# HTTP/HTTPS Enumeration
if grep -q "80\|443\|8080\|8000\|9000" open_ports.txt; then
    echo "[+] HTTP/HTTPS Services Found - Enumerating..."
    
    # Directory enumeration
    gobuster dir -u http://$TARGET -w ~/wordlists/custom/api_endpoints.txt -o http_dirs.txt 2>/dev/null &
    
    # Technology detection
    whatweb $TARGET > whatweb_results.txt
    
    # SSL certificate analysis
    if grep -q "443\|8443" open_ports.txt; then
        echo | openssl s_client -connect $TARGET:443 2>/dev/null | openssl x509 -text > ssl_cert.txt
    fi
fi

# SSH Enumeration
if grep -q "22" open_ports.txt; then
    echo "[+] SSH Service Found - Enumerating..."
    ssh-keyscan -t rsa,dsa,ecdsa,ed25519 $TARGET > ssh_keys.txt 2>/dev/null
    nmap --script ssh-hostkey,ssh-auth-methods $TARGET -p 22 > ssh_enum.txt
fi

# FTP Enumeration
if grep -q "21" open_ports.txt; then
    echo "[+] FTP Service Found - Enumerating..."
    nmap --script ftp-anon,ftp-bounce,ftp-libopie,ftp-proftpd-backdoor,ftp-vsftpd-backdoor $TARGET -p 21 > ftp_enum.txt
fi

# SMTP Enumeration
if grep -q "25\|587\|465" open_ports.txt; then
    echo "[+] SMTP Service Found - Enumerating..."
    nmap --script smtp-commands,smtp-enum-users,smtp-vuln-cve2010-4344,smtp-vuln-cve2011-1720,smtp-vuln-cve2011-1764 $TARGET -p 25,587,465 > smtp_enum.txt
fi

# DNS Enumeration
if grep -q "53" open_ports.txt; then
    echo "[+] DNS Service Found - Enumerating..."
    nmap --script dns-zone-transfer,dns-recursion,dns-cache-snoop,dns-nsec-enum $TARGET -p 53 > dns_enum.txt
    dig @$TARGET axfr > dns_zone_transfer.txt 2>/dev/null
fi

# Database Enumeration
if grep -q "3306\|5432\|1433\|1521" open_ports.txt; then
    echo "[+] Database Services Found - Enumerating..."
    
    # MySQL
    if grep -q "3306" open_ports.txt; then
        nmap --script mysql-info,mysql-audit,mysql-databases,mysql-dump-hashes,mysql-empty-password,mysql-enum,mysql-query,mysql-users,mysql-variables,mysql-vuln-cve2012-2122 $TARGET -p 3306 > mysql_enum.txt
    fi
    
    # PostgreSQL
    if grep -q "5432" open_ports.txt; then
        nmap --script pgsql-brute $TARGET -p 5432 > postgres_enum.txt
    fi
    
    # MSSQL
    if grep -q "1433" open_ports.txt; then
        nmap --script ms-sql-info,ms-sql-empty-password,ms-sql-xp-cmdshell,ms-sql-config,ms-sql-ntlm-info,ms-sql-tables,ms-sql-hasdbaccess,ms-sql-query $TARGET -p 1433 > mssql_enum.txt
    fi
fi

# SMB/NetBIOS Enumeration
if grep -q "139\|445" open_ports.txt; then
    echo "[+] SMB/NetBIOS Services Found - Enumerating..."
    nmap --script smb-os-discovery,smb-security-mode,smb-enum-shares,smb-enum-users,smb-vuln-* $TARGET -p 139,445 > smb_enum.txt
    enum4linux -a $TARGET > enum4linux_results.txt 2>/dev/null
fi

# SNMP Enumeration
if grep -q "161" open_ports.txt; then
    echo "[+] SNMP Service Found - Enumerating..."
    nmap --script snmp-sysdescr,snmp-processes,snmp-netstat,snmp-interfaces $TARGET -p 161 > snmp_enum.txt
    snmpwalk -c public -v1 $TARGET > snmpwalk_public.txt 2>/dev/null
    snmpwalk -c private -v1 $TARGET > snmpwalk_private.txt 2>/dev/null
fi

# RDP Enumeration
if grep -q "3389" open_ports.txt; then
    echo "[+] RDP Service Found - Enumerating..."
    nmap --script rdp-enum-encryption,rdp-vuln-ms12-020 $TARGET -p 3389 > rdp_enum.txt
fi

# Wait for background processes
wait

# Generate comprehensive report
echo ""
echo "📊 Generating enumeration report..."

cat > network_enum_report.txt << 'REPORT'
=== Network Service Enumeration Report ===
Target: $TARGET
Date: $(date)

Open Ports:
$(cat open_ports.txt)

Services Enumerated:
- HTTP/HTTPS: $([ -f http_dirs.txt ] && echo "Yes" || echo "No")
- SSH: $([ -f ssh_enum.txt ] && echo "Yes" || echo "No")
- FTP: $([ -f ftp_enum.txt ] && echo "Yes" || echo "No")
- SMTP: $([ -f smtp_enum.txt ] && echo "Yes" || echo "No")
- DNS: $([ -f dns_enum.txt ] && echo "Yes" || echo "No")
- Database: $([ -f mysql_enum.txt ] || [ -f postgres_enum.txt ] || [ -f mssql_enum.txt ] && echo "Yes" || echo "No")
- SMB/NetBIOS: $([ -f smb_enum.txt ] && echo "Yes" || echo "No")
- SNMP: $([ -f snmp_enum.txt ] && echo "Yes" || echo "No")
- RDP: $([ -f rdp_enum.txt ] && echo "Yes" || echo "No")

Files Generated:
$(ls -1 *.txt | wc -l) enumeration files created

Key Findings:
$(grep -h "VULNERABLE\|CRITICAL\|HIGH" *.txt 2>/dev/null | head -5)
REPORT

echo "✅ Network enumeration complete!"
echo "📁 Results saved in: network_enum/$TARGET/"
echo "📋 Report: network_enum_report.txt"
EOF

chmod +x network_enum.sh
```

### 🎯 Usage Examples

#### Basic Port Scanning
```bash
# Elite port scanner
./elite_port_scanner.sh target.com

# Masscan for large networks
./masscan_elite.sh 192.168.1.0/24 50000

# RustScan ultra-fast
./rustscan_elite.sh target.com
```

#### Advanced Service Detection
```bash
# Custom service detection
python3 service_detector.py target.com 80,443,22,21,25,53

# Network service enumeration
./network_enum.sh target.com

# Combine with subdomain results
cat subdomains/live_urls.txt | while read url; do
    host=$(echo $url | sed 's|https\?://||' | cut -d'/' -f1)
    ./elite_port_scanner.sh $host
done
```

#### Batch Scanning
```bash
# Scan multiple targets
cat targets.txt | xargs -I {} -P 5 ./elite_port_scanner.sh {}

# Scan discovered subdomains
cat subdomains/all_subdomains_clean.txt | head -50 | xargs -I {} -P 10 ./rustscan_elite.sh {}
```

### 🔥 Pro Tips for Elite Port Scanning

1. **Rate Limiting**: Adjust scan rates based on target network capacity
2. **Stealth Techniques**: Use decoy scans and source port manipulation
3. **Service Versions**: Always get service versions for vulnerability research
4. **Custom Scripts**: Use NSE scripts for specific service enumeration
5. **Timing**: Spread scans over time to avoid detection
6. **Documentation**: Keep detailed logs of all scanning activities

### 📊 Expected Results

- **Fast Discovery**: 10-50 open ports on typical targets
- **Comprehensive TCP**: 50-200+ ports on enterprise targets
- **Service Detection**: 80-90% service identification accuracy
- **Banner Information**: Detailed service versions and configurations
- **Vulnerability Indicators**: 5-15 potential security issues per target

This advanced port scanning approach provides comprehensive service discovery and detailed intelligence for further exploitation phases!

## 🔬 Technology Stack Fingerprinting & Version Detection

### 🎯 Elite Technology Detection Arsenal

#### 1. Advanced Web Technology Fingerprinting
```bash
cat > tech_fingerprinter.py << 'EOF'
#!/usr/bin/env python3
"""
Elite Technology Stack Fingerprinter
Advanced web technology detection and version identification
"""

import requests
import re
import json
import sys
import hashlib
from urllib.parse import urljoin, urlparse
from concurrent.futures import ThreadPoolExecutor
import builtwith
import whatweb

class TechFingerprinter:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        
        # Technology signatures
        self.tech_signatures = {
            'frameworks': {
                'Laravel': [r'laravel_session', r'XSRF-TOKEN', r'laravel_token'],
                'Django': [r'csrftoken', r'django', r'sessionid'],
                'Rails': [r'_session_id', r'authenticity_token', r'rails'],
                'Express': [r'express', r'connect.sid'],
                'Spring': [r'JSESSIONID', r'spring'],
                'ASP.NET': [r'ASP.NET_SessionId', r'__VIEWSTATE', r'__EVENTVALIDATION'],
                'PHP': [r'PHPSESSID', r'<?php', r'php'],
                'Node.js': [r'node', r'npm', r'express'],
                'React': [r'react', r'__REACT_DEVTOOLS', r'_reactInternalInstance'],
                'Angular': [r'ng-', r'angular', r'__ngContext'],
                'Vue.js': [r'vue', r'__vue__', r'v-'],
                'jQuery': [r'jquery', r'\$\(', r'jQuery']
            },
            'servers': {
                'Apache': [r'Apache/', r'Server: Apache'],
                'Nginx': [r'nginx/', r'Server: nginx'],
                'IIS': [r'Microsoft-IIS/', r'Server: Microsoft-IIS'],
                'Tomcat': [r'Apache-Coyote', r'Tomcat'],
                'Jetty': [r'Jetty', r'Server: Jetty'],
                'Cloudflare': [r'cloudflare', r'CF-RAY', r'__cfduid'],
                'AWS': [r'AmazonS3', r'CloudFront', r'X-Amz-'],
                'GCP': [r'Google Frontend', r'gws'],
                'Azure': [r'Microsoft-Azure', r'X-Azure-']
            },
            'databases': {
                'MySQL': [r'mysql', r'MySQL'],
                'PostgreSQL': [r'postgres', r'PostgreSQL'],
                'MongoDB': [r'mongodb', r'mongo'],
                'Redis': [r'redis', r'Redis'],
                'Oracle': [r'oracle', r'Oracle'],
                'MSSQL': [r'Microsoft SQL Server', r'MSSQL']
            },
            'cms': {
                'WordPress': [r'wp-content', r'wp-includes', r'wordpress'],
                'Drupal': [r'drupal', r'sites/default', r'misc/drupal.js'],
                'Joomla': [r'joomla', r'administrator/', r'components/'],
                'Magento': [r'magento', r'Mage.', r'skin/frontend'],
                'Shopify': [r'shopify', r'cdn.shopify.com', r'myshopify.com']
            }
        }
    
    def detect_headers(self, url):
        """Analyze HTTP headers for technology detection"""
        try:
            response = self.session.get(url, timeout=10, allow_redirects=True)
            headers = response.headers
            
            detected_tech = {
                'server': headers.get('Server', ''),
                'x_powered_by': headers.get('X-Powered-By', ''),
                'x_generator': headers.get('X-Generator', ''),
                'x_drupal_cache': headers.get('X-Drupal-Cache', ''),
                'x_frame_options': headers.get('X-Frame-Options', ''),
                'content_type': headers.get('Content-Type', ''),
                'set_cookie': headers.get('Set-Cookie', ''),
                'custom_headers': {}
            }
            
            # Check for custom headers
            for header, value in headers.items():
                if header.lower().startswith('x-') and header.lower() not in ['x-powered-by', 'x-generator', 'x-drupal-cache', 'x-frame-options']:
                    detected_tech['custom_headers'][header] = value
            
            return detected_tech, response.text
            
        except Exception as e:
            return {}, ""
    
    def detect_from_content(self, content):
        """Detect technologies from page content"""
        detected = []
        
        for category, technologies in self.tech_signatures.items():
            for tech, patterns in technologies.items():
                for pattern in patterns:
                    if re.search(pattern, content, re.IGNORECASE):
                        detected.append({
                            'technology': tech,
                            'category': category,
                            'pattern': pattern,
                            'confidence': 'high' if len(patterns) > 2 else 'medium'
                        })
                        break
        
        return detected
    
    def detect_javascript_frameworks(self, content):
        """Detect JavaScript frameworks and libraries"""
        js_frameworks = []
        
        # Common JS framework patterns
        js_patterns = {
            'React': [r'React\.createElement', r'ReactDOM\.render', r'__REACT_DEVTOOLS'],
            'Angular': [r'ng-app', r'angular\.module', r'@angular'],
            'Vue.js': [r'new Vue\(', r'Vue\.component', r'v-if'],
            'jQuery': [r'\$\(document\)\.ready', r'jQuery\(', r'\$\.'],
            'Bootstrap': [r'bootstrap\.min\.js', r'data-toggle', r'btn-'],
            'D3.js': [r'd3\.select', r'd3\.json', r'svg'],
            'Lodash': [r'_\.', r'lodash'],
            'Moment.js': [r'moment\(', r'moment\.js'],
            'Chart.js': [r'Chart\.js', r'new Chart\(']
        }
        
        for framework, patterns in js_patterns.items():
            for pattern in patterns:
                if re.search(pattern, content, re.IGNORECASE):
                    js_frameworks.append(framework)
                    break
        
        return js_frameworks
    
    def detect_cms_version(self, url, cms_type):
        """Detect CMS version"""
        version_info = {}
        
        if cms_type.lower() == 'wordpress':
            # WordPress version detection
            version_urls = [
                '/wp-includes/version.php',
                '/readme.html',
                '/wp-admin/css/install.css'
            ]
            
            for version_url in version_urls:
                try:
                    response = self.session.get(urljoin(url, version_url), timeout=5)
                    if response.status_code == 200:
                        # Extract version from content
                        version_match = re.search(f'Version (\d+\.\d+(?:\.\d+)?)', response.text)
                        if version_match:
                            version_info['wordpress_version'] = version_match.group(1)
                            break
                except:
                    continue
        
        elif cms_type.lower() == 'drupal':
            # Drupal version detection
            try:
                response = self.session.get(urljoin(url, '/CHANGELOG.txt'), timeout=5)
                if response.status_code == 200:
                    version_match = re.search(f'Drupal (\d+\.\d+(?:\.\d+)?)', response.text)
                    if version_match:
                        version_info['drupal_version'] = version_match.group(1)
            except:
                pass
        
        return version_info
    
    def detect_server_version(self, headers):
        """Extract detailed server version information"""
        server_info = {}
        
        server_header = headers.get('server', '')
        if server_header:
            # Apache version
            apache_match = re.search(r'Apache/(\d+\.\d+\.\d+)', server_header)
            if apache_match:
                server_info['apache_version'] = apache_match.group(1)
            
            # Nginx version
            nginx_match = re.search(r'nginx/(\d+\.\d+\.\d+)', server_header)
            if nginx_match:
                server_info['nginx_version'] = nginx_match.group(1)
            
            # IIS version
            iis_match = re.search(r'Microsoft-IIS/(\d+\.\d+)', server_header)
            if iis_match:
                server_info['iis_version'] = iis_match.group(1)
        
        return server_info
    
    def comprehensive_fingerprint(self, url):
        """Comprehensive technology fingerprinting"""
        print(f"🔍 Fingerprinting: {url}")
        
        # Get headers and content
        headers, content = self.detect_headers(url)
        
        # Detect technologies from content
        content_tech = self.detect_from_content(content)
        
        # Detect JavaScript frameworks
        js_frameworks = self.detect_javascript_frameworks(content)
        
        # Detect server versions
        server_versions = self.detect_server_version(headers)
        
        # Detect CMS versions
        cms_versions = {}
        for tech in content_tech:
            if tech['category'] == 'cms':
                cms_versions.update(self.detect_cms_version(url, tech['technology']))
        
        # Compile results
        results = {
            'url': url,
            'headers': headers,
            'detected_technologies': content_tech,
            'javascript_frameworks': js_frameworks,
            'server_versions': server_versions,
            'cms_versions': cms_versions,
            'security_headers': {
                'x_frame_options': headers.get('x_frame_options', 'Missing'),
                'x_content_type_options': headers.get('x_content_type_options', 'Missing'),
                'x_xss_protection': headers.get('x_xss_protection', 'Missing'),
                'strict_transport_security': headers.get('strict_transport_security', 'Missing'),
                'content_security_policy': headers.get('content_security_policy', 'Missing')
            }
        }
        
        return results

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 tech_fingerprinter.py <url_or_file>")
        sys.exit(1)
    
    target = sys.argv[1]
    fingerprinter = TechFingerprinter()
    
    if target.startswith('http'):
        # Single URL
        results = fingerprinter.comprehensive_fingerprint(target)
        
        # Save results
        with open('tech_fingerprint.json', 'w') as f:
            json.dump(results, f, indent=2)
        
        print(f"\n✅ Fingerprinting complete!")
        print(f"📁 Results saved to: tech_fingerprint.json")
        
    else:
        # File with URLs
        try:
            with open(target, 'r') as f:
                urls = [line.strip() for line in f if line.strip()]
            
            all_results = []
            for url in urls:
                if not url.startswith('http'):
                    url = 'http://' + url
                
                results = fingerprinter.comprehensive_fingerprint(url)
                all_results.append(results)
            
            # Save all results
            with open('tech_fingerprints_bulk.json', 'w') as f:
                json.dump(all_results, f, indent=2)
            
            print(f"\n✅ Bulk fingerprinting complete!")
            print(f"📁 Results saved to: tech_fingerprints_bulk.json")
            
        except FileNotFoundError:
            print(f"Error: File {target} not found")
            sys.exit(1)

if __name__ == "__main__":
    main()
EOF

chmod +x tech_fingerprinter.py
```

#### 2. Advanced Whatweb Integration
```bash
cat > whatweb_elite.sh << 'EOF'
#!/bin/bash
"""
Elite Whatweb Scanner
Advanced web technology detection with custom plugins
"""

TARGET=$1
if [ -z "$TARGET" ]; then
    echo "Usage: ./whatweb_elite.sh <url_or_file>"
    exit 1
fi

echo "🔍 Elite Whatweb Scanning for $TARGET"
echo "====================================="

# Create whatweb results directory
mkdir -p whatweb_results
cd whatweb_results

# Technique 1: Aggressive scan with all plugins
echo "[1/5] Aggressive Whatweb Scan..."
whatweb -a 3 --color=never --log-verbose=whatweb_aggressive.log $TARGET > whatweb_aggressive.txt

# Technique 2: Stealthy scan
echo "[2/5] Stealthy Whatweb Scan..."
whatweb -a 1 --color=never --log-verbose=whatweb_stealthy.log $TARGET > whatweb_stealthy.txt

# Technique 3: Custom plugins scan
echo "[3/5] Custom Plugins Scan..."
whatweb --list-plugins | grep -E "(CMS|Framework|Server|Database)" > available_plugins.txt
whatweb -a 3 --color=never --plugins=$(cat available_plugins.txt | cut -d' ' -f1 | tr '\n' ',' | sed 's/,$//') $TARGET > whatweb_custom.txt

# Technique 4: JSON output for parsing
echo "[4/5] JSON Output Generation..."
whatweb -a 3 --color=never --log-json=whatweb_results.json $TARGET

# Technique 5: Bulk scanning if file provided
if [ -f "$TARGET" ]; then
    echo "[5/5] Bulk Scanning from File..."
    whatweb -a 2 --color=never --input-file=$TARGET --log-verbose=whatweb_bulk.log > whatweb_bulk.txt
else
    echo "[5/5] Single URL - Skipping bulk scan"
fi

# Process and analyze results
echo ""
echo "🔥 Processing Whatweb results..."

# Extract key technologies
python3 << 'PYEOF'
import json
import re

def process_whatweb_json(filename):
    try:
        with open(filename, 'r') as f:
            results = []
            for line in f:
                if line.strip():
                    data = json.loads(line)
                    
                    tech_summary = {
                        'url': data.get('target', ''),
                        'status': data.get('http_status', ''),
                        'title': data.get('title', ''),
                        'technologies': []
                    }
                    
                    # Extract plugins (technologies)
                    for plugin_name, plugin_data in data.get('plugins', {}).items():
                        if isinstance(plugin_data, dict):
                            tech_info = {
                                'name': plugin_name,
                                'version': plugin_data.get('version', [''])[0] if plugin_data.get('version') else '',
                                'string': plugin_data.get('string', [''])[0] if plugin_data.get('string') else ''
                            }
                            tech_summary['technologies'].append(tech_info)
                    
                    results.append(tech_summary)
            
            return results
    except Exception as e:
        print(f"Error processing JSON: {e}")
        return []

# Process results
results = process_whatweb_json('whatweb_results.json')

# Generate summary
with open('whatweb_summary.txt', 'w') as f:
    f.write("=== Whatweb Technology Summary ===\n\n")
    
    for result in results:
        f.write(f"URL: {result['url']}\n")
        f.write(f"Status: {result['status']}\n")
        f.write(f"Title: {result['title']}\n")
        f.write("Technologies:\n")
        
        for tech in result['technologies']:
            version_info = f" v{tech['version']}" if tech['version'] else ""
            f.write(f"  - {tech['name']}{version_info}\n")
        
        f.write("\n" + "="*50 + "\n\n")

print("Whatweb results processed successfully!")
PYEOF

echo "✅ Whatweb scanning complete!"
echo "📁 Results saved in: whatweb_results/"
echo "📊 Summary: whatweb_summary.txt"
EOF

chmod +x whatweb_elite.sh
```

#### 3. Wappalyzer Integration
```bash
# Install Wappalyzer CLI
npm install -g wappalyzer

cat > wappalyzer_elite.sh << 'EOF'
#!/bin/bash
"""
Elite Wappalyzer Scanner
Advanced technology detection with Wappalyzer
"""

TARGET=$1
if [ -z "$TARGET" ]; then
    echo "Usage: ./wappalyzer_elite.sh <url_or_file>"
    exit 1
fi

echo "🔍 Elite Wappalyzer Scanning for $TARGET"
echo "========================================"

# Create wappalyzer results directory
mkdir -p wappalyzer_results
cd wappalyzer_results

if [ -f "$TARGET" ]; then
    # Bulk scanning from file
    echo "[1/2] Bulk Wappalyzer Scanning..."
    while IFS= read -r url; do
        if [[ $url == http* ]]; then
            echo "Scanning: $url"
            wappalyzer "$url" --pretty > "wappalyzer_$(echo $url | sed 's|https\?://||g' | tr '/' '_').json"
        fi
    done < "$TARGET"
    
    # Combine all results
    echo "[2/2] Combining results..."
    cat wappalyzer_*.json > wappalyzer_combined.json
else
    # Single URL scanning
    echo "[1/1] Single URL Wappalyzer Scanning..."
    wappalyzer "$TARGET" --pretty > wappalyzer_single.json
fi

# Process results
echo ""
echo "🔥 Processing Wappalyzer results..."

python3 << 'PYEOF'
import json
import glob
import os

def process_wappalyzer_results():
    results_summary = []
    
    # Find all JSON files
    json_files = glob.glob('wappalyzer_*.json')
    
    for json_file in json_files:
        try:
            with open(json_file, 'r') as f:
                data = json.load(f)
                
                if 'technologies' in data:
                    tech_summary = {
                        'url': data.get('url', ''),
                        'technologies': []
                    }
                    
                    for tech in data['technologies']:
                        tech_info = {
                            'name': tech.get('name', ''),
                            'version': tech.get('version', ''),
                            'confidence': tech.get('confidence', 0),
                            'categories': [cat.get('name', '') for cat in tech.get('categories', [])]
                        }
                        tech_summary['technologies'].append(tech_info)
                    
                    results_summary.append(tech_summary)
        
        except Exception as e:
            print(f"Error processing {json_file}: {e}")
    
    return results_summary

# Process and save results
results = process_wappalyzer_results()

# Generate detailed summary
with open('wappalyzer_summary.txt', 'w') as f:
    f.write("=== Wappalyzer Technology Summary ===\n\n")
    
    for result in results:
        f.write(f"URL: {result['url']}\n")
        f.write("Technologies Detected:\n")
        
        # Group by categories
        categories = {}
        for tech in result['technologies']:
            for category in tech['categories']:
                if category not in categories:
                    categories[category] = []
                categories[category].append(tech)
        
        for category, techs in categories.items():
            f.write(f"\n  {category}:\n")
            for tech in techs:
                version_info = f" v{tech['version']}" if tech['version'] else ""
                confidence = f" ({tech['confidence']}% confidence)" if tech['confidence'] else ""
                f.write(f"    - {tech['name']}{version_info}{confidence}\n")
        
        f.write("\n" + "="*60 + "\n\n")

# Generate JSON summary
with open('wappalyzer_processed.json', 'w') as f:
    json.dump(results, f, indent=2)

print("Wappalyzer results processed successfully!")
PYEOF

echo "✅ Wappalyzer scanning complete!"
echo "📁 Results saved in: wappalyzer_results/"
echo "📊 Summary: wappalyzer_summary.txt"
EOF

chmod +x wappalyzer_elite.sh
```

#### 4. Custom Technology Detection Scripts
```bash
cat > custom_tech_detector.py << 'EOF'
#!/usr/bin/env python3
"""
Custom Technology Detector
Advanced detection for specific technologies and versions
"""

import requests
import re
import json
import sys
import hashlib
from urllib.parse import urljoin
import ssl
import socket

class CustomTechDetector:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        
        # Custom detection patterns
        self.custom_patterns = {
            'php_version': [
                r'X-Powered-By: PHP/(\d+\.\d+\.\d+)',
                r'Set-Cookie: PHPSESSID=',
                r'<?php.*phpinfo\(\)'
            ],
            'apache_version': [
                r'Server: Apache/(\d+\.\d+\.\d+)',
                r'Apache/(\d+\.\d+\.\d+) \(.*\) Server'
            ],
            'nginx_version': [
                r'Server: nginx/(\d+\.\d+\.\d+)',
                r'nginx/(\d+\.\d+\.\d+)'
            ],
            'mysql_version': [
                r'mysql.*?(\d+\.\d+\.\d+)',
                r'MySQL.*?(\d+\.\d+\.\d+)'
            ],
            'wordpress_version': [
                r'wp-includes/js/wp-embed\.min\.js\?ver=(\d+\.\d+(?:\.\d+)?)',
                r'content="WordPress (\d+\.\d+(?:\.\d+)?)"'
            ],
            'jquery_version': [
                r'jquery[/-](\d+\.\d+\.\d+)',
                r'jQuery v(\d+\.\d+\.\d+)'
            ]
        }
    
    def detect_ssl_version(self, hostname, port=443):
        """Detect SSL/TLS version and cipher suites"""
        ssl_info = {}
        
        try:
            context = ssl.create_default_context()
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE
            
            with socket.create_connection((hostname, port), timeout=10) as sock:
                with context.wrap_socket(sock, server_hostname=hostname) as ssock:
                    ssl_info = {
                        'protocol': ssock.version(),
                        'cipher': ssock.cipher(),
                        'certificate': ssock.getpeercert()
                    }
        except Exception as e:
            ssl_info['error'] = str(e)
        
        return ssl_info
    
    def detect_cms_plugins(self, url, cms_type):
        """Detect CMS plugins and themes"""
        plugins = []
        
        if cms_type.lower() == 'wordpress':
            # WordPress plugin detection
            plugin_paths = [
                '/wp-content/plugins/',
                '/wp-includes/',
                '/wp-admin/'
            ]
            
            for path in plugin_paths:
                try:
                    response = self.session.get(urljoin(url, path), timeout=5)
                    if response.status_code == 200:
                        # Extract plugin names from directory listing
                        plugin_matches = re.findall(r'href="([^"]+)/"', response.text)
                        for match in plugin_matches:
                            if not match.startswith('..') and match not in ['css', 'js', 'images']:
                                plugins.append({
                                    'name': match,
                                    'type': 'plugin',
                                    'path': path + match
                                })
                except:
                    continue
        
        return plugins
    
    def detect_error_pages(self, url):
        """Detect technology from error pages"""
        error_info = {}
        
        # Common error paths
        error_paths = [
            '/nonexistent-page-404',
            '/admin/nonexistent',
            '/test/error'
        ]
        
        for path in error_paths:
            try:
                response = self.session.get(urljoin(url, path), timeout=5)
                if response.status_code in [404, 500, 403]:
                    # Analyze error page content
                    content = response.text.lower()
                    
                    if 'apache' in content:
                        error_info['server'] = 'Apache'
                    elif 'nginx' in content:
                        error_info['server'] = 'Nginx'
                    elif 'iis' in content:
                        error_info['server'] = 'IIS'
                    
                    # Extract version from error pages
                    version_match = re.search(r'(\d+\.\d+\.\d+)', content)
                    if version_match:
                        error_info['version'] = version_match.group(1)
                    
                    break
            except:
                continue
        
        return error_info
    
    def detect_admin_panels(self, url):
        """Detect admin panels and their technologies"""
        admin_panels = []
        
        # Common admin paths
        admin_paths = [
            '/admin', '/administrator', '/wp-admin', '/admin.php',
            '/login', '/dashboard', '/panel', '/control',
            '/manager', '/console', '/backend'
        ]
        
        for path in admin_paths:
            try:
                response = self.session.get(urljoin(url, path), timeout=5)
                if response.status_code == 200:
                    content = response.text.lower()
                    
                    # Detect admin panel type
                    if 'wordpress' in content or 'wp-login' in content:
                        admin_panels.append({'type': 'WordPress', 'path': path})
                    elif 'drupal' in content:
                        admin_panels.append({'type': 'Drupal', 'path': path})
                    elif 'joomla' in content:
                        admin_panels.append({'type': 'Joomla', 'path': path})
                    elif 'phpmyadmin' in content:
                        admin_panels.append({'type': 'phpMyAdmin', 'path': path})
                    elif 'cpanel' in content:
                        admin_panels.append({'type': 'cPanel', 'path': path})
                    else:
                        admin_panels.append({'type': 'Generic Admin', 'path': path})
            except:
                continue
        
        return admin_panels
    
    def comprehensive_detection(self, url):
        """Comprehensive custom technology detection"""
        print(f"🔍 Custom detection for: {url}")
        
        results = {
            'url': url,
            'custom_detections': {},
            'ssl_info': {},
            'cms_plugins': [],
            'error_page_info': {},
            'admin_panels': []
        }
        
        # Get main page
        try:
            response = self.session.get(url, timeout=10)
            content = response.text
            headers = dict(response.headers)
            
            # Custom pattern detection
            for tech, patterns in self.custom_patterns.items():
                for pattern in patterns:
                    # Check headers
                    for header_value in headers.values():
                        match = re.search(pattern, str(header_value))
                        if match:
                            results['custom_detections'][tech] = match.group(1) if match.groups() else True
                            break
                    
                    # Check content
                    if tech not in results['custom_detections']:
                        match = re.search(pattern, content, re.IGNORECASE)
                        if match:
                            results['custom_detections'][tech] = match.group(1) if match.groups() else True
            
            # SSL detection
            hostname = url.replace('https://', '').replace('http://', '').split('/')[0]
            if url.startswith('https://'):
                results['ssl_info'] = self.detect_ssl_version(hostname)
            
            # CMS plugin detection
            detected_cms = None
            for tech in results['custom_detections']:
                if 'wordpress' in tech.lower():
                    detected_cms = 'wordpress'
                    break
            
            if detected_cms:
                results['cms_plugins'] = self.detect_cms_plugins(url, detected_cms)
            
            # Error page detection
            results['error_page_info'] = self.detect_error_pages(url)
            
            # Admin panel detection
            results['admin_panels'] = self.detect_admin_panels(url)
            
        except Exception as e:
            results['error'] = str(e)
        
        return results

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 custom_tech_detector.py <url>")
        sys.exit(1)
    
    url = sys.argv[1]
    if not url.startswith('http'):
        url = 'http://' + url
    
    detector = CustomTechDetector()
    results = detector.comprehensive_detection(url)
    
    # Save results
    with open('custom_tech_detection.json', 'w') as f:
        json.dump(results, f, indent=2, default=str)
    
    # Print summary
    print(f"\n✅ Custom detection complete!")
    print(f"📁 Results saved to: custom_tech_detection.json")
    
    # Print key findings
    if results['custom_detections']:
        print(f"\n🔍 Key Technologies Detected:")
        for tech, version in results['custom_detections'].items():
            print(f"  - {tech}: {version}")
    
    if results['admin_panels']:
        print(f"\n🚪 Admin Panels Found:")
        for panel in results['admin_panels']:
            print(f"  - {panel['type']}: {panel['path']}")

if __name__ == "__main__":
    main()
EOF

chmod +x custom_tech_detector.py
```

#### 5. Comprehensive Technology Analysis Script
```bash
cat > comprehensive_tech_analysis.sh << 'EOF'
#!/bin/bash
"""
Comprehensive Technology Analysis
Combines multiple tools for complete technology stack detection
"""

TARGET=$1
if [ -z "$TARGET" ]; then
    echo "Usage: ./comprehensive_tech_analysis.sh <url_or_file>"
    exit 1
fi

echo "🔬 Comprehensive Technology Analysis for $TARGET"
echo "==============================================="

# Create comprehensive analysis directory
mkdir -p tech_analysis
cd tech_analysis

# Run all technology detection tools
echo "[1/6] Running Custom Tech Fingerprinter..."
python3 ../tech_fingerprinter.py $TARGET

echo "[2/6] Running Whatweb Elite Scanner..."
../whatweb_elite.sh $TARGET

echo "[3/6] Running Wappalyzer Elite Scanner..."
../wappalyzer_elite.sh $TARGET

echo "[4/6] Running Custom Tech Detector..."
if [[ $TARGET == http* ]]; then
    python3 ../custom_tech_detector.py $TARGET
else
    # Process file line by line
    while IFS= read -r url; do
        if [[ $url == http* ]]; then
            echo "Processing: $url"
            python3 ../custom_tech_detector.py $url
        fi
    done < "$TARGET"
fi

echo "[5/6] Running Nmap Service Detection..."
if [[ $TARGET == http* ]]; then
    # Extract hostname from URL
    hostname=$(echo $TARGET | sed 's|https\?://||g' | cut -d'/' -f1)
    nmap -sV -sC --script http-enum,http-headers,http-methods,http-title $hostname -oN nmap_service_detection.txt
else
    nmap -sV -sC --script http-enum,http-headers,http-methods,http-title -iL $TARGET -oN nmap_service_detection.txt
fi

echo "[6/6] Generating Comprehensive Report..."

# Combine all results into comprehensive report
python3 << 'PYEOF'
import json
import glob
import os
from datetime import datetime

def combine_all_results():
    comprehensive_report = {
        'analysis_date': datetime.now().isoformat(),
        'target': '$TARGET',
        'tools_used': [
            'Custom Tech Fingerprinter',
            'Whatweb',
            'Wappalyzer', 
            'Custom Tech Detector',
            'Nmap Service Detection'
        ],
        'results': {}
    }
    
    # Load tech fingerprinter results
    try:
        if os.path.exists('tech_fingerprint.json'):
            with open('tech_fingerprint.json', 'r') as f:
                comprehensive_report['results']['tech_fingerprinter'] = json.load(f)
        elif os.path.exists('tech_fingerprints_bulk.json'):
            with open('tech_fingerprints_bulk.json', 'r') as f:
                comprehensive_report['results']['tech_fingerprinter'] = json.load(f)
    except:
        pass
    
    # Load whatweb results
    try:
        if os.path.exists('whatweb_results/whatweb_results.json'):
            with open('whatweb_results/whatweb_results.json', 'r') as f:
                whatweb_data = []
                for line in f:
                    if line.strip():
                        whatweb_data.append(json.loads(line))
                comprehensive_report['results']['whatweb'] = whatweb_data
    except:
        pass
    
    # Load wappalyzer results
    try:
        if os.path.exists('wappalyzer_results/wappalyzer_processed.json'):
            with open('wappalyzer_results/wappalyzer_processed.json', 'r') as f:
                comprehensive_report['results']['wappalyzer'] = json.load(f)
    except:
        pass
    
    # Load custom detector results
    try:
        if os.path.exists('custom_tech_detection.json'):
            with open('custom_tech_detection.json', 'r') as f:
                comprehensive_report['results']['custom_detector'] = json.load(f)
    except:
        pass
    
    # Save comprehensive report
    with open('comprehensive_tech_report.json', 'w') as f:
        json.dump(comprehensive_report, f, indent=2, default=str)
    
    # Generate human-readable summary
    generate_summary_report(comprehensive_report)

def generate_summary_report(data):
    with open('technology_summary.txt', 'w') as f:
        f.write("="*60 + "\n")
        f.write("COMPREHENSIVE TECHNOLOGY ANALYSIS REPORT\n")
        f.write("="*60 + "\n\n")
        
        f.write(f"Target: {data['target']}\n")
        f.write(f"Analysis Date: {data['analysis_date']}\n")
        f.write(f"Tools Used: {', '.join(data['tools_used'])}\n\n")
        
        # Aggregate all detected technologies
        all_technologies = set()
        all_versions = {}
        
        for tool, results in data['results'].items():
            f.write(f"\n{tool.upper()} RESULTS:\n")
            f.write("-" * 30 + "\n")
            
            if tool == 'tech_fingerprinter':
                if isinstance(results, list):
                    for result in results:
                        f.write(f"URL: {result.get('url', 'N/A')}\n")
                        for tech in result.get('detected_technologies', []):
                            f.write(f"  - {tech['technology']} ({tech['category']})\n")
                            all_technologies.add(tech['technology'])
                else:
                    f.write(f"URL: {results.get('url', 'N/A')}\n")
                    for tech in results.get('detected_technologies', []):
                        f.write(f"  - {tech['technology']} ({tech['category']})\n")
                        all_technologies.add(tech['technology'])
            
            elif tool == 'wappalyzer':
                for result in results:
                    f.write(f"URL: {result.get('url', 'N/A')}\n")
                    for tech in result.get('technologies', []):
                        tech_name = tech.get('name', 'Unknown')
                        version = tech.get('version', '')
                        f.write(f"  - {tech_name}")
                        if version:
                            f.write(f" v{version}")
                            all_versions[tech_name] = version
                        f.write(f" ({tech.get('confidence', 0)}% confidence)\n")
                        all_technologies.add(tech_name)
            
            elif tool == 'custom_detector':
                f.write(f"URL: {results.get('url', 'N/A')}\n")
                for tech, version in results.get('custom_detections', {}).items():
                    f.write(f"  - {tech}: {version}\n")
                    all_technologies.add(tech)
                    if version != True:
                        all_versions[tech] = version
        
        # Technology summary
        f.write("\n" + "="*60 + "\n")
        f.write("TECHNOLOGY SUMMARY\n")
        f.write("="*60 + "\n")
        
        f.write(f"Total Technologies Detected: {len(all_technologies)}\n\n")
        
        for tech in sorted(all_technologies):
            version_info = f" v{all_versions[tech]}" if tech in all_versions else ""
            f.write(f"• {tech}{version_info}\n")

# Run the combination
combine_all_results()
print("Comprehensive analysis complete!")
PYEOF

echo ""
echo "✅ Comprehensive Technology Analysis Complete!"
echo "📁 Results saved in: tech_analysis/"
echo "📊 Main Report: comprehensive_tech_report.json"
echo "📋 Summary: technology_summary.txt"
EOF

chmod +x comprehensive_tech_analysis.sh
```

This comprehensive technology stack fingerprinting suite provides elite-level detection capabilities using multiple tools and custom techniques for maximum accuracy and coverage!

## ☁️ Cloud Asset Discovery (AWS, GCP, Azure)

### 🎯 Elite Cloud Reconnaissance Arsenal

#### 1. AWS S3 Bucket Discovery & Enumeration
```bash
cat > aws_s3_hunter.py << 'EOF'
#!/usr/bin/env python3
"""
Elite AWS S3 Bucket Hunter
Advanced S3 bucket discovery and enumeration
"""

import requests
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor
import xml.etree.ElementTree as ET
import json

class S3BucketHunter:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        
        # Common S3 bucket naming patterns
        self.bucket_patterns = [
            '{domain}',
            '{domain}-backup',
            '{domain}-backups',
            '{domain}-data',
            '{domain}-files',
            '{domain}-uploads',
            '{domain}-assets',
            '{domain}-static',
            '{domain}-media',
            '{domain}-images',
            '{domain}-logs',
            '{domain}-dev',
            '{domain}-test',
            '{domain}-staging',
            '{domain}-prod',
            '{domain}-production',
            'backup-{domain}',
            'backups-{domain}',
            'data-{domain}',
            'files-{domain}',
            'uploads-{domain}',
            'assets-{domain}',
            'static-{domain}',
            'media-{domain}',
            'images-{domain}',
            'logs-{domain}',
            'dev-{domain}',
            'test-{domain}',
            'staging-{domain}',
            'prod-{domain}',
            'production-{domain}',
            '{company}',
            '{company}-backup',
            '{company}-data',
            '{company}-files',
            'www-{domain}',
            'api-{domain}',
            'app-{domain}',
            '{domain}-www',
            '{domain}-api',
            '{domain}-app'
        ]
        
        # AWS regions to check
        self.aws_regions = [
            'us-east-1', 'us-east-2', 'us-west-1', 'us-west-2',
            'eu-west-1', 'eu-west-2', 'eu-west-3', 'eu-central-1',
            'ap-southeast-1', 'ap-southeast-2', 'ap-northeast-1',
            'ap-northeast-2', 'ap-south-1', 'ca-central-1',
            'sa-east-1'
        ]
    
    def check_bucket_exists(self, bucket_name, region='us-east-1'):
        """Check if S3 bucket exists"""
        try:
            if region == 'us-east-1':
                url = f'https://{bucket_name}.s3.amazonaws.com'
            else:
                url = f'https://{bucket_name}.s3.{region}.amazonaws.com'
            
            response = self.session.head(url, timeout=10)
            
            if response.status_code == 200:
                return 'exists_accessible'
            elif response.status_code == 403:
                return 'exists_forbidden'
            elif response.status_code == 404:
                return 'not_found'
            else:
                return f'unknown_{response.status_code}'
                
        except Exception as e:
            return 'error'
    
    def enumerate_bucket_contents(self, bucket_name, region='us-east-1'):
        """Enumerate S3 bucket contents"""
        try:
            if region == 'us-east-1':
                url = f'https://{bucket_name}.s3.amazonaws.com'
            else:
                url = f'https://{bucket_name}.s3.{region}.amazonaws.com'
            
            response = self.session.get(url, timeout=10)
            
            if response.status_code == 200:
                # Parse XML response
                root = ET.fromstring(response.content)
                contents = []
                
                for content in root.findall('.//{http://s3.amazonaws.com/doc/2006-03-01/}Contents'):
                    key = content.find('{http://s3.amazonaws.com/doc/2006-03-01/}Key')
                    size = content.find('{http://s3.amazonaws.com/doc/2006-03-01/}Size')
                    last_modified = content.find('{http://s3.amazonaws.com/doc/2006-03-01/}LastModified')
                    
                    if key is not None:
                        contents.append({
                            'key': key.text,
                            'size': size.text if size is not None else '0',
                            'last_modified': last_modified.text if last_modified is not None else 'unknown'
                        })
                
                return contents
            else:
                return []
                
        except Exception as e:
            return []
    
    def check_bucket_permissions(self, bucket_name, region='us-east-1'):
        """Check S3 bucket permissions"""
        permissions = {
            'read': False,
            'write': False,
            'read_acp': False,
            'write_acp': False
        }
        
        try:
            if region == 'us-east-1':
                base_url = f'https://{bucket_name}.s3.amazonaws.com'
            else:
                base_url = f'https://{bucket_name}.s3.{region}.amazonaws.com'
            
            # Test read permission
            response = self.session.get(base_url, timeout=10)
            if response.status_code == 200:
                permissions['read'] = True
            
            # Test write permission (try to upload a test file)
            test_data = b'test'
            response = self.session.put(f'{base_url}/test-write-permission.txt', 
                                      data=test_data, timeout=10)
            if response.status_code in [200, 201]:
                permissions['write'] = True
                # Clean up test file
                self.session.delete(f'{base_url}/test-write-permission.txt')
            
            # Test ACL permissions
            response = self.session.get(f'{base_url}/?acl', timeout=10)
            if response.status_code == 200:
                permissions['read_acp'] = True
            
        except Exception as e:
            pass
        
        return permissions
    
    def hunt_s3_buckets(self, domain, company_name=None):
        """Hunt for S3 buckets related to domain"""
        print(f"🔍 Hunting S3 buckets for: {domain}")
        
        found_buckets = []
        domain_clean = domain.replace('.', '-').replace('_', '-')
        company_clean = company_name.replace('.', '-').replace('_', '-') if company_name else domain_clean
        
        # Generate bucket names
        bucket_names = []
        for pattern in self.bucket_patterns:
            bucket_name = pattern.format(domain=domain_clean, company=company_clean)
            bucket_names.append(bucket_name.lower())
        
        # Remove duplicates
        bucket_names = list(set(bucket_names))
        
        print(f"Testing {len(bucket_names)} potential bucket names...")
        
        def check_bucket(bucket_name):
            for region in ['us-east-1', 'us-west-2', 'eu-west-1']:  # Check main regions
                status = self.check_bucket_exists(bucket_name, region)
                
                if status in ['exists_accessible', 'exists_forbidden']:
                    bucket_info = {
                        'name': bucket_name,
                        'region': region,
                        'status': status,
                        'url': f'https://{bucket_name}.s3.{region}.amazonaws.com' if region != 'us-east-1' else f'https://{bucket_name}.s3.amazonaws.com',
                        'contents': [],
                        'permissions': {}
                    }
                    
                    if status == 'exists_accessible':
                        # Enumerate contents
                        contents = self.enumerate_bucket_contents(bucket_name, region)
                        bucket_info['contents'] = contents[:50]  # Limit to first 50 files
                        
                        # Check permissions
                        permissions = self.check_bucket_permissions(bucket_name, region)
                        bucket_info['permissions'] = permissions
                    
                    found_buckets.append(bucket_info)
                    print(f"✅ Found bucket: {bucket_name} ({status})")
                    break
        
        # Use threading for faster scanning
        with ThreadPoolExecutor(max_workers=20) as executor:
            executor.map(check_bucket, bucket_names)
        
        return found_buckets

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 aws_s3_hunter.py <domain> [company_name]")
        sys.exit(1)
    
    domain = sys.argv[1]
    company_name = sys.argv[2] if len(sys.argv) > 2 else None
    
    hunter = S3BucketHunter()
    buckets = hunter.hunt_s3_buckets(domain, company_name)
    
    # Save results
    with open(f'{domain}_s3_buckets.json', 'w') as f:
        json.dump(buckets, f, indent=2)
    
    print(f"\n✅ S3 bucket hunting complete!")
    print(f"Found {len(buckets)} accessible buckets")
    print(f"📁 Results saved to: {domain}_s3_buckets.json")

if __name__ == "__main__":
    main()
EOF

chmod +x aws_s3_hunter.py
```

#### 2. Google Cloud Storage (GCS) Discovery
```bash
cat > gcp_storage_hunter.py << 'EOF'
#!/usr/bin/env python3
"""
Elite GCP Storage Hunter
Advanced Google Cloud Storage bucket discovery
"""

import requests
import sys
import json
from concurrent.futures import ThreadPoolExecutor

class GCSBucketHunter:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        
        # GCS bucket naming patterns
        self.bucket_patterns = [
            '{domain}',
            '{domain}-backup',
            '{domain}-backups',
            '{domain}-data',
            '{domain}-files',
            '{domain}-uploads',
            '{domain}-assets',
            '{domain}-static',
            '{domain}-media',
            '{domain}-images',
            '{domain}-logs',
            '{domain}-dev',
            '{domain}-test',
            '{domain}-staging',
            '{domain}-prod',
            '{domain}-production',
            'backup-{domain}',
            'data-{domain}',
            'files-{domain}',
            'uploads-{domain}',
            'assets-{domain}',
            'static-{domain}',
            'media-{domain}',
            'images-{domain}',
            'logs-{domain}',
            'dev-{domain}',
            'test-{domain}',
            'staging-{domain}',
            'prod-{domain}',
            'production-{domain}',
            '{company}',
            '{company}-backup',
            '{company}-data',
            '{company}-files'
        ]
    
    def check_gcs_bucket(self, bucket_name):
        """Check if GCS bucket exists and is accessible"""
        try:
            # Try direct access
            url = f'https://storage.googleapis.com/{bucket_name}'
            response = self.session.get(url, timeout=10)
            
            if response.status_code == 200:
                return 'exists_accessible', response.text
            elif response.status_code == 403:
                return 'exists_forbidden', None
            elif response.status_code == 404:
                return 'not_found', None
            else:
                return f'unknown_{response.status_code}', None
                
        except Exception as e:
            return 'error', None
    
    def enumerate_gcs_contents(self, bucket_name):
        """Enumerate GCS bucket contents"""
        try:
            url = f'https://www.googleapis.com/storage/v1/b/{bucket_name}/o'
            response = self.session.get(url, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                return data.get('items', [])
            else:
                return []
                
        except Exception as e:
            return []
    
    def hunt_gcs_buckets(self, domain, company_name=None):
        """Hunt for GCS buckets"""
        print(f"🔍 Hunting GCS buckets for: {domain}")
        
        found_buckets = []
        domain_clean = domain.replace('.', '-').replace('_', '-')
        company_clean = company_name.replace('.', '-').replace('_', '-') if company_name else domain_clean
        
        # Generate bucket names
        bucket_names = []
        for pattern in self.bucket_patterns:
            bucket_name = pattern.format(domain=domain_clean, company=company_clean)
            bucket_names.append(bucket_name.lower())
        
        bucket_names = list(set(bucket_names))
        print(f"Testing {len(bucket_names)} potential GCS bucket names...")
        
        def check_bucket(bucket_name):
            status, content = self.check_gcs_bucket(bucket_name)
            
            if status in ['exists_accessible', 'exists_forbidden']:
                bucket_info = {
                    'name': bucket_name,
                    'status': status,
                    'url': f'https://storage.googleapis.com/{bucket_name}',
                    'contents': []
                }
                
                if status == 'exists_accessible':
                    contents = self.enumerate_gcs_contents(bucket_name)
                    bucket_info['contents'] = contents[:50]  # Limit to first 50
                
                found_buckets.append(bucket_info)
                print(f"✅ Found GCS bucket: {bucket_name} ({status})")
        
        with ThreadPoolExecutor(max_workers=20) as executor:
            executor.map(check_bucket, bucket_names)
        
        return found_buckets

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 gcp_storage_hunter.py <domain> [company_name]")
        sys.exit(1)
    
    domain = sys.argv[1]
    company_name = sys.argv[2] if len(sys.argv) > 2 else None
    
    hunter = GCSBucketHunter()
    buckets = hunter.hunt_gcs_buckets(domain, company_name)
    
    with open(f'{domain}_gcs_buckets.json', 'w') as f:
        json.dump(buckets, f, indent=2)
    
    print(f"\n✅ GCS bucket hunting complete!")
    print(f"Found {len(buckets)} accessible buckets")
    print(f"📁 Results saved to: {domain}_gcs_buckets.json")

if __name__ == "__main__":
    main()
EOF

chmod +x gcp_storage_hunter.py
```

#### 3. Azure Blob Storage Discovery
```bash
cat > azure_blob_hunter.py << 'EOF'
#!/usr/bin/env python3
"""
Elite Azure Blob Storage Hunter
Advanced Azure storage account and container discovery
"""

import requests
import sys
import json
from concurrent.futures import ThreadPoolExecutor

class AzureBlobHunter:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        
        # Azure storage account naming patterns
        self.storage_patterns = [
            '{domain}',
            '{domain}storage',
            '{domain}data',
            '{domain}files',
            '{domain}backup',
            '{domain}assets',
            '{domain}media',
            '{domain}static',
            '{domain}uploads',
            '{domain}images',
            '{domain}logs',
            '{domain}dev',
            '{domain}test',
            '{domain}staging',
            '{domain}prod',
            'storage{domain}',
            'data{domain}',
            'files{domain}',
            'backup{domain}',
            'assets{domain}',
            'media{domain}',
            'static{domain}',
            'uploads{domain}',
            'images{domain}',
            'logs{domain}',
            'dev{domain}',
            'test{domain}',
            'staging{domain}',
            'prod{domain}',
            'production{domain}',
            '{company}',
            '{company}storage',
            '{company}data',
            '{company}files'
        ]
        
        # Common container names
        self.container_names = [
            'public',
            'private',
            'data',
            'files',
            'uploads',
            'downloads',
            'backup',
            'backups',
            'assets',
            'static',
            'media',
            'images',
            'documents',
            'logs',
            'temp',
            'cache',
            'archive',
            'export',
            'import',
            'reports'
        ]
    
    def check_azure_storage(self, storage_account):
        """Check if Azure storage account exists"""
        try:
            url = f'https://{storage_account}.blob.core.windows.net'
            response = self.session.get(url, timeout=10)
            
            if response.status_code == 400:  # Bad request usually means account exists
                return 'exists'
            elif response.status_code == 404:
                return 'not_found'
            else:
                return f'unknown_{response.status_code}'
                
        except Exception as e:
            return 'error'
    
    def check_azure_container(self, storage_account, container_name):
        """Check if Azure container exists and is accessible"""
        try:
            url = f'https://{storage_account}.blob.core.windows.net/{container_name}?restype=container&comp=list'
            response = self.session.get(url, timeout=10)
            
            if response.status_code == 200:
                return 'accessible', response.text
            elif response.status_code == 403:
                return 'exists_forbidden', None
            elif response.status_code == 404:
                return 'not_found', None
            else:
                return f'unknown_{response.status_code}', None
                
        except Exception as e:
            return 'error', None
    
    def hunt_azure_storage(self, domain, company_name=None):
        """Hunt for Azure storage accounts and containers"""
        print(f"🔍 Hunting Azure storage for: {domain}")
        
        found_storage = []
        domain_clean = domain.replace('.', '').replace('-', '').replace('_', '')
        company_clean = company_name.replace('.', '').replace('-', '').replace('_', '') if company_name else domain_clean
        
        # Generate storage account names
        storage_names = []
        for pattern in self.storage_patterns:
            storage_name = pattern.format(domain=domain_clean, company=company_clean)
            storage_names.append(storage_name.lower()[:24])  # Azure limit is 24 chars
        
        storage_names = list(set(storage_names))
        print(f"Testing {len(storage_names)} potential storage accounts...")
        
        def check_storage(storage_name):
            status = self.check_azure_storage(storage_name)
            
            if status == 'exists':
                storage_info = {
                    'storage_account': storage_name,
                    'url': f'https://{storage_name}.blob.core.windows.net',
                    'containers': []
                }
                
                print(f"✅ Found Azure storage: {storage_name}")
                
                # Check common containers
                for container in self.container_names:
                    container_status, content = self.check_azure_container(storage_name, container)
                    
                    if container_status in ['accessible', 'exists_forbidden']:
                        container_info = {
                            'name': container,
                            'status': container_status,
                            'url': f'https://{storage_name}.blob.core.windows.net/{container}',
                            'content_preview': content[:1000] if content else None
                        }
                        storage_info['containers'].append(container_info)
                        
                        if container_status == 'accessible':
                            print(f"  ✅ Accessible container: {container}")
                
                found_storage.append(storage_info)
        
        with ThreadPoolExecutor(max_workers=20) as executor:
            executor.map(check_storage, storage_names)
        
        return found_storage

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 azure_blob_hunter.py <domain> [company_name]")
        sys.exit(1)
    
    domain = sys.argv[1]
    company_name = sys.argv[2] if len(sys.argv) > 2 else None
    
    hunter = AzureBlobHunter()
    storage_accounts = hunter.hunt_azure_storage(domain, company_name)
    
    with open(f'{domain}_azure_storage.json', 'w') as f:
        json.dump(storage_accounts, f, indent=2)
    
    print(f"\n✅ Azure storage hunting complete!")
    print(f"Found {len(storage_accounts)} storage accounts")
    print(f"📁 Results saved to: {domain}_azure_storage.json")

if __name__ == "__main__":
    main()
EOF

chmod +x azure_blob_hunter.py
```

#### 4. Comprehensive Cloud Asset Discovery Script
```bash
cat > cloud_asset_hunter.sh << 'EOF'
#!/bin/bash
"""
Elite Cloud Asset Discovery Suite
Comprehensive cloud asset enumeration across AWS, GCP, and Azure
"""

TARGET=$1
COMPANY=${2:-$TARGET}

if [ -z "$TARGET" ]; then
    echo "Usage: ./cloud_asset_hunter.sh <domain> [company_name]"
    exit 1
fi

echo "☁️ Elite Cloud Asset Discovery for $TARGET"
echo "=========================================="

# Create cloud assets directory
mkdir -p cloud_assets/$TARGET
cd cloud_assets/$TARGET

# Phase 1: AWS S3 Bucket Discovery
echo "[1/6] AWS S3 Bucket Discovery..."
python3 ../../aws_s3_hunter.py $TARGET $COMPANY

# Phase 2: Google Cloud Storage Discovery
echo "[2/6] Google Cloud Storage Discovery..."
python3 ../../gcp_storage_hunter.py $TARGET $COMPANY

# Phase 3: Azure Blob Storage Discovery
echo "[3/6] Azure Blob Storage Discovery..."
python3 ../../azure_blob_hunter.py $TARGET $COMPANY

# Phase 4: AWS CloudFront Distribution Discovery
echo "[4/6] AWS CloudFront Distribution Discovery..."
domain_clean=$(echo $TARGET | sed 's/\./-/g')
cloudfront_domains=(
    "$domain_clean.cloudfront.net"
    "$TARGET.cloudfront.net"
    "cdn-$domain_clean.cloudfront.net"
    "assets-$domain_clean.cloudfront.net"
    "static-$domain_clean.cloudfront.net"
    "media-$domain_clean.cloudfront.net"
    "images-$domain_clean.cloudfront.net"
    "js-$domain_clean.cloudfront.net"
    "css-$domain_clean.cloudfront.net"
    "api-$domain_clean.cloudfront.net"
)

echo "Testing CloudFront distributions..."
for cf_domain in "${cloudfront_domains[@]}"; do
    if curl -s --connect-timeout 5 "https://$cf_domain" | grep -q "cloudfront"; then
        echo "✅ Found CloudFront: $cf_domain"
        echo "$cf_domain" >> cloudfront_distributions.txt
    fi
done

# Phase 5: Google Cloud CDN Discovery
echo "[5/6] Google Cloud CDN Discovery..."
gcp_cdn_domains=(
    "$domain_clean.googleusercontent.com"
    "$TARGET.googleusercontent.com"
    "$domain_clean.storage.googleapis.com"
    "$TARGET.storage.googleapis.com"
    "cdn-$domain_clean.googleusercontent.com"
    "assets-$domain_clean.googleusercontent.com"
    "static-$domain_clean.googleusercontent.com"
)

echo "Testing Google Cloud CDN..."
for gcp_domain in "${gcp_cdn_domains[@]}"; do
    if curl -s --connect-timeout 5 "https://$gcp_domain" >/dev/null 2>&1; then
        echo "✅ Found GCP CDN: $gcp_domain"
        echo "$gcp_domain" >> gcp_cdn_endpoints.txt
    fi
done

# Phase 6: Azure CDN Discovery
echo "[6/6] Azure CDN Discovery..."
azure_cdn_domains=(
    "$domain_clean.azureedge.net"
    "$TARGET.azureedge.net"
    "cdn-$domain_clean.azureedge.net"
    "assets
