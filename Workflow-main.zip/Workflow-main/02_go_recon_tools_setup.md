# 🚀 Elite Go-Based Reconnaissance Tools Setup
## Advanced Bug Bounty & Red Team Go Tools Collection

### 🔧 **Go Environment Verification & Setup**

#### **Go Installation Check**
```bash
#!/bin/bash
# Save as check_go_setup.sh

echo "🔍 Checking Go environment..."

# Check Go version
if command -v go &> /dev/null; then
    GO_VERSION=$(go version | cut -d' ' -f3)
    echo "✅ Go $GO_VERSION installed"
else
    echo "❌ Go not found. Installing Go 1.21.5..."
    
    # Install Go
    wget https://go.dev/dl/go1.21.5.linux-amd64.tar.gz
    sudo rm -rf /usr/local/go
    sudo tar -C /usr/local -xzf go1.21.5.linux-amd64.tar.gz
    
    # Add to PATH
    echo 'export PATH=$PATH:/usr/local/go/bin' >> ~/.bashrc
    echo 'export GOPATH=$HOME/go' >> ~/.bashrc
    echo 'export PATH=$PATH:$GOPATH/bin' >> ~/.bashrc
    source ~/.bashrc
fi

# Create Go workspace
mkdir -p $HOME/go/{bin,src,pkg}
echo "✅ Go workspace created"
```

### 🎯 **ProjectDiscovery Tools Suite**

#### **Core ProjectDiscovery Tools**
```bash
#!/bin/bash
# Save as install_projectdiscovery.sh

echo "🔥 Installing ProjectDiscovery Elite Tools..."

# Update Go modules
go clean -modcache

# Subfinder - Advanced subdomain discovery
echo "📡 Installing Subfinder..."
go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest

# Httpx - Fast HTTP probe
echo "🌐 Installing Httpx..."
go install -v github.com/projectdiscovery/httpx/cmd/httpx@latest

# Nuclei - Vulnerability scanner
echo "💥 Installing Nuclei..."
go install -v github.com/projectdiscovery/nuclei/v2/cmd/nuclei@latest

# Katana - Web crawler
echo "🕷️ Installing Katana..."
go install -v github.com/projectdiscovery/katana/cmd/katana@latest

# Naabu - Port scanner
echo "🔍 Installing Naabu..."
go install -v github.com/projectdiscovery/naabu/v2/cmd/naabu@latest

# Dnsx - DNS toolkit
echo "🌍 Installing Dnsx..."
go install -v github.com/projectdiscovery/dnsx/cmd/dnsx@latest

# Notify - Notification sender
echo "📢 Installing Notify..."
go install -v github.com/projectdiscovery/notify/cmd/notify@latest

# Interactsh - OOB interaction server
echo "🔗 Installing Interactsh..."
go install -v github.com/projectdiscovery/interactsh/cmd/interactsh-client@latest
go install -v github.com/projectdiscovery/interactsh/cmd/interactsh-server@latest

# Chaos - DNS enumeration
echo "🌪️ Installing Chaos..."
go install -v github.com/projectdiscovery/chaos-client/cmd/chaos@latest

# Uncover - Discovery engine
echo "🔎 Installing Uncover..."
go install -v github.com/projectdiscovery/uncover/cmd/uncover@latest

# Alterx - Subdomain wordlist generator
echo "🔤 Installing Alterx..."
go install -v github.com/projectdiscovery/alterx/cmd/alterx@latest

echo "✅ ProjectDiscovery tools installed successfully!"
```

#### **Advanced ProjectDiscovery Configuration**
```bash
# Create ProjectDiscovery config directory
mkdir -p ~/.config/subfinder
mkdir -p ~/.config/nuclei
mkdir -p ~/.config/httpx

# Subfinder API configuration
cat > ~/.config/subfinder/provider-config.yaml << 'EOF'
# Subfinder API Keys Configuration
binaryedge:
  - "YOUR_BINARYEDGE_API_KEY"
censys:
  - "YOUR_CENSYS_API_ID:YOUR_CENSYS_SECRET"
certspotter:
  - "YOUR_CERTSPOTTER_API_KEY"
chaos:
  - "YOUR_CHAOS_API_KEY"
chinaz:
  - "YOUR_CHINAZ_API_KEY"
dnsdb:
  - "YOUR_DNSDB_API_KEY"
fofa:
  - "YOUR_FOFA_EMAIL:YOUR_FOFA_KEY"
fullhunt:
  - "YOUR_FULLHUNT_API_KEY"
github:
  - "YOUR_GITHUB_TOKEN"
intelx:
  - "YOUR_INTELX_API_KEY:YOUR_INTELX_UUID"
passivetotal:
  - "YOUR_PASSIVETOTAL_USERNAME:YOUR_PASSIVETOTAL_API_KEY"
quake:
  - "YOUR_QUAKE_TOKEN"
robtex:
  - "YOUR_ROBTEX_API_KEY"
securitytrails:
  - "YOUR_SECURITYTRAILS_API_KEY"
shodan:
  - "YOUR_SHODAN_API_KEY"
spyse:
  - "YOUR_SPYSE_API_TOKEN"
threatbook:
  - "YOUR_THREATBOOK_API_KEY"
virustotal:
  - "YOUR_VIRUSTOTAL_API_KEY"
whoisxmlapi:
  - "YOUR_WHOISXMLAPI_KEY"
zoomeye:
  - "YOUR_ZOOMEYE_USERNAME:YOUR_ZOOMEYE_PASSWORD"
EOF

# Update Nuclei templates
nuclei -update-templates
```

### 🔍 **TomNomNom's Essential Tools**

#### **TomNomNom Tools Collection**
```bash
#!/bin/bash
# Save as install_tomnomnom_tools.sh

echo "🎯 Installing TomNomNom's Elite Tools..."

# Waybackurls - Wayback machine URL fetcher
echo "📜 Installing Waybackurls..."
go install -v github.com/tomnomnom/waybackurls@latest

# Gf - Grep for patterns
echo "🔍 Installing Gf..."
go install -v github.com/tomnomnom/gf@latest

# Anew - Add new lines to files
echo "➕ Installing Anew..."
go install -v github.com/tomnomnom/anew@latest

# Httprobe - HTTP probe
echo "🌐 Installing Httprobe..."
go install -v github.com/tomnomnom/httprobe@latest

# Assetfinder - Asset discovery
echo "🎯 Installing Assetfinder..."
go install -v github.com/tomnomnom/assetfinder@latest

# Unfurl - URL analysis
echo "🔗 Installing Unfurl..."
go install -v github.com/tomnomnom/unfurl@latest

# Qsreplace - Query string replacer
echo "🔄 Installing Qsreplace..."
go install -v github.com/tomnomnom/qsreplace@latest

# Meg - Many HTTP requests
echo "📡 Installing Meg..."
go install -v github.com/tomnomnom/meg@latest

# Gron - JSON grep
echo "📊 Installing Gron..."
go install -v github.com/tomnomnom/gron@latest

# Concurl - Concurrent curl
echo "⚡ Installing Concurl..."
go install -v github.com/tomnomnom/concurl@latest

echo "✅ TomNomNom tools installed successfully!"
```

#### **Gf Patterns Setup**
```bash
# Create gf patterns directory
mkdir -p ~/.gf

# Download gf patterns
echo "📥 Downloading Gf patterns..."
git clone https://github.com/tomnomnom/gf.git /tmp/gf-repo
cp /tmp/gf-repo/examples/*.json ~/.gf/
rm -rf /tmp/gf-repo

# Custom gf patterns for bug bounty
cat > ~/.gf/api-keys.json << 'EOF'
{
    "flags": "-HnriE",
    "patterns": [
        "(?i)(api[_-]?key|apikey)\\s*[:=]\\s*['\"]?[a-zA-Z0-9_\\-]{16,}['\"]?",
        "(?i)(secret[_-]?key|secretkey)\\s*[:=]\\s*['\"]?[a-zA-Z0-9_\\-]{16,}['\"]?",
        "(?i)(access[_-]?token|accesstoken)\\s*[:=]\\s*['\"]?[a-zA-Z0-9_\\-]{16,}['\"]?",
        "(?i)(auth[_-]?token|authtoken)\\s*[:=]\\s*['\"]?[a-zA-Z0-9_\\-]{16,}['\"]?",
        "AKIA[0-9A-Z]{16}",
        "sk_live_[0-9a-zA-Z]{24}",
        "sk_test_[0-9a-zA-Z]{24}",
        "AIza[0-9A-Za-z\\-_]{35}",
        "ya29\\.[0-9A-Za-z\\-_]+",
        "ghp_[0-9A-Za-z]{36}",
        "xox[baprs]-[0-9a-zA-Z]{10,48}"
    ]
}
EOF

cat > ~/.gf/ssrf.json << 'EOF'
{
    "flags": "-HnriE",
    "patterns": [
        "(?i)(url|uri|path|dest|redirect|next|target|rurl|link|domain|host)=",
        "(?i)(callback|return|jump|continue|view|data|reference|site|html)=",
        "(?i)(window|frame|popup|tab|page|content|ajax|jsonp)=",
        "(?i)(fetch|load|include|require|import|open|read|get|post)="
    ]
}
EOF

cat > ~/.gf/xss.json << 'EOF'
{
    "flags": "-HnriE",
    "patterns": [
        "(?i)(q|query|search|keyword|term|filter|find|lookup|name|value|data|input|field|param|var|arg|text|content|message|comment|description|title|subject|body|html|xml|json|callback|jsonp|function|method|action|cmd|exec|eval|expression|formula|script|code|payload|inject|attack|exploit|hack|test|debug|demo|example|sample|template|format|type|mode|style|theme|skin|layout|view|page|tab|window|frame|popup|modal|dialog|alert|confirm|prompt|console|log|error|warning|info|success|fail|exception|trace|stack|dump|output|result|response|request|header|cookie|session|token|key|secret|password|pass|pwd|user|username|email|mail|phone|mobile|address|location|geo|lat|lng|zip|postal|country|region|state|city|street|building|floor|room|apartment|suite|unit|number|id|uuid|guid|hash|checksum|signature|timestamp|date|time|year|month|day|hour|minute|second|timezone|locale|language|culture|encoding|charset|mime|extension|suffix|prefix|namespace|package|module|class|interface|enum|struct|union|typedef|define|macro|constant|variable|property|attribute|field|member|element|node|item|entry|record|row|column|cell|table|database|schema|collection|document|file|folder|directory|path|url|uri|link|href|src|action|method|target|rel|type|name|id|class|style|title|alt|width|height|size|length|count|index|position|offset|limit|page|per_page|sort|order|direction|asc|desc|group|having|where|filter|search|query|select|from|join|inner|left|right|full|outer|on|using|union|intersect|except|distinct|all|top|first|last|min|max|sum|avg|count|exists|in|not|and|or|like|between|is|null|true|false|case|when|then|else|end|if|while|for|do|break|continue|return|throw|try|catch|finally|switch|default|goto|label|function|procedure|trigger|view|index|constraint|foreign|primary|unique|check|default|auto_increment|serial|sequence|identity|generated|computed|virtual|stored|persistent|temporary|global|local|session|system|user|role|grant|revoke|create|alter|drop|truncate|insert|update|delete|select|show|describe|explain|analyze|optimize|repair|backup|restore|import|export|load|unload|copy|move|rename|clone|duplicate|merge|split|join|combine|aggregate|pivot|unpivot|transpose|normalize|denormalize|encode|decode|encrypt|decrypt|hash|unhash|compress|decompress|zip|unzip|tar|untar|gzip|gunzip|base64|hex|binary|ascii|utf8|unicode|json|xml|yaml|csv|tsv|html|markdown|latex|pdf|doc|docx|xls|xlsx|ppt|pptx|odt|ods|odp|rtf|txt|log|ini|cfg|conf|config|properties|env|dotenv|dockerfile|makefile|rakefile|gemfile|package|composer|bower|npm|yarn|pip|requirements|setup|build|deploy|release|version|changelog|readme|license|copyright|author|contributor|maintainer|owner|admin|moderator|editor|viewer|guest|anonymous|public|private|protected|internal|external|local|remote|client|server|frontend|backend|api|rest|graphql|soap|rpc|websocket|sse|webhook|callback|cors|csrf|xss|sqli|rce|lfi|rfi|xxe|ssrf|idor|bola|bfla|mflac|owasp|cwe|cve|cvss|nist|sans|mitre|capec|attack|technique|tactic|procedure|indicator|ioc|ttp|apt|malware|virus|trojan|worm|rootkit|backdoor|keylogger|spyware|adware|ransomware|cryptominer|botnet|c2|command|control|exfiltration|persistence|privilege|escalation|defense|evasion|credential|access|discovery|lateral|movement|collection|impact|initial|execution|development|reconnaissance|weaponization|delivery|exploitation|installation|action|objective)"
    ]
}
EOF

echo "✅ Gf patterns configured successfully!"
```

### 🌐 **Additional Elite Go Tools**

#### **Advanced Reconnaissance Tools**
```bash
#!/bin/bash
# Save as install_advanced_go_tools.sh

echo "🔥 Installing Advanced Go Reconnaissance Tools..."

# Amass - Advanced subdomain enumeration
echo "🌍 Installing Amass..."
go install -v github.com/OWASP/Amass/v3/...@master

# Gobuster - Directory/file brute-forcer
echo "📁 Installing Gobuster..."
go install -v github.com/OJ/gobuster/v3@latest

# Ffuf - Fast web fuzzer
echo "⚡ Installing Ffuf..."
go install -v github.com/ffuf/ffuf@latest

# Gau - Get All URLs
echo "🔗 Installing Gau..."
go install -v github.com/lc/gau/v2/cmd/gau@latest

# Hakrawler - Web crawler
echo "🕸️ Installing Hakrawler..."
go install -v github.com/hakluke/hakrawler@latest

# Subjack - Subdomain takeover
echo "🎯 Installing Subjack..."
go install -v github.com/haccer/subjack@latest

# Aquatone - Visual inspection
echo "👁️ Installing Aquatone..."
go install -v github.com/michenriksen/aquatone@latest

# Dalfox - XSS scanner
echo "💉 Installing Dalfox..."
go install -v github.com/hahwul/dalfox/v2@latest

# Kxss - XSS finder
echo "🔍 Installing Kxss..."
go install -v github.com/Emoe/kxss@latest

# Anti-burl - Remove duplicate URLs
echo "🔄 Installing Anti-burl..."
go install -v github.com/tomnomnom/hacks/anti-burl@latest

# Freq - Frequency analysis
echo "📊 Installing Freq..."
go install -v github.com/takshal/freq@latest

# Gospider - Web spider
echo "🕷️ Installing Gospider..."
go install -v github.com/jaeles-project/gospider@latest

# Hakcheckurl - URL checker
echo "✅ Installing Hakcheckurl..."
go install -v github.com/hakluke/hakcheckurl@latest

# Haklistgen - List generator
echo "📝 Installing Haklistgen..."
go install -v github.com/hakluke/haklistgen@latest

# Hakrevdns - Reverse DNS
echo "🔄 Installing Hakrevdns..."
go install -v github.com/hakluke/hakrevdns@latest

# Httprobe - HTTP probe
echo "🌐 Installing Httprobe..."
go install -v github.com/tomnomnom/httprobe@latest

# Jaeles - Automated testing
echo "🤖 Installing Jaeles..."
go install -v github.com/jaeles-project/jaeles@latest

# Mapcidr - CIDR mapper
echo "🗺️ Installing Mapcidr..."
go install -v github.com/projectdiscovery/mapcidr/cmd/mapcidr@latest

# Naabu - Port scanner
echo "🔍 Installing Naabu..."
go install -v github.com/projectdiscovery/naabu/v2/cmd/naabu@latest

# Shuffledns - DNS resolver
echo "🌐 Installing Shuffledns..."
go install -v github.com/projectdiscovery/shuffledns/cmd/shuffledns@latest

# Tlsx - TLS data extractor
echo "🔐 Installing Tlsx..."
go install -v github.com/projectdiscovery/tlsx/cmd/tlsx@latest

# Proxify - HTTP proxy
echo "🔄 Installing Proxify..."
go install -v github.com/projectdiscovery/proxify/cmd/proxify@latest

echo "✅ Advanced Go tools installed successfully!"
```

### 🔧 **Custom Go Tools Development**

#### **Custom Subdomain Enumeration Tool**
```go
// Save as custom_subdomain_enum.go
package main

import (
    "bufio"
    "fmt"
    "net"
    "os"
    "strings"
    "sync"
    "time"
)

func main() {
    if len(os.Args) != 3 {
        fmt.Println("Usage: go run custom_subdomain_enum.go <domain> <wordlist>")
        os.Exit(1)
    }

    domain := os.Args[1]
    wordlistFile := os.Args[2]

    wordlist, err := readWordlist(wordlistFile)
    if err != nil {
        fmt.Printf("Error reading wordlist: %v\n", err)
        os.Exit(1)
    }

    fmt.Printf("🔍 Starting subdomain enumeration for %s\n", domain)
    fmt.Printf("📝 Using wordlist: %s (%d words)\n", wordlistFile, len(wordlist))

    var wg sync.WaitGroup
    semaphore := make(chan struct{}, 50) // Limit concurrent goroutines

    for _, word := range wordlist {
        wg.Add(1)
        go func(subdomain string) {
            defer wg.Done()
            semaphore <- struct{}{}
            defer func() { <-semaphore }()

            fullDomain := subdomain + "." + domain
            if isValidDomain(fullDomain) {
                fmt.Printf("✅ Found: %s\n", fullDomain)
            }
        }(word)
    }

    wg.Wait()
    fmt.Println("🎯 Subdomain enumeration completed!")
}

func readWordlist(filename string) ([]string, error) {
    file, err := os.Open(filename)
    if err != nil {
        return nil, err
    }
    defer file.Close()

    var words []string
    scanner := bufio.NewScanner(file)
    for scanner.Scan() {
        word := strings.TrimSpace(scanner.Text())
        if word != "" {
            words = append(words, word)
        }
    }

    return words, scanner.Err()
}

func isValidDomain(domain string) bool {
    _, err := net.LookupHost(domain)
    return err == nil
}
```

#### **Custom Port Scanner Tool**
```go
// Save as custom_port_scanner.go
package main

import (
    "fmt"
    "net"
    "os"
    "strconv"
    "strings"
    "sync"
    "time"
)

func main() {
    if len(os.Args) != 3 {
        fmt.Println("Usage: go run custom_port_scanner.go <host> <ports>")
        fmt.Println("Example: go run custom_port_scanner.go example.com 80,443,8080")
        os.Exit(1)
    }

    host := os.Args[1]
    portsStr := os.Args[2]

    ports := parsePorts(portsStr)
    if len(ports) == 0 {
        fmt.Println("❌ No valid ports specified")
        os.Exit(1)
    }

    fmt.Printf("🎯 Scanning %s for %d ports\n", host, len(ports))

    var wg sync.WaitGroup
    semaphore := make(chan struct{}, 100) // Limit concurrent connections

    for _, port := range ports {
        wg.Add(1)
        go func(p int) {
            defer wg.Done()
            semaphore <- struct{}{}
            defer func() { <-semaphore }()

            if scanPort(host, p) {
                fmt.Printf("✅ Port %d is open\n", p)
            }
        }(port)
    }

    wg.Wait()
    fmt.Println("🔍 Port scan completed!")
}

func parsePorts(portsStr string) []int {
    var ports []int
    portStrs := strings.Split(portsStr, ",")

    for _, portStr := range portStrs {
        portStr = strings.TrimSpace(portStr)
        if strings.Contains(portStr, "-") {
            // Handle port ranges like "80-90"
            rangeParts := strings.Split(portStr, "-")
            if len(rangeParts) == 2 {
                start, err1 := strconv.Atoi(rangeParts[0])
                end, err2 := strconv.Atoi(rangeParts[1])
                if err1 == nil && err2 == nil && start <= end {
                    for i := start; i <= end; i++ {
                        ports = append(ports, i)
                    }
                }
            }
        } else {
            // Handle single ports
            port, err := strconv.Atoi(portStr)
            if err == nil && port > 0 && port <= 65535 {
                ports = append(ports, port)
            }
        }
    }

    return ports
}

func scanPort(host string, port int) bool {
    timeout := time.Second * 2
    conn, err := net.DialTimeout("tcp", fmt.Sprintf("%s:%d", host, port), timeout)
    if err != nil {
        return false
    }
    conn.Close()
    return true
}
```

### 🚀 **Automation Scripts**

#### **Complete Go Tools Installation Script**
```bash
#!/bin/bash
# Save as install_all_go_tools.sh

echo "🔥 Elite Go Tools Mass Installation Script"
echo "=========================================="

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if Go is installed
if ! command -v go &> /dev/null; then
    print_error "Go is not installed. Please install Go first."
    exit 1
fi

print_status "Go version: $(go version)"

# Create tools directory
mkdir -p ~/go-tools
cd ~/go-tools

# Array of tools to install
declare -A tools=(
    ["subfinder"]="github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest"
    ["httpx"]="github.com/projectdiscovery/httpx/cmd/httpx@latest"
    ["nuclei"]="github.com/projectdiscovery/nuclei/v2/cmd/nuclei@latest"
    ["katana"]="github.com/projectdiscovery/katana/cmd/katana@latest"
    ["naabu"]="github.com/projectdiscovery/naabu/v2/cmd/naabu@latest"
    ["dnsx"]="github.com/projectdiscovery/dnsx/cmd/dnsx@latest"
    ["notify"]="github.com/projectdiscovery/notify/cmd/notify@latest"
    ["interactsh-client"]="github.com/projectdiscovery/interactsh/cmd/interactsh-client@latest"
    ["chaos"]="github.com/projectdiscovery/chaos-client/cmd/chaos@latest"
    ["uncover"]="github.com/projectdiscovery/uncover/cmd/uncover@latest"
    ["alterx"]="github.com/projectdiscovery/alterx/cmd/alterx@latest"
    ["waybackurls"]="github.com/tomnomnom/waybackurls@latest"
    ["gf"]="github.com/tomnomnom/gf@latest"
    ["anew"]="github.com/tomnomnom/anew@latest"
    ["httprobe"]="github.com/tomnomnom/httprobe@latest"
    ["assetfinder"]="github.com/tomnomnom/assetfinder@latest"
    ["unfurl"]="github.com/tomnomnom/unfurl@latest"
    ["qsreplace"]="github.com/tomnomnom/qsreplace@latest"
    ["meg"]="github.com/tomnomnom/meg@latest"
    ["gron"]="github.com/tomnomnom/gron@latest"
    ["concurl"]="github.com/tomnomnom/concurl@latest"
    ["amass"]="github.com/OWASP/Amass/v3/...@master"
    ["gobuster"]="github.com/OJ/gobuster/v3@latest"
    ["ffuf"]="github.com/ffuf/ffuf@latest"
    ["gau"]="github.com/lc/gau/v2/cmd/gau@latest"
    ["hakrawler"]="github.com/hakluke/hakrawler@latest"
    ["subjack"]="github.com/haccer/subjack@latest"
    ["aquatone"]="github.com/michenriksen/aquatone@latest"
    ["dalfox"]="github.com/hahwul/dalfox/v2@latest"
    ["kxss"]="github.com/Emoe/kxss@latest"
    ["gospider"]="github.com/jaeles-project/gospider@latest"
    ["hakcheckurl"]="github.com/hakluke/hakcheckurl@latest"
    ["hakrevdns"]="github.com/hakluke/hakrevdns@latest"
    ["jaeles"]="github.com/jaeles-project/jaeles@latest"
    ["mapcidr"]="github.com/projectdiscovery/mapcidr/cmd/mapcidr@latest"
    ["shuffledns"]="github.com/projectdiscovery/shuffledns/cmd/shuffledns@latest"
    ["tlsx"]="github.com/projectdiscovery/tlsx/cmd/tlsx@latest"
    ["proxify"]="github.com/projectdiscovery/proxify/cmd/proxify@latest"
)

# Install tools
total_tools=${#tools[@]}
current=0

for tool in "${!tools[@]}"; do
    current=$((current + 1))
    print_status "[$current/$total_tools] Installing $tool..."
    
    if go install -v "${tools[$tool]}"; then
        print_status "✅ $tool installed successfully"
    else
        print_error "❌ Failed to install $tool"
    fi
done

# Verify installations
print_status "Verifying installations..."
failed_tools=()

for tool in "${!tools[@]}"; do
    if command -v "$tool" &> /dev/null; then
        print_status "✅ $tool - Available"
    else
        print_warning "❌ $tool - Not found in PATH"
        failed_tools+=("$tool")
    fi
done

# Summary
echo ""
echo "=========================================="
print_status "Installation Summary:"
print_status "Total tools: $total_tools"
print_status "Successfully installed: $((total_tools - ${#failed_tools[@]}))"

if [ ${#failed_tools[@]} -gt 0 ]; then
    print_warning "Failed installations: ${#failed_tools[@]}"
    for tool in "${failed_tools[@]}"; do
        print_warning "  - $tool"
    done
fi

# Update nuclei templates
if command -v nuclei &> /dev/null; then
    print_status "Updating Nuclei templates..."
    nuclei -update-templates
fi

# Create verification script
cat > ~/go-tools/verify_tools.sh << 'EOF'
#!/bin/bash
echo "🔍 Verifying Go tools installation..."

tools=("subfinder" "httpx" "nuclei" "katana" "naabu" "dnsx" "waybackurls" "gf" "anew" "httprobe" "assetfinder" "unfurl" "qsreplace" "amass" "gobuster" "ffuf" "gau" "hakrawler" "subjack" "dalfox" "gospider" "mapcidr" "shuffledns" "tlsx")

for tool in "${tools[@]}"; do
    if command -v "$tool" &> /dev/null; then
        echo "✅ $tool"
    else
        echo "❌ $tool"
    fi
done
EOF

chmod +x ~/go-tools/verify_tools.sh

print_status "🎯 Installation completed!"
print_status "Run '~/go-tools/verify_tools.sh' to verify all installations"
print_status "Add ~/go/bin to your PATH if not already added"
```

### 🎯 **Tool Usage Examples**

#### **Advanced Reconnaissance Workflow**
```bash
#!/bin/bash
# Save as advanced_recon_workflow.sh

TARGET=$1
if [ -z "$TARGET" ]; then
    echo "Usage: ./advanced_recon_workflow.sh target.com"
    exit 1
fi

echo "🎯 Starting advanced reconnaissance for $TARGET"
mkdir -p $TARGET && cd $TARGET

# Step 1: Subdomain enumeration
echo "🔍 Step 1: Subdomain enumeration..."
subfinder -d $TARGET -silent -o subfinder.txt
assetfinder --subs-only $TARGET > assetfinder.txt
amass enum -passive -d $TARGET -o amass.txt
cat subfinder.txt assetfinder.txt amass.txt | sort -u > all_subdomains.txt

# Step 2: HTTP probing
echo "🌐 Step 2: HTTP probing..."
cat all_subdomains.txt | httpx -silent -ports 80,443,8080,8443 -status-code -title -tech-detect -o live_hosts.txt

# Step 3: URL discovery
echo "🔗 Step 3: URL discovery..."
cat live_hosts.txt | awk '{print $1}' | gau > gau_urls.txt
cat live_hosts.txt | awk '{print $1}' | waybackurls > wayback_urls.txt
cat gau_urls.txt wayback_urls.txt | sort -u > all_urls.txt

# Step 4: Parameter discovery
echo "📝 Step 4: Parameter discovery..."
cat all_urls.txt | grep "=" | unfurl keys | sort -u > parameters.txt

# Step 5: Vulnerability scanning
echo "💥 Step 5: Vulnerability scanning..."
nuclei -l live_hosts.txt -t ~/nuclei-templates/ -o nuclei_results.txt

# Step 6: Technology detection
echo "🔧 Step 6: Technology detection..."
cat live_hosts.txt | awk '{print $1}' | httpx -silent -tech-detect > tech_stack.txt

echo "✅ Advanced reconnaissance completed for $TARGET"
echo "📊 Results:"
echo "  - Subdomains found: $(wc -l < all_subdomains.txt)"
echo "  - Live hosts: $(wc -l < live_hosts.txt)"
echo "  - URLs discovered: $(wc -l < all_urls.txt)"
echo "  - Parameters found: $(wc -l < parameters.txt)"
```

---

## 🔥 **Elite Go Tools Setup Complete!**

Your Go-based reconnaissance arsenal now includes:
- ✅ **40+ Advanced Go Tools**
- ✅ **ProjectDiscovery Complete Suite**
- ✅ **TomNomNom's Essential Tools**
- ✅ **Custom Tool Development Templates**
- ✅ **Automated Installation Scripts**
- ✅ **Advanced Reconnaissance Workflows**

**Next Steps:**
1. Run verification: `~/go-tools/verify_tools.sh`
2. Configure API keys in subfinder config
3. Update nuclei templates regularly
4. Create custom wordlists (next guide)

**Pro Tip:** Keep your Go tools updated with `go install -a std` and regularly update nuclei templates!