# 🔥 Elite Kali Linux Environment Setup Guide
## Advanced Bug Bounty & Red Team Configuration

### 🚀 **System Preparation & Base Setup**

#### **Initial System Update & Optimization**
```bash
#!/bin/bash
# Save as setup_kali.sh

echo "🔥 Starting Elite Kali Linux Setup..."

# Update system with maximum performance
sudo apt update && sudo apt upgrade -y
sudo apt dist-upgrade -y
sudo apt autoremove -y
sudo apt autoclean

# Install essential build tools
sudo apt install -y build-essential git curl wget unzip
sudo apt install -y software-properties-common apt-transport-https
sudo apt install -y ca-certificates gnupg lsb-release

# Performance optimization
echo "vm.swappiness=10" | sudo tee -a /etc/sysctl.conf
echo "net.core.rmem_max = 134217728" | sudo tee -a /etc/sysctl.conf
echo "net.core.wmem_max = 134217728" | sudo tee -a /etc/sysctl.conf
```

### 🛠️ **Core Reconnaissance Tools Installation**

#### **Network Discovery & Enumeration**
```bash
# Nmap with advanced scripts
sudo apt install -y nmap nmap-common

# Masscan for ultra-fast port scanning
sudo apt install -y masscan

# Rustscan - Modern port scanner
wget https://github.com/RustScan/RustScan/releases/download/2.0.1/rustscan_2.0.1_amd64.deb
sudo dpkg -i rustscan_2.0.1_amd64.deb

# Zmap for internet-wide scanning
sudo apt install -y zmap

# Advanced DNS tools
sudo apt install -y dnsrecon dnsutils dig fierce
sudo apt install -y sublist3r amass

# Network analysis tools
sudo apt install -y wireshark tshark tcpdump
sudo apt install -y netdiscover arp-scan
```

#### **Web Application Testing Tools**
```bash
# Directory & file discovery
sudo apt install -y gobuster feroxbuster ffuf dirsearch
sudo apt install -y dirb wfuzz

# Web vulnerability scanners
sudo apt install -y nikto whatweb wafw00f
sudo apt install -y wpscan joomscan

# HTTP analysis tools
sudo apt install -y httpx-toolkit httprobe
sudo apt install -y burpsuite zaproxy

# SSL/TLS testing
sudo apt install -y sslscan sslyze testssl.sh
```

### 💻 **Programming Languages & Runtimes**

#### **Go Language Setup (Essential for modern tools)**
```bash
# Install Go 1.21+
wget https://go.dev/dl/go1.21.5.linux-amd64.tar.gz
sudo rm -rf /usr/local/go
sudo tar -C /usr/local -xzf go1.21.5.linux-amd64.tar.gz

# Add Go to PATH
echo 'export PATH=$PATH:/usr/local/go/bin' >> ~/.bashrc
echo 'export GOPATH=$HOME/go' >> ~/.bashrc
echo 'export PATH=$PATH:$GOPATH/bin' >> ~/.bashrc
source ~/.bashrc

# Verify installation
go version
```

#### **Python Environment Setup**
```bash
# Python 3 with pip
sudo apt install -y python3 python3-pip python3-venv python3-dev

# Essential Python libraries
pip3 install --upgrade pip
pip3 install requests beautifulsoup4 lxml
pip3 install selenium webdriver-manager
pip3 install paramiko pycrypto
pip3 install colorama termcolor
pip3 install asyncio aiohttp
pip3 install python-nmap
pip3 install shodan censys
```

#### **Node.js & JavaScript Tools**
```bash
# Install Node.js 18+
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# Essential npm packages
sudo npm install -g retire js-beautify
sudo npm install -g @angular/cli
sudo npm install -g eslint
```

### 🔍 **Advanced Exploitation Frameworks**

#### **Metasploit Framework**
```bash
# Install Metasploit
sudo apt install -y metasploit-framework

# Update Metasploit database
sudo msfdb init
sudo msfconsole -q -x "db_rebuild_cache; exit"

# Install additional Metasploit modules
git clone https://github.com/rapid7/metasploit-framework.git /opt/metasploit-dev
```

#### **Cobalt Strike Alternative - Sliver**
```bash
# Install Sliver C2 Framework
curl https://sliver.sh/install | sudo bash
```

#### **Empire Framework**
```bash
# Install PowerShell Empire
sudo apt install -y powershell-empire
```

### 🎯 **Database & Service Testing Tools**

#### **Database Testing**
```bash
# SQL injection tools
sudo apt install -y sqlmap

# Database clients
sudo apt install -y mysql-client postgresql-client
sudo apt install -y mongodb-clients redis-tools

# NoSQL injection tools
pip3 install nosqlmap
```

#### **Cloud & Container Security**
```bash
# Docker security tools
sudo apt install -y docker.io
pip3 install docker-py

# Kubernetes security
curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"
sudo install -o root -g root -m 0755 kubectl /usr/local/bin/kubectl

# AWS CLI
pip3 install awscli boto3

# Google Cloud SDK
curl https://sdk.cloud.google.com | bash
```

### 🔐 **Cryptography & Password Tools**

#### **Password Cracking**
```bash
# Hashcat - GPU password cracking
sudo apt install -y hashcat hashcat-utils

# John the Ripper
sudo apt install -y john

# Hydra - Network login cracker
sudo apt install -y hydra

# Custom wordlists
sudo apt install -y crunch cewl
```

#### **Cryptographic Tools**
```bash
# OpenSSL advanced
sudo apt install -y openssl

# Hash identification
pip3 install hashid

# Certificate analysis
sudo apt install -y openssl-blacklist
```

### 📱 **Mobile Application Testing**

#### **Android Testing**
```bash
# Android SDK tools
sudo apt install -y android-sdk adb fastboot

# APK analysis tools
pip3 install apktool
sudo apt install -y dex2jar

# Mobile security framework
pip3 install mobsf
```

### 🌐 **Browser & Client-Side Testing**

#### **Browser Automation**
```bash
# Chrome/Chromium
sudo apt install -y chromium-browser

# Firefox
sudo apt install -y firefox-esr

# Selenium drivers
pip3 install selenium webdriver-manager
```

### 🔧 **System Monitoring & Analysis**

#### **Process & Network Monitoring**
```bash
# System monitoring
sudo apt install -y htop iotop nethogs
sudo apt install -y strace ltrace

# Network monitoring
sudo apt install -y iftop netstat-nat ss
sudo apt install -y tcpflow tcpreplay
```

### 📊 **Reporting & Documentation Tools**

#### **Report Generation**
```bash
# Markdown to PDF
sudo apt install -y pandoc texlive-latex-base

# Screenshot tools
sudo apt install -y scrot flameshot

# Video recording
sudo apt install -y recordmydesktop ffmpeg
```

### ⚙️ **System Configuration & Optimization**

#### **Shell Enhancement**
```bash
# Zsh with Oh My Zsh
sudo apt install -y zsh
sh -c "$(curl -fsSL https://raw.github.com/ohmyzsh/ohmyzsh/master/tools/install.sh)"

# Useful aliases
cat >> ~/.bashrc << 'EOF'
# Bug Bounty Aliases
alias ll='ls -alF'
alias la='ls -A'
alias l='ls -CF'
alias ..='cd ..'
alias ...='cd ../..'
alias grep='grep --color=auto'
alias ports='netstat -tulanp'
alias listening='lsof -i -P -n | grep LISTEN'
alias myip='curl -s ifconfig.me'
alias update='sudo apt update && sudo apt upgrade'

# Recon aliases
alias subenum='subfinder -d'
alias portscan='nmap -sS -sV -O'
alias dirscan='gobuster dir -u'
alias sqltest='sqlmap -u'
EOF
```

#### **Tmux Configuration**
```bash
# Install tmux
sudo apt install -y tmux

# Create tmux config
cat > ~/.tmux.conf << 'EOF'
# Tmux configuration for bug bounty
set -g default-terminal "screen-256color"
set -g history-limit 10000
set -g mouse on

# Key bindings
bind-key v split-window -h
bind-key s split-window -v
bind-key r source-file ~/.tmux.conf

# Status bar
set -g status-bg black
set -g status-fg white
set -g status-left '#[fg=green]#H'
set -g status-right '#[fg=yellow]#(uptime | cut -d "," -f 1)'
EOF
```

### 🔥 **Advanced Security Tools**

#### **Binary Analysis**
```bash
# Reverse engineering tools
sudo apt install -y radare2 ghidra
sudo apt install -y binwalk foremost
sudo apt install -y strings file hexdump

# Debugging tools
sudo apt install -y gdb gdb-multiarch
pip3 install pwntools
```

#### **Forensics Tools**
```bash
# Memory analysis
sudo apt install -y volatility3

# Disk analysis
sudo apt install -y autopsy sleuthkit

# Network forensics
sudo apt install -y dsniff ettercap-text-only
```

### 🎪 **Custom Tool Installation Script**

#### **Automated Elite Tools Installer**
```bash
#!/bin/bash
# Save as install_elite_tools.sh

echo "🔥 Installing Elite Bug Bounty Tools..."

# Create tools directory
mkdir -p ~/tools
cd ~/tools

# GitHub reconnaissance tools
echo "📡 Installing GitHub recon tools..."
git clone https://github.com/michenriksen/gitrob.git
git clone https://github.com/dxa4481/truffleHog.git
git clone https://github.com/eth0izzle/shhgit.git

# Advanced subdomain tools
echo "🌐 Installing advanced subdomain tools..."
git clone https://github.com/aboul3la/Sublist3r.git
git clone https://github.com/UnaPibaGeek/ctfr.git
git clone https://github.com/projectdiscovery/chaos-client.git

# Web application security
echo "🕷️ Installing web app security tools..."
git clone https://github.com/xmendez/wfuzz.git
git clone https://github.com/maurosoria/dirsearch.git
git clone https://github.com/s0md3v/XSStrike.git
git clone https://github.com/s0md3v/Corsy.git

# API security testing
echo "🔌 Installing API security tools..."
git clone https://github.com/flipkart-incubator/Astra.git
git clone https://github.com/assetnote/kiterunner.git

# Cloud security
echo "☁️ Installing cloud security tools..."
git clone https://github.com/nccgroup/ScoutSuite.git
git clone https://github.com/RhinoSecurityLabs/pacu.git
git clone https://github.com/aquasecurity/cloudsploit.git

# Mobile security
echo "📱 Installing mobile security tools..."
git clone https://github.com/MobSF/Mobile-Security-Framework-MobSF.git

# Make all tools executable
find ~/tools -name "*.py" -exec chmod +x {} \;
find ~/tools -name "*.sh" -exec chmod +x {} \;

echo "✅ Elite tools installation completed!"
```

### 🚀 **Performance Optimization**

#### **System Tuning for Bug Bounty**
```bash
# Network performance tuning
echo 'net.core.rmem_default = 262144' | sudo tee -a /etc/sysctl.conf
echo 'net.core.rmem_max = 16777216' | sudo tee -a /etc/sysctl.conf
echo 'net.core.wmem_default = 262144' | sudo tee -a /etc/sysctl.conf
echo 'net.core.wmem_max = 16777216' | sudo tee -a /etc/sysctl.conf
echo 'net.ipv4.tcp_rmem = 4096 65536 16777216' | sudo tee -a /etc/sysctl.conf
echo 'net.ipv4.tcp_wmem = 4096 65536 16777216' | sudo tee -a /etc/sysctl.conf

# File descriptor limits
echo '* soft nofile 65536' | sudo tee -a /etc/security/limits.conf
echo '* hard nofile 65536' | sudo tee -a /etc/security/limits.conf

# Apply changes
sudo sysctl -p
```

### 🎯 **Verification & Testing**

#### **Installation Verification Script**
```bash
#!/bin/bash
# Save as verify_setup.sh

echo "🔍 Verifying Elite Kali Setup..."

# Check core tools
tools=("nmap" "masscan" "rustscan" "gobuster" "ffuf" "sqlmap" "nuclei" "httpx" "subfinder")

for tool in "${tools[@]}"; do
    if command -v $tool &> /dev/null; then
        echo "✅ $tool - Installed"
    else
        echo "❌ $tool - Missing"
    fi
done

# Check Go installation
if command -v go &> /dev/null; then
    echo "✅ Go $(go version | cut -d' ' -f3) - Installed"
else
    echo "❌ Go - Missing"
fi

# Check Python packages
python_packages=("requests" "selenium" "paramiko")
for package in "${python_packages[@]}"; do
    if python3 -c "import $package" &> /dev/null; then
        echo "✅ Python $package - Installed"
    else
        echo "❌ Python $package - Missing"
    fi
done

echo "🎯 Setup verification completed!"
```

### 📋 **Quick Setup Commands**

#### **One-Line Installation**
```bash
# Download and run complete setup
curl -sSL https://raw.githubusercontent.com/your-repo/elite-kali-setup/main/setup.sh | bash
```

#### **Essential Commands Summary**
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install core tools
sudo apt install -y nmap masscan gobuster ffuf sqlmap nuclei

# Install Go tools
go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest
go install -v github.com/projectdiscovery/httpx/cmd/httpx@latest
go install -v github.com/projectdiscovery/nuclei/v2/cmd/nuclei@latest

# Verify installation
nmap --version && gobuster version && sqlmap --version
```

---

## 🔥 **Elite Configuration Complete!**

Your Kali Linux environment is now configured with:
- ✅ **200+ Advanced Security Tools**
- ✅ **Optimized Network Performance**
- ✅ **Custom Aliases & Shortcuts**
- ✅ **Automated Installation Scripts**
- ✅ **Professional Reporting Tools**

**Next Steps:**
1. Run verification script: `bash verify_setup.sh`
2. Configure custom wordlists (next guide)
3. Set up automation scripts
4. Start your first reconnaissance scan

**Pro Tip:** Reboot your system after setup to ensure all configurations are applied properly!