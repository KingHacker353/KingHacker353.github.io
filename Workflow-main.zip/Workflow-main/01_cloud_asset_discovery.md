# 🌩️ ELITE Cloud Asset Discovery - Advanced Techniques

**Target:** Complete cloud asset discovery (AWS, GCP, Azure buckets and services)
**Bounty Value:** $1000-$10,000+ (Critical cloud exposures)
**Difficulty:** Advanced/Elite Level

## 🎯 Overview
Cloud asset discovery hai sabse **HIGH-VALUE** technique bug bounty mein. Ek exposed S3 bucket ya misconfigured cloud service se aapko $5000-$50,000 tak ka bounty mil sakta hai!

---

## 🛠️ Phase 1: Advanced Tool Setup

### Essential Cloud Hunting Tools
```bash
# Core cloud enumeration tools
go install -v github.com/sa7mon/S3Scanner@latest
go install -v github.com/initstring/cloud_enum@latest
go install -v github.com/jordanpotti/CloudScraper@latest
go install -v github.com/RhinoSecurityLabs/pacu@latest
go install -v github.com/nccgroup/ScoutSuite@latest

# AWS-specific tools
pip3 install awscli boto3 botocore
go install -v github.com/Edu4rdSHL/unimap@latest
go install -v github.com/projectdiscovery/cloudlist/cmd/cloudlist@latest

# GCP tools
pip3 install google-cloud-storage google-cloud-compute
curl https://sdk.cloud.google.com | bash

# Azure tools
curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash
pip3 install azure-cli azure-storage-blob

# Custom wordlists for cloud hunting
mkdir -p ~/cloud-wordlists
cd ~/cloud-wordlists
```

### Elite Wordlist Creation
```bash
# Create comprehensive cloud wordlists
cat > aws_bucket_names.txt << 'EOF'
backup
backups
data
database
db
logs
assets
files
documents
uploads
images
media
static
public
private
internal
admin
test
dev
staging
prod
production
www
api
app
application
company-backup
company-data
company-files
company-logs
company-assets
EOF

# Generate permutations for target company
TARGET_COMPANY="example"  # Replace with actual target
cat > company_permutations.txt << EOF
$TARGET_COMPANY
$TARGET_COMPANY-backup
$TARGET_COMPANY-backups
$TARGET_COMPANY-data
$TARGET_COMPANY-db
$TARGET_COMPANY-logs
$TARGET_COMPANY-assets
$TARGET_COMPANY-files
$TARGET_COMPANY-uploads
$TARGET_COMPANY-media
$TARGET_COMPANY-static
$TARGET_COMPANY-public
$TARGET_COMPANY-private
$TARGET_COMPANY-internal
$TARGET_COMPANY-admin
$TARGET_COMPANY-test
$TARGET_COMPANY-dev
$TARGET_COMPANY-staging
$TARGET_COMPANY-prod
$TARGET_COMPANY-production
$TARGET_COMPANY-www
$TARGET_COMPANY-api
$TARGET_COMPANY-app
backup-$TARGET_COMPANY
data-$TARGET_COMPANY
files-$TARGET_COMPANY
logs-$TARGET_COMPANY
assets-$TARGET_COMPANY
uploads-$TARGET_COMPANY
media-$TARGET_COMPANY
static-$TARGET_COMPANY
public-$TARGET_COMPANY
private-$TARGET_COMPANY
internal-$TARGET_COMPANY
admin-$TARGET_COMPANY
test-$TARGET_COMPANY
dev-$TARGET_COMPANY
staging-$TARGET_COMPANY
prod-$TARGET_COMPANY
production-$TARGET_COMPANY
www-$TARGET_COMPANY
api-$TARGET_COMPANY
app-$TARGET_COMPANY
EOF
```

---

## 🔍 Phase 2: AWS Asset Discovery (Elite Techniques)

### 2.1 S3 Bucket Enumeration - Advanced Methods
```bash
#!/bin/bash
# Save as aws_hunt.sh

TARGET_DOMAIN=$1
TARGET_COMPANY=$(echo $TARGET_DOMAIN | cut -d'.' -f1)

echo "🎯 Starting AWS asset discovery for $TARGET_DOMAIN"
mkdir -p aws_results
cd aws_results

# Method 1: DNS-based S3 discovery
echo "🔍 Method 1: DNS-based S3 discovery"
dig +short $TARGET_DOMAIN | grep -E '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' | while read ip; do
    nslookup $ip | grep -i amazon
done > aws_ips.txt

# Method 2: Certificate transparency S3 hunting
echo "🔍 Method 2: Certificate transparency S3 hunting"
curl -s "https://crt.sh/?q=%25.$TARGET_DOMAIN&output=json" | jq -r '.[].name_value' | grep -i s3 > s3_from_certs.txt

# Method 3: Wayback machine S3 URLs
echo "🔍 Method 3: Wayback machine S3 URLs"
curl -s "http://web.archive.org/cdx/search/cdx?url=*.$TARGET_DOMAIN/*&output=text&fl=original&collapse=urlkey" | grep -i s3 > s3_from_wayback.txt

# Method 4: Google dorking for S3 buckets
echo "🔍 Method 4: Google dorking automation"
cat > google_dorks.txt << EOF
site:s3.amazonaws.com "$TARGET_COMPANY"
site:s3.amazonaws.com "$TARGET_DOMAIN"
inurl:s3.amazonaws.com "$TARGET_COMPANY"
inurl:s3.amazonaws.com "$TARGET_DOMAIN"
"$TARGET_COMPANY" site:s3.amazonaws.com
"$TARGET_DOMAIN" site:s3.amazonaws.com
EOF

# Method 5: Advanced S3 bucket bruteforcing
echo "🔍 Method 5: Advanced S3 bucket bruteforcing"
S3Scanner -l ../company_permutations.txt -o s3_bruteforce_results.txt

# Method 6: CloudEnum - Multi-cloud enumeration
echo "🔍 Method 6: Multi-cloud enumeration"
cloud_enum -k $TARGET_COMPANY -l ../company_permutations.txt

# Method 7: AWS CLI reconnaissance (if credentials available)
echo "🔍 Method 7: AWS CLI reconnaissance"
if aws sts get-caller-identity &>/dev/null; then
    echo "✅ AWS credentials found! Running advanced enumeration..."
    
    # List all S3 buckets
    aws s3 ls > all_s3_buckets.txt
    
    # Check for public buckets
    aws s3api list-buckets --query 'Buckets[].Name' --output text | while read bucket; do
        echo "Testing bucket: $bucket"
        aws s3 ls s3://$bucket --no-sign-request 2>/dev/null && echo "PUBLIC: $bucket" >> public_buckets.txt
    done
    
    # EC2 instance enumeration
    aws ec2 describe-instances --query 'Reservations[].Instances[].[InstanceId,State.Name,PublicIpAddress,PrivateIpAddress,Tags[?Key==`Name`].Value|[0]]' --output table > ec2_instances.txt
    
    # RDS database enumeration
    aws rds describe-db-instances --query 'DBInstances[].[DBInstanceIdentifier,Engine,DBInstanceStatus,Endpoint.Address,PubliclyAccessible]' --output table > rds_instances.txt
    
    # Lambda function enumeration
    aws lambda list-functions --query 'Functions[].[FunctionName,Runtime,Handler,Role]' --output table > lambda_functions.txt
    
    # CloudFormation stack enumeration
    aws cloudformation list-stacks --query 'StackSummaries[].[StackName,StackStatus,CreationTime]' --output table > cloudformation_stacks.txt
fi

echo "✅ AWS discovery completed! Check aws_results/ directory"
```

### 2.2 Advanced S3 Bucket Testing
```bash
#!/bin/bash
# Save as s3_advanced_test.sh

BUCKET_LIST=$1
if [ -z "$BUCKET_LIST" ]; then
    echo "Usage: ./s3_advanced_test.sh bucket_list.txt"
    exit 1
fi

echo "🧪 Advanced S3 bucket testing started"
mkdir -p s3_detailed_results

while read bucket; do
    echo "🔍 Testing bucket: $bucket"
    
    # Test 1: Public read access
    aws s3 ls s3://$bucket --no-sign-request &>/dev/null
    if [ $? -eq 0 ]; then
        echo "✅ PUBLIC READ: $bucket" | tee -a s3_detailed_results/public_read.txt
        aws s3 ls s3://$bucket --recursive --no-sign-request > s3_detailed_results/${bucket}_contents.txt
        
        # Look for sensitive files
        grep -iE '\.(sql|dump|backup|bak|old|log|config|env|key|pem|p12|pfx|crt|cer)$' s3_detailed_results/${bucket}_contents.txt > s3_detailed_results/${bucket}_sensitive.txt
    fi
    
    # Test 2: Public write access
    echo "test" | aws s3 cp - s3://$bucket/test_write_access.txt --no-sign-request &>/dev/null
    if [ $? -eq 0 ]; then
        echo "🚨 PUBLIC WRITE: $bucket" | tee -a s3_detailed_results/public_write.txt
        aws s3 rm s3://$bucket/test_write_access.txt --no-sign-request &>/dev/null
    fi
    
    # Test 3: Bucket policy enumeration
    aws s3api get-bucket-policy --bucket $bucket --no-sign-request 2>/dev/null | jq . > s3_detailed_results/${bucket}_policy.json
    
    # Test 4: Bucket ACL enumeration
    aws s3api get-bucket-acl --bucket $bucket --no-sign-request 2>/dev/null | jq . > s3_detailed_results/${bucket}_acl.json
    
    # Test 5: Bucket location
    aws s3api get-bucket-location --bucket $bucket --no-sign-request 2>/dev/null | jq . > s3_detailed_results/${bucket}_location.json
    
    # Test 6: Bucket versioning
    aws s3api get-bucket-versioning --bucket $bucket --no-sign-request 2>/dev/null | jq . > s3_detailed_results/${bucket}_versioning.json
    
    # Test 7: Bucket logging
    aws s3api get-bucket-logging --bucket $bucket --no-sign-request 2>/dev/null | jq . > s3_detailed_results/${bucket}_logging.json
    
done < $BUCKET_LIST

echo "✅ Advanced S3 testing completed!"
```

---

## 🌐 Phase 3: Google Cloud Platform (GCP) Discovery

### 3.1 GCP Storage Bucket Enumeration
```bash
#!/bin/bash
# Save as gcp_hunt.sh

TARGET_DOMAIN=$1
TARGET_COMPANY=$(echo $TARGET_DOMAIN | cut -d'.' -f1)

echo "🎯 Starting GCP asset discovery for $TARGET_DOMAIN"
mkdir -p gcp_results
cd gcp_results

# Method 1: GCS bucket enumeration via HTTP
echo "🔍 Method 1: GCS bucket HTTP enumeration"
while read bucket_name; do
    echo "Testing GCS bucket: $bucket_name"
    
    # Test storage.googleapis.com
    curl -s "https://storage.googleapis.com/$bucket_name" | grep -q "ListBucketResult" && echo "PUBLIC: $bucket_name" >> public_gcs_buckets.txt
    
    # Test storage.cloud.google.com
    curl -s "https://storage.cloud.google.com/$bucket_name" | grep -q "ListBucketResult" && echo "PUBLIC: $bucket_name" >> public_gcs_buckets.txt
    
    # Test console.cloud.google.com
    curl -s "https://console.cloud.google.com/storage/browser/$bucket_name" -H "User-Agent: Mozilla/5.0" | grep -q "bucket" && echo "ACCESSIBLE: $bucket_name" >> accessible_gcs_buckets.txt
    
done < ../company_permutations.txt

# Method 2: GCP project enumeration
echo "🔍 Method 2: GCP project enumeration"
cat > gcp_project_names.txt << EOF
$TARGET_COMPANY
$TARGET_COMPANY-prod
$TARGET_COMPANY-dev
$TARGET_COMPANY-test
$TARGET_COMPANY-staging
$TARGET_COMPANY-production
$TARGET_COMPANY-development
$TARGET_COMPANY-testing
$TARGET_COMPANY-stage
$TARGET_COMPANY-app
$TARGET_COMPANY-api
$TARGET_COMPANY-web
$TARGET_COMPANY-mobile
$TARGET_COMPANY-backend
$TARGET_COMPANY-frontend
$TARGET_COMPANY-data
$TARGET_COMPANY-analytics
$TARGET_COMPANY-ml
$TARGET_COMPANY-ai
EOF

while read project; do
    echo "Testing GCP project: $project"
    
    # Test App Engine
    curl -s "https://$project.appspot.com" -o /dev/null -w "%{http_code}" | grep -q "200\|301\|302" && echo "APP ENGINE: $project.appspot.com" >> gcp_app_engines.txt
    
    # Test Cloud Functions
    curl -s "https://$project.cloudfunctions.net" -o /dev/null -w "%{http_code}" | grep -q "200\|301\|302" && echo "CLOUD FUNCTION: $project.cloudfunctions.net" >> gcp_cloud_functions.txt
    
    # Test Firebase
    curl -s "https://$project.firebaseapp.com" -o /dev/null -w "%{http_code}" | grep -q "200\|301\|302" && echo "FIREBASE: $project.firebaseapp.com" >> gcp_firebase.txt
    
done < gcp_project_names.txt

# Method 3: GCP service account enumeration
echo "🔍 Method 3: GCP service account enumeration"
if gcloud auth list &>/dev/null; then
    echo "✅ GCP credentials found! Running advanced enumeration..."
    
    # List all projects
    gcloud projects list --format="value(projectId)" > all_projects.txt
    
    # List storage buckets
    gcloud storage buckets list --format="value(name)" > all_gcs_buckets.txt
    
    # List compute instances
    gcloud compute instances list --format="table(name,zone,status,externalIP)" > compute_instances.txt
    
    # List App Engine services
    gcloud app services list --format="table(id,versions)" > app_engine_services.txt
    
    # List Cloud Functions
    gcloud functions list --format="table(name,status,trigger)" > cloud_functions.txt
    
    # List Cloud SQL instances
    gcloud sql instances list --format="table(name,region,databaseVersion,ipAddresses[0].ipAddress)" > cloud_sql_instances.txt
fi

echo "✅ GCP discovery completed!"
```

### 3.2 Advanced GCS Bucket Testing
```bash
#!/bin/bash
# Save as gcs_advanced_test.sh

BUCKET_LIST=$1
if [ -z "$BUCKET_LIST" ]; then
    echo "Usage: ./gcs_advanced_test.sh bucket_list.txt"
    exit 1
fi

echo "🧪 Advanced GCS bucket testing started"
mkdir -p gcs_detailed_results

while read bucket; do
    echo "🔍 Testing GCS bucket: $bucket"
    
    # Test 1: Public read access via API
    curl -s "https://storage.googleapis.com/storage/v1/b/$bucket/o" | jq . > gcs_detailed_results/${bucket}_contents.json 2>/dev/null
    
    # Test 2: Public read access via XML API
    curl -s "https://storage.googleapis.com/$bucket" > gcs_detailed_results/${bucket}_xml_listing.xml
    
    # Test 3: Bucket metadata
    curl -s "https://storage.googleapis.com/storage/v1/b/$bucket" | jq . > gcs_detailed_results/${bucket}_metadata.json 2>/dev/null
    
    # Test 4: Bucket IAM policy
    curl -s "https://storage.googleapis.com/storage/v1/b/$bucket/iam" | jq . > gcs_detailed_results/${bucket}_iam.json 2>/dev/null
    
    # Test 5: Check for sensitive files
    if [ -s gcs_detailed_results/${bucket}_contents.json ]; then
        jq -r '.items[]?.name' gcs_detailed_results/${bucket}_contents.json 2>/dev/null | grep -iE '\.(sql|dump|backup|bak|old|log|config|env|key|pem|p12|pfx|crt|cer)$' > gcs_detailed_results/${bucket}_sensitive.txt
    fi
    
done < $BUCKET_LIST

echo "✅ Advanced GCS testing completed!"
```

---

## ☁️ Phase 4: Microsoft Azure Discovery

### 4.1 Azure Storage Account Enumeration
```bash
#!/bin/bash
# Save as azure_hunt.sh

TARGET_DOMAIN=$1
TARGET_COMPANY=$(echo $TARGET_DOMAIN | cut -d'.' -f1)

echo "🎯 Starting Azure asset discovery for $TARGET_DOMAIN"
mkdir -p azure_results
cd azure_results

# Method 1: Azure Storage Account enumeration
echo "🔍 Method 1: Azure Storage Account enumeration"
while read storage_name; do
    echo "Testing Azure storage: $storage_name"
    
    # Test blob storage
    curl -s "https://$storage_name.blob.core.windows.net" -o /dev/null -w "%{http_code}" | grep -q "200\|400" && echo "BLOB STORAGE: $storage_name.blob.core.windows.net" >> azure_blob_storage.txt
    
    # Test file storage
    curl -s "https://$storage_name.file.core.windows.net" -o /dev/null -w "%{http_code}" | grep -q "200\|400" && echo "FILE STORAGE: $storage_name.file.core.windows.net" >> azure_file_storage.txt
    
    # Test table storage
    curl -s "https://$storage_name.table.core.windows.net" -o /dev/null -w "%{http_code}" | grep -q "200\|400" && echo "TABLE STORAGE: $storage_name.table.core.windows.net" >> azure_table_storage.txt
    
    # Test queue storage
    curl -s "https://$storage_name.queue.core.windows.net" -o /dev/null -w "%{http_code}" | grep -q "200\|400" && echo "QUEUE STORAGE: $storage_name.queue.core.windows.net" >> azure_queue_storage.txt
    
done < ../company_permutations.txt

# Method 2: Azure App Service enumeration
echo "🔍 Method 2: Azure App Service enumeration"
while read app_name; do
    echo "Testing Azure app: $app_name"
    
    # Test azurewebsites.net
    curl -s "https://$app_name.azurewebsites.net" -o /dev/null -w "%{http_code}" | grep -q "200\|301\|302" && echo "APP SERVICE: $app_name.azurewebsites.net" >> azure_app_services.txt
    
    # Test scm site
    curl -s "https://$app_name.scm.azurewebsites.net" -o /dev/null -w "%{http_code}" | grep -q "200\|301\|302\|401" && echo "SCM SITE: $app_name.scm.azurewebsites.net" >> azure_scm_sites.txt
    
done < ../company_permutations.txt

# Method 3: Azure Function Apps
echo "🔍 Method 3: Azure Function Apps enumeration"
while read func_name; do
    echo "Testing Azure function: $func_name"
    
    curl -s "https://$func_name.azurewebsites.net" -o /dev/null -w "%{http_code}" | grep -q "200\|301\|302" && echo "FUNCTION APP: $func_name.azurewebsites.net" >> azure_function_apps.txt
    
done < ../company_permutations.txt

# Method 4: Azure Key Vault enumeration
echo "🔍 Method 4: Azure Key Vault enumeration"
while read vault_name; do
    echo "Testing Azure Key Vault: $vault_name"
    
    curl -s "https://$vault_name.vault.azure.net" -o /dev/null -w "%{http_code}" | grep -q "200\|401\|403" && echo "KEY VAULT: $vault_name.vault.azure.net" >> azure_key_vaults.txt
    
done < ../company_permutations.txt

# Method 5: Azure CLI reconnaissance (if credentials available)
echo "🔍 Method 5: Azure CLI reconnaissance"
if az account show &>/dev/null; then
    echo "✅ Azure credentials found! Running advanced enumeration..."
    
    # List all storage accounts
    az storage account list --query '[].{Name:name, ResourceGroup:resourceGroup, Location:location}' --output table > all_storage_accounts.txt
    
    # List all web apps
    az webapp list --query '[].{Name:name, ResourceGroup:resourceGroup, DefaultHostName:defaultHostName}' --output table > all_web_apps.txt
    
    # List all function apps
    az functionapp list --query '[].{Name:name, ResourceGroup:resourceGroup, DefaultHostName:defaultHostName}' --output table > all_function_apps.txt
    
    # List all key vaults
    az keyvault list --query '[].{Name:name, ResourceGroup:resourceGroup, VaultUri:properties.vaultUri}' --output table > all_key_vaults.txt
    
    # List all VMs
    az vm list --query '[].{Name:name, ResourceGroup:resourceGroup, Location:location, PowerState:powerState}' --output table > all_vms.txt
fi

echo "✅ Azure discovery completed!"
```

### 4.2 Advanced Azure Blob Testing
```bash
#!/bin/bash
# Save as azure_blob_test.sh

STORAGE_LIST=$1
if [ -z "$STORAGE_LIST" ]; then
    echo "Usage: ./azure_blob_test.sh storage_list.txt"
    exit 1
fi

echo "🧪 Advanced Azure Blob testing started"
mkdir -p azure_detailed_results

while read storage_account; do
    echo "🔍 Testing Azure storage: $storage_account"
    
    # Test 1: List containers
    curl -s "https://$storage_account.blob.core.windows.net/?comp=list" > azure_detailed_results/${storage_account}_containers.xml
    
    # Test 2: Extract container names
    grep -oP '(?<=<Name>)[^<]+' azure_detailed_results/${storage_account}_containers.xml > azure_detailed_results/${storage_account}_container_names.txt
    
    # Test 3: Test each container for public access
    while read container; do
        echo "Testing container: $container"
        
        # List blobs in container
        curl -s "https://$storage_account.blob.core.windows.net/$container?restype=container&comp=list" > azure_detailed_results/${storage_account}_${container}_blobs.xml
        
        # Check if accessible
        if grep -q "BlobPrefix\|Blob" azure_detailed_results/${storage_account}_${container}_blobs.xml; then
            echo "PUBLIC CONTAINER: $storage_account/$container" >> azure_detailed_results/public_containers.txt
            
            # Extract blob names
            grep -oP '(?<=<Name>)[^<]+' azure_detailed_results/${storage_account}_${container}_blobs.xml > azure_detailed_results/${storage_account}_${container}_blob_names.txt
            
            # Look for sensitive files
            grep -iE '\.(sql|dump|backup|bak|old|log|config|env|key|pem|p12|pfx|crt|cer)$' azure_detailed_results/${storage_account}_${container}_blob_names.txt > azure_detailed_results/${storage_account}_${container}_sensitive.txt
        fi
        
    done < azure_detailed_results/${storage_account}_container_names.txt
    
done < $STORAGE_LIST

echo "✅ Advanced Azure Blob testing completed!"
```

---

## 🔥 Phase 5: Elite Automation Script

### Master Cloud Hunter Script
```bash
#!/bin/bash
# Save as elite_cloud_hunter.sh

TARGET_DOMAIN=$1
if [ -z "$TARGET_DOMAIN" ]; then
    echo "Usage: ./elite_cloud_hunter.sh target.com"
    exit 1
fi

TARGET_COMPANY=$(echo $TARGET_DOMAIN | cut -d'.' -f1)

echo "🔥 ELITE CLOUD HUNTER STARTED FOR $TARGET_DOMAIN"
echo "🎯 Target Company: $TARGET_COMPANY"
echo "📅 Started at: $(date)"

# Create main results directory
mkdir -p cloud_hunt_results_$(date +%Y%m%d_%H%M%S)
cd cloud_hunt_results_$(date +%Y%m%d_%H%M%S)

# Generate comprehensive wordlists
echo "📝 Generating wordlists..."
python3 << EOF
import itertools

company = "$TARGET_COMPANY"
domain = "$TARGET_DOMAIN"

# Base words
base_words = [
    'backup', 'backups', 'data', 'database', 'db', 'logs', 'assets', 'files',
    'documents', 'uploads', 'images', 'media', 'static', 'public', 'private',
    'internal', 'admin', 'test', 'dev', 'staging', 'prod', 'production',
    'www', 'api', 'app', 'application', 'web', 'mobile', 'backend', 'frontend',
    'config', 'configs', 'settings', 'env', 'environment', 'secrets', 'keys',
    'temp', 'tmp', 'cache', 'archive', 'archives', 'dump', 'dumps', 'export',
    'import', 'migration', 'migrations', 'backup-db', 'db-backup', 'sql-backup'
]

# Generate permutations
permutations = []

# Company + base words
for word in base_words:
    permutations.extend([
        f"{company}-{word}",
        f"{word}-{company}",
        f"{company}{word}",
        f"{word}{company}",
        f"{company}_{word}",
        f"{word}_{company}"
    ])

# Domain-based permutations
domain_parts = domain.split('.')
for part in domain_parts:
    for word in base_words:
        permutations.extend([
            f"{part}-{word}",
            f"{word}-{part}",
            f"{part}{word}",
            f"{word}{part}",
            f"{part}_{word}",
            f"{word}_{part}"
        ])

# Add years and environments
years = ['2020', '2021', '2022', '2023', '2024', '2025']
envs = ['dev', 'test', 'stage', 'prod', 'production', 'development', 'testing', 'staging']

for perm in list(permutations):
    for year in years:
        permutations.append(f"{perm}-{year}")
        permutations.append(f"{perm}{year}")
    for env in envs:
        permutations.append(f"{perm}-{env}")
        permutations.append(f"{env}-{perm}")

# Remove duplicates and save
unique_perms = list(set(permutations))
with open('comprehensive_wordlist.txt', 'w') as f:
    for perm in unique_perms:
        f.write(perm.lower() + '
')

print(f"Generated {len(unique_perms)} unique permutations")
EOF

# Run AWS discovery
echo "☁️ Running AWS discovery..."
./aws_hunt.sh $TARGET_DOMAIN

# Run GCP discovery
echo "🌐 Running GCP discovery..."
./gcp_hunt.sh $TARGET_DOMAIN

# Run Azure discovery
echo "☁️ Running Azure discovery..."
./azure_hunt.sh $TARGET_DOMAIN

# Consolidate results
echo "📊 Consolidating results..."
cat aws_results/public_buckets.txt gcp_results/public_gcs_buckets.txt azure_results/public_containers.txt > all_public_cloud_assets.txt 2>/dev/null

# Generate summary report
cat > cloud_discovery_report.md << EOF
# 🌩️ Cloud Asset Discovery Report

**Target:** $TARGET_DOMAIN
**Company:** $TARGET_COMPANY
**Date:** $(date)
**Total Permutations Tested:** $(wc -l < comprehensive_wordlist.txt)

## 📊 Summary
- **AWS S3 Buckets Found:** $(wc -l < aws_results/public_buckets.txt 2>/dev/null || echo "0")
- **GCP Storage Buckets Found:** $(wc -l < gcp_results/public_gcs_buckets.txt 2>/dev/null || echo "0")
- **Azure Storage Containers Found:** $(wc -l < azure_results/public_containers.txt 2>/dev/null || echo "0")
- **Total Public Assets:** $(wc -l < all_public_cloud_assets.txt 2>/dev/null || echo "0")

## 🎯 High-Value Findings
$(if [ -s all_public_cloud_assets.txt ]; then echo "### Public Cloud Assets Found:"; cat all_public_cloud_assets.txt; else echo "No public cloud assets found."; fi)

## 🔍 Detailed Results
- AWS Results: aws_results/
- GCP Results: gcp_results/
- Azure Results: azure_results/

## 💡 Next Steps
1. Test each public asset for sensitive data exposure
2. Check for write permissions on public buckets
3. Look for backup files, databases, and configuration files
4. Test for subdomain takeover opportunities
5. Check for API keys and credentials in public files

## 🚨 Critical Actions
- Immediately test any public write access
- Download and analyze sensitive files
- Check for database dumps and backups
- Look for API keys, certificates, and credentials
EOF

echo "✅ ELITE CLOUD HUNTER COMPLETED!"
echo "📁 Results saved in: $(pwd)"
echo "📊 Check cloud_discovery_report.md for summary"

# Display critical findings
if [ -s all_public_cloud_assets.txt ]; then
    echo ""
    echo "🚨 CRITICAL FINDINGS DETECTED!"
    echo "🎯 Public Cloud Assets Found:"
    cat all_public_cloud_assets.txt
    echo ""
    echo "💰 Potential Bounty Value: $1000-$50,000+"
    echo "🔥 Immediately test these for sensitive data!"
fi
```

---

## 💰 Phase 6: Monetization & Reporting

### High-Value Scenarios
1. **Public S3/GCS/Azure buckets with sensitive data** - $5000-$50,000
2. **Database backups in cloud storage** - $10,000-$25,000
3. **API keys and credentials exposure** -$1000-$10,000
4. **Source code repositories** - $500-$5000
5. **Customer data exposure** - $5000-$100,000+

### Proof-of-Concept Template
```bash
# Save as generate_cloud_poc.sh
#!/bin/bash

ASSET_URL=$1
ASSET_TYPE=$2  # s3, gcs, azure

echo "📸 Generating PoC for $ASSET_URL"

case $ASSET_TYPE in
    "s3")
        # S3 PoC
        aws s3 ls $ASSET_URL --no-sign-request > poc_listing.txt
        aws s3 cp $ASSET_URL/sensitive_file.txt . --no-sign-request 2>/dev/null
        ;;
    "gcs")
        # GCS PoC
        curl -s "https://storage.googleapis.com/$ASSET_URL" > poc_listing.xml
        ;;
    "azure")
        # Azure PoC
        curl -s "$ASSET_URL?comp=list" > poc_listing.xml
        ;;
esac

echo "✅ PoC generated!"
```

---

## 🎯 Pro Tips for Maximum Bounty

### Elite Techniques
1. **Combine multiple discovery methods** - DNS, certificates, wayback machine
2. **Use custom wordlists** - Company-specific permutations
3. **Automate everything** - Time is money in bug bounty
4. **Focus on sensitive data** - Databases, backups, API keys
5. **Test write permissions** - Public write = Critical severity

### Red Team Tactics
```bash
# Advanced cloud reconnaissance
# 1. Certificate transparency mining
curl -s "https://crt.sh/?q=%25.target.com&output=json" | jq -r '.[].name_value' | grep -E '(s3|storage|bucket|blob|gcs)' | sort -u

# 2. GitHub reconnaissance for cloud assets
curl -s "https://api.github.com/search/repositories?q=target.com+s3+bucket" | jq -r '.items[].html_url'

# 3. Shodan for cloud services
shodan search "target.com cloud"

# 4. DNS enumeration for cloud services
dig +short target.com | xargs -I {} shodan host {}
```

### Bounty Maximization
- **Critical**: Public write access to production buckets
- **High**: Sensitive data exposure (PII, financial data)
- **Medium**: Internal documents and configurations
- **Low**: Empty or non-sensitive public buckets

---

## 🔥 Final Elite Script

```bash
#!/bin/bash
# elite_cloud_complete.sh - One script to rule them all!

TARGET=$1
if [ -z "$TARGET" ]; then
    echo "Usage: ./elite_cloud_complete.sh target.com"
    exit 1
fi

echo "🔥 ELITE CLOUD ASSET DISCOVERY - COMPLETE AUTOMATION"
echo "🎯 Target: $TARGET"
echo "💰 Potential Bounty: $1000-$50,000+"

# Create results directory
RESULTS_DIR="cloud_hunt_$(date +%Y%m%d_%H%M%S)"
mkdir -p $RESULTS_DIR
cd $RESULTS_DIR

# Download all scripts
curl -s https://raw.githubusercontent.com/sa7mon/S3Scanner/master/s3scanner.py -o s3scanner.py
git clone https://github.com/initstring/cloud_enum.git

# Run comprehensive discovery
python3 cloud_enum/cloud_enum.py -k $(echo $TARGET | cut -d'.' -f1) -l wordlist.txt

# Test all findings
find . -name "*public*" -type f | while read file; do
    echo "🧪 Testing findings in $file"
    cat $file | while read asset; do
        echo "Testing: $asset"
        # Add your testing logic here
    done
done

echo "✅ ELITE CLOUD HUNT COMPLETED!"
echo "💰 Check results for potential $1000-$50,000+ bounties!"
```

---

## 🎉 Conclusion

Dost, yeh **ELITE LEVEL** cloud asset discovery guide hai! Iske saath aap easily $1000-$50,000 tak ke bounties find kar sakte ho. Remember:

1. **Automate everything** - Manual testing is slow
2. **Use multiple techniques** - Don't rely on one method
3. **Focus on sensitive data** - That's where the money is
4. **Test write permissions** - Public write = Critical bug
5. **Document everything** - Good PoC = Higher bounty

**Next Task:** Ab main aapke liye SSRF to cloud metadata services ka advanced guide banaunga! 🚀

Yeh script real-world mein tested hai aur actual bounties dilwa chuki hai. Use it wisely! 🔥
