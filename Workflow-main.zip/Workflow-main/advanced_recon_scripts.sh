#!/bin/bash
# 🔍 Advanced Reconnaissance Scripts - Elite Bug Bounty Methodology
# Bhai, yeh scripts tumhe deep reconnaissance denge jo elite hackers use karte hain

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

TARGET=$1
if [ -z "$TARGET" ]; then
    echo -e "${RED}Usage: ./advanced_recon_scripts.sh target.com${NC}"
    exit 1
fi

echo -e "${GREEN}🔥 Starting Advanced Recon for $TARGET${NC}"
mkdir -p $TARGET/{subdomains,ports,content,vulnerabilities,secrets}
cd $TARGET

# Function: Multi-source subdomain enumeration
subdomain_enum() {
    echo -e "${BLUE}🎯 Phase 1: Multi-Source Subdomain Enumeration${NC}"
    
    # Passive enumeration (6 sources)
    echo -e "${YELLOW}[+] Running Subfinder...${NC}"
    subfinder -d $TARGET -silent -o subdomains/subfinder.txt
    
    echo -e "${YELLOW}[+] Running Amass...${NC}"
    amass enum -passive -d $TARGET -o subdomains/amass.txt
    
    echo -e "${YELLOW}[+] Running Assetfinder...${NC}"
    assetfinder --subs-only $TARGET > subdomains/assetfinder.txt
    
    echo -e "${YELLOW}[+] Certificate Transparency...${NC}"
    curl -s "https://crt.sh/?q=%25.$TARGET&output=json" | jq -r '.[].name_value' | sed 's/\*\.//g' | sort -u > subdomains/crt.txt
    
    echo -e "${YELLOW}[+] Chaos API...${NC}"
    curl -s "https://dns.bufferover.run/dns?q=.$TARGET" | jq -r '.FDNS_A[]' | cut -d',' -f2 | sort -u > subdomains/chaos.txt
    
    echo -e "${YELLOW}[+] RapidDNS...${NC}"
    curl -s "https://rapiddns.io/subdomain/$TARGET?full=1" | grep -oP '_blank">\K[^<]*' | grep -v $TARGET | sort -u > subdomains/rapiddns.txt
    
    # Combine all results
    cat subdomains/*.txt | sort -u > subdomains/all_subdomains.txt
    echo -e "${GREEN}✅ Found $(wc -l < subdomains/all_subdomains.txt) unique subdomains${NC}"
    
    # Active subdomain bruteforcing
    echo -e "${YELLOW}[+] Active subdomain bruteforcing...${NC}"
    gobuster dns -d $TARGET -w ~/wordlists/SecLists/Discovery/DNS/subdomains-top1million-5000.txt -o subdomains/gobuster.txt --quiet
    
    # Combine active + passive
    cat subdomains/all_subdomains.txt subdomains/gobuster.txt | grep $TARGET | sort -u > subdomains/final_subdomains.txt
    echo -e "${GREEN}✅ Final subdomain count: $(wc -l < subdomains/final_subdomains.txt)${NC}"
}

# Function: Advanced port scanning
port_scanning() {
    echo -e "${BLUE}🎯 Phase 2: Advanced Port Scanning${NC}"
    
    # Check live hosts first
    echo -e "${YELLOW}[+] Checking live hosts...${NC}"
    cat subdomains/final_subdomains.txt | httpx -silent -ports 80,443,8080,8443,8000,9000,3000,5000 -status-code -title -tech-detect -o ports/live_hosts.txt
    cat ports/live_hosts.txt | awk '{print $1}' > ports/live_urls.txt
    echo -e "${GREEN}✅ Found $(wc -l < ports/live_urls.txt) live hosts${NC}"
    
    # Fast port scan with rustscan
    echo -e "${YELLOW}[+] Fast port scanning with rustscan...${NC}"
    for host in $(cat ports/live_urls.txt | sed 's/https\?:\/\///g' | cut -d'/' -f1 | head -10); do
        echo "Scanning: $host"
        rustscan -a $host --ulimit 5000 --range 1-65535 -- -sV -sC -oN ports/nmap_$host.txt &
    done
    wait
    
    # Service-specific scans
    echo -e "${YELLOW}[+] Service-specific scanning...${NC}"
    
    # Web services
    nmap -iL <(cat ports/live_urls.txt | sed 's/https\?:\/\///g' | cut -d'/' -f1) -p 80,443,8080,8443 --script http-enum,http-headers,http-methods,http-robots.txt -oN ports/web_services.txt
    
    # Database services
    nmap -iL <(cat ports/live_urls.txt | sed 's/https\?:\/\///g' | cut -d'/' -f1) -p 3306,5432,1433,27017,6379 --script *-info -oN ports/database_services.txt
    
    # SSL/TLS analysis
    nmap -iL <(cat ports/live_urls.txt | sed 's/https\?:\/\///g' | cut -d'/' -f1) -p 443 --script ssl-enum-ciphers,ssl-cert,ssl-heartbleed -oN ports/ssl_analysis.txt
}

# Function: Web technology analysis
tech_analysis() {
    echo -e "${BLUE}🎯 Phase 3: Web Technology Analysis${NC}"
    
    # Technology detection
    echo -e "${YELLOW}[+] Technology stack detection...${NC}"
    cat ports/live_urls.txt | httpx -silent -tech-detect -status-code -content-length -o content/tech_stack.txt
    
    # Whatweb analysis
    echo -e "${YELLOW}[+] Whatweb analysis...${NC}"
    whatweb -i ports/live_urls.txt --log-brief=content/whatweb.txt
    
    # Wappalyzer-like detection
    echo -e "${YELLOW}[+] Advanced technology detection...${NC}"
    for url in $(cat ports/live_urls.txt | head -20); do
        echo "Analyzing: $url"
        curl -s -I "$url" | grep -i "server\|x-powered-by\|x-generator" >> content/headers_analysis.txt
        curl -s "$url" | grep -i "wordpress\|drupal\|joomla\|laravel\|django\|rails" >> content/cms_detection.txt
    done
}

# Function: Content discovery with custom wordlists
content_discovery() {
    echo -e "${BLUE}🎯 Phase 4: Advanced Content Discovery${NC}"
    
    # Create custom wordlist based on target
    echo -e "${YELLOW}[+] Creating custom wordlists...${NC}"
    
    # Extract words from main page
    for url in $(cat ports/live_urls.txt | head -5); do
        curl -s "$url" | html2text | tr ' ' '\n' | grep -v '^$' | sort -u >> content/custom_words.txt
    done
    
    # Combine with common wordlists
    cat ~/wordlists/SecLists/Discovery/Web-Content/common.txt content/custom_words.txt | sort -u > content/combined_wordlist.txt
    
    # Directory bruteforcing with multiple tools
    echo -e "${YELLOW}[+] Directory bruteforcing...${NC}"
    
    # Feroxbuster (Rust-based, fast)
    for url in $(cat ports/live_urls.txt | head -10); do
        echo "Feroxbuster on: $url"
        feroxbuster -u "$url" -w content/combined_wordlist.txt -x php,html,js,txt,xml,json -t 50 -C 404,403 -o content/ferox_$url.txt &
    done
    
    # Gobuster
    for url in $(cat ports/live_urls.txt | head -10); do
        echo "Gobuster on: $url"
        gobuster dir -u "$url" -w content/combined_wordlist.txt -x php,html,js,txt,xml,json -t 50 -o content/gobuster_$url.txt &
    done
    
    wait
    
    # API endpoint discovery
    echo -e "${YELLOW}[+] API endpoint discovery...${NC}"
    
    # Common API paths
    cat > content/api_wordlist.txt << 'EOF'
api
api/v1
api/v2
api/v3
graphql
swagger
swagger.json
swagger.yaml
api-docs
openapi.json
rest
restapi
webapi
admin/api
internal/api
dev/api
test/api
staging/api
EOF
    
    for url in $(cat ports/live_urls.txt | head -10); do
        echo "API discovery on: $url"
        ffuf -w content/api_wordlist.txt -u "$url/FUZZ" -mc 200,301,302,403 -t 50 -o content/api_$url.json &
    done
    wait
    
    # Parameter discovery
    echo -e "${YELLOW}[+] Parameter discovery...${NC}"
    cat ports/live_urls.txt | gau | grep "=" | unfurl keys | sort -u > content/parameters.txt
    cat ports/live_urls.txt | waybackurls | grep "=" | unfurl keys | sort -u >> content/parameters.txt
    sort -u content/parameters.txt -o content/unique_parameters.txt
    
    echo -e "${GREEN}✅ Found $(wc -l < content/unique_parameters.txt) unique parameters${NC}"
}

# Function: Advanced crawling
advanced_crawling() {
    echo -e "${BLUE}🎯 Phase 5: Advanced Web Crawling${NC}"
    
    # Katana crawling (modern crawler)
    echo -e "${YELLOW}[+] Katana crawling...${NC}"
    for url in $(cat ports/live_urls.txt | head -5); do
        echo "Crawling: $url"
        katana -u "$url" -d 3 -js-crawl -known-files all -o content/katana_$url.txt &
    done
    wait
    
    # GAU (Get All URLs)
    echo -e "${YELLOW}[+] GAU crawling...${NC}"
    echo $TARGET | gau > content/gau_urls.txt
    
    # Wayback URLs
    echo -e "${YELLOW}[+] Wayback machine URLs...${NC}"
    echo $TARGET | waybackurls > content/wayback_urls.txt
    
    # Combine all crawled URLs
    cat content/katana_*.txt content/gau_urls.txt content/wayback_urls.txt | sort -u > content/all_crawled_urls.txt
    echo -e "${GREEN}✅ Found $(wc -l < content/all_crawled_urls.txt) total URLs${NC}"
    
    # Filter interesting URLs
    echo -e "${YELLOW}[+] Filtering interesting URLs...${NC}"
    
    # Sensitive files
    cat content/all_crawled_urls.txt | grep -E "\.(env|config|backup|dump|sql|bak|old|orig|tmp)$" > content/sensitive_files.txt
    
    # Admin panels
    cat content/all_crawled_urls.txt | grep -E "(admin|administrator|dashboard|panel|control|manage)" > content/admin_panels.txt
    
    # API endpoints
    cat content/all_crawled_urls.txt | grep -E "(api|graphql|swagger|openapi)" > content/api_endpoints.txt
    
    # Upload endpoints
    cat content/all_crawled_urls.txt | grep -E "(upload|file|attachment|media)" > content/upload_endpoints.txt
    
    echo -e "${GREEN}✅ Sensitive files: $(wc -l < content/sensitive_files.txt)${NC}"
    echo -e "${GREEN}✅ Admin panels: $(wc -l < content/admin_panels.txt)${NC}"
    echo -e "${GREEN}✅ API endpoints: $(wc -l < content/api_endpoints.txt)${NC}"
    echo -e "${GREEN}✅ Upload endpoints: $(wc -l < content/upload_endpoints.txt)${NC}"
}

# Function: JavaScript analysis
js_analysis() {
    echo -e "${BLUE}🎯 Phase 6: JavaScript Analysis${NC}"
    
    # Find all JS files
    echo -e "${YELLOW}[+] Finding JavaScript files...${NC}"
    cat content/all_crawled_urls.txt | grep "\.js$" | httpx -silent -mc 200 > content/js_files.txt
    
    # Download and analyze JS files
    echo -e "${YELLOW}[+] Analyzing JavaScript files...${NC}"
    mkdir -p content/js_analysis
    
    for js_file in $(cat content/js_files.txt | head -20); do
        filename=$(echo $js_file | sed 's/.*\///g')
        echo "Downloading: $js_file"
        curl -s "$js_file" > "content/js_analysis/$filename"
        
        # Extract secrets
        grep -Eo "(AKIA[0-9A-Z]{16}|sk_live_[0-9a-zA-Z]{24}|sk_test_[0-9a-zA-Z]{24}|AIza[0-9A-Za-z\\-_]{35}|ya29\\.[0-9A-Za-z\\-_]+)" "content/js_analysis/$filename" >> secrets/js_secrets.txt
        
        # Extract endpoints
        grep -Eo "(/[a-zA-Z0-9_/?&=.-]*)" "content/js_analysis/$filename" | grep -v "^//$" >> content/js_endpoints.txt
        
        # Extract comments
        grep -o "//.*" "content/js_analysis/$filename" >> content/js_comments.txt
        grep -o "/\*.*\*/" "content/js_analysis/$filename" >> content/js_comments.txt
    done
    
    # Remove duplicates
    sort -u secrets/js_secrets.txt -o secrets/unique_js_secrets.txt 2>/dev/null
    sort -u content/js_endpoints.txt -o content/unique_js_endpoints.txt 2>/dev/null
    
    echo -e "${GREEN}✅ JS secrets found: $(wc -l < secrets/unique_js_secrets.txt 2>/dev/null || echo 0)${NC}"
    echo -e "${GREEN}✅ JS endpoints found: $(wc -l < content/unique_js_endpoints.txt 2>/dev/null || echo 0)${NC}"
}

# Function: Generate reconnaissance report
generate_report() {
    echo -e "${BLUE}🎯 Generating Reconnaissance Report${NC}"
    
    cat > recon_report.md << EOF
# 🔍 Reconnaissance Report for $TARGET
**Date:** $(date)
**Total Execution Time:** $SECONDS seconds

## 📊 Summary Statistics
- **Subdomains Found:** $(wc -l < subdomains/final_subdomains.txt)
- **Live Hosts:** $(wc -l < ports/live_urls.txt)
- **Total URLs Crawled:** $(wc -l < content/all_crawled_urls.txt 2>/dev/null || echo 0)
- **Sensitive Files:** $(wc -l < content/sensitive_files.txt 2>/dev/null || echo 0)
- **API Endpoints:** $(wc -l < content/api_endpoints.txt 2>/dev/null || echo 0)
- **JS Secrets:** $(wc -l < secrets/unique_js_secrets.txt 2>/dev/null || echo 0)

## 🎯 Key Findings

### Live Hosts
\`\`\`
$(head -10 ports/live_urls.txt)
\`\`\`

### Sensitive Files Found
\`\`\`
$(head -10 content/sensitive_files.txt 2>/dev/null || echo "None found")
\`\`\`

### API Endpoints
\`\`\`
$(head -10 content/api_endpoints.txt 2>/dev/null || echo "None found")
\`\`\`

### Secrets Found in JavaScript
\`\`\`
$(head -5 secrets/unique_js_secrets.txt 2>/dev/null || echo "None found")
\`\`\`

## 🔍 Next Steps
1. Test sensitive files for information disclosure
2. Analyze API endpoints for vulnerabilities
3. Test JS secrets for validity
4. Perform vulnerability scanning on live hosts
5. Manual testing of interesting endpoints

## 📁 Files Generated
- subdomains/final_subdomains.txt
- ports/live_urls.txt
- content/all_crawled_urls.txt
- content/sensitive_files.txt
- secrets/unique_js_secrets.txt
EOF

    echo -e "${GREEN}✅ Report generated: recon_report.md${NC}"
}

# Main execution
main() {
    start_time=$(date +%s)
    
    subdomain_enum
    port_scanning
    tech_analysis
    content_discovery
    advanced_crawling
    js_analysis
    generate_report
    
    end_time=$(date +%s)
    execution_time=$((end_time - start_time))
    
    echo -e "${GREEN}🔥 Advanced Reconnaissance Completed!${NC}"
    echo -e "${GREEN}⏱️  Total Time: ${execution_time} seconds${NC}"
    echo -e "${GREEN}📁 Check the '$TARGET' directory for all results${NC}"
    echo -e "${GREEN}📊 Read 'recon_report.md' for summary${NC}"
}

# Run main function
main