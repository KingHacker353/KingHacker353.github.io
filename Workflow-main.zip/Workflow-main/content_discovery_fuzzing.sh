#!/bin/bash
# 🔍 Content Discovery with Custom Wordlists & Advanced Fuzzing - Elite Bug Bounty
# Bhai, yeh script tumhe comprehensive content discovery aur fuzzing dega

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

TARGET=$1
if [ -z "$TARGET" ]; then
    echo -e "${RED}Usage: ./content_discovery_fuzzing.sh target.com${NC}"
    echo -e "${RED}       ./content_discovery_fuzzing.sh http://target.com${NC}"
    echo -e "${RED}       ./content_discovery_fuzzing.sh url_list.txt${NC}"
    exit 1
fi

echo -e "${GREEN}🔍 Content Discovery & Advanced Fuzzing for $TARGET${NC}"
mkdir -p $TARGET/content_discovery/{wordlists,directories,files,parameters,vhosts,backups,apis,custom}
cd $TARGET

# Function: Prepare target URLs and create custom wordlists
prepare_targets_and_wordlists() {
    echo -e "${BLUE}🎯 Phase 1: Target Preparation & Custom Wordlist Creation${NC}"
    
    # Determine input type and prepare URLs
    if [ -f "$TARGET" ]; then
        cp "$TARGET" content_discovery/target_urls.txt
        echo -e "${YELLOW}[+] Using URL list from file: $TARGET${NC}"
    elif [[ "$TARGET" == http* ]]; then
        echo "$TARGET" > content_discovery/target_urls.txt
        echo -e "${YELLOW}[+] Using single URL: $TARGET${NC}"
    elif [ -f "web_tech/live_urls.txt" ]; then
        cp web_tech/live_urls.txt content_discovery/target_urls.txt
        echo -e "${YELLOW}[+] Using discovered web services${NC}"
    else
        echo "http://$TARGET" > content_discovery/target_urls.txt
        echo "https://$TARGET" >> content_discovery/target_urls.txt
        echo -e "${YELLOW}[+] Using domain: $TARGET${NC}"
    fi
    
    # Test URL accessibility
    echo -e "${YELLOW}[+] Testing URL accessibility...${NC}"
    while read url; do
        if [ ! -z "$url" ]; then
            if curl -s -m 10 -I "$url" >/dev/null 2>&1; then
                echo "$url" >> content_discovery/live_urls.txt
            fi
        fi
    done < content_discovery/target_urls.txt
    
    if [ ! -f "content_discovery/live_urls.txt" ]; then
        echo -e "${RED}❌ No live URLs found${NC}"
        exit 1
    fi
    
    echo -e "${GREEN}✅ Live URLs: $(wc -l < content_discovery/live_urls.txt)${NC}"
    
    # Create custom wordlists based on target analysis
    echo -e "${YELLOW}[+] Creating custom wordlists...${NC}"
    
    # Extract words from target websites
    while read url; do
        if [ ! -z "$url" ]; then
            echo "Extracting words from: $url"
            
            # Download and extract words from content
            curl -s -m 15 "$url" | html2text | tr ' ' '\n' | grep -v '^$' | tr '[:upper:]' '[:lower:]' | grep -E '^[a-z0-9_-]+$' | sort -u >> content_discovery/wordlists/extracted_words.txt
            
            # Extract directory names from URLs
            curl -s -m 15 "$url" | grep -oE 'href="[^"]*"' | sed 's/href="//g; s/"//g' | grep '/' | cut -d'/' -f2 | grep -v '^$' | sort -u >> content_discovery/wordlists/extracted_dirs.txt
            
            # Extract file names
            curl -s -m 15 "$url" | grep -oE 'href="[^"]*\.[a-z]{2,4}"' | sed 's/href="//g; s/"//g' | rev | cut -d'/' -f1 | rev | sort -u >> content_discovery/wordlists/extracted_files.txt
        fi
    done < content_discovery/live_urls.txt
    
    # Clean and deduplicate extracted words
    sort -u content_discovery/wordlists/extracted_words.txt -o content_discovery/wordlists/extracted_words.txt 2>/dev/null
    sort -u content_discovery/wordlists/extracted_dirs.txt -o content_discovery/wordlists/extracted_dirs.txt 2>/dev/null
    sort -u content_discovery/wordlists/extracted_files.txt -o content_discovery/wordlists/extracted_files.txt 2>/dev/null
    
    # Create comprehensive custom wordlist
    cat > content_discovery/wordlists/common_dirs.txt << 'EOF'
admin
administrator
api
app
apps
assets
backup
backups
bin
blog
cache
cgi-bin
config
css
data
db
debug
dev
development
docs
download
downloads
error
files
ftp
help
home
images
img
include
includes
js
lib
library
log
logs
mail
media
old
panel
private
public
root
scripts
search
secure
src
static
stats
support
temp
test
testing
tmp
tools
upload
uploads
user
users
var
web
webmail
www
EOF
    
    cat > content_discovery/wordlists/common_files.txt << 'EOF'
index.html
index.php
index.asp
index.aspx
index.jsp
admin.php
login.php
config.php
database.php
db.php
connect.php
connection.php
settings.php
wp-config.php
configuration.php
config.inc.php
config.xml
web.config
.htaccess
.htpasswd
robots.txt
sitemap.xml
crossdomain.xml
phpinfo.php
info.php
test.php
backup.sql
dump.sql
database.sql
.env
.env.local
.env.production
readme.txt
README.md
changelog.txt
version.txt
license.txt
EOF
    
    cat > content_discovery/wordlists/api_endpoints.txt << 'EOF'
api
api/v1
api/v2
api/v3
rest
rest/v1
rest/v2
graphql
swagger
swagger.json
swagger.yaml
openapi.json
api-docs
docs/api
api/docs
endpoints
services
webservice
ws
rpc
jsonrpc
xmlrpc
soap
wsdl
EOF
    
    # Combine all wordlists
    cat content_discovery/wordlists/common_dirs.txt content_discovery/wordlists/extracted_words.txt content_discovery/wordlists/extracted_dirs.txt 2>/dev/null | sort -u > content_discovery/wordlists/combined_dirs.txt
    
    cat content_discovery/wordlists/common_files.txt content_discovery/wordlists/extracted_files.txt 2>/dev/null | sort -u > content_discovery/wordlists/combined_files.txt
    
    echo -e "${GREEN}✅ Custom wordlists created${NC}"
    echo -e "   📁 Directories: $(wc -l < content_discovery/wordlists/combined_dirs.txt) entries"
    echo -e "   📄 Files: $(wc -l < content_discovery/wordlists/combined_files.txt) entries"
    echo -e "   🔌 API endpoints: $(wc -l < content_discovery/wordlists/api_endpoints.txt) entries"
}

# Function: Directory discovery with multiple tools
directory_discovery() {
    echo -e "${BLUE}🔍 Phase 2: Directory Discovery${NC}"
    
    # Method 1: Gobuster directory bruteforcing
    echo -e "${YELLOW}[1/4] Gobuster directory bruteforcing...${NC}"
    
    while read url; do
        if [ ! -z "$url" ]; then
            echo "Gobuster on: $url"
            
            # Fast scan with common directories
            gobuster dir -u "$url" -w content_discovery/wordlists/combined_dirs.txt -x php,html,asp,aspx,jsp,txt,xml,json -t 50 -q --no-error -o "content_discovery/directories/gobuster_$(echo $url | sed 's|https\?://||g' | tr '/' '_' | tr ':' '_').txt" &
            
            # Comprehensive scan with SecLists
            if [ -f "~/wordlists/SecLists/Discovery/Web-Content/directory-list-2.3-medium.txt" ]; then
                gobuster dir -u "$url" -w ~/wordlists/SecLists/Discovery/Web-Content/directory-list-2.3-medium.txt -x php,html,asp,aspx,jsp -t 30 -q --no-error -o "content_discovery/directories/gobuster_comprehensive_$(echo $url | sed 's|https\?://||g' | tr '/' '_' | tr ':' '_').txt" &
            fi
        fi
    done < content_discovery/live_urls.txt
    
    # Method 2: Feroxbuster (Rust-based, fast)
    echo -e "${YELLOW}[2/4] Feroxbuster directory discovery...${NC}"
    
    while read url; do
        if [ ! -z "$url" ]; then
            echo "Feroxbuster on: $url"
            feroxbuster -u "$url" -w content_discovery/wordlists/combined_dirs.txt -x php,html,js,txt,xml,json,asp,aspx,jsp -t 50 -C 404,403 --silent -o "content_discovery/directories/ferox_$(echo $url | sed 's|https\?://||g' | tr '/' '_' | tr ':' '_').txt" &
        fi
    done < content_discovery/live_urls.txt
    
    # Method 3: Dirsearch
    echo -e "${YELLOW}[3/4] Dirsearch directory scanning...${NC}"
    
    if command -v dirsearch &> /dev/null; then
        while read url; do
            if [ ! -z "$url" ]; then
                echo "Dirsearch on: $url"
                dirsearch -u "$url" -w content_discovery/wordlists/combined_dirs.txt -e php,html,asp,aspx,jsp,txt,xml,json --simple-report="content_discovery/directories/dirsearch_$(echo $url | sed 's|https\?://||g' | tr '/' '_' | tr ':' '_').txt" &
            fi
        done < content_discovery/live_urls.txt
    else
        echo -e "${RED}❌ Dirsearch not found${NC}"
    fi
    
    # Method 4: Custom directory fuzzing with ffuf
    echo -e "${YELLOW}[4/4] FFUF directory fuzzing...${NC}"
    
    while read url; do
        if [ ! -z "$url" ]; then
            echo "FFUF on: $url"
            ffuf -w content_discovery/wordlists/combined_dirs.txt -u "$url/FUZZ" -mc 200,301,302,403 -fs 0 -t 50 -o "content_discovery/directories/ffuf_$(echo $url | sed 's|https\?://||g' | tr '/' '_' | tr ':' '_').json" &
        fi
    done < content_discovery/live_urls.txt
    
    # Wait for all directory discovery jobs to complete
    wait
    echo -e "${GREEN}✅ Directory discovery completed${NC}"
    
    # Combine and deduplicate results
    find content_discovery/directories -name "*.txt" -exec cat {} \; | grep -oE 'http[s]?://[^[:space:]]+' | sort -u > content_discovery/directories/all_discovered_dirs.txt 2>/dev/null
    
    echo -e "${GREEN}📁 Total directories discovered: $(wc -l < content_discovery/directories/all_discovered_dirs.txt 2>/dev/null || echo 0)${NC}"
}

# Function: File discovery and sensitive file hunting
file_discovery() {
    echo -e "${BLUE}📄 Phase 3: File Discovery & Sensitive File Hunting${NC}"
    
    # Method 1: Common file extensions fuzzing
    echo -e "${YELLOW}[1/5] Common file extensions fuzzing...${NC}"
    
    # Create file extension list
    cat > content_discovery/wordlists/file_extensions.txt << 'EOF'
php
asp
aspx
jsp
html
htm
txt
xml
json
js
css
sql
bak
backup
old
orig
tmp
log
conf
config
ini
yml
yaml
properties
env
EOF
    
    while read url; do
        if [ ! -z "$url" ]; then
            echo "File fuzzing on: $url"
            
            # Fuzz common filenames with extensions
            while read filename; do
                while read ext; do
                    echo "$filename.$ext" >> content_discovery/wordlists/files_with_ext.txt
                done < content_discovery/wordlists/file_extensions.txt
            done < content_discovery/wordlists/combined_files.txt
            
            # Use ffuf for file discovery
            ffuf -w content_discovery/wordlists/files_with_ext.txt -u "$url/FUZZ" -mc 200,403 -fs 0 -t 50 -o "content_discovery/files/ffuf_files_$(echo $url | sed 's|https\?://||g' | tr '/' '_' | tr ':' '_').json" &
        fi
    done < content_discovery/live_urls.txt
    
    # Method 2: Backup file discovery
    echo -e "${YELLOW}[2/5] Backup file discovery...${NC}"
    
    # Create backup file patterns
    cat > content_discovery/wordlists/backup_patterns.txt << 'EOF'
index.php.bak
index.php.backup
index.php.old
index.php.orig
index.php~
index.php.tmp
config.php.bak
config.php.backup
database.php.bak
wp-config.php.bak
web.config.bak
.htaccess.bak
backup.zip
backup.tar.gz
backup.sql
database.sql
dump.sql
site.zip
www.zip
public_html.zip
backup_2023.zip
backup_2024.zip
EOF
    
    while read url; do
        if [ ! -z "$url" ]; then
            echo "Backup file discovery on: $url"
            ffuf -w content_discovery/wordlists/backup_patterns.txt -u "$url/FUZZ" -mc 200,403 -fs 0 -t 30 -o "content_discovery/backups/ffuf_backups_$(echo $url | sed 's|https\?://||g' | tr '/' '_' | tr ':' '_').json" &
        fi
    done < content_discovery/live_urls.txt
    
    # Method 3: Configuration file discovery
    echo -e "${YELLOW}[3/5] Configuration file discovery...${NC}"
    
    cat > content_discovery/wordlists/config_files.txt << 'EOF'
.env
.env.local
.env.production
.env.development
config.php
configuration.php
config.xml
web.config
app.config
database.yml
config.yml
settings.yml
application.yml
config.json
settings.json
package.json
composer.json
.htaccess
.htpasswd
wp-config.php
config.inc.php
db_config.php
database_config.php
EOF
    
    while read url; do
        if [ ! -z "$url" ]; then
            echo "Config file discovery on: $url"
            ffuf -w content_discovery/wordlists/config_files.txt -u "$url/FUZZ" -mc 200,403 -fs 0 -t 30 -o "content_discovery/files/ffuf_configs_$(echo $url | sed 's|https\?://||g' | tr '/' '_' | tr ':' '_').json" &
        fi
    done < content_discovery/live_urls.txt
    
    # Method 4: Log file discovery
    echo -e "${YELLOW}[4/5] Log file discovery...${NC}"
    
    cat > content_discovery/wordlists/log_files.txt << 'EOF'
access.log
error.log
debug.log
application.log
app.log
system.log
server.log
apache.log
nginx.log
php.log
mysql.log
database.log
security.log
audit.log
admin.log
user.log
login.log
auth.log
logs/access.log
logs/error.log
logs/debug.log
log/access.log
log/error.log
log/debug.log
EOF
    
    while read url; do
        if [ ! -z "$url" ]; then
            echo "Log file discovery on: $url"
            ffuf -w content_discovery/wordlists/log_files.txt -u "$url/FUZZ" -mc 200,403 -fs 0 -t 30 -o "content_discovery/files/ffuf_logs_$(echo $url | sed 's|https\?://||g' | tr '/' '_' | tr ':' '_').json" &
        fi
    done < content_discovery/live_urls.txt
    
    # Method 5: Source code file discovery
    echo -e "${YELLOW}[5/5] Source code file discovery...${NC}"
    
    cat > content_discovery/wordlists/source_files.txt << 'EOF'
.git/config
.git/HEAD
.git/index
.svn/entries
.svn/wc.db
.hg/hgrc
.bzr/branch/branch.conf
CVS/Entries
.DS_Store
Thumbs.db
.gitignore
.gitconfig
.svnignore
.hgignore
.dockerignore
Dockerfile
docker-compose.yml
Makefile
Gruntfile.js
gulpfile.js
webpack.config.js
package.json
composer.json
requirements.txt
Pipfile
yarn.lock
package-lock.json
EOF
    
    while read url; do
        if [ ! -z "$url" ]; then
            echo "Source code discovery on: $url"
            ffuf -w content_discovery/wordlists/source_files.txt -u "$url/FUZZ" -mc 200,403 -fs 0 -t 30 -o "content_discovery/files/ffuf_source_$(echo $url | sed 's|https\?://||g' | tr '/' '_' | tr ':' '_').json" &
        fi
    done < content_discovery/live_urls.txt
    
    # Wait for all file discovery jobs
    wait
    echo -e "${GREEN}✅ File discovery completed${NC}"
    
    # Combine results
    find content_discovery/files content_discovery/backups -name "*.json" -exec jq -r '.results[].url' {} \; 2>/dev/null | sort -u > content_discovery/files/all_discovered_files.txt
    
    echo -e "${GREEN}📄 Total files discovered: $(wc -l < content_discovery/files/all_discovered_files.txt 2>/dev/null || echo 0)${NC}"
}

# Function: API endpoint discovery
api_discovery() {
    echo -e "${BLUE}🔌 Phase 4: API Endpoint Discovery${NC}"
    
    # Method 1: Common API paths
    echo -e "${YELLOW}[1/3] Common API endpoint discovery...${NC}"
    
    while read url; do
        if [ ! -z "$url" ]; then
            echo "API discovery on: $url"
            ffuf -w content_discovery/wordlists/api_endpoints.txt -u "$url/FUZZ" -mc 200,301,302,403,405 -fs 0 -t 50 -o "content_discovery/apis/ffuf_api_$(echo $url | sed 's|https\?://||g' | tr '/' '_' | tr ':' '_').json" &
        fi
    done < content_discovery/live_urls.txt
    
    # Method 2: API documentation discovery
    echo -e "${YELLOW}[2/3] API documentation discovery...${NC}"
    
    cat > content_discovery/wordlists/api_docs.txt << 'EOF'
swagger
swagger.json
swagger.yaml
swagger-ui
swagger-ui.html
openapi.json
openapi.yaml
api-docs
api/docs
docs/api
documentation
doc
redoc
postman
insomnia
api.html
api/v1/docs
api/v2/docs
api/v3/docs
graphql
graphiql
playground
EOF
    
    while read url; do
        if [ ! -z "$url" ]; then
            echo "API docs discovery on: $url"
            ffuf -w content_discovery/wordlists/api_docs.txt -u "$url/FUZZ" -mc 200,301,302 -fs 0 -t 30 -o "content_discovery/apis/ffuf_docs_$(echo $url | sed 's|https\?://||g' | tr '/' '_' | tr ':' '_').json" &
        fi
    done < content_discovery/live_urls.txt
    
    # Method 3: API version discovery
    echo -e "${YELLOW}[3/3] API version discovery...${NC}"
    
    cat > content_discovery/wordlists/api_versions.txt << 'EOF'
v1
v2
v3
v4
v5
api/v1
api/v2
api/v3
api/v4
api/v5
rest/v1
rest/v2
rest/v3
1.0
2.0
3.0
api/1.0
api/2.0
api/3.0
EOF
    
    while read url; do
        if [ ! -z "$url" ]; then
            echo "API version discovery on: $url"
            ffuf -w content_discovery/wordlists/api_versions.txt -u "$url/FUZZ" -mc 200,301,302,403,405 -fs 0 -t 30 -o "content_discovery/apis/ffuf_versions_$(echo $url | sed 's|https\?://||g' | tr '/' '_' | tr ':' '_').json" &
        fi
    done < content_discovery/live_urls.txt
    
    wait
    echo -e "${GREEN}✅ API discovery completed${NC}"
    
    # Combine API results
    find content_discovery/apis -name "*.json" -exec jq -r '.results[].url' {} \; 2>/dev/null | sort -u > content_discovery/apis/all_discovered_apis.txt
    
    echo -e "${GREEN}🔌 Total API endpoints discovered: $(wc -l < content_discovery/apis/all_discovered_apis.txt 2>/dev/null || echo 0)${NC}"
}

# Function: Parameter discovery and fuzzing
parameter_discovery() {
    echo -e "${BLUE}🔍 Phase 5: Parameter Discovery & Fuzzing${NC}"
    
    # Method 1: Common parameter names
    echo -e "${YELLOW}[1/3] Common parameter fuzzing...${NC}"
    
    cat > content_discovery/wordlists/common_params.txt << 'EOF'
id
user
username
email
password
token
key
api_key
access_token
auth
session
csrf
page
limit
offset
search
query
q
filter
sort
order
category
type
format
callback
jsonp
redirect
url
path
file
filename
upload
download
action
method
function
cmd
command
exec
system
debug
test
admin
login
logout
register
reset
forgot
change
update
delete
create
edit
view
show
list
get
post
put
patch
EOF
    
    # Get URLs with existing parameters for fuzzing
    if [ -f "content_discovery/directories/all_discovered_dirs.txt" ]; then
        grep "?" content_discovery/directories/all_discovered_dirs.txt > content_discovery/parameters/urls_with_params.txt 2>/dev/null
    fi
    
    # Add base URLs for parameter fuzzing
    while read url; do
        if [ ! -z "$url" ]; then
            echo "$url/?FUZZ=test" >> content_discovery/parameters/param_fuzz_urls.txt
        fi
    done < content_discovery/live_urls.txt
    
    # Fuzz parameters
    if [ -f "content_discovery/parameters/param_fuzz_urls.txt" ]; then
        while read fuzz_url; do
            if [ ! -z "$fuzz_url" ]; then
                echo "Parameter fuzzing: $fuzz_url"
                ffuf -w content_discovery/wordlists/common_params.txt -u "$fuzz_url" -mc 200,301,302,403,500 -fs 0 -t 30 -o "content_discovery/parameters/ffuf_params_$(echo $fuzz_url | sed 's|https\?://||g' | tr '/' '_' | tr ':' '_' | tr '?' '_').json" &
            fi
        done < content_discovery/parameters/param_fuzz_urls.txt
    fi
    
    # Method 2: Extract parameters from JavaScript files
    echo -e "${YELLOW}[2/3] JavaScript parameter extraction...${NC}"
    
    # Find JavaScript files from discovered content
    find content_discovery -name "*.json" -exec jq -r '.results[].url' {} \; 2>/dev/null | grep "\.js$" > content_discovery/parameters/js_files.txt
    
    # Download and analyze JS files
    while read js_url; do
        if [ ! -z "$js_url" ]; then
            echo "Analyzing JS file: $js_url"
            js_filename=$(echo $js_url | sed 's|.*/||g' | tr '?' '_')
            curl -s -m 10 "$js_url" > "content_discovery/parameters/js_${js_filename}" 2>/dev/null
            
            # Extract parameter names from JS
            if [ -f "content_discovery/parameters/js_${js_filename}" ]; then
                grep -oE '["\']([a-zA-Z_][a-zA-Z0-9_]*)["\']' "content_discovery/parameters/js_${js_filename}" | sed 's/["\']//g' | grep -E '^[a-zA-Z_][a-zA-Z0-9_]*$' | sort -u >> content_discovery/parameters/js_extracted_params.txt
            fi
        fi
    done < content_discovery/parameters/js_files.txt
    
    # Method 3: Parameter pollution testing
    echo -e "${YELLOW}[3/3] Parameter pollution testing...${NC}"
    
    # Create parameter pollution payloads
    cat > content_discovery/wordlists/param_pollution.txt << 'EOF'
id=1&id=2
user=admin&user=test
page=1&page=../../../etc/passwd
filter=*&filter=
sort=name&sort=name;id
limit=10&limit=999999
debug=0&debug=1
test=false&test=true
format=json&format=xml
callback=test&callback=alert(1)
EOF
    
    wait
    echo -e "${GREEN}✅ Parameter discovery completed${NC}"
    
    # Combine parameter results
    find content_discovery/parameters -name "*.json" -exec jq -r '.results[].url' {} \; 2>/dev/null | sort -u > content_discovery/parameters/all_discovered_params.txt
    
    echo -e "${GREEN}🔍 Total parameter endpoints discovered: $(wc -l < content_discovery/parameters/all_discovered_params.txt 2>/dev/null || echo 0)${NC}"
}

# Function: Virtual host discovery
vhost_discovery() {
    echo -e "${BLUE}🌐 Phase 6: Virtual Host Discovery${NC}"
    
    # Extract base domains from URLs
    while read url; do
        if [ ! -z "$url" ]; then
            domain=$(echo $url | sed 's|https\?://||g' | cut -d'/' -f1 | cut -d':' -f1)
            echo "$domain" >> content_discovery/vhosts/base_domains.txt
        fi
    done < content_discovery/live_urls.txt
    
    sort -u content_discovery/vhosts/base_domains.txt -o content_discovery/vhosts/base_domains.txt
    
    # Create vhost wordlist
    cat > content_discovery/wordlists/vhost_subdomains.txt << 'EOF'
www
mail
ftp
admin
api
app
blog
dev
test
staging
prod
production
beta
alpha
demo
docs
help
support
portal
dashboard
panel
control
manage
secure
vpn
remote
internal
intranet
extranet
private
public
static
assets
cdn
media
images
css
js
files
download
upload
backup
old
new
mobile
m
wap
service
services
web
webmail
email
smtp
pop
imap
ns1
ns2
dns
mx
EOF
    
    # Perform vhost discovery
    echo -e "${YELLOW}[+] Virtual host fuzzing...${NC}"
    
    while read domain; do
        if [ ! -z "$domain" ]; then
            echo "VHost discovery for: $domain"
            
            # Get IP address
            ip=$(dig +short "$domain" | head -1)
            if [ ! -z "$ip" ]; then
                # Fuzz vhosts
                ffuf -w content_discovery/wordlists/vhost_subdomains.txt -u "http://$ip" -H "Host: FUZZ.$domain" -mc 200,301,302,403 -fs 0 -t 30 -o "content_discovery/vhosts/ffuf_vhost_${domain}.json" &
            fi
        fi
    done < content_discovery/vhosts/base_domains.txt
    
    wait
    echo -e "${GREEN}✅ Virtual host discovery completed${NC}"
    
    # Extract discovered vhosts
    find content_discovery/vhosts -name "*.json" -exec jq -r '.results[] | .input.FUZZ + "." + (.host | split(".")[1:] | join("."))' {} \; 2>/dev/null | sort -u > content_discovery/vhosts/discovered_vhosts.txt
    
    echo -e "${GREEN}🌐 Virtual hosts discovered: $(wc -l < content_discovery/vhosts/discovered_vhosts.txt 2>/dev/null || echo 0)${NC}"
}

# Function: Generate comprehensive content discovery report
generate_content_discovery_report() {
    echo -e "${BLUE}📊 Generating Content Discovery Report${NC}"
    
    # Calculate statistics
    total_dirs=$(wc -l < content_discovery/directories/all_discovered_dirs.txt 2>/dev/null || echo 0)
    total_files=$(wc -l < content_discovery/files/all_discovered_files.txt 2>/dev/null || echo 0)
    total_apis=$(wc -l < content_discovery/apis/all_discovered_apis.txt 2>/dev/null || echo 0)
    total_params=$(wc -l < content_discovery/parameters/all_discovered_params.txt 2>/dev/null || echo 0)
    total_vhosts=$(wc -l < content_discovery/vhosts/discovere_vhosts.txt 2>/dev/null || echo 0)
    
    cat > content_discovery_report.md << EOF
# 🔍 Content Discovery & Advanced Fuzzing Report
**Target:** $TARGET
**Date:** $(date)
**Discovery Duration:** $SECONDS seconds

## 📊 Executive Summary
- **Directories Discovered:** $total_dirs
- **Files Discovered:** $total_files
- **API Endpoints:** $total_apis
- **Parameter Endpoints:** $total_params
- **Virtual Hosts:** $total_vhosts

## 🔍 Discovery Methodology

### Tools & Techniques Used
1. **Gobuster** - Directory and file bruteforcing
2. **Feroxbuster** - Fast recursive directory discovery
3. **Dirsearch** - Web path scanner
4. **FFUF** - Fast web fuzzer for all discovery types
5. **Custom Wordlists** - Target-specific wordlist generation
6. **JavaScript Analysis** - Parameter extraction from JS files
7. **Virtual Host Discovery** - Subdomain and vhost fuzzing

### Wordlist Sources
- **Extracted Content** - Words extracted from target websites
- **Common Patterns** - Standard directory and file patterns
- **SecLists Integration** - Industry-standard wordlists
- **Custom Signatures** - Target-specific patterns

## 📁 Directory Discovery Results

### Top Discovered Directories
\`\`\`
$(head -20 content_discovery/directories/all_discovered_dirs.txt 2>/dev/null | sort || echo "No directories discovered")
\`\`\`

### Interesting Directory Patterns
\`\`\`
$(grep -E "(admin|api|backup|config|debug|dev|test|upload)" content_discovery/directories/all_discovered_dirs.txt 2>/dev/null | head -15 || echo "No interesting patterns found")
\`\`\`

## 📄 File Discovery Results

### Sensitive Files Found
\`\`\`
$(grep -E "\.(env|config|sql|bak|backup|old|log)$" content_discovery/files/all_discovered_files.txt 2>/dev/null | head -15 || echo "No sensitive files found")
\`\`\`

### Configuration Files
\`\`\`
$(grep -E "(config|\.env|web\.config|\.htaccess)" content_discovery/files/all_discovered_files.txt 2>/dev/null | head -10 || echo "No configuration files found")
\`\`\`

### Backup Files
\`\`\`
$(grep -E "\.(bak|backup|old|orig|tmp)$" content_discovery/files/all_discovered_files.txt 2>/dev/null | head -10 || echo "No backup files found")
\`\`\`

### Log Files
\`\`\`
$(grep -E "\.log$|/logs?/" content_discovery/files/all_discovered_files.txt 2>/dev/null | head -10 || echo "No log files found")
\`\`\`

## 🔌 API Discovery Results

### API Endpoints
\`\`\`
$(head -15 content_discovery/apis/all_discovered_apis.txt 2>/dev/null || echo "No API endpoints discovered")
\`\`\`

### API Documentation
\`\`\`
$(grep -E "(swagger|openapi|docs|documentation)" content_discovery/apis/all_discovered_apis.txt 2>/dev/null | head -10 || echo "No API documentation found")
\`\`\`

### GraphQL Endpoints
\`\`\`
$(grep -i "graphql" content_discovery/apis/all_discovered_apis.txt 2>/dev/null || echo "No GraphQL endpoints found")
\`\`\`

## 🔍 Parameter Discovery Results

### Parameter Endpoints
\`\`\`
$(head -15 content_discovery/parameters/all_discovered_params.txt 2>/dev/null || echo "No parameter endpoints discovered")
\`\`\`

### JavaScript Extracted Parameters
\`\`\`
$(head -20 content_discovery/parameters/js_extracted_params.txt 2>/dev/null | sort -u || echo "No parameters extracted from JavaScript")
\`\`\`

## 🌐 Virtual Host Discovery

### Discovered Virtual Hosts
\`\`\`
$(cat content_discovery/vhosts/discovered_vhosts.txt 2>/dev/null || echo "No virtual hosts discovered")
\`\`\`

## 🎯 High-Priority Findings

### Administrative Interfaces
\`\`\`
$(grep -i -E "(admin|administrator|panel|dashboard|control|manage)" content_discovery/directories/all_discovered_dirs.txt content_discovery/files/all_discovered_files.txt 2>/dev/null | head -10 || echo "No admin interfaces found")
\`\`\`

### Development/Testing Environments
\`\`\`
$(grep -i -E "(dev|test|staging|debug|beta|alpha|demo)" content_discovery/directories/all_discovered_dirs.txt content_discovery/files/all_discovered_files.txt 2>/dev/null | head -10 || echo "No development environments found")
\`\`\`

### Backup and Configuration Files
\`\`\`
$(grep -E "\.(env|config|bak|backup|sql|dump)$" content_discovery/files/all_discovered_files.txt 2>/dev/null | head -10 || echo "No backup/config files found")
\`\`\`

### Upload Directories
\`\`\`
$(grep -i -E "(upload|uploads|files|media|assets)" content_discovery/directories/all_discovered_dirs.txt 2>/dev/null | head -10 || echo "No upload directories found")
\`\`\`

## 🛠️ Technical Analysis

### Custom Wordlist Statistics
- **Extracted Words:** $(wc -l < content_discovery/wordlists/extracted_words.txt 2>/dev/null || echo 0)
- **Extracted Directories:** $(wc -l < content_discovery/wordlists/extracted_dirs.txt 2>/dev/null || echo 0)
- **Extracted Files:** $(wc -l < content_discovery/wordlists/extracted_files.txt 2>/dev/null || echo 0)
- **Combined Directory List:** $(wc -l < content_discovery/wordlists/combined_dirs.txt 2>/dev/null || echo 0)
- **Combined File List:** $(wc -l < content_discovery/wordlists/combined_files.txt 2>/dev/null || echo 0)

### Discovery Tool Results
$(find content_discovery -name "*.txt" -o -name "*.json" | wc -l) result files generated across all discovery methods

### JavaScript Analysis
- **JS Files Analyzed:** $(wc -l < content_discovery/parameters/js_files.txt 2>/dev/null || echo 0)
- **Parameters Extracted:** $(wc -l < content_discovery/parameters/js_extracted_params.txt 2>/dev/null || echo 0)

## 📁 Files Generated
- **content_discovery/directories/** - Directory discovery results
- **content_discovery/files/** - File discovery results  
- **content_discovery/apis/** - API endpoint discovery
- **content_discovery/parameters/** - Parameter discovery
- **content_discovery/vhosts/** - Virtual host discovery
- **content_discovery/wordlists/** - Custom wordlists
- **content_discovery/backups/** - Backup file discovery

## 🚀 Recommended Next Steps

### Immediate Actions
1. **Analyze Sensitive Files** - Download and examine configuration/backup files
2. **Test API Endpoints** - Perform API security testing
3. **Parameter Testing** - Test discovered parameters for vulnerabilities
4. **Admin Interface Testing** - Attempt authentication bypass on admin panels

### Deep Dive Analysis
1. **Directory Traversal** - Test discovered directories for traversal vulnerabilities
2. **File Upload Testing** - Test upload directories for unrestricted file upload
3. **API Documentation Review** - Analyze discovered API documentation
4. **Parameter Pollution** - Test for HTTP parameter pollution vulnerabilities

### Bug Bounty Focus Areas
1. **Sensitive Information Disclosure** - Configuration files, backups, logs
2. **Administrative Access** - Admin panels, debug interfaces
3. **API Security** - Unauthorized access, injection vulnerabilities
4. **File Upload Vulnerabilities** - Unrestricted file upload, path traversal

## ⚡ Quick Testing Commands

### Manual Verification
\`\`\`bash
# Test discovered directories
curl -I http://target.com/admin/
curl -I http://target.com/api/

# Download sensitive files
wget http://target.com/.env
wget http://target.com/config.php.bak

# Test API endpoints
curl http://target.com/api/v1/users
curl http://target.com/graphql
\`\`\`

### Further Discovery
\`\`\`bash
# Recursive directory discovery
feroxbuster -u http://target.com/admin/ -w /usr/share/wordlists/dirb/common.txt

# Parameter fuzzing
ffuf -w /usr/share/wordlists/SecLists/Discovery/Web-Content/burp-parameter-names.txt -u "http://target.com/?FUZZ=test"

# API testing
nuclei -u http://target.com/api/ -t ~/nuclei-templates/exposures/
\`\`\`

---
**Note:** Always ensure proper authorization before accessing discovered content.
EOF

    echo -e "${GREEN}✅ Content discovery report generated: content_discovery_report.md${NC}"
}

# Main execution function
main() {
    start_time=$(date +%s)
    
    echo -e "${PURPLE}🚀 Starting Content Discovery & Advanced Fuzzing${NC}"
    
    prepare_targets_and_wordlists
    directory_discovery
    file_discovery
    api_discovery
    parameter_discovery
    vhost_discovery
    generate_content_discovery_report
    
    end_time=$(date +%s)
    execution_time=$((end_time - start_time))
    
    echo -e "${GREEN}🎉 Content Discovery & Fuzzing Completed!${NC}"
    echo -e "${GREEN}⏱️  Total Execution Time: ${execution_time} seconds${NC}"
    echo -e "${GREEN}📊 Results Summary:${NC}"
    echo -e "   📁 Directories: $(wc -l < content_discovery/directories/all_discovered_dirs.txt 2>/dev/null || echo 0)"
    echo -e "   📄 Files: $(wc -l < content_discovery/files/all_discovered_files.txt 2>/dev/null || echo 0)"
    echo -e "   🔌 APIs: $(wc -l < content_discovery/apis/all_discovered_apis.txt 2>/dev/null || echo 0)"
    echo -e "   🔍 Parameters: $(wc -l < content_discovery/parameters/all_discovered_params.txt 2>/dev/null || echo 0)"
    echo -e "   🌐 VHosts: $(wc -l < content_discovery/vhosts/discovered_vhosts.txt 2>/dev/null || echo 0)"
    echo -e "${GREEN}📄 Check 'content_discovery_report.md' for detailed analysis${NC}"
}

# Execute main function
main