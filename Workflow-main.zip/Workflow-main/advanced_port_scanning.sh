#!/bin/bash
# 🔍 Advanced Port Scanning & Service Fingerprinting - Elite Bug Bounty
# Bhai, yeh script tumhe comprehensive port scanning aur service detection dega

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

TARGET=$1
if [ -z "$TARGET" ]; then
    echo -e "${RED}Usage: ./advanced_port_scanning.sh target.com${NC}"
    echo -e "${RED}       ./advanced_port_scanning.sh target_list.txt${NC}"
    exit 1
fi

echo -e "${GREEN}🔍 Advanced Port Scanning & Service Fingerprinting for $TARGET${NC}"
mkdir -p $TARGET/ports/{discovery,services,vulnerabilities,screenshots}
cd $TARGET

# Function: Fast port discovery with multiple tools
fast_port_discovery() {
    echo -e "${BLUE}🚀 Phase 1: Fast Port Discovery${NC}"
    
    # Determine if input is a file or single target
    if [ -f "$TARGET" ]; then
        target_list="$TARGET"
        echo -e "${YELLOW}[+] Using target list: $TARGET${NC}"
    elif [ -f "subdomains/live_subdomains.txt" ]; then
        target_list="subdomains/live_subdomains.txt"
        echo -e "${YELLOW}[+] Using live subdomains list${NC}"
    else
        echo "$TARGET" > ports/single_target.txt
        target_list="ports/single_target.txt"
        echo -e "${YELLOW}[+] Using single target: $TARGET${NC}"
    fi
    
    # Method 1: Rustscan (Ultra-fast initial scan)
    echo -e "${YELLOW}[1/4] Rustscan - Ultra-fast discovery...${NC}"
    if command -v rustscan &> /dev/null; then
        while read target; do
            if [ ! -z "$target" ]; then
                echo "Rustscan on: $target"
                rustscan -a "$target" --ulimit 5000 --range 1-65535 --timeout 1000 | grep "Open" | awk '{print $2}' >> ports/discovery/rustscan_raw.txt
            fi
        done < "$target_list"
        
        # Clean and sort results
        sort -u ports/discovery/rustscan_raw.txt > ports/discovery/rustscan_ports.txt 2>/dev/null
        echo -e "${GREEN}✅ Rustscan: $(wc -l < ports/discovery/rustscan_ports.txt 2>/dev/null || echo 0) unique ports${NC}"
    else
        echo -e "${RED}❌ Rustscan not found, skipping${NC}"
    fi
    
    # Method 2: Masscan (Fast network scanner)
    echo -e "${YELLOW}[2/4] Masscan - Fast network scanning...${NC}"
    if command -v masscan &> /dev/null; then
        # Create IP list from targets
        while read target; do
            if [ ! -z "$target" ]; then
                dig +short "$target" | grep -E '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' >> ports/discovery/target_ips.txt
            fi
        done < "$target_list"
        
        if [ -f "ports/discovery/target_ips.txt" ]; then
            sort -u ports/discovery/target_ips.txt -o ports/discovery/target_ips.txt
            echo "Masscan on $(wc -l < ports/discovery/target_ips.txt) IPs"
            sudo masscan -iL ports/discovery/target_ips.txt -p1-65535 --rate=1000 --output-format list --output-filename ports/discovery/masscan_results.txt
            
            # Extract ports from masscan results
            awk '{print $3}' ports/discovery/masscan_results.txt | cut -d'/' -f1 | sort -u > ports/discovery/masscan_ports.txt 2>/dev/null
            echo -e "${GREEN}✅ Masscan: $(wc -l < ports/discovery/masscan_ports.txt 2>/dev/null || echo 0) unique ports${NC}"
        fi
    else
        echo -e "${RED}❌ Masscan not found or requires sudo, skipping${NC}"
    fi
    
    # Method 3: Nmap SYN scan (Reliable and stealthy)
    echo -e "${YELLOW}[3/4] Nmap SYN scan - Reliable discovery...${NC}"
    
    # Top 1000 ports first (fast)
    nmap -sS -T4 --top-ports 1000 -iL "$target_list" --open -oG ports/discovery/nmap_top1000.gnmap 2>/dev/null
    grep "open" ports/discovery/nmap_top1000.gnmap | grep -oP '\d+/open' | cut -d'/' -f1 | sort -u > ports/discovery/nmap_top1000_ports.txt
    echo -e "${GREEN}✅ Nmap Top 1000: $(wc -l < ports/discovery/nmap_top1000_ports.txt) ports${NC}"
    
    # All ports scan (slower but comprehensive)
    echo -e "${YELLOW}[+] Nmap full port scan (this may take time)...${NC}"
    nmap -sS -T4 -p- -iL "$target_list" --open -oG ports/discovery/nmap_all_ports.gnmap 2>/dev/null &
    nmap_pid=$!
    
    # Method 4: Custom port list based on common services
    echo -e "${YELLOW}[4/4] Custom service port scan...${NC}"
    
    # Create comprehensive port list
    cat > ports/discovery/custom_ports.txt << 'EOF'
21,22,23,25,53,80,110,111,135,139,143,443,993,995,1723,3306,3389,5432,5900,6379,8080,8443,9200,11211,27017
EOF
    
    # Scan custom ports
    nmap -sS -T4 -p $(cat ports/discovery/custom_ports.txt) -iL "$target_list" --open -oG ports/discovery/nmap_custom.gnmap 2>/dev/null
    grep "open" ports/discovery/nmap_custom.gnmap | grep -oP '\d+/open' | cut -d'/' -f1 | sort -u > ports/discovery/nmap_custom_ports.txt
    echo -e "${GREEN}✅ Custom ports: $(wc -l < ports/discovery/nmap_custom_ports.txt) ports${NC}"
    
    # Wait for full port scan to complete (with timeout)
    echo -e "${YELLOW}[+] Waiting for full port scan (max 30 minutes)...${NC}"
    timeout 1800 wait $nmap_pid 2>/dev/null
    if [ $? -eq 124 ]; then
        echo -e "${YELLOW}⚠️  Full port scan timed out, using partial results${NC}"
        kill $nmap_pid 2>/dev/null
    fi
    
    # Process full port scan results if available
    if [ -f "ports/discovery/nmap_all_ports.gnmap" ]; then
        grep "open" ports/discovery/nmap_all_ports.gnmap | grep -oP '\d+/open' | cut -d'/' -f1 | sort -u > ports/discovery/nmap_all_ports_list.txt
        echo -e "${GREEN}✅ Nmap Full Scan: $(wc -l < ports/discovery/nmap_all_ports_list.txt 2>/dev/null || echo 0) ports${NC}"
    fi
    
    # Combine all discovered ports
    cat ports/discovery/*_ports.txt ports/discovery/*_ports_list.txt 2>/dev/null | sort -u > ports/discovery/all_discovered_ports.txt
    echo -e "${GREEN}🎉 Total Unique Ports Discovered: $(wc -l < ports/discovery/all_discovered_ports.txt)${NC}"
}

# Function: Service detection and fingerprinting
service_fingerprinting() {
    echo -e "${BLUE}🔍 Phase 2: Service Detection & Fingerprinting${NC}"
    
    # Prepare target:port combinations
    echo -e "${YELLOW}[+] Preparing target:port combinations...${NC}"
    
    # Create target:port list
    while read target; do
        if [ ! -z "$target" ]; then
            while read port; do
                if [ ! -z "$port" ]; then
                    echo "$target:$port" >> ports/services/target_port_combinations.txt
                fi
            done < ports/discovery/all_discovered_ports.txt
        fi
    done < "$target_list"
    
    echo -e "${GREEN}✅ Created $(wc -l < ports/services/target_port_combinations.txt) target:port combinations${NC}"
    
    # Method 1: Nmap service detection
    echo -e "${YELLOW}[1/5] Nmap service detection...${NC}"
    
    # Intensive service detection
    nmap -sV -sC -A -T4 -p $(cat ports/discovery/all_discovered_ports.txt | tr '\n' ',' | sed 's/,$//') -iL "$target_list" -oA ports/services/nmap_service_detection 2>/dev/null
    
    # Extract service information
    grep -E "open|filtered" ports/services/nmap_service_detection.nmap | grep -v "Nmap scan report" > ports/services/nmap_services.txt
    echo -e "${GREEN}✅ Nmap service detection completed${NC}"
    
    # Method 2: Banner grabbing with netcat
    echo -e "${YELLOW}[2/5] Banner grabbing with netcat...${NC}"
    
    while read target_port; do
        if [ ! -z "$target_port" ]; then
            target=$(echo $target_port | cut -d':' -f1)
            port=$(echo $target_port | cut -d':' -f2)
            
            echo "Banner grabbing: $target:$port"
            timeout 5 nc -nv "$target" "$port" < /dev/null > "ports/services/banner_${target}_${port}.txt" 2>&1 &
        fi
    done < <(head -50 ports/services/target_port_combinations.txt)  # Limit to first 50 for speed
    
    wait
    echo -e "${GREEN}✅ Banner grabbing completed${NC}"
    
    # Method 3: HTTP service detection
    echo -e "${YELLOW}[3/5] HTTP service detection...${NC}"
    
    # Find HTTP/HTTPS services
    grep -E ":80|:443|:8080|:8443|:8000|:9000|:3000|:5000" ports/services/target_port_combinations.txt > ports/services/http_services.txt
    
    # HTTP title and technology detection
    if [ -s "ports/services/http_services.txt" ]; then
        while read http_service; do
            if [ ! -z "$http_service" ]; then
                target=$(echo $http_service | cut -d':' -f1)
                port=$(echo $http_service | cut -d':' -f2)
                
                # Try both HTTP and HTTPS
                for protocol in http https; do
                    echo "Checking $protocol://$target:$port"
                    curl -s -m 10 -I "$protocol://$target:$port" > "ports/services/http_headers_${target}_${port}_${protocol}.txt" 2>/dev/null &
                    curl -s -m 10 "$protocol://$target:$port" | head -20 > "ports/services/http_content_${target}_${port}_${protocol}.txt" 2>/dev/null &
                done
            fi
        done < ports/services/http_services.txt
        
        wait
        echo -e "${GREEN}✅ HTTP service detection completed${NC}"
    fi
    
    # Method 4: Database service detection
    echo -e "${YELLOW}[4/5] Database service detection...${NC}"
    
    # Common database ports
    grep -E ":3306|:5432|:1433|:27017|:6379|:11211|:9200" ports/services/target_port_combinations.txt > ports/services/database_services.txt
    
    if [ -s "ports/services/database_services.txt" ]; then
        while read db_service; do
            if [ ! -z "$db_service" ]; then
                target=$(echo $db_service | cut -d':' -f1)
                port=$(echo $db_service | cut -d':' -f2)
                
                echo "Database detection: $target:$port"
                
                case $port in
                    3306)
                        # MySQL
                        timeout 5 mysql -h "$target" -P "$port" -e "SELECT VERSION();" > "ports/services/mysql_${target}_${port}.txt" 2>&1 &
                        ;;
                    5432)
                        # PostgreSQL
                        timeout 5 psql -h "$target" -p "$port" -c "SELECT version();" > "ports/services/postgres_${target}_${port}.txt" 2>&1 &
                        ;;
                    6379)
                        # Redis
                        timeout 5 redis-cli -h "$target" -p "$port" INFO > "ports/services/redis_${target}_${port}.txt" 2>&1 &
                        ;;
                    9200)
                        # Elasticsearch
                        curl -s -m 5 "http://$target:$port/_cluster/health" > "ports/services/elasticsearch_${target}_${port}.txt" 2>/dev/null &
                        ;;
                    27017)
                        # MongoDB
                        timeout 5 mongo --host "$target:$port" --eval "db.version()" > "ports/services/mongodb_${target}_${port}.txt" 2>&1 &
                        ;;
                esac
            fi
        done < ports/services/database_services.txt
        
        wait
        echo -e "${GREEN}✅ Database service detection completed${NC}"
    fi
    
    # Method 5: SSL/TLS certificate analysis
    echo -e "${YELLOW}[5/5] SSL/TLS certificate analysis...${NC}"
    
    # Find SSL/TLS services
    grep -E ":443|:8443|:993|:995|:465|:587" ports/services/target_port_combinations.txt > ports/services/ssl_services.txt
    
    if [ -s "ports/services/ssl_services.txt" ]; then
        while read ssl_service; do
            if [ ! -z "$ssl_service" ]; then
                target=$(echo $ssl_service | cut -d':' -f1)
                port=$(echo $ssl_service | cut -d':' -f2)
                
                echo "SSL analysis: $target:$port"
                
                # Get certificate information
                timeout 10 openssl s_client -connect "$target:$port" -servername "$target" < /dev/null 2>/dev/null | openssl x509 -text > "ports/services/ssl_cert_${target}_${port}.txt" 2>/dev/null &
                
                # SSL/TLS version and cipher detection
                timeout 10 nmap --script ssl-enum-ciphers -p "$port" "$target" > "ports/services/ssl_ciphers_${target}_${port}.txt" 2>/dev/null &
            fi
        done < ports/services/ssl_services.txt
        
        wait
        echo -e "${GREEN}✅ SSL/TLS analysis completed${NC}"
    fi
}

# Function: Vulnerability scanning on discovered services
vulnerability_scanning() {
    echo -e "${BLUE}🚨 Phase 3: Vulnerability Scanning${NC}"
    
    # Method 1: Nmap vulnerability scripts
    echo -e "${YELLOW}[1/4] Nmap vulnerability scripts...${NC}"
    
    # Run vulnerability detection scripts
    nmap --script vuln -p $(cat ports/discovery/all_discovered_ports.txt | tr '\n' ',' | sed 's/,$//') -iL "$target_list" -oA ports/vulnerabilities/nmap_vuln_scan 2>/dev/null
    
    # Extract vulnerability information
    grep -A 5 -B 5 "VULNERABLE\|CVE-" ports/vulnerabilities/nmap_vuln_scan.nmap > ports/vulnerabilities/nmap_vulnerabilities.txt 2>/dev/null
    echo -e "${GREEN}✅ Nmap vulnerability scan completed${NC}"
    
    # Method 2: Service-specific vulnerability checks
    echo -e "${YELLOW}[2/4] Service-specific vulnerability checks...${NC}"
    
    # SSH vulnerability checks
    if grep -q ":22" ports/services/target_port_combinations.txt; then
        echo "Checking SSH vulnerabilities..."
        grep ":22" ports/services/target_port_combinations.txt | while read ssh_service; do
            target=$(echo $ssh_service | cut -d':' -f1)
            nmap --script ssh-hostkey,ssh-auth-methods,ssh2-enum-algos -p 22 "$target" > "ports/vulnerabilities/ssh_vuln_${target}.txt" 2>/dev/null &
        done
    fi
    
    # HTTP vulnerability checks
    if [ -s "ports/services/http_services.txt" ]; then
        echo "Checking HTTP vulnerabilities..."
        head -10 ports/services/http_services.txt | while read http_service; do
            target=$(echo $http_service | cut -d':' -f1)
            port=$(echo $http_service | cut -d':' -f2)
            nmap --script http-vuln* -p "$port" "$target" > "ports/vulnerabilities/http_vuln_${target}_${port}.txt" 2>/dev/null &
        done
    fi
    
    # Database vulnerability checks
    if [ -s "ports/services/database_services.txt" ]; then
        echo "Checking database vulnerabilities..."
        head -5 ports/services/database_services.txt | while read db_service; do
            target=$(echo $db_service | cut -d':' -f1)
            port=$(echo $db_service | cut -d':' -f2)
            
            case $port in
                3306)
                    nmap --script mysql-vuln* -p 3306 "$target" > "ports/vulnerabilities/mysql_vuln_${target}.txt" 2>/dev/null &
                    ;;
                5432)
                    nmap --script pgsql-brute -p 5432 "$target" > "ports/vulnerabilities/postgres_vuln_${target}.txt" 2>/dev/null &
                    ;;
                6379)
                    nmap --script redis-info -p 6379 "$target" > "ports/vulnerabilities/redis_vuln_${target}.txt" 2>/dev/null &
                    ;;
            esac
        done
    fi
    
    wait
    echo -e "${GREEN}✅ Service-specific vulnerability checks completed${NC}"
    
    # Method 3: SSL/TLS vulnerability assessment
    echo -e "${YELLOW}[3/4] SSL/TLS vulnerability assessment...${NC}"
    
    if [ -s "ports/services/ssl_services.txt" ]; then
        head -10 ports/services/ssl_services.txt | while read ssl_service; do
            target=$(echo $ssl_service | cut -d':' -f1)
            port=$(echo $ssl_service | cut -d':' -f2)
            
            echo "SSL vulnerability check: $target:$port"
            nmap --script ssl-heartbleed,ssl-poodle,ssl-dh-params -p "$port" "$target" > "ports/vulnerabilities/ssl_vuln_${target}_${port}.txt" 2>/dev/null &
        done
        
        wait
        echo -e "${GREEN}✅ SSL/TLS vulnerability assessment completed${NC}"
    fi
    
    # Method 4: Default credential testing
    echo -e "${YELLOW}[4/4] Default credential testing...${NC}"
    
    # Create default credential list
    cat > ports/vulnerabilities/default_creds.txt << 'EOF'
admin:admin
admin:password
admin:123456
root:root
root:admin
root:password
administrator:admin
administrator:password
guest:guest
test:test
demo:demo
user:user
EOF
    
    # Test default credentials on common services
    if [ -s "ports/services/database_services.txt" ]; then
        head -5 ports/services/database_services.txt | while read db_service; do
            target=$(echo $db_service | cut -d':' -f1)
            port=$(echo $db_service | cut -d':' -f2)
            
            case $port in
                3306)
                    echo "Testing MySQL default credentials on $target:$port"
                    while IFS=: read username password; do
                        timeout 5 mysql -h "$target" -P "$port" -u "$username" -p"$password" -e "SELECT 1;" > "ports/vulnerabilities/mysql_creds_${target}_${username}.txt" 2>&1 &
                    done < ports/vulnerabilities/default_creds.txt
                    ;;
                6379)
                    echo "Testing Redis authentication on $target:$port"
                    timeout 5 redis-cli -h "$target" -p "$port" ping > "ports/vulnerabilities/redis_auth_${target}.txt" 2>&1 &
                    ;;
            esac
        done
        
        wait
        echo -e "${GREEN}✅ Default credential testing completed${NC}"
    fi
}

# Function: Screenshot web services
screenshot_services() {
    echo -e "${BLUE}📸 Phase 4: Web Service Screenshots${NC}"
    
    if [ -s "ports/services/http_services.txt" ]; then
        echo -e "${YELLOW}[+] Taking screenshots of web services...${NC}"
        
        # Install webscreenshot if not available
        if ! command -v webscreenshot &> /dev/null; then
            echo -e "${YELLOW}[+] Installing webscreenshot...${NC}"
            pip3 install webscreenshot 2>/dev/null
        fi
        
        # Create URL list for screenshots
        while read http_service; do
            if [ ! -z "$http_service" ]; then
                target=$(echo $http_service | cut -d':' -f1)
                port=$(echo $http_service | cut -d':' -f2)
                
                # Add both HTTP and HTTPS URLs
                echo "http://$target:$port" >> ports/screenshots/url_list.txt
                if [ "$port" = "443" ] || [ "$port" = "8443" ]; then
                    echo "https://$target:$port" >> ports/screenshots/url_list.txt
                fi
            fi
        done < ports/services/http_services.txt
        
        # Remove duplicates
        sort -u ports/screenshots/url_list.txt -o ports/screenshots/url_list.txt
        
        # Take screenshots
        if command -v webscreenshot &> /dev/null; then
            webscreenshot -i ports/screenshots/url_list.txt -o ports/screenshots/ --no-error-file
            echo -e "${GREEN}✅ Screenshots taken for $(wc -l < ports/screenshots/url_list.txt) URLs${NC}"
        else
            echo -e "${RED}❌ Webscreenshot not available, skipping screenshots${NC}"
        fi
    fi
}

# Function: Generate comprehensive port scanning report
generate_port_report() {
    echo -e "${BLUE}📊 Generating Comprehensive Port Scanning Report${NC}"
    
    # Calculate statistics
    total_ports=$(wc -l < ports/discovery/all_discovered_ports.txt 2>/dev/null || echo 0)
    total_combinations=$(wc -l < ports/services/target_port_combinations.txt 2>/dev/null || echo 0)
    http_services=$(wc -l < ports/services/http_services.txt 2>/dev/null || echo 0)
    database_services=$(wc -l < ports/services/database_services.txt 2>/dev/null || echo 0)
    ssl_services=$(wc -l < ports/services/ssl_services.txt 2>/dev/null || echo 0)
    
    cat > port_scanning_report.md << EOF
# 🔍 Advanced Port Scanning & Service Fingerprinting Report
**Target:** $TARGET
**Date:** $(date)
**Scan Duration:** $SECONDS seconds

## 📊 Executive Summary
- **Total Unique Ports:** $total_ports
- **Target:Port Combinations:** $total_combinations
- **HTTP/HTTPS Services:** $http_services
- **Database Services:** $database_services
- **SSL/TLS Services:** $ssl_services

## 🚀 Scanning Methodology

### Port Discovery Methods
1. **Rustscan** - Ultra-fast initial discovery
2. **Masscan** - High-speed network scanning
3. **Nmap SYN Scan** - Reliable and comprehensive
4. **Custom Service Ports** - Targeted common services

### Service Detection Methods
1. **Nmap Service Detection** - Version and script scanning
2. **Banner Grabbing** - Direct service communication
3. **HTTP Analysis** - Web service identification
4. **Database Probing** - Database service detection
5. **SSL/TLS Analysis** - Certificate and cipher analysis

## 🎯 Discovered Ports
\`\`\`
$(head -20 ports/discovery/all_discovered_ports.txt 2>/dev/null | sort -n || echo "No ports discovered")
\`\`\`

## 🌐 Web Services Identified
\`\`\`
$(head -15 ports/services/http_services.txt 2>/dev/null || echo "No HTTP services found")
\`\`\`

## 🗄️ Database Services
\`\`\`
$(cat ports/services/database_services.txt 2>/dev/null || echo "No database services found")
\`\`\`

## 🔒 SSL/TLS Services
\`\`\`
$(head -10 ports/services/ssl_services.txt 2>/dev/null || echo "No SSL services found")
\`\`\`

## 🚨 Vulnerability Findings

### Critical Vulnerabilities
\`\`\`
$(grep -i "critical\|high" ports/vulnerabilities/nmap_vulnerabilities.txt 2>/dev/null | head -10 || echo "No critical vulnerabilities found")
\`\`\`

### CVE References
\`\`\`
$(grep -o "CVE-[0-9]\{4\}-[0-9]\{4,\}" ports/vulnerabilities/nmap_vuln_scan.nmap 2>/dev/null | sort -u | head -10 || echo "No CVEs identified")
\`\`\`

### Default Credentials Found
\`\`\`
$(find ports/vulnerabilities -name "*creds*" -exec grep -l "success\|connected\|authenticated" {} \; 2>/dev/null | head -5 || echo "No default credentials found")
\`\`\`

## 🔍 Service Analysis

### HTTP Service Headers
$(find ports/services -name "http_headers_*" -exec echo "=== {} ===" \; -exec head -5 {} \; 2>/dev/null | head -50)

### Database Service Information
$(find ports/services -name "*mysql*" -o -name "*postgres*" -o -name "*redis*" -exec echo "=== {} ===" \; -exec head -3 {} \; 2>/dev/null | head -30)

### SSL Certificate Information
$(find ports/services -name "ssl_cert_*" -exec echo "=== {} ===" \; -exec grep -E "Subject:|Issuer:|Not After" {} \; 2>/dev/null | head -30)

## 📸 Visual Evidence
- **Screenshots:** $(ls ports/screenshots/*.png 2>/dev/null | wc -l || echo 0) web service screenshots captured
- **Location:** ports/screenshots/

## 🎯 High-Priority Targets

### Administrative Interfaces
\`\`\`
$(grep -E "admin|administrator|panel|dashboard|control|manage" ports/services/http_content_* 2>/dev/null | head -5 || echo "No admin interfaces identified")
\`\`\`

### Development/Testing Services
\`\`\`
$(grep -E ":8080|:8000|:3000|:9000" ports/services/http_services.txt 2>/dev/null | head -5 || echo "No development services found")
\`\`\`

### Database Services with Potential Issues
\`\`\`
$(find ports/vulnerabilities -name "*vuln*" -exec grep -l "vulnerable\|exposed\|misconfigured" {} \; 2>/dev/null | head -5 || echo "No vulnerable database services identified")
\`\`\`

## 🛠️ Technical Details

### Nmap Service Detection Results
\`\`\`
$(head -20 ports/services/nmap_services.txt 2>/dev/null || echo "No service detection results")
\`\`\`

### Banner Grabbing Results
$(find ports/services -name "banner_*" -exec echo "=== {} ===" \; -exec cat {} \; 2>/dev/null | head -50)

## 📁 Files Generated
- **ports/discovery/** - Port discovery results
- **ports/services/** - Service detection and fingerprinting
- **ports/vulnerabilities/** - Vulnerability scan results
- **ports/screenshots/** - Web service screenshots

## 🚀 Recommended Next Steps

### Immediate Actions
1. **Verify Critical Vulnerabilities** - Manually test identified CVEs
2. **Test Default Credentials** - Attempt authentication on database services
3. **Analyze Web Applications** - Perform content discovery and vulnerability testing
4. **Review SSL/TLS Configuration** - Check for weak ciphers and certificate issues

### Deep Dive Analysis
1. **Service Version Research** - Check for known vulnerabilities in identified versions
2. **Configuration Review** - Analyze service configurations for misconfigurations
3. **Access Control Testing** - Test authentication and authorization mechanisms
4. **Data Exposure Assessment** - Check for sensitive information disclosure

### Bug Bounty Focus Areas
1. **Administrative Interfaces** - High-value targets for authentication bypass
2. **API Endpoints** - Look for API documentation and testing opportunities
3. **Database Services** - Test for injection vulnerabilities and data exposure
4. **SSL/TLS Issues** - Certificate and configuration vulnerabilities

## ⚡ Quick Commands for Further Testing

### Web Application Testing
\`\`\`bash
# Directory bruteforcing
gobuster dir -u http://target:port -w /usr/share/wordlists/dirb/common.txt

# Nikto web vulnerability scanner
nikto -h http://target:port

# SSL/TLS testing
sslscan target:port
\`\`\`

### Database Testing
\`\`\`bash
# MySQL testing
mysql -h target -P port -u root -p

# Redis testing
redis-cli -h target -p port

# PostgreSQL testing
psql -h target -p port -U postgres
\`\`\`

---
**Note:** Always ensure proper authorization before conducting security testing.
EOF

    echo -e "${GREEN}✅ Comprehensive port scanning report generated: port_scanning_report.md${NC}"
}

# Main execution function
main() {
    start_time=$(date +%s)
    
    echo -e "${PURPLE}🚀 Starting Advanced Port Scanning & Service Fingerprinting${NC}"
    
    fast_port_discovery
    service_fingerprinting
    vulnerability_scanning
    screenshot_services
    generate_port_report
    
    end_time=$(date +%s)
    execution_time=$((end_time - start_time))
    
    echo -e "${GREEN}🎉 Advanced Port Scanning Completed!${NC}"
    echo -e "${GREEN}⏱️  Total Execution Time: ${execution_time} seconds${NC}"
    echo -e "${GREEN}📊 Results: $(wc -l < ports/discovery/all_discovered_ports.txt) ports, $(wc -l < ports/services/target_port_combinations.txt 2>/dev/null || echo 0) services${NC}"
    echo -e "${GREEN}📄 Check 'port_scanning_report.md' for detailed analysis${NC}"
    
    # Show summary of interesting findings
    echo -e "${YELLOW}🎯 Quick Summary:${NC}"
    echo -e "   🌐 HTTP Services: $(wc -l < ports/services/http_services.txt 2>/dev/null || echo 0)"
    echo -e "   🗄️  Database Services: $(wc -l < ports/services/database_services.txt 2>/dev/null || echo 0)"
    echo -e "   🔒 SSL Services: $(wc -l < ports/services/ssl_services.txt 2>/dev/null || echo 0)"
    echo -e "   🚨 Vulnerability Files: $(find ports/vulnerabilities -name "*.txt" | wc -l)"
    echo -e "   📸 Screenshots: $(ls ports/screenshots/*.png 2>/dev/null | wc -l || echo 0)"
}

# Execute main function
main