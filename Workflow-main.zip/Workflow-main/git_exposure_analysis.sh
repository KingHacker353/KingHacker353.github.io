#!/bin/bash
# 🔍 Elite Git Repository Exposure & Source Code Analysis (Fixed Version)
# Advanced techniques for finding and analyzing exposed Git repositories

# Debug mode
DEBUG=1

echo "🔍 Elite Git Repository Exposure Analysis Started"

TARGET=$1
if [ -z "$TARGET" ]; then
    echo "Usage: ./git_exposure_analysis.sh target.com"
    exit 1
fi

# Create results directory
mkdir -p git_analysis_results
cd git_analysis_results

# Debug info
if [ "$DEBUG" = "1" ]; then
    echo "Debug: Current directory: $(pwd)"
    echo "Debug: Target: $TARGET"
    echo "Debug: Starting analysis..."
fi

echo "🎯 Starting Git exposure analysis for $TARGET"

# Initialize result files
touch git_exposed.txt git_forbidden.txt git_other_responses.txt

# ===== PHASE 1: GIT REPOSITORY DETECTION =====
echo "📂 Phase 1: Git repository detection..."

# Common Git paths to check
cat > git_paths.txt << 'EOF'
/.git/
/.git/config
/.git/HEAD
/.git/index
/.git/logs/HEAD
/.git/refs/heads/master
/.git/refs/heads/main
/.git/refs/heads/develop
/.git/refs/heads/dev
/.git/objects/
/.git/packed-refs
/.git/description
/.git/hooks/
/.git/info/refs
/.git/logs/refs/heads/master
/.git/logs/refs/heads/main
/.gitignore
/.gitmodules
/.git-credentials
/.gitconfig
EOF

# Test Git paths with better error handling
echo "🔍 Testing Git paths on $TARGET..."
exposed_count=0
forbidden_count=0
total_paths=$(wc -l < git_paths.txt)
current_path=0

while read -r path; do
    current_path=$((current_path + 1))
    test_url="https://$TARGET$path"
    
    if [ "$DEBUG" = "1" ]; then
        echo "Debug: Testing [$current_path/$total_paths]: $test_url"
    fi
    
    # Test with better error handling
    response=$(curl -s -o /dev/null -w "%{http_code}:%{size_download}:%{time_total}" "$test_url" --max-time 10 --connect-timeout 5)
    
    if [ $? -eq 0 ]; then
        status_code=$(echo $response | cut -d: -f1)
        size=$(echo $response | cut -d: -f2)
        time_total=$(echo $response | cut -d: -f3)
        
        if [ "$status_code" = "200" ] && [ "$size" -gt "0" ]; then
            echo "✅ GIT EXPOSURE FOUND: $test_url (Size: $size bytes, Time: ${time_total}s)" | tee -a git_exposed.txt
            exposed_count=$((exposed_count + 1))
            
            # Download Git files for analysis with error handling
            echo "📥 Downloading: $test_url"
            filename=$(basename "$path")
            if [ "$filename" = "" ] || [ "$filename" = "/" ]; then
                filename="git_index_$(date +%s).html"
            fi
            
            if curl -s "$test_url" -o "git_${filename//\//_}" --max-time 30; then
                echo "✅ Downloaded successfully: git_${filename//\//_}"
            else
                echo "❌ Download failed: $test_url"
            fi
            
        elif [ "$status_code" = "403" ]; then
            echo "🚫 FORBIDDEN (Potential Git): $test_url" | tee -a git_forbidden.txt
            forbidden_count=$((forbidden_count + 1))
        elif [ "$status_code" = "301" ] || [ "$status_code" = "302" ]; then
            echo "🔄 REDIRECT: $test_url (Status: $status_code)" | tee -a git_other_responses.txt
        elif [ "$DEBUG" = "1" ] && [ "$status_code" != "404" ]; then
            echo "Debug: Unexpected response: $test_url (Status: $status_code, Size: $size)"
        fi
    else
        if [ "$DEBUG" = "1" ]; then
            echo "Debug: Connection failed for: $test_url"
        fi
    fi
    
    sleep 0.3  # Rate limiting
done < git_paths.txt

echo "📊 Phase 1 Summary: Found $exposed_count exposures, $forbidden_count forbidden paths"

# ===== PHASE 2: AUTOMATED GIT DUMPING =====
echo "📦 Phase 2: Automated Git repository dumping..."

if [ -s "git_exposed.txt" ]; then
    echo "🔄 Attempting to dump Git repositories..."
    
    # Create enhanced Git dumper script
    cat > git_dumper.py << 'EOF'
#!/usr/bin/env python3
import requests
import os
import sys
import re
from urllib.parse import urljoin
import time

class GitDumper:
    def __init__(self, base_url, debug=False):
        self.base_url = base_url.rstrip('/')
        self.debug = debug
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        })
        self.downloaded_files = []
        
    def log(self, message):
        if self.debug:
            print(f"Debug: {message}")
    
    def download_file(self, path, local_path):
        """Download a file from the Git repository with error handling"""
        url = f"{self.base_url}/.git/{path}"
        try:
            self.log(f"Attempting to download: {url}")
            response = self.session.get(url, timeout=15)
            
            if response.status_code == 200 and len(response.content) > 0:
                os.makedirs(os.path.dirname(local_path), exist_ok=True)
                with open(local_path, 'wb') as f:
                    f.write(response.content)
                print(f"✅ Downloaded: {path} ({len(response.content)} bytes)")
                self.downloaded_files.append(path)
                return True
            elif response.status_code == 403:
                print(f"🚫 Forbidden: {path}")
            elif response.status_code == 404:
                self.log(f"Not found: {path}")
            else:
                self.log(f"Unexpected status {response.status_code} for: {path}")
                
        except requests.exceptions.Timeout:
            print(f"⏰ Timeout downloading: {path}")
        except requests.exceptions.ConnectionError:
            print(f"🔌 Connection error for: {path}")
        except Exception as e:
            print(f"❌ Error downloading {path}: {e}")
        
        return False
    
    def dump_git_repo(self):
        """Dump the entire Git repository with comprehensive error handling"""
        print(f"🔄 Dumping Git repository from: {self.base_url}")
        
        # Create local Git directory
        safe_name = self.base_url.replace('https://', '').replace('http://', '').replace('/', '_').replace(':', '_')
        git_dir = f"dumped_git_{safe_name}"
        
        try:
            os.makedirs(f"{git_dir}/.git", exist_ok=True)
        except Exception as e:
            print(f"❌ Failed to create directory {git_dir}: {e}")
            return None, []
        
        # Essential Git files to download
        essential_files = [
            'config',
            'HEAD',
            'index',
            'packed-refs',
            'description',
            'logs/HEAD',
            'refs/heads/master',
            'refs/heads/main',
            'refs/heads/develop',
            'refs/heads/dev',
            'info/refs',
            'COMMIT_EDITMSG'
        ]
        
        print(f"📁 Created directory: {git_dir}")
        
        for file_path in essential_files:
            local_path = f"{git_dir}/.git/{file_path}"
            self.download_file(file_path, local_path)
            time.sleep(0.2)  # Rate limiting
        
        # Try to download objects
        self.download_objects(git_dir)
        
        # Try to reconstruct files
        self.reconstruct_files(git_dir)
        
        return git_dir, self.downloaded_files
    
    def download_objects(self, git_dir):
        """Download Git objects with error handling"""
        print("📦 Downloading Git objects...")
        
        # Try to get packed objects
        pack_info_path = f"{git_dir}/.git/objects/info/packs"
        if self.download_file('objects/info/packs', pack_info_path):
            try:
                with open(pack_info_path, 'r') as f:
                    content = f.read()
                    self.log(f"Pack info content: {content}")
                    for line in content.split('\n'):
                        if line.startswith('P pack-'):
                            pack_name = line.strip().split()[1]
                            self.download_file(f'objects/pack/{pack_name}', 
                                             f"{git_dir}/.git/objects/pack/{pack_name}")
                            idx_name = pack_name.replace('.pack', '.idx')
                            self.download_file(f'objects/pack/{idx_name}', 
                                             f"{git_dir}/.git/objects/pack/{idx_name}")
            except Exception as e:
                print(f"❌ Error processing pack files: {e}")
        
        # Try to download some loose objects
        print("🔍 Attempting to download loose objects...")
        for i in range(10):  # Limited range for performance
            hex_prefix = f"{i:02x}"
            # Try common object patterns
            for suffix in ['0' * 38, '1' * 38, 'a' * 38]:
                obj_path = f"objects/{hex_prefix}/{suffix}"
                local_path = f"{git_dir}/.git/{obj_path}"
                if self.download_file(obj_path, local_path):
                    break  # Found one, move to next prefix
    
    def reconstruct_files(self, git_dir):
        """Try to reconstruct files from Git repository"""
        print("🔧 Attempting to reconstruct files...")
        
        try:
            original_dir = os.getcwd()
            os.chdir(git_dir)
            
            # Create status files
            status_files = {
                'git_status.txt': 'git status',
                'git_log.txt': 'git log --oneline --all',
                'git_branches.txt': 'git branch -a',
                'git_remotes.txt': 'git remote -v',
                'git_head.txt': 'git show HEAD',
                'git_config.txt': 'git config --list'
            }
            
            for filename, command in status_files.items():
                try:
                    os.system(f"{command} > {filename} 2>&1")
                    self.log(f"Created: {filename}")
                except Exception as e:
                    self.log(f"Failed to create {filename}: {e}")
            
            # Try to checkout files
            print("🔄 Attempting file checkout...")
            os.system("git checkout . 2>/dev/null")
            os.system("git reset --hard HEAD 2>/dev/null")
            
            # List recovered files
            recovered_files = []
            for root, dirs, files in os.walk('.'):
                for file in files:
                    if not file.startswith('git_') and not root.startswith('./.git'):
                        recovered_files.append(os.path.join(root, file))
            
            if recovered_files:
                print(f"✅ Recovered {len(recovered_files)} source files!")
                with open('recovered_files.txt', 'w') as f:
                    for file in recovered_files:
                        f.write(f"{file}\n")
            
            os.chdir(original_dir)
            
        except Exception as e:
            print(f"❌ Git reconstruction failed: {e}")
            try:
                os.chdir(original_dir)
            except:
                pass

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 git_dumper.py <base_url> [debug]")
        sys.exit(1)
    
    base_url = sys.argv[1]
    debug = len(sys.argv) > 2 and sys.argv[2].lower() == 'debug'
    
    dumper = GitDumper(base_url, debug)
    git_dir, files = dumper.dump_git_repo()
    
    if git_dir:
        print(f"\n✅ Git dumping completed!")
        print(f"📁 Repository saved to: {git_dir}")
        print(f"📋 Downloaded {len(files)} Git files")
    else:
        print("❌ Git dumping failed!")

if __name__ == "__main__":
    main()
EOF

    chmod +x git_dumper.py
    
    # Run Git dumper on found repositories
    while read -r git_line; do
        if [[ $git_line == *"GIT EXPOSURE FOUND"* ]]; then
            base_url=$(echo "$git_line" | grep -o 'https://[^/]*' | head -1)
            if [ ! -z "$base_url" ]; then
                echo "🔄 Dumping repository: $base_url"
                if [ "$DEBUG" = "1" ]; then
                    python3 git_dumper.py "$base_url" debug
                else
                    python3 git_dumper.py "$base_url"
                fi
            fi
        fi
    done < git_exposed.txt
else
    echo "ℹ️  No Git exposures found to dump"
fi

# ===== PHASE 3: SOURCE CODE ANALYSIS =====
echo "🔬 Phase 3: Source code analysis..."

# Create enhanced source code analyzer
cat > analyze_source.py << 'EOF'
#!/usr/bin/env python3
import os
import re
import sys
from pathlib import Path
import json

class SourceCodeAnalyzer:
    def __init__(self, directory, debug=False):
        self.directory = directory
        self.debug = debug
        self.sensitive_patterns = {
            'API Keys': [
                r'AKIA[0-9A-Z]{16}',  # AWS Access Key
                r'sk_live_[0-9a-zA-Z]{24}',  # Stripe Live Key
                r'sk_test_[0-9a-zA-Z]{24}',  # Stripe Test Key
                r'AIza[0-9A-Za-z\-_]{35}',  # Google API Key
                r'ya29\.[0-9A-Za-z\-_]+',  # Google OAuth
                r'ghp_[0-9A-Za-z]{36}',  # GitHub Personal Access Token
                r'gho_[0-9A-Za-z]{36}',  # GitHub OAuth Token
                r'glpat-[0-9A-Za-z\-_]{20}',  # GitLab Personal Access Token
                r'xoxb-[0-9A-Za-z\-]+',  # Slack Bot Token
                r'xoxp-[0-9A-Za-z\-]+',  # Slack User Token
            ],
            'Database Credentials': [
                r'mysql://[^\s\'"<>]+',
                r'postgresql://[^\s\'"<>]+',
                r'mongodb://[^\s\'"<>]+',
                r'redis://[^\s\'"<>]+',
                r'DATABASE_URL[\s]*=[\s]*["\']([^"\']+)["\']',
                r'DB_PASSWORD[\s]*=[\s]*["\']([^"\']+)["\']',
                r'DB_HOST[\s]*=[\s]*["\']([^"\']+)["\']',
                r'DB_USER[\s]*=[\s]*["\']([^"\']+)["\']',
            ],
            'Private Keys': [
                r'-----BEGIN PRIVATE KEY-----',
                r'-----BEGIN RSA PRIVATE KEY-----',
                r'-----BEGIN DSA PRIVATE KEY-----',
                r'-----BEGIN EC PRIVATE KEY-----',
                r'-----BEGIN OPENSSH PRIVATE KEY-----',
                r'-----BEGIN PGP PRIVATE KEY BLOCK-----',
            ],
            'Passwords & Secrets': [
                r'password[\s]*=[\s]*["\']([^"\']{3,})["\']',
                r'passwd[\s]*=[\s]*["\']([^"\']{3,})["\']',
                r'pwd[\s]*=[\s]*["\']([^"\']{3,})["\']',
                r'secret[\s]*=[\s]*["\']([^"\']{3,})["\']',
                r'SECRET_KEY[\s]*=[\s]*["\']([^"\']+)["\']',
                r'API_SECRET[\s]*=[\s]*["\']([^"\']+)["\']',
            ],
            'URLs and Endpoints': [
                r'https?://[^\s"\'<>)]+',
                r'api[._-]?key[\s]*=[\s]*["\']([^"\']+)["\']',
                r'api[._-]?secret[\s]*=[\s]*["\']([^"\']+)["\']',
                r'webhook[\s]*=[\s]*["\']([^"\']+)["\']',
            ],
            'Email Addresses': [
                r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
            ],
            'IP Addresses': [
                r'\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b',
            ]
        }
    
    def log(self, message):
        if self.debug:
            print(f"Debug: {message}")
    
    def analyze_file(self, file_path):
        """Analyze a single file for sensitive information"""
        findings = []
        
        try:
            # Skip binary files
            if self.is_binary_file(file_path):
                self.log(f"Skipping binary file: {file_path}")
                return findings
            
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                
                # Skip very large files
                if len(content) > 1024 * 1024:  # 1MB limit
                    self.log(f"Skipping large file: {file_path}")
                    return findings
                
                for category, patterns in self.sensitive_patterns.items():
                    for pattern in patterns:
                        try:
                            matches = re.finditer(pattern, content, re.IGNORECASE | re.MULTILINE)
                            for match in matches:
                                # Get context around the match
                                start = max(0, match.start() - 50)
                                end = min(len(content), match.end() + 50)
                                context = content[start:end].replace('\n', ' ').strip()
                                
                                findings.append({
                                    'file': file_path,
                                    'category': category,
                                    'pattern': pattern,
                                    'match': match.group(),
                                    'context': context,
                                    'line': content[:match.start()].count('\n') + 1,
                                    'confidence': self.calculate_confidence(match.group(), category)
                                })
                        except re.error as e:
                            self.log(f"Regex error in pattern {pattern}: {e}")
                            
        except Exception as e:
            print(f"❌ Error analyzing {file_path}: {e}")
        
        return findings
    
    def is_binary_file(self, file_path):
        """Check if file is binary"""
        try:
            with open(file_path, 'rb') as f:
                chunk = f.read(1024)
                return b'\0' in chunk
        except:
            return True
    
    def calculate_confidence(self, match, category):
        """Calculate confidence score for a match"""
        if category == 'API Keys':
            return 0.9  # High confidence for API key patterns
        elif category == 'Private Keys':
            return 0.95  # Very high confidence
        elif category == 'URLs and Endpoints':
            if 'localhost' in match.lower() or '127.0.0.1' in match:
                return 0.3  # Low confidence for local URLs
            return 0.7
        elif 'test' in match.lower() or 'example' in match.lower():
            return 0.4  # Lower confidence for test data
        else:
            return 0.6  # Medium confidence
    
    def analyze_directory(self):
        """Analyze all files in directory"""
        print(f"🔬 Analyzing source code in: {self.directory}")
        
        if not os.path.exists(self.directory):
            print(f"❌ Directory not found: {self.directory}")
            return []
        
        all_findings = []
        file_extensions = [
            '.php', '.py', '.js', '.java', '.rb', '.go', '.cpp', '.c', '.cs', '.vb',
            '.config', '.xml', '.json', '.yml', '.yaml', '.env', '.txt', '.md', '.ini',
            '.cfg', '.conf', '.properties', '.sql', '.sh', '.bat', '.ps1', '.dockerfile'
        ]
        
        analyzed_files = 0
        total_files = 0
        
        # Count total files first
        for root, dirs, files in os.walk(self.directory):
            # Skip .git directory
            dirs[:] = [d for d in dirs if d != '.git']
            total_files += len([f for f in files if any(f.lower().endswith(ext) for ext in file_extensions) or '.' not in f])
        
        for root, dirs, files in os.walk(self.directory):
            # Skip .git directory
            dirs[:] = [d for d in dirs if d != '.git']
            
            for file in files:
                file_path = os.path.join(root, file)
                
                # Check if file has interesting extension or no extension
                if any(file.lower().endswith(ext) for ext in file_extensions) or '.' not in file:
                    analyzed_files += 1
                    self.log(f"Analyzing [{analyzed_files}/{total_files}]: {file_path}")
                    
                    findings = self.analyze_file(file_path)
                    all_findings.extend(findings)
        
        print(f"📊 Analyzed {analyzed_files} files, found {len(all_findings)} potential issues")
        return all_findings
    
    def generate_report(self, findings):
        """Generate comprehensive analysis report"""
        if not findings:
            print("✅ No sensitive information found!")
            return "No sensitive information detected."
        
        # Sort findings by confidence score
        findings.sort(key=lambda x: x['confidence'], reverse=True)
        
        report = f"""# Source Code Security Analysis Report
Directory: {self.directory}
Analysis Date: {os.popen('date').read().strip()}
Total findings: {len(findings)}

## Executive Summary
"""
        
        # Group findings by category and confidence
        by_category = {}
        high_confidence = [f for f in findings if f['confidence'] >= 0.8]
        medium_confidence = [f for f in findings if 0.5 <= f['confidence'] < 0.8]
        low_confidence = [f for f in findings if f['confidence'] < 0.5]
        
        report += f"- High confidence issues: {len(high_confidence)}\n"
        report += f"- Medium confidence issues: {len(medium_confidence)}\n"
        report += f"- Low confidence issues: {len(low_confidence)}\n\n"
        
        for finding in findings:
            category = finding['category']
            if category not in by_category:
                by_category[category] = []
            by_category[category].append(finding)
        
        # High priority findings first
        if high_confidence:
            report += "## 🚨 High Priority Findings\n\n"
            for finding in high_confidence[:10]:  # Limit to top 10
                report += f"**File:** `{finding['file']}` (Line {finding['line']})\n"
                report += f"**Category:** {finding['category']}\n"
                report += f"**Match:** `{finding['match'][:100]}...` (Confidence: {finding['confidence']:.2f})\n"
                report += f"**Context:** `{finding['context'][:150]}...`\n\n"
        
        # Category breakdown
        for category, category_findings in by_category.items():
            report += f"## {category} ({len(category_findings)} findings)\n\n"
            
            for finding in category_findings[:5]:  # Limit to 5 per category
                report += f"**File:** `{finding['file']}` (Line {finding['line']})\n"
                report += f"**Match:** `{finding['match'][:100]}`\n"
                report += f"**Confidence:** {finding['confidence']:.2f}\n\n"
            
            if len(category_findings) > 5:
                report += f"... and {len(category_findings) - 5} more findings in this category\n\n"
        
        # Save report
        report_file = f"{os.path.basename(self.directory)}_security_analysis.md"
        try:
            with open(report_file, 'w', encoding='utf-8') as f:
                f.write(report)
            print(f"📋 Security analysis report saved: {report_file}")
        except Exception as e:
            print(f"❌ Failed to save report: {e}")
        
        # Save JSON for further processing
        json_file = f"{os.path.basename(self.directory)}_findings.json"
        try:
            with open(json_file, 'w', encoding='utf-8') as f:
                json.dump(findings, f, indent=2, default=str)
            print(f"💾 Raw findings saved: {json_file}")
        except Exception as e:
            print(f"❌ Failed to save JSON: {e}")
        
        return report

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 analyze_source.py <directory> [debug]")
        sys.exit(1)
    
    directory = sys.argv[1]
    debug = len(sys.argv) > 2 and sys.argv[2].lower() == 'debug'
    
    if not os.path.exists(directory):
        print(f"❌ Directory not found: {directory}")
        sys.exit(1)
    
    analyzer = SourceCodeAnalyzer(directory, debug)
    findings = analyzer.analyze_directory()
    analyzer.generate_report(findings)
    
    if findings:
        high_risk = len([f for f in findings if f['confidence'] >= 0.8])
        print(f"\n🎯 Analysis Summary:")
        print(f"   Total issues: {len(findings)}")
        print(f"   High risk: {high_risk}")
        if high_risk > 0:
            print(f"   ⚠️  Review high-risk findings immediately!")
    else:
        print(f"\n✅ No security issues detected in {directory}")

if __name__ == "__main__":
    main()
EOF

chmod +x analyze_source.py

# Analyze dumped repositories
dumped_repos=(dumped_git_*)
if [ ${#dumped_repos[@]} -gt 0 ] && [ -d "${dumped_repos[0]}" ]; then
    echo "🔬 Analyzing dumped Git repositories..."
    for git_dir in "${dumped_repos[@]}"; do
        if [ -d "$git_dir" ]; then
            echo "Analyzing: $git_dir"
            if [ "$DEBUG" = "1" ]; then
                python3 analyze_source.py "$git_dir" debug
            else
                python3 analyze_source.py "$git_dir"
            fi
        fi
    done
else
    echo "ℹ️  No dumped repositories found to analyze"
fi

# ===== PHASE 4: COMMIT HISTORY ANALYSIS =====
echo "📜 Phase 4: Commit history analysis..."

cat > analyze_commits.sh << 'EOF'
#!/bin/bash
# Enhanced commit history analysis

echo "📜 Starting commit history analysis..."

commit_analysis_count=0

for git_dir in dumped_git_*; do
    if [ -d "$git_dir/.git" ]; then
        echo "📜 Analyzing commit history: $git_dir"
        cd "$git_dir"
        
        repo_name=$(basename "$git_dir")
        
        # Get commit history with error handling
        if git log --oneline --all > "../commit_history_${repo_name}.txt" 2>/dev/null; then
            echo "✅ Extracted commit history for $repo_name"
        else
            echo "❌ Failed to extract commit history for $repo_name"
            echo "No valid commit history found" > "../commit_history_${repo_name}.txt"
        fi
        
        # Search for sensitive commits
        {
            echo "# Potentially Sensitive Commits for $repo_name"
            echo "Generated: $(date)"
            echo ""
            git log --grep="password" --grep="secret" --grep="key" --grep="token" --grep="credential" --grep="auth" --all --oneline 2>/dev/null
        } > "../sensitive_commits_${repo_name}.txt"
        
        # Get file changes
        if git log --name-only --all > "../file_changes_${repo_name}.txt" 2>/dev/null; then
            echo "✅ Extracted file changes for $repo_name"
        else
            echo "❌ Failed to extract file changes for $repo_name"
        fi
        
        # Search for deleted files that might contain secrets
        {
            echo "# Deleted Files Analysis for $repo_name"
            echo "Generated: $(date)"
            echo ""
            git log --diff-filter=D --summary --all 2>/dev/null
        } > "../deleted_files_${repo_name}.txt"
        
        # Additional analysis
        {
            echo "# Git Statistics for $repo_name"
            echo "Generated: $(date)"
            echo ""
            echo "## Total Commits:"
            git rev-list --all --count 2>/dev/null || echo "Unable to count commits"
            echo ""
            echo "## Contributors:"
            git shortlog -sn --all 2>/dev/null || echo "Unable to list contributors"
            echo ""
            echo "## Recent Activity:"
            git log --oneline -10 --all 2>/dev/null || echo "No recent activity found"
        } > "../git_stats_${repo_name}.txt"
        
        commit_analysis_count=$((commit_analysis_count + 1))
        cd ..
    fi
done

if [ $commit_analysis_count -eq 0 ]; then
    echo "ℹ️  No Git repositories found for commit analysis"
else
    echo "✅ Analyzed $commit_analysis_count repositories for commit history"
fi
EOF

chmod +x analyze_commits.sh
./analyze_commits.sh

# ===== PHASE 5: ENHANCED REPORTING =====
echo "📋 Phase 5: Generating comprehensive report..."

# Check file existence and create counts
if [ -f "git_exposed.txt" ] && [ -s "git_exposed.txt" ]; then
    exposures=$(wc -l < git_exposed.txt)
else
    exposures=0
fi

if [ -f "git_forbidden.txt" ] && [ -s "git_forbidden.txt" ]; then
    forbidden=$(wc -l < git_forbidden.txt)
else
    forbidden=0
fi

dumped_count=$(find . -maxdepth 1 -name "dumped_git_*" -type d 2>/dev/null | wc -l)

# Generate comprehensive report
cat > git_exposure_report.md << EOF
# 🔍 Git Repository Exposure Analysis Report

**Target:** $TARGET  
**Generated:** $(date)  
**Analysis Duration:** Started at script launch

## 📊 Executive Summary

| Metric | Count |
|--------|--------|
| Git exposures found | $exposures |
| Forbidden Git paths | $forbidden |
| Repositories dumped | $dumped_count |
| Analysis files created | $(find . -name "*.txt" -o -name "*.md" -o -name "*.json" | wc -l) |

## 🎯 Risk Assessment

EOF

if [ $exposures -gt 0 ]; then
    echo "**🚨 HIGH RISK - Git repositories are exposed!**" >> git_exposure_report.md
    echo "" >> git_exposure_report.md
    echo "Immediate action required:" >> git_exposure_report.md
    echo "- Remove .git directories from web-accessible locations" >> git_exposure_report.md
    echo "- Review exposed source code for sensitive information" >> git_exposure_report.md
    echo "- Check commit history for leaked credentials" >> git_exposure_report.md
elif [ $forbidden -gt 0 ]; then
    echo "**⚠️ MEDIUM RISK - Git paths return 403 Forbidden**" >> git_exposure_report.md
    echo "" >> git_exposure_report.md
    echo "Potential issues:" >> git_exposure_report.md
    echo "- Git repositories may be present but protected" >> git_exposure_report.md
    echo "- Server configuration may have vulnerabilities" >> git_exposure_report.md
else
    echo "**✅ LOW RISK - No Git exposures detected**" >> git_exposure_report.md
    echo "" >> git_exposure_report.md
    echo "The target appears to be properly configured." >> git_exposure_report.md
fi

cat >> git_exposure_report.md << EOF

## 🔍 Detailed Findings

### Exposed Git Paths
EOF

if [ -f "git_exposed.txt" ] && [ -s "git_exposed.txt" ]; then
    echo '```
    cat git_exposed.txt >> git_exposure_report.md
    echo '```' >> git_exposure_report.md
else
    echo "None found." >> git_exposure_report.md
fi

cat >> git_exposure_report.md << EOF

### Forbidden Git Paths
EOF

if [ -f "git_forbidden.txt" ] && [ -s "git_forbidden.txt" ]; then
    echo '```
    head -20 git_forbidden.txt >> git_exposure_report.md
    if [ $(wc -l < git_forbidden.txt) -gt 20 ]; then
        echo "... and $(($(wc -l < git_forbidden.txt) - 20)) more entries" >> git_exposure_report.md
    fi
    echo '```' >> git_exposure_report.md
else
    echo "None found." >> git_exposure_report.md
fi

cat >> git_exposure_report.md << EOF

## 📁 Dumped Repositories

EOF

if [ $dumped_count -gt 0 ]; then
    for git_dir in dumped_git_*; do
        if [ -d "$git_dir" ]; then
            echo "### $git_dir" >> git_exposure_report.md
            echo "" >> git_exposure_report.md
            if [ -f "$git_dir/recovered_files.txt" ]; then
                recovered_count=$(wc -l < "$git_dir/recovered_files.txt")
                echo "- **Recovered files:** $recovered_count" >> git_exposure_report.md
            fi
            if [ -f "${git_dir}_security_analysis.md" ]; then
                echo "- **Security analysis:** Available" >> git_exposure_report.md
            fi
            echo "- **Location:** $(pwd)/$git_dir" >> git_exposure_report.md
            echo "" >> git_exposure_report.md
        fi
    done
else
    echo "No repositories were successfully dumped." >> git_exposure_report.md
fi

cat >> git_exposure_report.md << EOF

## 🔧 Files Generated

This analysis created the following files:

EOF

# List all generated files
find . -maxdepth 1 \( -name "*.txt" -o -name "*.md" -o -name "*.json" -o -name "*.py" -o -name "*.sh" \) -type f | sort | while read -r file; do
    filename=$(basename "$file")
    size=$(ls -lh "$file" | awk '{print $5}')
    echo "- **$filename** ($size)" >> git_exposure_report.md
done

cat >> git_exposure_report.md << EOF

## 🎯 Recommendations

### For Security Teams:
1. **Immediate Actions:**
   - Remove any exposed .git directories from web servers
   - Scan exposed source code for hardcoded credentials
   - Review commit history for sensitive information

2. **Preventive Measures:**
   - Implement proper .gitignore files
   - Use environment variables for sensitive configuration
   - Regular security scans of web-accessible directories

### For Developers:
1. **Best Practices:**
   - Never commit sensitive information to Git
   - Use separate repositories for public and private code
   - Implement pre-commit hooks to detect secrets

2. **Remediation Steps:**
   - If credentials were exposed, rotate them immediately
   - Consider repository history cleanup if sensitive data was committed
   - Implement proper deployment processes that exclude .git directories

## 📞 Support

This analysis was generated by the Elite Git Exposure Analysis tool.
For questions or additional analysis, review the individual result files.

---
**Analysis completed at:** $(date)
EOF

# Create summary statistics
cat > analysis_summary.txt << EOF
Git Exposure Analysis Summary for $TARGET
==========================================
Generated: $(date)

Results:
- Git exposures: $exposures
- Forbidden paths: $forbidden  
- Repositories dumped: $dumped_count
- Total files analyzed: $(find . -name "*.txt" -o -name "*.md" -o -name "*.json" | wc -l)

Risk Level: $([ $exposures -gt 0 ] && echo "HIGH" || ([ $forbidden -gt 0 ] && echo "MEDIUM" || echo "LOW"))

Next Steps:
1. Review git_exposure_report.md for detailed findings
2. Check individual analysis files for specific issues
3. If repositories were dumped, review security analysis reports
4. Take appropriate remediation actions based on risk level
EOF

echo "✅ Git exposure analysis completed successfully!"
echo ""
echo "📁 Results saved in: $(pwd)/"
echo "📋 Main report: git_exposure_report.md"
echo "📊 Summary: analysis_summary.txt"
echo ""
echo "🔍 Quick Results:"
echo "   - Git exposures found: $exposures"
echo "   - Forbidden Git paths: $forbidden" 
echo "   - Repositories dumped: $dumped_count"
echo ""

if [ $exposures -gt 0 ]; then
    echo "🚨 CRITICAL: Git repositories are exposed!"
    echo "🎯 Priority Actions:"
    echo "   1. Review git_exposed.txt immediately"
    echo "   2. Check dumped repositories for sensitive data"
    echo "   3. Review security analysis reports"
elif [ $forbidden -gt 0 ]; then
    echo "⚠️  WARNING: Some Git paths are forbidden but may exist"
    echo "🎯 Recommended Actions:"
    echo "   1. Review git_forbidden.txt"
    echo "   2. Investigate server configuration"
else
    echo "✅ GOOD: No Git exposures detected"
    echo "🎯 The target appears properly secured"
fi

echo ""
echo "📚 Documentation: All analysis steps and results are documented in git_exposure_report.md"

# Debug info
if [ "$DEBUG" = "1" ]; then
    echo ""
    echo "🐛 Debug Info:"
    echo "   - Current directory: $(pwd)"
    echo "   - Files created: $(ls -1 | wc -l)"
    echo "   - Analysis completed successfully"
fi
