#!/bin/bash
# 🎯 Multi-Source Subdomain Enumeration - Elite Bug Bounty Technique
# Bhai, yeh script tumhe 15+ sources se subdomains nikaal kar dega

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

TARGET=$1
if [ -z "$TARGET" ]; then
    echo -e "${RED}Usage: ./multi_source_subdomain_enum.sh target.com${NC}"
    exit 1
fi

echo -e "${GREEN}🎯 Multi-Source Subdomain Enumeration for $TARGET${NC}"
mkdir -p $TARGET/subdomains/{passive,active,dns,certificate,archive,social}
cd $TARGET

# Function: Passive subdomain enumeration (15+ sources)
passive_enumeration() {
    echo -e "${BLUE}🔍 Phase 1: Passive Subdomain Enumeration (15+ Sources)${NC}"
    
    # Source 1: Subfinder (multiple APIs)
    echo -e "${YELLOW}[1/15] Running Subfinder...${NC}"
    subfinder -d $TARGET -silent -o subdomains/passive/subfinder.txt
    echo -e "${GREEN}✅ Subfinder: $(wc -l < subdomains/passive/subfinder.txt) subdomains${NC}"
    
    # Source 2: Amass passive
    echo -e "${YELLOW}[2/15] Running Amass passive...${NC}"
    amass enum -passive -d $TARGET -o subdomains/passive/amass.txt
    echo -e "${GREEN}✅ Amass: $(wc -l < subdomains/passive/amass.txt) subdomains${NC}"
    
    # Source 3: Assetfinder
    echo -e "${YELLOW}[3/15] Running Assetfinder...${NC}"
    assetfinder --subs-only $TARGET > subdomains/passive/assetfinder.txt
    echo -e "${GREEN}✅ Assetfinder: $(wc -l < subdomains/passive/assetfinder.txt) subdomains${NC}"
    
    # Source 4: Certificate Transparency (crt.sh)
    echo -e "${YELLOW}[4/15] Certificate Transparency (crt.sh)...${NC}"
    curl -s "https://crt.sh/?q=%25.$TARGET&output=json" | jq -r '.[].name_value' | sed 's/\*\.//g' | sort -u > subdomains/certificate/crt_sh.txt
    echo -e "${GREEN}✅ crt.sh: $(wc -l < subdomains/certificate/crt_sh.txt) subdomains${NC}"
    
    # Source 5: Chaos API (ProjectDiscovery)
    echo -e "${YELLOW}[5/15] Chaos API...${NC}"
    curl -s "https://dns.bufferover.run/dns?q=.$TARGET" | jq -r '.FDNS_A[]' | cut -d',' -f2 | sort -u > subdomains/dns/chaos.txt 2>/dev/null
    echo -e "${GREEN}✅ Chaos: $(wc -l < subdomains/dns/chaos.txt 2>/dev/null || echo 0) subdomains${NC}"
    
    # Source 6: RapidDNS
    echo -e "${YELLOW}[6/15] RapidDNS...${NC}"
    curl -s "https://rapiddns.io/subdomain/$TARGET?full=1" | grep -oP '_blank">\K[^<]*' | grep -v $TARGET | sort -u > subdomains/dns/rapiddns.txt
    echo -e "${GREEN}✅ RapidDNS: $(wc -l < subdomains/dns/rapiddns.txt) subdomains${NC}"
    
    # Source 7: DNSdumpster
    echo -e "${YELLOW}[7/15] DNSdumpster...${NC}"
    curl -s "https://dnsdumpster.com/api/" -H "Content-Type: application/x-www-form-urlencoded" -d "targetip=$TARGET" | grep -oP 'https://[^"]*' | grep $TARGET | cut -d'/' -f3 | sort -u > subdomains/dns/dnsdumpster.txt
    echo -e "${GREEN}✅ DNSdumpster: $(wc -l < subdomains/dns/dnsdumpster.txt) subdomains${NC}"
    
    # Source 8: Wayback Machine URLs
    echo -e "${YELLOW}[8/15] Wayback Machine...${NC}"
    curl -s "http://web.archive.org/cdx/search/cdx?url=*.$TARGET/*&output=text&fl=original&collapse=urlkey" | cut -d'/' -f3 | grep $TARGET | sort -u > subdomains/archive/wayback.txt
    echo -e "${GREEN}✅ Wayback: $(wc -l < subdomains/archive/wayback.txt) subdomains${NC}"
    
    # Source 9: CommonCrawl
    echo -e "${YELLOW}[9/15] CommonCrawl...${NC}"
    curl -s "http://index.commoncrawl.org/CC-MAIN-2023-06-index?url=*.$TARGET&output=json" | jq -r '.url' | cut -d'/' -f3 | grep $TARGET | sort -u > subdomains/archive/commoncrawl.txt 2>/dev/null
    echo -e "${GREEN}✅ CommonCrawl: $(wc -l < subdomains/archive/commoncrawl.txt 2>/dev/null || echo 0) subdomains${NC}"
    
    # Source 10: VirusTotal
    echo -e "${YELLOW}[10/15] VirusTotal...${NC}"
    curl -s "https://www.virustotal.com/vtapi/v2/domain/report?apikey=YOUR_API_KEY&domain=$TARGET" | jq -r '.subdomains[]' 2>/dev/null | sort -u > subdomains/passive/virustotal.txt
    echo -e "${GREEN}✅ VirusTotal: $(wc -l < subdomains/passive/virustotal.txt 2>/dev/null || echo 0) subdomains${NC}"
    
    # Source 11: Shodan
    echo -e "${YELLOW}[11/15] Shodan...${NC}"
    curl -s "https://api.shodan.io/dns/domain/$TARGET?key=YOUR_API_KEY" | jq -r '.subdomains[]' 2>/dev/null | sed "s/$/.${TARGET}/" | sort -u > subdomains/passive/shodan.txt
    echo -e "${GREEN}✅ Shodan: $(wc -l < subdomains/passive/shodan.txt 2>/dev/null || echo 0) subdomains${NC}"
    
    # Source 12: SecurityTrails
    echo -e "${YELLOW}[12/15] SecurityTrails...${NC}"
    curl -s "https://api.securitytrails.com/v1/domain/$TARGET/subdomains" -H "APIKEY: YOUR_API_KEY" | jq -r '.subdomains[]' 2>/dev/null | sed "s/$/.${TARGET}/" | sort -u > subdomains/passive/securitytrails.txt
    echo -e "${GREEN}✅ SecurityTrails: $(wc -l < subdomains/passive/securitytrails.txt 2>/dev/null || echo 0) subdomains${NC}"
    
    # Source 13: Spyse
    echo -e "${YELLOW}[13/15] Spyse...${NC}"
    curl -s "https://api.spyse.com/v4/data/domain/subdomain/$TARGET" -H "Authorization: Bearer YOUR_API_KEY" | jq -r '.data.items[].name' 2>/dev/null | sort -u > subdomains/passive/spyse.txt
    echo -e "${GREEN}✅ Spyse: $(wc -l < subdomains/passive/spyse.txt 2>/dev/null || echo 0) subdomains${NC}"
    
    # Source 14: GitHub Search
    echo -e "${YELLOW}[14/15] GitHub Search...${NC}"
    curl -s "https://api.github.com/search/code?q=$TARGET+extension:txt+extension:json+extension:yml+extension:yaml+extension:conf" | jq -r '.items[].html_url' 2>/dev/null | xargs -I {} curl -s {} | grep -oE "[a-zA-Z0-9.-]+\.$TARGET" | sort -u > subdomains/social/github.txt
    echo -e "${GREEN}✅ GitHub: $(wc -l < subdomains/social/github.txt 2>/dev/null || echo 0) subdomains${NC}"
    
    # Source 15: Google Dorking
    echo -e "${YELLOW}[15/15] Google Dorking...${NC}"
    # Note: This requires manual verification due to CAPTCHA
    echo "site:$TARGET -www" > subdomains/social/google_dorks.txt
    echo "site:*.$TARGET" >> subdomains/social/google_dorks.txt
    echo "inurl:$TARGET" >> subdomains/social/google_dorks.txt
    echo -e "${GREEN}✅ Google Dorks: Created search queries${NC}"
    
    # Combine all passive results
    cat subdomains/passive/*.txt subdomains/certificate/*.txt subdomains/dns/*.txt subdomains/archive/*.txt subdomains/social/*.txt 2>/dev/null | sort -u > subdomains/all_passive.txt
    echo -e "${GREEN}🎉 Total Passive Subdomains: $(wc -l < subdomains/all_passive.txt)${NC}"
}

# Function: Active subdomain enumeration
active_enumeration() {
    echo -e "${BLUE}🔍 Phase 2: Active Subdomain Enumeration${NC}"
    
    # DNS bruteforcing with multiple wordlists
    echo -e "${YELLOW}[+] DNS Bruteforcing with Gobuster...${NC}"
    
    # Small wordlist (fast)
    gobuster dns -d $TARGET -w ~/wordlists/SecLists/Discovery/DNS/subdomains-top1million-5000.txt -o subdomains/active/gobuster_small.txt --quiet
    echo -e "${GREEN}✅ Gobuster (5K): $(wc -l < subdomains/active/gobuster_small.txt) subdomains${NC}"
    
    # Medium wordlist
    gobuster dns -d $TARGET -w ~/wordlists/SecLists/Discovery/DNS/subdomains-top1million-20000.txt -o subdomains/active/gobuster_medium.txt --quiet
    echo -e "${GREEN}✅ Gobuster (20K): $(wc -l < subdomains/active/gobuster_medium.txt) subdomains${NC}"
    
    # Custom wordlist based on target
    echo -e "${YELLOW}[+] Creating custom wordlist...${NC}"
    
    # Extract words from main domain
    curl -s "http://$TARGET" | html2text | tr ' ' '\n' | grep -v '^$' | sort -u > subdomains/active/custom_words.txt
    
    # Common subdomain patterns
    cat > subdomains/active/common_patterns.txt << 'EOF'
api
admin
www
mail
ftp
blog
shop
store
dev
test
staging
prod
production
beta
alpha
demo
docs
help
support
portal
dashboard
panel
control
manage
secure
vpn
remote
internal
intranet
extranet
private
public
static
assets
cdn
media
images
img
css
js
files
download
upload
backup
old
new
v1
v2
v3
mobile
m
wap
app
apps
service
services
web
webmail
email
smtp
pop
imap
ns1
ns2
dns
mx
subdomain
sub
EOF
    
    # Combine custom words with common patterns
    cat subdomains/active/custom_words.txt subdomains/active/common_patterns.txt | sort -u > subdomains/active/combined_wordlist.txt
    
    # Bruteforce with custom wordlist
    gobuster dns -d $TARGET -w subdomains/active/combined_wordlist.txt -o subdomains/active/gobuster_custom.txt --quiet
    echo -e "${GREEN}✅ Gobuster (Custom): $(wc -l < subdomains/active/gobuster_custom.txt) subdomains${NC}"
    
    # Alternative DNS bruteforcing with puredns
    if command -v puredns &> /dev/null; then
        echo -e "${YELLOW}[+] DNS Bruteforcing with puredns...${NC}"
        puredns bruteforce ~/wordlists/SecLists/Discovery/DNS/subdomains-top1million-5000.txt $TARGET -r ~/resolvers.txt > subdomains/active/puredns.txt
        echo -e "${GREEN}✅ Puredns: $(wc -l < subdomains/active/puredns.txt) subdomains${NC}"
    fi
    
    # Combine all active results
    cat subdomains/active/*.txt 2>/dev/null | grep $TARGET | sort -u > subdomains/all_active.txt
    echo -e "${GREEN}🎉 Total Active Subdomains: $(wc -l < subdomains/all_active.txt)${NC}"
}

# Function: DNS zone transfer attempts
dns_zone_transfer() {
    echo -e "${BLUE}🔍 Phase 3: DNS Zone Transfer Attempts${NC}"
    
    # Find nameservers
    echo -e "${YELLOW}[+] Finding nameservers...${NC}"
    dig NS $TARGET +short > subdomains/dns/nameservers.txt
    
    # Attempt zone transfer on each nameserver
    echo -e "${YELLOW}[+] Attempting zone transfers...${NC}"
    while read ns; do
        if [ ! -z "$ns" ]; then
            echo "Trying zone transfer on: $ns"
            dig AXFR $TARGET @$ns > subdomains/dns/zone_transfer_$ns.txt
            if grep -q "$TARGET" subdomains/dns/zone_transfer_$ns.txt; then
                echo -e "${GREEN}✅ Zone transfer successful on $ns${NC}"
                grep $TARGET subdomains/dns/zone_transfer_$ns.txt | awk '{print $1}' >> subdomains/dns/zone_transfer_results.txt
            else
                echo -e "${RED}❌ Zone transfer failed on $ns${NC}"
            fi
        fi
    done < subdomains/dns/nameservers.txt
    
    if [ -f "subdomains/dns/zone_transfer_results.txt" ]; then
        sort -u subdomains/dns/zone_transfer_results.txt -o subdomains/dns/zone_transfer_results.txt
        echo -e "${GREEN}🎉 Zone Transfer Results: $(wc -l < subdomains/dns/zone_transfer_results.txt) subdomains${NC}"
    else
        echo -e "${YELLOW}⚠️  No successful zone transfers${NC}"
    fi
}

# Function: Certificate transparency deep dive
certificate_transparency() {
    echo -e "${BLUE}🔍 Phase 4: Certificate Transparency Deep Dive${NC}"
    
    # Multiple CT log sources
    echo -e "${YELLOW}[+] Searching multiple CT logs...${NC}"
    
    # crt.sh (already done in passive, but with more detail)
    curl -s "https://crt.sh/?q=%25.$TARGET&output=json" | jq -r '.[].name_value' | sed 's/\*\.//g' | sort -u > subdomains/certificate/crt_sh_detailed.txt
    
    # Censys CT search
    curl -s "https://search.censys.io/api/v2/certificates/search?q=names:$TARGET" -H "Authorization: Basic YOUR_API_KEY" | jq -r '.result.hits[].names[]' 2>/dev/null | grep $TARGET | sort -u > subdomains/certificate/censys.txt
    
    # Facebook CT API
    curl -s "https://graph.facebook.com/certificates?query=$TARGET&access_token=YOUR_TOKEN" | jq -r '.data[].domains[]' 2>/dev/null | grep $TARGET | sort -u > subdomains/certificate/facebook.txt
    
    # Google CT API
    curl -s "https://transparencyreport.google.com/transparencyreport/api/v3/httpsct/search?include_expired=true&include_subdomains=true&domain=$TARGET" | jq -r '.results[].subjectName' 2>/dev/null | grep $TARGET | sort -u > subdomains/certificate/google_ct.txt
    
    # Combine all certificate sources
    cat subdomains/certificate/*.txt 2>/dev/null | sort -u > subdomains/all_certificate.txt
    echo -e "${GREEN}🎉 Total Certificate Subdomains: $(wc -l < subdomains/all_certificate.txt)${NC}"
}

# Function: Social media and code repository search
social_code_search() {
    echo -e "${BLUE}🔍 Phase 5: Social Media & Code Repository Search${NC}"
    
    # GitHub advanced search
    echo -e "${YELLOW}[+] GitHub advanced search...${NC}"
    
    # Search in different file types
    for ext in txt json yml yaml conf xml; do
        echo "Searching GitHub for .$ext files..."
        curl -s "https://api.github.com/search/code?q=$TARGET+extension:$ext" | jq -r '.items[].html_url' 2>/dev/null | head -10 >> subdomains/social/github_urls.txt
    done
    
    # GitLab search
    echo -e "${YELLOW}[+] GitLab search...${NC}"
    curl -s "https://gitlab.com/api/v4/search?scope=blobs&search=$TARGET" | jq -r '.[].web_url' 2>/dev/null | head -10 > subdomains/social/gitlab_urls.txt
    
    # Pastebin search (using Google)
    echo -e "${YELLOW}[+] Pastebin search patterns...${NC}"
    cat > subdomains/social/pastebin_searches.txt << EOF
site:pastebin.com "$TARGET"
site:paste.org "$TARGET"
site:pastie.org "$TARGET"
site:slexy.org "$TARGET"
site:snipplr.com "$TARGET"
site:snipt.net "$TARGET"
site:textsnip.com "$TARGET"
EOF
    
    # Social media search patterns
    echo -e "${YELLOW}[+] Social media search patterns...${NC}"
    cat > subdomains/social/social_searches.txt << EOF
site:twitter.com "$TARGET"
site:facebook.com "$TARGET"
site:linkedin.com "$TARGET"
site:reddit.com "$TARGET"
site:stackoverflow.com "$TARGET"
site:github.com "$TARGET"
site:gitlab.com "$TARGET"
site:bitbucket.org "$TARGET"
EOF
    
    echo -e "${GREEN}✅ Social and code search patterns created${NC}"
}

# Function: Advanced DNS techniques
advanced_dns_techniques() {
    echo -e "${BLUE}🔍 Phase 6: Advanced DNS Techniques${NC}"
    
    # DNS cache snooping
    echo -e "${YELLOW}[+] DNS cache snooping...${NC}"
    for ns in $(cat subdomains/dns/nameservers.txt); do
        if [ ! -z "$ns" ]; then
            echo "Cache snooping on: $ns"
            dig @$ns $TARGET +norecurse > subdomains/dns/cache_snoop_$ns.txt
        fi
    done
    
    # Reverse DNS lookups
    echo -e "${YELLOW}[+] Reverse DNS lookups...${NC}"
    
    # Get IP ranges for the target
    dig $TARGET +short | head -5 > subdomains/dns/target_ips.txt
    
    # Perform reverse DNS on IP ranges
    while read ip; do
        if [ ! -z "$ip" ]; then
            # Get the /24 network
            network=$(echo $ip | cut -d'.' -f1-3)
            echo "Reverse DNS scan on $network.0/24"
            for i in {1..254}; do
                host $network.$i 2>/dev/null | grep $TARGET >> subdomains/dns/reverse_dns.txt &
            done
            wait
        fi
    done < subdomains/dns/target_ips.txt
    
    # DNS wildcard detection
    echo -e "${YELLOW}[+] DNS wildcard detection...${NC}"
    random_sub=$(openssl rand -hex 10)
    wildcard_ip=$(dig $random_sub.$TARGET +short | head -1)
    if [ ! -z "$wildcard_ip" ]; then
        echo "Wildcard detected: $wildcard_ip" > subdomains/dns/wildcard_info.txt
        echo -e "${YELLOW}⚠️  Wildcard DNS detected: $wildcard_ip${NC}"
    else
        echo "No wildcard detected" > subdomains/dns/wildcard_info.txt
        echo -e "${GREEN}✅ No wildcard DNS detected${NC}"
    fi
    
    # DNS record enumeration
    echo -e "${YELLOW}[+] DNS record enumeration...${NC}"
    for record_type in A AAAA CNAME MX TXT NS SOA PTR; do
        echo "Querying $record_type records..."
        dig $TARGET $record_type +short > subdomains/dns/${record_type}_records.txt
    done
}

# Function: Subdomain validation and filtering
subdomain_validation() {
    echo -e "${BLUE}🔍 Phase 7: Subdomain Validation & Filtering${NC}"
    
    # Combine all sources
    echo -e "${YELLOW}[+] Combining all sources...${NC}"
    cat subdomains/all_passive.txt subdomains/all_active.txt subdomains/all_certificate.txt subdomains/dns/zone_transfer_results.txt subdomains/dns/reverse_dns.txt 2>/dev/null | sort -u > subdomains/all_combined.txt
    
    # Remove wildcards and invalid entries
    echo -e "${YELLOW}[+] Filtering invalid entries...${NC}"
    
    # Remove entries with wildcards
    grep -v '\*' subdomains/all_combined.txt > subdomains/filtered_no_wildcards.txt
    
    # Remove entries that don't end with target domain
    grep "\.$TARGET$\|^$TARGET$" subdomains/filtered_no_wildcards.txt > subdomains/filtered_valid_domain.txt
    
    # Remove duplicates and empty lines
    grep -v '^$' subdomains/filtered_valid_domain.txt | sort -u > subdomains/final_subdomains.txt
    
    echo -e "${GREEN}🎉 Final Subdomain Count: $(wc -l < subdomains/final_subdomains.txt)${NC}"
    
    # Validate subdomains with DNS resolution
    echo -e "${YELLOW}[+] Validating subdomains with DNS resolution...${NC}"
    
    # Check which subdomains resolve
    while read subdomain; do
        if [ ! -z "$subdomain" ]; then
            ip=$(dig +short "$subdomain" | head -1)
            if [ ! -z "$ip" ] && [[ $ip =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
                echo "$subdomain:$ip" >> subdomains/resolved_subdomains.txt
            fi
        fi
    done < subdomains/final_subdomains.txt
    
    # Extract just the subdomain names that resolved
    cut -d':' -f1 subdomains/resolved_subdomains.txt > subdomains/live_subdomains.txt
    
    echo -e "${GREEN}🎉 Live Subdomains: $(wc -l < subdomains/live_subdomains.txt 2>/dev/null || echo 0)${NC}"
}

# Function: Generate comprehensive report
generate_subdomain_report() {
    echo -e "${BLUE}🎯 Generating Comprehensive Subdomain Report${NC}"
    
    # Calculate statistics
    passive_count=$(wc -l < subdomains/all_passive.txt 2>/dev/null || echo 0)
    active_count=$(wc -l < subdomains/all_active.txt 2>/dev/null || echo 0)
    certificate_count=$(wc -l < subdomains/all_certificate.txt 2>/dev/null || echo 0)
    final_count=$(wc -l < subdomains/final_subdomains.txt 2>/dev/null || echo 0)
    live_count=$(wc -l < subdomains/live_subdomains.txt 2>/dev/null || echo 0)
    
    cat > subdomain_enumeration_report.md << EOF
# 🎯 Multi-Source Subdomain Enumeration Report
**Target:** $TARGET
**Date:** $(date)
**Execution Time:** $SECONDS seconds

## 📊 Summary Statistics
- **Passive Sources:** $passive_count subdomains
- **Active Enumeration:** $active_count subdomains  
- **Certificate Transparency:** $certificate_count subdomains
- **Total Unique:** $final_count subdomains
- **Live/Resolved:** $live_count subdomains

## 🔍 Enumeration Sources Used

### Passive Sources (15 sources)
1. **Subfinder** - Multiple API integrations
2. **Amass** - Passive reconnaissance
3. **Assetfinder** - Fast subdomain discovery
4. **Certificate Transparency** - crt.sh database
5. **Chaos API** - ProjectDiscovery dataset
6. **RapidDNS** - DNS database
7. **DNSdumpster** - DNS reconnaissance
8. **Wayback Machine** - Archive.org URLs
9. **CommonCrawl** - Web crawl data
10. **VirusTotal** - Threat intelligence
11. **Shodan** - Internet-connected devices
12. **SecurityTrails** - DNS history
13. **Spyse** - Internet assets
14. **GitHub** - Code repositories
15. **Google Dorking** - Search engine queries

### Active Sources
- **Gobuster DNS** - Multiple wordlists (5K, 20K, custom)
- **Puredns** - Fast DNS bruteforcing
- **Custom Wordlists** - Target-specific patterns

### Advanced Techniques
- **DNS Zone Transfer** - AXFR attempts
- **Certificate Transparency** - Multiple CT logs
- **Reverse DNS** - IP range scanning
- **DNS Cache Snooping** - Nameserver analysis
- **Wildcard Detection** - DNS configuration analysis

## 🎯 Top Subdomains Found
\`\`\`
$(head -20 subdomains/live_subdomains.txt 2>/dev/null || echo "No live subdomains found")
\`\`\`

## 🔍 Interesting Findings

### Potential Admin Panels
\`\`\`
$(grep -E "(admin|administrator|panel|dashboard|control|manage)" subdomains/live_subdomains.txt 2>/dev/null | head -10 || echo "None found")
\`\`\`

### Development/Staging Environments
\`\`\`
$(grep -E "(dev|test|staging|beta|alpha|demo)" subdomains/live_subdomains.txt 2>/dev/null | head -10 || echo "None found")
\`\`\`

### API Endpoints
\`\`\`
$(grep -E "(api|rest|graphql|webhook)" subdomains/live_subdomains.txt 2>/dev/null | head -10 || echo "None found")
\`\`\`

### Mail Servers
\`\`\`
$(grep -E "(mail|smtp|pop|imap|webmail|email)" subdomains/live_subdomains.txt 2>/dev/null | head -10 || echo "None found")
\`\`\`

## 🛠️ Technical Details

### DNS Configuration
- **Nameservers:** $(cat subdomains/dns/nameservers.txt 2>/dev/null | wc -l || echo 0) found
- **Wildcard DNS:** $(cat subdomains/dns/wildcard_info.txt 2>/dev/null || echo "Not checked")
- **Zone Transfer:** $(ls subdomains/dns/zone_transfer_*.txt 2>/dev/null | wc -l || echo 0) attempts

### Source Breakdown
$(for file in subdomains/passive/*.txt; do
    if [ -f "$file" ]; then
        basename "$file" .txt | tr '[:lower:]' '[:upper:]' | sed 's/_/ /g'
        echo ": $(wc -l < "$file") subdomains"
    fi
done 2>/dev/null)

## 📁 Files Generated
- **subdomains/final_subdomains.txt** - All unique subdomains
- **subdomains/live_subdomains.txt** - DNS-resolved subdomains
- **subdomains/resolved_subdomains.txt** - Subdomains with IP addresses
- **subdomains/passive/** - Passive enumeration results
- **subdomains/active/** - Active enumeration results
- **subdomains/certificate/** - Certificate transparency results
- **subdomains/dns/** - DNS-related findings

## 🚀 Next Steps
1. **Port Scanning** - Scan live subdomains for open ports
2. **Web Technology Detection** - Identify web technologies
3. **Content Discovery** - Find hidden directories and files
4. **Vulnerability Assessment** - Test for security issues
5. **Manual Review** - Investigate interesting subdomains

## 🎯 High-Priority Targets
Based on naming patterns, these subdomains should be prioritized:
\`\`\`
$(grep -E "(admin|api|dev|test|staging|internal|vpn|mail)" subdomains/live_subdomains.txt 2>/dev/null | head -15 || echo "None identified")
\`\`\`

---
**Note:** Always ensure you have proper authorization before testing these subdomains.
EOF

    echo -e "${GREEN}✅ Comprehensive report generated: subdomain_enumeration_report.md${NC}"
}

# Main execution function
main() {
    start_time=$(date +%s)
    
    echo -e "${PURPLE}🚀 Starting Multi-Source Subdomain Enumeration${NC}"
    
    passive_enumeration
    active_enumeration
    dns_zone_transfer
    certificate_transparency
    social_code_search
    advanced_dns_techniques
    subdomain_validation
    generate_subdomain_report
    
    end_time=$(date +%s)
    execution_time=$((end_time - start_time))
    
    echo -e "${GREEN}🎉 Multi-Source Subdomain Enumeration Completed!${NC}"
    echo -e "${GREEN}⏱️  Total Execution Time: ${execution_time} seconds${NC}"
    echo -e "${GREEN}📊 Final Results: $(wc -l < subdomains/final_subdomains.txt) total, $(wc -l < subdomains/live_subdomains.txt 2>/dev/null || echo 0) live${NC}"
    echo -e "${GREEN}📄 Check 'subdomain_enumeration_report.md' for detailed analysis${NC}"
    
    # Show top findings
    echo -e "${YELLOW}🎯 Top 10 Live Subdomains:${NC}"
    head -10 subdomains/live_subdomains.txt 2>/dev/null || echo "No live subdomains found"
}

# Execute main function
main