#!/bin/bash
# 🌐 Web Technology Stack Analysis & Version Detection - Elite Bug Bounty
# Bhai, yeh script tumhe complete web technology fingerprinting dega

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

TARGET=$1
if [ -z "$TARGET" ]; then
    echo -e "${RED}Usage: ./web_tech_analysis.sh target.com${NC}"
    echo -e "${RED}       ./web_tech_analysis.sh http_services.txt${NC}"
    exit 1
fi

echo -e "${GREEN}🌐 Web Technology Stack Analysis for $TARGET${NC}"
mkdir -p $TARGET/web_tech/{detection,headers,content,cms,frameworks,vulnerabilities}
cd $TARGET

# Function: Prepare target URLs
prepare_targets() {
    echo -e "${BLUE}🎯 Phase 1: Target Preparation${NC}"
    
    # Determine input type
    if [ -f "$TARGET" ]; then
        # File input
        cp "$TARGET" web_tech/target_urls.txt
        echo -e "${YELLOW}[+] Using URL list from file: $TARGET${NC}"
    elif [ -f "ports/services/http_services.txt" ]; then
        # Use discovered HTTP services
        while read service; do
            if [ ! -z "$service" ]; then
                target=$(echo $service | cut -d':' -f1)
                port=$(echo $service | cut -d':' -f2)
                
                # Add HTTP URLs
                echo "http://$target:$port" >> web_tech/target_urls.txt
                
                # Add HTTPS for common SSL ports
                if [[ "$port" =~ ^(443|8443)$ ]]; then
                    echo "https://$target:$port" >> web_tech/target_urls.txt
                fi
            fi
        done < ports/services/http_services.txt
        echo -e "${YELLOW}[+] Using discovered HTTP services${NC}"
    else
        # Single target
        echo "http://$TARGET" > web_tech/target_urls.txt
        echo "https://$TARGET" >> web_tech/target_urls.txt
        echo -e "${YELLOW}[+] Using single target: $TARGET${NC}"
    fi
    
    # Remove duplicates and validate URLs
    sort -u web_tech/target_urls.txt -o web_tech/target_urls.txt
    
    # Test URL accessibility
    echo -e "${YELLOW}[+] Testing URL accessibility...${NC}"
    while read url; do
        if [ ! -z "$url" ]; then
            if curl -s -m 10 -I "$url" >/dev/null 2>&1; then
                echo "$url" >> web_tech/live_urls.txt
            fi
        fi
    done < web_tech/target_urls.txt
    
    if [ -f "web_tech/live_urls.txt" ]; then
        echo -e "${GREEN}✅ Live URLs: $(wc -l < web_tech/live_urls.txt)${NC}"
    else
        echo -e "${RED}❌ No live URLs found${NC}"
        exit 1
    fi
}

# Function: HTTP header analysis
header_analysis() {
    echo -e "${BLUE}🔍 Phase 2: HTTP Header Analysis${NC}"
    
    echo -e "${YELLOW}[+] Collecting HTTP headers...${NC}"
    
    while read url; do
        if [ ! -z "$url" ]; then
            echo "Analyzing headers for: $url"
            
            # Get headers with curl
            curl -s -I -L -m 15 "$url" > "web_tech/headers/$(echo $url | sed 's|https\?://||g' | tr '/' '_' | tr ':' '_')_headers.txt" 2>/dev/null
            
            # Get headers with specific user agents
            curl -s -I -L -m 10 -H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" "$url" > "web_tech/headers/$(echo $url | sed 's|https\?://||g' | tr '/' '_' | tr ':' '_')_headers_chrome.txt" 2>/dev/null
            
            # Extract technology indicators from headers
            curl -s -I -L -m 10 "$url" 2>/dev/null | grep -i -E "server|x-powered-by|x-generator|x-drupal-cache|x-framework|x-version|x-aspnet-version|x-runtime" >> web_tech/detection/header_technologies.txt
        fi
    done < web_tech/live_urls.txt
    
    echo -e "${GREEN}✅ HTTP header analysis completed${NC}"
}

# Function: Content-based technology detection
content_analysis() {
    echo -e "${BLUE}🔍 Phase 3: Content-Based Technology Detection${NC}"
    
    echo -e "${YELLOW}[+] Downloading and analyzing web content...${NC}"
    
    while read url; do
        if [ ! -z "$url" ]; then
            echo "Content analysis for: $url"
            
            # Download page content
            filename=$(echo $url | sed 's|https\?://||g' | tr '/' '_' | tr ':' '_')
            curl -s -L -m 15 "$url" > "web_tech/content/${filename}_content.html" 2>/dev/null
            
            # Extract technology indicators from content
            if [ -f "web_tech/content/${filename}_content.html" ]; then
                # CMS Detection
                grep -i -E "wordpress|wp-content|wp-includes|drupal|joomla|magento|shopify|woocommerce" "web_tech/content/${filename}_content.html" >> web_tech/detection/cms_indicators.txt 2>/dev/null
                
                # Framework Detection
                grep -i -E "laravel|django|rails|express|angular|react|vue|bootstrap|jquery|foundation" "web_tech/content/${filename}_content.html" >> web_tech/detection/framework_indicators.txt 2>/dev/null
                
                # JavaScript Libraries
                grep -o -E "jquery-[0-9]+\.[0-9]+\.[0-9]+|bootstrap-[0-9]+\.[0-9]+\.[0-9]+|angular-[0-9]+\.[0-9]+\.[0-9]+" "web_tech/content/${filename}_content.html" >> web_tech/detection/js_libraries.txt 2>/dev/null
                
                # Meta tags analysis
                grep -i -E "<meta.*generator|<meta.*author|<meta.*description" "web_tech/content/${filename}_content.html" >> web_tech/detection/meta_tags.txt 2>/dev/null
                
                # Extract version numbers
                grep -o -E "version[\"'\s]*[:=][\"'\s]*[0-9]+\.[0-9]+\.[0-9]+" "web_tech/content/${filename}_content.html" >> web_tech/detection/version_numbers.txt 2>/dev/null
            fi
        fi
    done < web_tech/live_urls.txt
    
    echo -e "${GREEN}✅ Content analysis completed${NC}"
}

# Function: Advanced technology detection with multiple tools
advanced_tech_detection() {
    echo -e "${BLUE}🔍 Phase 4: Advanced Technology Detection${NC}"
    
    # Method 1: Whatweb
    echo -e "${YELLOW}[1/5] Whatweb technology detection...${NC}"
    if command -v whatweb &> /dev/null; then
        whatweb -i web_tech/live_urls.txt --log-brief=web_tech/detection/whatweb_results.txt --log-verbose=web_tech/detection/whatweb_verbose.txt
        echo -e "${GREEN}✅ Whatweb analysis completed${NC}"
    else
        echo -e "${RED}❌ Whatweb not found${NC}"
    fi
    
    # Method 2: Wappalyzer (if available)
    echo -e "${YELLOW}[2/5] Wappalyzer-style detection...${NC}"
    
    # Create custom technology signatures
    cat > web_tech/detection/tech_signatures.txt << 'EOF'
# CMS Signatures
WordPress:/wp-content/,/wp-includes/,wp-json
Drupal:/sites/default/,drupal.js,Drupal.settings
Joomla:/components/,/modules/,joomla
Magento:/skin/frontend/,Mage.Cookies
Shopify:cdn.shopify.com,shopify-analytics
PrestaShop:/modules/,prestashop

# Frameworks
Laravel:laravel_session,/vendor/laravel/
Django:csrfmiddlewaretoken,django
Ruby on Rails:authenticity_token,rails
Express.js:express,X-Powered-By: Express
ASP.NET:__VIEWSTATE,aspnet_client
PHP:PHPSESSID,X-Powered-By: PHP

# JavaScript Frameworks
React:react,ReactDOM
Angular:ng-version,angular
Vue.js:vue.js,Vue.config
jQuery:jquery,jQuery

# Web Servers
Apache:Server: Apache,apache
Nginx:Server: nginx,nginx
IIS:Server: Microsoft-IIS,IIS
Cloudflare:Server: cloudflare,cf-ray
EOF
    
    # Apply signatures to detect technologies
    while read url; do
        if [ ! -z "$url" ]; then
            filename=$(echo $url | sed 's|https\?://||g' | tr '/' '_' | tr ':' '_')
            
            if [ -f "web_tech/content/${filename}_content.html" ] && [ -f "web_tech/headers/${filename}_headers.txt" ]; then
                echo "Signature matching for: $url"
                
                # Combine headers and content for analysis
                cat "web_tech/headers/${filename}_headers.txt" "web_tech/content/${filename}_content.html" > "web_tech/detection/combined_${filename}.txt"
                
                # Match signatures
                while IFS=: read tech signatures; do
                    if [ ! -z "$tech" ] && [ ! -z "$signatures" ]; then
                        IFS=',' read -ra SIGS <<< "$signatures"
                        for sig in "${SIGS[@]}"; do
                            if grep -q "$sig" "web_tech/detection/combined_${filename}.txt" 2>/dev/null; then
                                echo "$url:$tech:$sig" >> web_tech/detection/signature_matches.txt
                                break
                            fi
                        done
                    fi
                done < <(grep -v "^#" web_tech/detection/tech_signatures.txt)
            fi
        fi
    done < web_tech/live_urls.txt
    
    echo -e "${GREEN}✅ Signature-based detection completed${NC}"
    
    # Method 3: Nuclei technology detection
    echo -e "${YELLOW}[3/5] Nuclei technology detection...${NC}"
    if command -v nuclei &> /dev/null; then
        nuclei -l web_tech/live_urls.txt -t ~/nuclei-templates/technologies/ -o web_tech/detection/nuclei_tech.txt -silent
        echo -e "${GREEN}✅ Nuclei technology detection completed${NC}"
    else
        echo -e "${RED}❌ Nuclei not found${NC}"
    fi
    
    # Method 4: Custom JavaScript analysis
    echo -e "${YELLOW}[4/5] JavaScript library analysis...${NC}"
    
    while read url; do
        if [ ! -z "$url" ]; then
            echo "JS analysis for: $url"
            
            # Find JavaScript files
            filename=$(echo $url | sed 's|https\?://||g' | tr '/' '_' | tr ':' '_')
            
            if [ -f "web_tech/content/${filename}_content.html" ]; then
                # Extract JS file URLs
                grep -o -E 'src="[^"]*\.js[^"]*"' "web_tech/content/${filename}_content.html" | sed 's/src="//g; s/"//g' > "web_tech/detection/js_files_${filename}.txt"
                
                # Download and analyze JS files
                while read js_url; do
                    if [ ! -z "$js_url" ]; then
                        # Handle relative URLs
                        if [[ $js_url == /* ]]; then
                            js_full_url="${url}${js_url}"
                        elif [[ $js_url == http* ]]; then
                            js_full_url="$js_url"
                        else
                            js_full_url="${url}/${js_url}"
                        fi
                        
                        # Download JS file
                        js_filename=$(echo $js_url | sed 's|.*/||g' | tr '?' '_')
                        curl -s -m 10 "$js_full_url" > "web_tech/detection/js_${js_filename}" 2>/dev/null
                        
                        # Analyze JS file for libraries and versions
                        if [ -f "web_tech/detection/js_${js_filename}" ]; then
                            grep -o -E "(jQuery|React|Angular|Vue|Bootstrap|Foundation|Lodash|Moment|D3).*[0-9]+\.[0-9]+\.[0-9]+" "web_tech/detection/js_${js_filename}" >> web_tech/detection/js_library_versions.txt 2>/dev/null
                        fi
                    fi
                done < "web_tech/detection/js_files_${filename}.txt"
            fi
        fi
    done < web_tech/live_urls.txt
    
    echo -e "${GREEN}✅ JavaScript analysis completed${NC}"
    
    # Method 5: CSS framework detection
    echo -e "${YELLOW}[5/5] CSS framework detection...${NC}"
    
    while read url; do
        if [ ! -z "$url" ]; then
            filename=$(echo $url | sed 's|https\?://||g' | tr '/' '_' | tr ':' '_')
            
            if [ -f "web_tech/content/${filename}_content.html" ]; then
                echo "CSS analysis for: $url"
                
                # Extract CSS file URLs
                grep -o -E 'href="[^"]*\.css[^"]*"' "web_tech/content/${filename}_content.html" | sed 's/href="//g; s/"//g' > "web_tech/detection/css_files_${filename}.txt"
                
                # Analyze CSS content for frameworks
                grep -i -E "bootstrap|foundation|bulma|materialize|semantic|tailwind" "web_tech/content/${filename}_content.html" >> web_tech/detection/css_frameworks.txt 2>/dev/null
                
                # Download and analyze CSS files
                while read css_url; do
                    if [ ! -z "$css_url" ]; then
                        # Handle relative URLs
                        if [[ $css_url == /* ]]; then
                            css_full_url="${url}${css_url}"
                        elif [[ $css_url == http* ]]; then
                            css_full_url="$css_url"
                        else
                            css_full_url="${url}/${css_url}"
                        fi
                        
                        # Check CSS file headers for framework info
                        curl -s -I -m 5 "$css_full_url" | grep -i -E "bootstrap|foundation|bulma" >> web_tech/detection/css_framework_headers.txt 2>/dev/null
                    fi
                done < "web_tech/detection/css_files_${filename}.txt"
            fi
        fi
    done < web_tech/live_urls.txt
    
    echo -e "${GREEN}✅ CSS framework detection completed${NC}"
}

# Function: CMS and framework specific analysis
cms_framework_analysis() {
    echo -e "${BLUE}🔍 Phase 5: CMS & Framework Specific Analysis${NC}"
    
    # WordPress specific analysis
    echo -e "${YELLOW}[+] WordPress specific analysis...${NC}"
    while read url; do
        if [ ! -z "$url" ]; then
            if curl -s -m 10 "$url/wp-admin/" | grep -q "wordpress\|wp-login" 2>/dev/null; then
                echo "$url" >> web_tech/cms/wordpress_sites.txt
                
                # WordPress version detection
                wp_version=$(curl -s -m 10 "$url/wp-includes/version.php" | grep -o "wp_version = '[^']*'" | cut -d"'" -f2)
                if [ ! -z "$wp_version" ]; then
                    echo "$url:$wp_version" >> web_tech/cms/wordpress_versions.txt
                fi
                
                # WordPress plugins detection
                curl -s -m 10 "$url" | grep -o "/wp-content/plugins/[^/]*" | sort -u >> web_tech/cms/wordpress_plugins_${url//[^a-zA-Z0-9]/_}.txt
                
                # WordPress themes detection
                curl -s -m 10 "$url" | grep -o "/wp-content/themes/[^/]*" | sort -u >> web_tech/cms/wordpress_themes_${url//[^a-zA-Z0-9]/_}.txt
            fi
        fi
    done < web_tech/live_urls.txt
    
    # Drupal specific analysis
    echo -e "${YELLOW}[+] Drupal specific analysis...${NC}"
    while read url; do
        if [ ! -z "$url" ]; then
            if curl -s -m 10 "$url" | grep -q "drupal\|Drupal.settings" 2>/dev/null; then
                echo "$url" >> web_tech/cms/drupal_sites.txt
                
                # Drupal version detection
                drupal_version=$(curl -s -m 10 "$url/CHANGELOG.txt" | head -1 | grep -o "[0-9]\+\.[0-9]\+")
                if [ ! -z "$drupal_version" ]; then
                    echo "$url:$drupal_version" >> web_tech/cms/drupal_versions.txt
                fi
                
                # Drupal modules detection
                curl -s -m 10 "$url" | grep -o "/sites/all/modules/[^/]*" | sort -u >> web_tech/cms/drupal_modules_${url//[^a-zA-Z0-9]/_}.txt
            fi
        fi
    done < web_tech/live_urls.txt
    
    # Joomla specific analysis
    echo -e "${YELLOW}[+] Joomla specific analysis...${NC}"
    while read url; do
        if [ ! -z "$url" ]; then
            if curl -s -m 10 "$url" | grep -q "joomla\|/administrator/" 2>/dev/null; then
                echo "$url" >> web_tech/cms/joomla_sites.txt
                
                # Joomla version detection
                joomla_version=$(curl -s -m 10 "$url/administrator/manifests/files/joomla.xml" | grep -o "<version>[^<]*</version>" | sed 's/<[^>]*>//g')
                if [ ! -z "$joomla_version" ]; then
                    echo "$url:$joomla_version" >> web_tech/cms/joomla_versions.txt
                fi
            fi
        fi
    done < web_tech/live_urls.txt
    
    # Laravel specific analysis
    echo -e "${YELLOW}[+] Laravel specific analysis...${NC}"
    while read url; do
        if [ ! -z "$url" ]; then
            if curl -s -I -m 10 "$url" | grep -q "laravel_session" 2>/dev/null; then
                echo "$url" >> web_tech/frameworks/laravel_sites.txt
                
                # Laravel debug mode check
                if curl -s -m 10 "$url" | grep -q "Laravel\|Whoops" 2>/dev/null; then
                    echo "$url:debug_mode_enabled" >> web_tech/frameworks/laravel_debug.txt
                fi
            fi
        fi
    done < web_tech/live_urls.txt
    
    echo -e "${GREEN}✅ CMS & Framework analysis completed${NC}"
}

# Function: Version vulnerability analysis
version_vulnerability_analysis() {
    echo -e "${BLUE}🚨 Phase 6: Version Vulnerability Analysis${NC}"
    
    echo -e "${YELLOW}[+] Analyzing detected versions for vulnerabilities...${NC}"
    
    # Create vulnerability database (simplified)
    cat > web_tech/vulnerabilities/vuln_db.txt << 'EOF'
WordPress:4.9.0:CVE-2017-1001000
WordPress:5.0.0:CVE-2019-8942
WordPress:5.2.0:CVE-2019-8943
Drupal:7.0:CVE-2018-7600
Drupal:8.5.0:CVE-2018-7602
Joomla:3.4.0:CVE-2015-8562
jQuery:1.6.0:CVE-2011-4969
jQuery:3.0.0:CVE-2020-11022
Bootstrap:3.0.0:XSS-2018-14040
Laravel:5.5.0:CVE-2018-15133
EOF
    
    # Check WordPress versions
    if [ -f "web_tech/cms/wordpress_versions.txt" ]; then
        while IFS=: read url version; do
            if [ ! -z "$version" ]; then
                echo "Checking WordPress $version for vulnerabilities..."
                grep "WordPress:$version" web_tech/vulnerabilities/vuln_db.txt >> web_tech/vulnerabilities/wordpress_vulns.txt 2>/dev/null
            fi
        done < web_tech/cms/wordpress_versions.txt
    fi
    
    # Check Drupal versions
    if [ -f "web_tech/cms/drupal_versions.txt" ]; then
        while IFS=: read url version; do
            if [ ! -z "$version" ]; then
                echo "Checking Drupal $version for vulnerabilities..."
                grep "Drupal:$version" web_tech/vulnerabilities/vuln_db.txt >> web_tech/vulnerabilities/drupal_vulns.txt 2>/dev/null
            fi
        done < web_tech/cms/drupal_versions.txt
    fi
    
    # Check JavaScript library versions
    if [ -f "web_tech/detection/js_library_versions.txt" ]; then
        while read library_version; do
            if [ ! -z "$library_version" ]; then
                library=$(echo $library_version | cut -d' ' -f1)
                version=$(echo $library_version | grep -o "[0-9]\+\.[0-9]\+\.[0-9]\+")
                if [ ! -z "$library" ] && [ ! -z "$version" ]; then
                    echo "Checking $library $version for vulnerabilities..."
                    grep "$library:$version" web_tech/vulnerabilities/vuln_db.txt >> web_tech/vulnerabilities/js_vulns.txt 2>/dev/null
                fi
            fi
        done < web_tech/detection/js_library_versions.txt
    fi
    
    echo -e "${GREEN}✅ Version vulnerability analysis completed${NC}"
}

# Function: Generate comprehensive web technology report
generate_web_tech_report() {
    echo -e "${BLUE}📊 Generating Web Technology Analysis Report${NC}"
    
    # Calculate statistics
    total_urls=$(wc -l < web_tech/live_urls.txt 2>/dev/null || echo 0)
    wordpress_sites=$(wc -l < web_tech/cms/wordpress_sites.txt 2>/dev/null || echo 0)
    drupal_sites=$(wc -l < web_tech/cms/drupal_sites.txt 2>/dev/null || echo 0)
    joomla_sites=$(wc -l < web_tech/cms/joomla_sites.txt 2>/dev/null || echo 0)
    laravel_sites=$(wc -l < web_tech/frameworks/laravel_sites.txt 2>/dev/null || echo 0)
    
    cat > web_technology_analysis_report.md << EOF
# 🌐 Web Technology Stack Analysis Report
**Target:** $TARGET
**Date:** $(date)
**Analysis Duration:** $SECONDS seconds

## 📊 Executive Summary
- **Total URLs Analyzed:** $total_urls
- **WordPress Sites:** $wordpress_sites
- **Drupal Sites:** $drupal_sites
- **Joomla Sites:** $joomla_sites
- **Laravel Applications:** $laravel_sites

## 🔍 Analysis Methodology

### Detection Methods Used
1. **HTTP Header Analysis** - Server and framework headers
2. **Content Analysis** - HTML source code examination
3. **Signature Matching** - Custom technology signatures
4. **Tool Integration** - Whatweb, Nuclei integration
5. **JavaScript Analysis** - Library and framework detection
6. **CSS Framework Detection** - Frontend framework identification
7. **CMS-Specific Analysis** - Targeted CMS fingerprinting

## 🎯 Technology Stack Overview

### Web Servers Detected
\`\`\`
$(grep -i "server:" web_tech/headers/*_headers.txt 2>/dev/null | cut -d':' -f3- | sort | uniq -c | sort -nr | head -10 || echo "No web servers detected")
\`\`\`

### Programming Languages/Frameworks
\`\`\`
$(grep -i "x-powered-by:" web_tech/headers/*_headers.txt 2>/dev/null | cut -d':' -f3- | sort | uniq -c | sort -nr | head -10 || echo "No frameworks detected in headers")
\`\`\`

### Content Management Systems
\`\`\`
WordPress: $wordpress_sites sites
Drupal: $drupal_sites sites  
Joomla: $joomla_sites sites
\`\`\`

## 🔍 Detailed Findings

### WordPress Analysis
$(if [ -f "web_tech/cms/wordpress_sites.txt" ]; then
    echo "#### WordPress Sites Identified"
    echo "\`\`\`"
    cat web_tech/cms/wordpress_sites.txt 2>/dev/null | head -10
    echo "\`\`\`"
    
    if [ -f "web_tech/cms/wordpress_versions.txt" ]; then
        echo "#### WordPress Versions"
        echo "\`\`\`"
        cat web_tech/cms/wordpress_versions.txt 2>/dev/null
        echo "\`\`\`"
    fi
    
    echo "#### Common WordPress Plugins"
    echo "\`\`\`"
    find web_tech/cms -name "wordpress_plugins_*" -exec cat {} \; 2>/dev/null | sort | uniq -c | sort -nr | head -10
    echo "\`\`\`"
else
    echo "No WordPress sites detected"
fi)

### Drupal Analysis
$(if [ -f "web_tech/cms/drupal_sites.txt" ]; then
    echo "#### Drupal Sites Identified"
    echo "\`\`\`"
    cat web_tech/cms/drupal_sites.txt 2>/dev/null
    echo "\`\`\`"
    
    if [ -f "web_tech/cms/drupal_versions.txt" ]; then
        echo "#### Drupal Versions"
        echo "\`\`\`"
        cat web_tech/cms/drupal_versions.txt 2>/dev/null
        echo "\`\`\`"
    fi
else
    echo "No Drupal sites detected"
fi)

### JavaScript Libraries & Frameworks
\`\`\`
$(cat web_tech/detection/js_library_versions.txt 2>/dev/null | sort | uniq -c | sort -nr | head -15 || echo "No JavaScript libraries detected")
\`\`\`

### CSS Frameworks
\`\`\`
$(cat web_tech/detection/css_frameworks.txt 2>/dev/null | sort | uniq -c | sort -nr | head -10 || echo "No CSS frameworks detected")
\`\`\`

## 🚨 Security Findings

### Potential Vulnerabilities
$(if [ -f "web_tech/vulnerabilities/wordpress_vulns.txt" ] || [ -f "web_tech/vulnerabilities/drupal_vulns.txt" ] || [ -f "web_tech/vulnerabilities/js_vulns.txt" ]; then
    echo "#### WordPress Vulnerabilities"
    echo "\`\`\`"
    cat web_tech/vulnerabilities/wordpress_vulns.txt 2>/dev/null || echo "None found"
    echo "\`\`\`"
    
    echo "#### Drupal Vulnerabilities"
    echo "\`\`\`"
    cat web_tech/vulnerabilities/drupal_vulns.txt 2>/dev/null || echo "None found"
    echo "\`\`\`"
    
    echo "#### JavaScript Library Vulnerabilities"
    echo "\`\`\`"
    cat web_tech/vulnerabilities/js_vulns.txt 2>/dev/null || echo "None found"
    echo "\`\`\`"
else
    echo "No known vulnerabilities detected in analyzed versions"
fi)

### Debug Mode Detection
$(if [ -f "web_tech/frameworks/laravel_debug.txt" ]; then
    echo "#### Laravel Debug Mode Enabled"
    echo "\`\`\`"
    cat web_tech/frameworks/laravel_debug.txt 2>/dev/null
    echo "\`\`\`"
else
    echo "No debug modes detected"
fi)

### Interesting Headers
\`\`\`
$(grep -h -i -E "x-debug|x-trace|x-forwarded|x-real-ip|x-original" web_tech/headers/*_headers.txt 2>/dev/null | head -10 || echo "No interesting headers found")
\`\`\`

## 🎯 High-Priority Targets

### Administrative Interfaces
\`\`\`
$(find web_tech/content -name "*content.html" -exec grep -l -i "admin\|administrator\|dashboard\|panel" {} \; 2>/dev/null | head -5 || echo "No admin interfaces detected in content")
\`\`\`

### Development/Debug Environments
\`\`\`
$(grep -l -i -E "debug|development|staging|test" web_tech/content/*_content.html 2>/dev/null | head -5 || echo "No development environments detected")
\`\`\`

### Outdated Software
$(if [ -f "web_tech/vulnerabilities/wordpress_vulns.txt" ] || [ -f "web_tech/vulnerabilities/drupal_vulns.txt" ]; then
    echo "\`\`\`"
    echo "WordPress vulnerabilities: $(wc -l < web_tech/vulnerabilities/wordpress_vulns.txt 2>/dev/null || echo 0)"
    echo "Drupal vulnerabilities: $(wc -l < web_tech/vulnerabilities/drupal_vulns.txt 2>/dev/null || echo 0)"
    echo "JavaScript vulnerabilities: $(wc -l < web_tech/vulnerabilities/js_vulns.txt 2>/dev/null || echo 0)"
    echo "\`\`\`"
else
    echo "No outdated software with known vulnerabilities detected"
fi)

## 🛠️ Technical Details

### Signature Matches
$(if [ -f "web_tech/detection/signature_matches.txt" ]; then
    
    echo "\`\`\`"
    cat web_tech/detection/signature_matches.txt 2>/dev/null | head -20
    echo "\`\`\`"
else
    echo "No signature matches recorded"
fi)

### Whatweb Results
$(if [ -f "web_tech/detection/whatweb_results.txt" ]; then
    echo "\`\`\`"
    head -20 web_tech/detection/whatweb_results.txt 2>/dev/null
    echo "\`\`\`"
else
    echo "Whatweb results not available"
fi)

### Nuclei Technology Detection
$(if [ -f "web_tech/detection/nuclei_tech.txt" ]; then
    echo "\`\`\`"
    cat web_tech/detection/nuclei_tech.txt 2>/dev/null
    echo "\`\`\`"
else
    echo "Nuclei technology detection not available"
fi)

## 📁 Files Generated
- **web_tech/headers/** - HTTP header analysis results
- **web_tech/content/** - Downloaded web content
- **web_tech/detection/** - Technology detection results
- **web_tech/cms/** - CMS-specific analysis
- **web_tech/frameworks/** - Framework analysis
- **web_tech/vulnerabilities/** - Vulnerability analysis

## 🚀 Recommended Next Steps

### Immediate Actions
1. **Update Outdated Software** - Address identified vulnerable versions
2. **Disable Debug Modes** - Turn off development/debug features in production
3. **Review Admin Interfaces** - Test authentication and access controls
4. **Analyze Custom Applications** - Focus on non-standard implementations

### Security Testing Priorities
1. **CMS-Specific Tests** - WordPress/Drupal/Joomla vulnerability testing
2. **Framework Exploitation** - Laravel, Django, Rails specific attacks
3. **JavaScript Library Exploits** - Client-side vulnerability testing
4. **Version-Specific CVEs** - Test for known vulnerabilities in detected versions

### Bug Bounty Focus Areas
1. **Admin Panel Access** - Authentication bypass attempts
2. **Plugin/Module Vulnerabilities** - Test identified plugins for issues
3. **Framework-Specific Bugs** - Look for framework-related vulnerabilities
4. **Version Disclosure** - Information disclosure through version detection

## ⚡ Quick Testing Commands

### WordPress Testing
\`\`\`bash
# WordPress vulnerability scanner
wpscan --url http://target.com --enumerate p,t,u

# WordPress version detection
curl -s http://target.com/wp-includes/version.php
\`\`\`

### Drupal Testing
\`\`\`bash
# Drupal version detection
curl -s http://target.com/CHANGELOG.txt | head -1

# Drupal vulnerability testing
droopescan scan drupal -u http://target.com
\`\`\`

### General CMS Testing
\`\`\`bash
# CMSmap for multiple CMS detection
cmsmap http://target.com

# Nikto web vulnerability scanner
nikto -h http://target.com
\`\`\`

---
**Note:** Always ensure proper authorization before conducting security testing.
EOF

    echo -e "${GREEN}✅ Web technology analysis report generated: web_technology_analysis_report.md${NC}"
}

# Main execution function
main() {
    start_time=$(date +%s)
    
    echo -e "${PURPLE}🚀 Starting Web Technology Stack Analysis${NC}"
    
    prepare_targets
    header_analysis
    content_analysis
    advanced_tech_detection
    cms_framework_analysis
    version_vulnerability_analysis
    generate_web_tech_report
    
    end_time=$(date +%s)
    execution_time=$((end_time - start_time))
    
    echo -e "${GREEN}🎉 Web Technology Analysis Completed!${NC}"
    echo -e "${GREEN}⏱️  Total Execution Time: ${execution_time} seconds${NC}"
    echo -e "${GREEN}📊 Results: $(wc -l < web_tech/live_urls.txt) URLs analyzed${NC}"
    echo -e "${GREEN}📄 Check 'web_technology_analysis_report.md' for detailed results${NC}"
    
    # Show quick summary
    echo -e "${YELLOW}🎯 Quick Summary:${NC}"
    echo -e "   🌐 Live URLs: $(wc -l < web_tech/live_urls.txt 2>/dev/null || echo 0)"
    echo -e "   📝 WordPress: $(wc -l < web_tech/cms/wordpress_sites.txt 2>/dev/null || echo 0) sites"
    echo -e "   🔷 Drupal: $(wc -l < web_tech/cms/drupal_sites.txt 2>/dev/null || echo 0) sites"
    echo -e "   🟠 Joomla: $(wc -l < web_tech/cms/joomla_sites.txt 2>/dev/null || echo 0) sites"
    echo -e "   🔴 Laravel: $(wc -l < web_tech/frameworks/laravel_sites.txt 2>/dev/null || echo 0) sites"
    echo -e "   🚨 Vulnerabilities: $(find web_tech/vulnerabilities -name "*_vulns.txt" -exec wc -l {} + 2>/dev/null | tail -1 | awk '{print $1}' || echo 0)"
}

# Execute main function
main